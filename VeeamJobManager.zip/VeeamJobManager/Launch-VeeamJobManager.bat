@echo off
:: ============================================================
::  Launch-VeeamJobManager.bat
:: ============================================================

set SCRIPT=%~dp0VeeamJobManager.ps1
set LOG=%~dp0launch.log

:: Re-launch elevated if needed
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process 'cmd' -ArgumentList '/c \"%~f0\"' -Verb RunAs -Wait"
    exit /b
)

echo [%date% %time%] Started > "%LOG%"

:: Locate pwsh.exe
where pwsh >nul 2>&1
if %errorlevel% equ 0 (
    set PWSH=pwsh
) else if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" (
    set PWSH="%ProgramFiles%\PowerShell\7\pwsh.exe"
) else (
    echo [ERROR] PowerShell 7 not found >> "%LOG%"
    echo [ERROR] PowerShell 7 not found
    cmd /k
    exit /b 1
)

echo Using: %PWSH% >> "%LOG%"
echo Script: %SCRIPT% >> "%LOG%"

%PWSH% -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"

echo.
echo Script exited with code %errorlevel%
cmd /k
