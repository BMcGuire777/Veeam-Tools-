# Shared state, column-width constants, and throttle-safe helper for VBR v13.

$script:VBRServer = "localhost"
$script:ChangeLog = [System.Collections.Generic.List[string]]::new()

$COL_SETTING = 26
$COL_VAL     = 32
$COL_STATUS  = 10

# ============================================================
#  Invoke-VeeamSafe  -  throttle-safe VBR cmdlet wrapper
# ============================================================
# VBR v13 routes every PowerShell cmdlet through the same service layer
# used by the REST API and Web UI, which enforces request throttling.
# Any VBR call inside a tight loop (mass edits, bulk reports, etc.)
# can return TooManyRequests (HTTP 429).
#
# Usage:
#   $result = Invoke-VeeamSafe { Get-VBRJob }
#   $jobs   = Invoke-VeeamSafe { Get-VBRBackup -Job $job } -Retry 8
#
# Guidelines:
#   - Prefetch once before loops; filter in-memory — do NOT call inside loops.
#   - For very large environments increase -Retry and -DelaySeconds.
#   - The helper uses linear backoff; switch to exponential if needed.
function Invoke-VeeamSafe {
    param (
        [Parameter(Mandatory = $true)]
        [scriptblock]$Command,

        # Maximum number of retry attempts on TooManyRequests
        [int]$Retry = 5,

        # Base delay in seconds between retries (linear: Delay * attempt#)
        [int]$DelaySeconds = 2
    )

    for ($i = 1; $i -le $Retry; $i++) {
        try {
            return & $Command
        } catch {
            $msg = $_.Exception.Message
            if ($msg -match 'TooManyRequests|429') {
                $wait = $DelaySeconds * $i
                Write-Warn "VBR throttle hit (attempt $i/$Retry) — waiting ${wait}s..."
                Start-Sleep -Seconds $wait
            } else {
                # Not a throttle error — re-throw immediately
                throw
            }
        }
    }

    throw "Invoke-VeeamSafe: VBR API throttling not cleared after $Retry attempts."
}
