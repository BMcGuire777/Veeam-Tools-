function Initialize-VBRConnection {
    Write-Header "Connecting to Veeam VBR"

    # VBR v13 module is PS7-native — do NOT use -UseWindowsPowerShell (that shim runs
    # the module in PS5.1 which the module explicitly forbids).
    # Set TLS before loading to avoid SSslOptions type-initializer errors.
    if (-not (Get-Module -Name "Veeam.Backup.PowerShell" -ErrorAction SilentlyContinue)) {
        try {
            # TLS setup — required for Veeam's SSL initialisation in PS7
            [System.Net.ServicePointManager]::SecurityProtocol =
                [System.Net.SecurityProtocolType]::Tls12 -bor
                [System.Net.SecurityProtocolType]::Tls13

            $modulePath = "C:\Program Files\Veeam\Backup and Replication\Console\Veeam.Backup.PowerShell\Veeam.Backup.PowerShell.psd1"
            if (Test-Path $modulePath) {
                Import-Module $modulePath -DisableNameChecking -SkipEditionCheck -ErrorAction Stop
            } else {
                Import-Module Veeam.Backup.PowerShell -DisableNameChecking -SkipEditionCheck -ErrorAction Stop
            }
            Write-Success "Loaded Veeam.Backup.PowerShell module."
        } catch {
            Write-Err "Could not load Veeam.Backup.PowerShell module."
            Write-Err "Ensure VBR v13 console is installed and this session is running as Administrator."
            Write-Err "Error: $_"
            Write-Warn "If you see an SSslOptions error, ensure the Veeam Backup Service is running:"
            Write-Warn "  Get-Service VeeamBackupSvc | Start-Service"
            exit 1
        }
    }

    # Prompt for server
    $inputServer = (Read-Host "  VBR Server IP or hostname").Trim()
    if ($inputServer -ne "") { $script:VBRServer = $inputServer }

    if (-not $script:VBRServer) {
        Write-Err "No VBR server specified."
        exit 1
    }

    # Prompt for credentials — stored as PSCredential (SecureString) in memory only
    Write-Info "Enter credentials for $script:VBRServer"
    $script:VBRCredential = Get-Credential -Message "VBR credentials for $script:VBRServer"

    if (-not $script:VBRCredential) {
        Write-Err "No credentials provided."
        exit 1
    }

    try {
        Disconnect-VBRServer -ErrorAction SilentlyContinue | Out-Null
        Connect-VBRServer -Server $script:VBRServer -Credential $script:VBRCredential -ErrorAction Stop
        Write-Success "Connected to: $script:VBRServer"
    } catch {
        Write-Err "Connection failed: $_"
        Write-Warn "Check that VeeamBackupSvc is running on $script:VBRServer"
        Write-Warn "and your account has the Veeam Backup Administrator role."
        exit 1
    }
}
