function Invoke-MassEditRetention {
    Write-Header "Mass Edit: Retention (Restore Points)"

    $jobs = @(Select-MassEditTargetJobs)
    if ($jobs.Count -eq 0) { return }

    Write-Host ""
    do {
        $rawIn = Read-Host "  New restore point count for ALL selected jobs (1-999, 0 to cancel)"
        if ($rawIn -eq "0") { Write-Info "Cancelled."; return }
    } while ($rawIn -notmatch '^\d+$' -or [int]$rawIn -lt 1 -or [int]$rawIn -gt 999)
    $newRetain = [int]$rawIn

    $confirmed = Show-MassEditPreview -Jobs $jobs -SettingName "Restore Points" `
        -GetCurrent {
            param($Job)
            try {
                if ($Job.JobType -eq "BackupSync") { $Job.Options.GenerationPolicy.SimpleRetentionRestorePoints }
                else { $Job.Options.BackupStorageOptions.RetainCycles }
            } catch { "N/A" }
        } `
        -NewValue "$newRetain"

    if (-not $confirmed) { Write-Info "Aborted  - no changes made."; return }

    # ----- Phase 1: Disable all enabled jobs -----
    Write-Host ""
    Write-Info "Phase 1 of 3: Disabling enabled jobs..."
    $disabledJobs = [System.Collections.Generic.List[object]]::new()
    foreach ($job in $jobs) {
        $wasEnabled = $false
        try { $wasEnabled = $job.IsScheduleEnabled } catch {}
        if ($wasEnabled) {
            try {
                # Disable-VBRJob (not Disable-VBRJobSchedule) — we need the
                # full job disabled so VBR allows the retention change.
                Invoke-VeeamSafe { Disable-VBRJob -Job $job -ErrorAction Stop }
                $disabledJobs.Add($job)
                Write-Detail "Disabled : $($job.Name)"
            } catch {
                Write-Warn "Could not disable '$($job.Name)': $_"
            }
        }
    }

    # ----- Phase 2: Apply retention -----
    Write-Host ""
    Write-Info "Phase 2 of 3: Applying retention to all jobs..."
    $results = [System.Collections.Generic.List[hashtable]]::new()
    foreach ($job in $jobs) {
        $before = try {
            if ($job.JobType -eq "BackupSync") { "$($job.Options.GenerationPolicy.SimpleRetentionRestorePoints)" }
            else { "$($job.Options.BackupStorageOptions.RetainCycles)" }
        } catch { "N/A" }

        $saved = Set-VBRRetentionValue -Job $job -RetainCycles $newRetain
        if ($saved) {
            Log-Change $job.Name "Restore Points (Mass)" $before "$newRetain"
            $results.Add(@{ JobName = $job.Name; Before = $before; After = "$newRetain"; Status = "SUCCESS"; Error = "" })
            Write-Detail "  Applied  : $($job.Name)  ($before -> $newRetain)"
        } else {
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $before; Status = "FAILED"; Error = "Set-VBRRetentionValue returned false" })
            Write-Detail "  Failed   : $($job.Name)"
        }
    }

    # ----- Phase 3: Re-enable -----
    Write-Host ""
    Write-Info "Phase 3 of 3: Re-enabling previously enabled jobs..."
    foreach ($job in $disabledJobs) {
        try {
            Invoke-VeeamSafe { Enable-VBRJob -Job $job -ErrorAction Stop }
            Write-Detail "Enabled  : $($job.Name)"
        } catch {
            Write-Warn "Re-enable failed for '$($job.Name)': $_"
        }
    }

    Write-Host ""
    Write-Header "Mass Edit Retention  - Results"
    Show-MassEditSummary -Results $results -SettingName "Restore Points"
}
