function Edit-JobSchedule {
    param($Job)
    Write-Header "Edit Schedule: $($Job.Name)"

    try {
        $cur = Get-VBRJobScheduleOptions -Job $Job
        Write-Info "Current type : $($cur.ScheduleType)"
        Write-Info "Enabled      : $($Job.IsScheduleEnabled)"
    } catch { Write-Warn "Could not read current schedule." }
    Write-Host ""

    Write-Host "  [1] Daily" -ForegroundColor Yellow
    Write-Host "  [2] Weekly" -ForegroundColor Yellow
    Write-Host "  [3] Monthly" -ForegroundColor Yellow
    Write-Host "  [4] Continuously" -ForegroundColor Yellow
    Write-Host "  [5] Enable / Disable schedule" -ForegroundColor Yellow
    Write-Host "  [0] Cancel" -ForegroundColor DarkGray
    Write-Host ""
    $choice = Read-Host "  Select schedule type"

    function Read-ValidTime {
        $t = ""
        do { $t = Read-Host "  Run at time (HH:mm, e.g. 22:00)" } while ($t -notmatch '^\d{2}:\d{2}$')
        return $t   # Return as string — Set-VBRJobSchedule -At accepts "HH:mm"
    }

    switch ($choice) {
        "1" {
            $runAt = Read-ValidTime
            # VBR v13: Set-VBRJobSchedule replaces obsolete Set-VBRJobScheduleOptions
            try {
                Set-VBRJobSchedule -Job $Job -Daily -At $runAt -DailyKind Everyday -ErrorAction Stop
                Log-Change $Job.Name "Schedule" "previous" "Daily at $runAt"
                Write-Success "Schedule set to Daily at $runAt"
            } catch { Write-Err "Failed: $_" }
        }
        "2" {
            $runAt   = Read-ValidTime
            Write-Host "  Days: Monday Tuesday Wednesday Thursday Friday Saturday Sunday" -ForegroundColor Gray
            $daysStr = Read-Host "  Day(s), comma-separated (e.g. Monday,Wednesday,Friday)"
            $days    = $daysStr -split "," | ForEach-Object { $_.Trim() }
            try {
                Set-VBRJobSchedule -Job $Job -Weekly -At $runAt -Days $days -ErrorAction Stop
                Log-Change $Job.Name "Schedule" "previous" "Weekly $($days -join ',') @ $runAt"
                Write-Success "Schedule set to Weekly."
            } catch { Write-Err "Failed: $_" }
        }
        "3" {
            $runAt      = Read-ValidTime
            Write-Host "  Occurrence: First Second Third Fourth Last" -ForegroundColor Gray
            $occurrence = Read-Host "  Occurrence"
            Write-Host "  Day: Monday Tuesday Wednesday Thursday Friday Saturday Sunday Day" -ForegroundColor Gray
            $dayOfWeek  = Read-Host "  Day of week"
            Write-Host "  Months (comma-separated or 'all'):" -ForegroundColor Gray
            $mIn = Read-Host "  Month(s)"
            $months = if ($mIn.Trim().ToLower() -eq "all") {
                @("January","February","March","April","May","June","July","August","September","October","November","December")
            } else {
                $mIn -split "," | ForEach-Object { $_.Trim() }
            }
            try {
                Set-VBRJobSchedule -Job $Job -Monthly -At $runAt `
                    -Months $months -DayOfMonth $occurrence -DayOfWeek $dayOfWeek -ErrorAction Stop
                Log-Change $Job.Name "Schedule" "previous" "Monthly $occurrence $dayOfWeek @ $runAt"
                Write-Success "Schedule set to Monthly."
            } catch { Write-Err "Failed: $_" }
        }
        "4" {
            if (Confirm-Action "Set '$($Job.Name)' to run continuously?") {
                try {
                    Set-VBRJobSchedule -Job $Job -Continuously -ErrorAction Stop
                    Log-Change $Job.Name "Schedule" "previous" "Continuously"
                    Write-Success "Schedule set to Continuously."
                } catch { Write-Err "Failed: $_" }
            }
        }
        "5" {
            # VBR v13: Disable-VBRJobSchedule / Enable-VBRJobSchedule toggle only the
            # schedule; Disable-VBRJob / Enable-VBRJob disable the job entirely.
            $enabled = $Job.IsScheduleEnabled
            $action  = $enabled ? "Disable" : "Enable"
            if (Confirm-Action "$action schedule for '$($Job.Name)'?") {
                try {
                    if ($enabled) { Disable-VBRJobSchedule -Job $Job -ErrorAction Stop }
                    else          { Enable-VBRJobSchedule  -Job $Job -ErrorAction Stop }
                    Log-Change $Job.Name "Schedule Enabled" "$enabled" "$(-not $enabled)"
                    Write-Success "Schedule ${action}d."
                } catch { Write-Err "Failed: $_" }
            }
        }
        default { Write-Info "Cancelled." }
    }
}
