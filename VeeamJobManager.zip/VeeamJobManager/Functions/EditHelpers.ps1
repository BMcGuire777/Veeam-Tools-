function Set-VBRRetentionValue {
    <#
    Sets the restore-point retention for a job using the documented Veeam v12 approach.

    Per Veeam Product Manager (forums.veeam.com/powershell-f26/t31963):
      - VMware / Hyper-V backup jobs : Options.BackupStorageOptions.RetainCycles
      - Backup Copy jobs             : Options.GenerationPolicy.SimpleRetentionRestorePoints

    Both are persisted via Get-VBRJobOptions / Set-VBRJobOptions.
    Returns $true on success, $false on failure.
    #>
    param($Job, [int]$RetainCycles)

    # Primary: documented Get/Set-VBRJobOptions pattern
    try {
        $opts = Get-VBRJobOptions -Job $Job -ErrorAction Stop
        if ($Job.JobType -eq "BackupSync") {
            # Backup Copy jobs store retention in GenerationPolicy
            $opts.GenerationPolicy.SimpleRetentionRestorePoints = $RetainCycles
        } else {
            # VMware / Hyper-V backup jobs use BackupStorageOptions
            $opts.BackupStorageOptions.RetainCycles = $RetainCycles
        }
        Set-VBRJobOptions -Job $Job -Options $opts -ErrorAction Stop
        return $true
    } catch {
        Write-Warn "Get/Set-VBRJobOptions approach failed: $_"
    }

    # Note: the v12 fallback using [Veeam.Backup.Core.CBackupJob]::Update() has been
    # removed — .NET static calls on deserialized objects fail in PS7 compatibility mode.
    Write-Err "All retention-save methods failed."
    Write-Warn "Ensure the Veeam Backup Service is running and you have the Administrator role."
    return $false
}

function Invoke-ToggleJobEnabled {
    <#
    Disables or enables a job. Returns $true if the operation succeeded.
    Pass -Disable $true to disable, -Disable $false to enable.
    #>
    param($Job, [bool]$Disable)
    $action = if ($Disable) { "Disabling" } else { "Enabling" }
    try {
        if ($Disable) { Disable-VBRJob -Job $Job -ErrorAction Stop }
        else          { Enable-VBRJob  -Job $Job -ErrorAction Stop }
        $state = if ($Disable) { "Disabled" } else { "Enabled" }
        Log-Change $Job.Name "Schedule Enabled" "$(if($Disable){'True'}else{'False'})" "$(if($Disable){'False'}else{'True'})"
        Write-Success "$action '$($Job.Name)': done."
        return $true
    } catch {
        Write-Err "$action failed: $_"
        return $false
    }
}
