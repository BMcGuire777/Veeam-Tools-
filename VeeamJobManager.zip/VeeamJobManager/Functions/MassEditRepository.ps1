function Invoke-MassEditRepository {
    Write-Header "Mass Edit: Repository"

    $jobs = @(Select-MassEditTargetJobs)
    if ($jobs.Count -eq 0) { return }

    Write-Host ""
    $repos = @(Get-VBRBackupRepository | Sort-Object Name)
    if ($repos.Count -eq 0) { Write-Err "No repositories found."; return }

    Write-Host ("  {0,-4} {1,-40} {2}" -f "#", "Repository Name", "Type") -ForegroundColor White
    Write-Host ("  {0,-4} {1,-40} {2}" -f "----", "---------------", "----") -ForegroundColor DarkGray
    for ($i = 0; $i -lt $repos.Count; $i++) {
        Write-Host ("  {0,-4} {1,-40} {2}" -f ($i+1), $repos[$i].Name, $repos[$i].Type) -ForegroundColor Yellow
    }
    Write-Host ""

    do {
        $sel = Read-Host "  Select new repository (1-$($repos.Count), 0 to cancel)"
        if ($sel -eq "0") { Write-Info "Cancelled."; return }
    } while ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $repos.Count)

    $newRepo = $repos[[int]$sel - 1]

    $confirmed = Show-MassEditPreview -Jobs $jobs -SettingName "Repository" `
        -GetCurrent { param($Job) try { $Job.GetTargetRepository().Name } catch { "N/A" } } `
        -NewValue $newRepo.Name

    if (-not $confirmed) { Write-Info "Aborted  - no changes made."; return }

    Write-Host ""
    Write-Info "Applying repository change to $($jobs.Count) job(s)..."
    $results = [System.Collections.Generic.List[hashtable]]::new()

    foreach ($job in $jobs) {
        $before = try { $job.GetTargetRepository().Name } catch { "N/A" }
        try {
            Invoke-VeeamSafe { Set-VBRJob -Job $job -BackupRepository $newRepo -ErrorAction Stop }
            Log-Change $job.Name "Repository (Mass)" $before $newRepo.Name
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $newRepo.Name; Status = "SUCCESS"; Error = "" })
            Write-Detail "Applied : $($job.Name)  ($before -> $($newRepo.Name))"
        } catch {
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $before; Status = "FAILED"; Error = "$_" })
            Write-Detail "  Failed  : $($job.Name): $_"
        }
    }

    Write-Host ""
    Write-Header "Mass Edit Repository  - Results"
    Show-MassEditSummary -Results $results -SettingName "Repository"
}
