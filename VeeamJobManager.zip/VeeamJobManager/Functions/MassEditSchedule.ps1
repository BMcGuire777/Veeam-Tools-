function Invoke-MassEditSchedule {
    Write-Header "Mass Edit: Schedule"

    $jobs = @(Select-MassEditTargetJobs)
    if ($jobs.Count -eq 0) { return }

    Write-Host ""
    Write-Host "  [1] Daily" -ForegroundColor Yellow
    Write-Host "  [2] Weekly" -ForegroundColor Yellow
    Write-Host "  [3] Monthly" -ForegroundColor Yellow
    Write-Host "  [4] Continuously" -ForegroundColor Yellow
    Write-Host "  [5] Enable all selected jobs' schedules" -ForegroundColor Green
    Write-Host "  [6] Disable all selected jobs' schedules" -ForegroundColor Red
    Write-Host "  [0] Cancel" -ForegroundColor DarkGray
    Write-Host ""
    $schedChoice = Read-Host "  Select schedule type to apply"
    if ($schedChoice -eq "0") { Write-Info "Cancelled."; return }
    if ($schedChoice -notin @("1","2","3","4","5","6")) { Write-Info "Invalid selection."; return }

    function Read-ValidTimeMS {
        $t = ""
        do { $t = Read-Host "  Run at time (HH:mm, e.g. 22:00)" } while ($t -notmatch '^\d{2}:\d{2}$')
        return $t   # Return as string — Set-VBRJobSchedule -At accepts "HH:mm"
    }

    # Collect parameters for the chosen schedule type
    $schedRunAt      = $null
    $schedDays       = @()
    $schedOccurrence = ""
    $schedDayOfWeek  = ""
    $schedMonths     = @()
    $schedDesc       = ""

    switch ($schedChoice) {
        "1" {
            $schedRunAt = Read-ValidTimeMS
            $schedDesc  = "Daily at $schedRunAt"
        }
        "2" {
            $schedRunAt = Read-ValidTimeMS
            Write-Host "  Days: Monday Tuesday Wednesday Thursday Friday Saturday Sunday" -ForegroundColor Gray
            $daysStr    = Read-Host "  Day(s), comma-separated"
            $schedDays  = @($daysStr -split "," | ForEach-Object { $_.Trim() })
            $schedDesc  = "Weekly $($schedDays -join ',') @ $schedRunAt"
        }
        "3" {
            $schedRunAt      = Read-ValidTimeMS
            Write-Host "  Occurrence: First Second Third Fourth Last" -ForegroundColor Gray
            $schedOccurrence = Read-Host "  Occurrence"
            Write-Host "  Day: Monday Tuesday Wednesday Thursday Friday Saturday Sunday Day" -ForegroundColor Gray
            $schedDayOfWeek  = Read-Host "  Day of week"
            $mIn             = Read-Host "  Month(s) comma-separated or 'all'"
            $schedMonths     = if ($mIn.Trim().ToLower() -eq "all") {
                @("January","February","March","April","May","June","July","August","September","October","November","December")
            } else {
                @($mIn -split "," | ForEach-Object { $_.Trim() })
            }
            $schedDesc = "Monthly $schedOccurrence $schedDayOfWeek @ $schedRunAt"
        }
        "4" { $schedDesc = "Continuously"     }
        "5" { $schedDesc = "Enable Schedule"  }
        "6" { $schedDesc = "Disable Schedule" }
    }

    $confirmed = Show-MassEditPreview -Jobs $jobs -SettingName "Schedule" `
        -GetCurrent {
            param($Job)
            try { (Get-VBRJobScheduleOptions -Job $Job).ScheduleType } catch { "N/A" }
        } `
        -NewValue $schedDesc

    if (-not $confirmed) { Write-Info "Aborted — no changes made."; return }

    Write-Host ""
    Write-Info "Applying schedule to $($jobs.Count) job(s)..."
    $results = [System.Collections.Generic.List[hashtable]]::new()

    foreach ($job in $jobs) {
        $before = try { (Get-VBRJobScheduleOptions -Job $job).ScheduleType } catch { "N/A" }
        try {
            # VBR v13: Set-VBRJobSchedule replaces obsolete Set-VBRJobScheduleOptions.
            # Enable/Disable-VBRJobSchedule toggle only the schedule (not the job itself).
            switch ($schedChoice) {
                "1" { Invoke-VeeamSafe { Set-VBRJobSchedule -Job $job -Daily -At $schedRunAt -DailyKind Everyday -ErrorAction Stop } }
                "2" { Invoke-VeeamSafe { Set-VBRJobSchedule -Job $job -Weekly -At $schedRunAt -Days $schedDays -ErrorAction Stop } }
                "3" { Invoke-VeeamSafe { Set-VBRJobSchedule -Job $job -Monthly -At $schedRunAt -Months $schedMonths -DayOfMonth $schedOccurrence -DayOfWeek $schedDayOfWeek -ErrorAction Stop } }
                "4" { Invoke-VeeamSafe { Set-VBRJobSchedule -Job $job -Continuously -ErrorAction Stop } }
                "5" { Invoke-VeeamSafe { Enable-VBRJobSchedule  -Job $job -ErrorAction Stop } }
                "6" { Invoke-VeeamSafe { Disable-VBRJobSchedule -Job $job -ErrorAction Stop } }
            }
            Log-Change $job.Name "Schedule (Mass)" $before $schedDesc
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $schedDesc; Status = "SUCCESS"; Error = "" })
            Write-Detail "Applied : $($job.Name)"
        } catch {
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $before; Status = "FAILED"; Error = "$_" })
            Write-Detail "Failed  : $($job.Name): $_"
        }
    }

    Write-Host ""
    Write-Header "Mass Edit Schedule — Results"
    Show-MassEditSummary -Results $results -SettingName "Schedule"
}
