function Copy-JobSettings {
    Write-Header "Bulk Copy: Source Job Settings -> Multiple Target Jobs"

    # Need at least 2 jobs  - one source, one target
    $allJobs = @(Get-AllEditableJobs)
    if ($allJobs.Count -lt 2) {
        Write-Err "Bulk copy requires at least 2 jobs."
        Write-Warn "Only $($allJobs.Count) job(s) found. Add more jobs in VBR, then try again."
        Pause-Screen
        return
    }

    Write-Info "Step 1: Select SOURCE job"
    $src = Select-SingleJob -Prompt "Select source job"
    if ($null -eq $src) { return }

    # Snapshot source
    $srcSnap = Get-JobSnapshot -Job $src

    Write-SubHeader "Source Job Current Settings"
    foreach ($k in $srcSnap.Keys) {
        Write-Detail ("{0,-26}: {1}" -f $k, $srcSnap[$k])
    }

    Write-Host ""
    Write-Host "  Which settings do you want to copy?" -ForegroundColor White
    Write-Host "  [1] Repository only" -ForegroundColor Yellow
    Write-Host "  [2] Retention (simple) only" -ForegroundColor Yellow
    Write-Host "  [3] GFS Retention only" -ForegroundColor Yellow
    Write-Host "  [4] Schedule only" -ForegroundColor Yellow
    Write-Host "  [5] Notifications only" -ForegroundColor Yellow
    Write-Host "  [6] Repository + Retention + GFS" -ForegroundColor Yellow
    Write-Host "  [7] ALL settings" -ForegroundColor Yellow
    Write-Host "  [0] Cancel" -ForegroundColor DarkGray
    Write-Host ""
    $settingsChoice = Read-Host "  Select"
    if ($settingsChoice -eq "0") { return }

    $copyRepo    = $settingsChoice -in @("1","6","7")
    $copyRetain  = $settingsChoice -in @("2","6","7")
    $copyGfs     = $settingsChoice -in @("3","6","7")
    $copySched   = $settingsChoice -in @("4","7")
    $copyNotify  = $settingsChoice -in @("5","7")

    Write-Host ""
    Write-Info "Step 2: Select TARGET job(s)"
    $targets = @(Select-MultipleJobs -ExcludeJobName $src.Name)
    if ($targets.Count -eq 0) { Write-Err "No targets selected."; return }

    Write-Host ""
    Write-Info "Will apply settings from '$($src.Name)' to $($targets.Count) job(s):"
    foreach ($t in $targets) { Write-Detail "  -> $($t.Name)" }
    Write-Host ""
    if (-not (Confirm-Action "Proceed?")) { Write-Info "Aborted."; return }

    # Pre-gather source values
    $srcRepo    = if ($copyRepo)   { try { $src.GetTargetRepository() } catch { $null } } else { $null }
    $srcRetain  = if ($copyRetain) { try { $src.Options.BackupStorageOptions.RetainCycles } catch { $null } } else { $null }
    $srcSched   = if ($copySched)  { try { Get-VBRJobScheduleOptions -Job $src } catch { $null } } else { $null }

    $comparisons = [System.Collections.Generic.List[hashtable]]::new()

    foreach ($tgt in $targets) {
        Write-Host ""
        Write-Info "Processing: $($tgt.Name)"

        $before = Get-JobSnapshot -Job $tgt

        if ($copyRepo -and $srcRepo) {
            try {
                Set-VBRJob -Job $tgt -BackupRepository $srcRepo -ErrorAction Stop
                Log-Change $tgt.Name "Repository" "$($before['Repository'])" $srcRepo.Name
                Write-Success "  Repository -> $($srcRepo.Name)"
            } catch { Write-Err "  Repository failed: $_" }
        }

        if ($copyRetain -and $null -ne $srcRetain) {
            # Disable target job first, apply retention, then re-enable
            $tgtWasEnabled = $false
            try { $tgtWasEnabled = $tgt.IsScheduleEnabled } catch {}
            if ($tgtWasEnabled) {
                try { Disable-VBRJob -Job $tgt -ErrorAction Stop; Write-Info "  Disabled '$($tgt.Name)' for retention change." } catch { Write-Err "  Could not disable job  - skipping retention change."; $copyRetain = $false }
            }
            if ($copyRetain) {
                $saved = Set-VBRRetentionValue -Job $tgt -RetainCycles $srcRetain
                if ($saved) {
                    Log-Change $tgt.Name "Restore Points" "$($before['Restore Points'])" "$srcRetain"
                    Write-Success "  Retention  -> $srcRetain"
                }
                if ($tgtWasEnabled) {
                    try { Enable-VBRJob -Job $tgt -ErrorAction Stop; Write-Info "  Re-enabled '$($tgt.Name)'." } catch { Write-Warn "  Re-enable failed  - job remains disabled." }
                }
            }
        }

        if ($copyGfs) {
            $tgtWasEnabled = $false
            try { $tgtWasEnabled = $tgt.IsScheduleEnabled } catch {}
            if ($tgtWasEnabled) {
                try { Disable-VBRJob -Job $tgt -ErrorAction Stop; Write-Info "  Disabled '$($tgt.Name)' for GFS change." } catch { Write-Err "  Could not disable job  - skipping GFS change."; $copyGfs = $false }
            }
            if ($copyGfs) {
                try {
                    $srcOpts = $src.Options.BackupStorageOptions
                    Set-VBRJobAdvancedBackupOptions -Job $tgt `
                        -EnableGfsOptions      $srcOpts.EnableGfsOptions `
                        -GfsWeeklyBackups      $srcOpts.GfsWeeklyBackups `
                        -WeeklyBackupDayOfWeek $srcOpts.WeeklyBackupDayOfWeek `
                        -GfsMonthlyBackups     $srcOpts.GfsMonthlyBackups `
                        -GfsYearlyBackups      $srcOpts.GfsYearlyBackups `
                        -YearlyBackupMonthOfYear $srcOpts.YearlyBackupMonthOfYear `
                        -ErrorAction Stop
                    Log-Change $tgt.Name "GFS" "$($before['GFS Enabled'])" "$($srcOpts.EnableGfsOptions)"
                    Write-Success "  GFS settings copied."
                } catch { Write-Err "  GFS copy failed: $_" }
                if ($tgtWasEnabled) {
                    try { Enable-VBRJob -Job $tgt -ErrorAction Stop; Write-Info "  Re-enabled '$($tgt.Name)'." } catch { Write-Warn "  Re-enable failed  - job remains disabled." }
                }
            }
        }

        if ($copySched -and $null -ne $srcSched) {
            try {
                switch ($srcSched.ScheduleType) {
                    # v13: Set-VBRJobScheduleOptions is obsolete — replaced by Set-VBRJobSchedule
                    "Daily"        { Set-VBRJobSchedule -Job $tgt -Daily        -At $srcSched.DailyOptions.Period -DailyKind Everyday -ErrorAction Stop }
                    "Weekly"       { Set-VBRJobSchedule -Job $tgt -Weekly       -At $srcSched.WeeklyOptions.Period -Days $srcSched.WeeklyOptions.DaysSrv -ErrorAction Stop }
                    "Monthly"      { Set-VBRJobSchedule -Job $tgt -Monthly      -At $srcSched.MonthlyOptions.Period -Months $srcSched.MonthlyOptions.Months -DayOfMonth $srcSched.MonthlyOptions.DayNumberInMonth -DayOfWeek $srcSched.MonthlyOptions.DayOfWeek -ErrorAction Stop }
                    "Continuously" { Set-VBRJobSchedule -Job $tgt -Continuously -ErrorAction Stop }
                }
                Log-Change $tgt.Name "Schedule" "$($before['Schedule Type'])" "$($srcSched.ScheduleType)"
                Write-Success "  Schedule   -> $($srcSched.ScheduleType)"
            } catch { Write-Err "  Schedule copy failed: $_" }
        }

        if ($copyNotify) {
            try {
                $srcNotif = $src.Options.NotificationOptions
                $tgtNotif = $tgt.Options.NotificationOptions
                $tgtNotif.SendEmail = $srcNotif.SendEmail
                $tgtNotif.EmailNotificationOptions.NotifyOnSuccess = $srcNotif.EmailNotificationOptions.NotifyOnSuccess
                $tgtNotif.EmailNotificationOptions.NotifyOnWarning = $srcNotif.EmailNotificationOptions.NotifyOnWarning
                try {
                    $tgtNotif.EmailNotificationOptions.NotifyOnError = $srcNotif.EmailNotificationOptions.NotifyOnError
                } catch {
                    $tgtNotif.EmailNotificationOptions.NotifyOnFailure = $srcNotif.EmailNotificationOptions.NotifyOnFailure
                }
                $tgtNotif.EmailNotificationOptions.EmailAddresses = $srcNotif.EmailNotificationOptions.EmailAddresses
                Set-VBRJobAdvancedNotificationOptions -Job $tgt -Options $tgtNotif -ErrorAction Stop
                Log-Change $tgt.Name "Notifications" "$($before['Email Notify'])" "$($srcNotif.SendEmail)"
                Write-Success "  Notifications copied."
            } catch { Write-Err "  Notifications copy failed: $_" }
        }

        # Refresh job object and capture after snapshot
        try { $tgtRefresh = Get-VBRJob -Name $tgt.Name } catch { $tgtRefresh = $tgt }
        $after = Get-JobSnapshot -Job $tgtRefresh
        $comparisons.Add(@{ JobName = $tgt.Name; Before = $before; After = $after })
    }

    # Show before/after for each target
    Write-Host ""
    Write-Info "Bulk copy complete. Showing comparison for each job..."
    Pause-Screen

    foreach ($comp in $comparisons) {
        Show-Comparison -JobName $comp.JobName -Before $comp.Before -After $comp.After
        Pause-Screen
    }
}
