function Invoke-DiskConsumptionReport {
    <#
    .SYNOPSIS
        Reports on-disk space consumed by each backup/copy job and exports to CSV.

    .DESCRIPTION
        Iterates every editable job, reads its backup chains via Get-VBRBackup,
        counts restore points, and estimates sizes from restore point ApproxSize.

        Columns in the CSV:
          Job Name | Job Type | Repository | Hardened | Restore Points |
          Oldest Restore Point | Newest Restore Point |
          Approx Data GB | Status

    .NOTES
        VBR v13 True Per-VM mode: Get-VBRBackup returns parent containers whose
        JobId matches the job Id. Restore points link to per-VM child backup IDs,
        not the parent container ID. Get-VBRRestorePoint -Backup <parent> traverses
        the chain correctly in native PS7.

        Get-VBRBackupFile returns nothing for hardened Linux repos — size is
        estimated from restore point ApproxSize instead.
    #>

    Write-Header "Disk Space Consumption Report"

    # ----------------------------------------------------------------
    #  Output folder
    # ----------------------------------------------------------------
    Write-Info "CSV output folder  (press Enter to use current directory):"
    $folderInput = (Read-Host "  Folder").Trim()

    $outFolder = [string]::IsNullOrWhiteSpace($folderInput) ? (Get-Location).Path : $folderInput

    if (-not (Test-Path $outFolder -PathType Container)) {
        if (Confirm-Action "Folder '$outFolder' does not exist. Create it?") {
            try {
                New-Item -ItemType Directory -Path $outFolder -Force | Out-Null
                Write-Success "Created: $outFolder"
            } catch {
                Write-Err "Could not create folder: $_"
                Pause-Screen
                return
            }
        } else {
            Write-Info "Cancelled."
            Pause-Screen
            return
        }
    }

    # ----------------------------------------------------------------
    #  Gather jobs
    # ----------------------------------------------------------------
    $jobs = @(Get-AllEditableJobs)
    if ($jobs.Count -eq 0) {
        Write-Err "No editable jobs found."
        Pause-Screen
        return
    }

    Write-Info "Querying $($jobs.Count) job(s) — this may take a moment..."
    Write-Host ""

    # Pre-fetch backup catalog once.
    # Match to jobs via backup.JobId == job.Id (not by name).
    Write-Detail "Loading backup catalog..."
    $allBackupCache = @(try { Invoke-VeeamSafe { Get-VBRBackup -ErrorAction Stop } } catch { @() })

    $rows   = [System.Collections.Generic.List[pscustomobject]]::new()
    $errors = 0

    foreach ($job in $jobs) {
        $jName = $job.Name
        $jId   = $job.Id.ToString()

        Write-Detail $jName

        try {
            # Match backup containers to this job by JobId
            $backups = @($allBackupCache | Where-Object { $_.JobId.ToString() -eq $jId })

            # Determine job type from backup platform, fall back to job type
            $jType = if ($backups.Count -gt 0) {
                switch ($backups[0].BackupPlatform) {
                    'EVmware'  { 'VMware Backup'  }
                    'EHyperV'  { 'Hyper-V Backup' }
                    'EHvVim'   { 'Hyper-V Backup' }
                    default    {
                        if ($job.JobType -eq 'BackupSync') { 'Backup Copy' }
                        else { $backups[0].BackupPlatform }
                    }
                }
            } else {
                if ($job.JobType -eq 'BackupSync') { 'Backup Copy' } else { 'Backup' }
            }

            # Repository name and hardened flag
            $jRepo     = try { $job.GetTargetRepository().Name } catch { 'N/A' }
            $hardened  = if ($backups.Count -gt 0 -and $backups[0].RepositoryType -eq 'LinuxHardened') { 'Yes' } else { 'No' }

            if ($backups.Count -eq 0) {
                $rows.Add([pscustomobject]@{
                    'Job Name'             = $jName
                    'Job Type'             = $jType
                    'Repository'           = $jRepo
                    'Hardened'             = $hardened
                    'Restore Points'       = 0
                    'Oldest Restore Point' = 'N/A'
                    'Newest Restore Point' = 'N/A'
                    'Approx Data GB'       = 0.00
                    'Status'               = 'No backups'
                })
                continue
            }

            # -- Restore points --
            # Use Get-VBRRestorePoint -Backup (native PS7 typed param) which correctly
            # traverses the True Per-VM parent -> child chain in VBR v13.
            $allRPs = [System.Collections.Generic.List[object]]::new()
            foreach ($backup in $backups) {
                try {
                    $rps = @(Invoke-VeeamSafe { Get-VBRRestorePoint -Backup $backup -ErrorAction Stop })
                    foreach ($rp in $rps) { $allRPs.Add($rp) }
                } catch {
                    Write-Warn "  RP query failed for '$jName': $_"
                }
            }

            $rpCount = $allRPs.Count
            $oldest  = 'N/A'
            $newest  = 'N/A'
            $approxBytes = [long]0

            if ($rpCount -gt 0) {
                $sorted = @($allRPs | Sort-Object CreationTime)
                $oldest = $sorted[0].CreationTime.ToString('yyyy-MM-dd')
                $newest = $sorted[-1].CreationTime.ToString('yyyy-MM-dd')
                # ApproxSize is per-VM per restore point (source data estimate)
                foreach ($rp in $allRPs) {
                    if ($rp.ApproxSize -gt 0) { $approxBytes += [long]$rp.ApproxSize }
                }
            }

            $approxGB = [math]::Round($approxBytes / 1GB, 2)

            $rows.Add([pscustomobject]@{
                'Job Name'             = $jName
                'Job Type'             = $jType
                'Repository'           = $jRepo
                'Hardened'             = $hardened
                'Restore Points'       = $rpCount
                'Oldest Restore Point' = $oldest
                'Newest Restore Point' = $newest
                'Approx Data GB'       = $approxGB
                'Status'               = 'OK'
            })

        } catch {
            $errors++
            Write-Warn "Query failed for '$jName': $_"
            $rows.Add([pscustomobject]@{
                'Job Name'             = $jName
                'Job Type'             = 'N/A'
                'Repository'           = 'N/A'
                'Hardened'             = 'N/A'
                'Restore Points'       = 'N/A'
                'Oldest Restore Point' = 'N/A'
                'Newest Restore Point' = 'N/A'
                'Approx Data GB'       = 'N/A'
                'Status'               = "ERROR: $($_.Exception.Message)"
            })
        }
    }

    # ----------------------------------------------------------------
    #  Console summary table
    # ----------------------------------------------------------------
    Write-Host ""
    $CJ = 34; $CT = 15; $CR = 22; $CH = 9; $CRP = 7; $CDS = 13

    Write-Host ("  {0,-$CJ} {1,-$CT} {2,-$CR} {3,-$CH} {4,-$CRP} {5}" -f `
        "Job Name", "Type", "Repository", "Hardened", "Points", "Approx Data (GB)") `
        -ForegroundColor White
    Write-Host ("  {0,-$CJ} {1,-$CT} {2,-$CR} {3,-$CH} {4,-$CRP} {5}" -f `
        ("-" * ($CJ-1)), ("-" * ($CT-1)), ("-" * ($CR-1)), "--------", "------", "----------------") `
        -ForegroundColor DarkGray

    foreach ($r in $rows) {
        $color = switch ($r.Status) {
            "OK"         { "Cyan"       }
            "No backups" { "DarkYellow" }
            default      { "Red"        }
        }
        $hColor = if ($r.Hardened -eq 'Yes') { "Yellow" } else { $color }
        Write-Host ("  {0,-$CJ} {1,-$CT} {2,-$CR} " -f `
            (Truncate-String $r.'Job Name'   ($CJ-1)),
            (Truncate-String $r.'Job Type'   ($CT-1)),
            (Truncate-String $r.'Repository' ($CR-1))) -ForegroundColor $color -NoNewline
        Write-Host ("{0,-$CH} " -f $r.'Hardened') -ForegroundColor $hColor -NoNewline
        Write-Host ("{0,-$CRP} {1}" -f $r.'Restore Points', $r.'Approx Data GB') -ForegroundColor $color
    }

    Write-Host ""

    # Totals line (OK rows only)
    $okRows = @($rows | Where-Object { $_.Status -eq 'OK' })
    if ($okRows.Count -gt 0) {
        $totData = [math]::Round(
            ($okRows | ForEach-Object { [double]$_.'Approx Data GB' } | Measure-Object -Sum).Sum, 2)
        $totRPs  = [int]($okRows | ForEach-Object { [int]$_.'Restore Points' } | Measure-Object -Sum).Sum

        Write-Host ("  +- Totals ({0} of {1} jobs)  RPs: {2}  |  Approx Data: {3} GB" -f `
            $okRows.Count, $jobs.Count, $totRPs, $totData) -ForegroundColor Cyan
    }

    if ($errors -gt 0) {
        Write-Host ""
        Write-Warn "$errors job(s) encountered errors (shown in red above)."
    }

    # ----------------------------------------------------------------
    #  Export CSV
    # ----------------------------------------------------------------
    Write-Host ""
    $csvName = "VeeamDiskConsumption_$(Get-Date -f 'yyyyMMdd_HHmmss').csv"
    $csvPath = Join-Path $outFolder $csvName

    try {
        $rows | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
        Write-Success "CSV saved: $csvPath"
    } catch {
        Write-Err "CSV export failed: $_"
    }

    Pause-Screen
}
