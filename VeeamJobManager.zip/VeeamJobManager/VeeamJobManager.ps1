#Requires -Version 7.0
<#
.SYNOPSIS
    Veeam Backup & Replication v13 - Interactive Job Manager v3.0

.DESCRIPTION
    Interactive PowerShell menu to view, edit, and bulk-apply settings for
    VMware Backup Jobs and Backup Copy Jobs in Veeam VBR v13.

    Features:
      - Edit repository and retention (simple + GFS)
      - Edit job schedule (daily, weekly, monthly, continuous)
      - Edit notification and email alert settings
      - Start / Stop jobs
      - Bulk copy settings from one source job to multiple target jobs
      - MASS EDIT: push one setting to hundreds of jobs at once
          > Scope filter: All / VMware only / Backup Copy only / Hand-pick
          > Preview table (current vs. new value per job) before any change
          > 3-phase disable -> apply -> re-enable for retention and GFS
          > Post-apply results table (SUCCESS / FAILED / SKIPPED) with export
      - Disk Space Consumption Report (per job, CSV export)
      - Side-by-side Before / After comparison after every edit or bulk operation
      - Session change log with optional export
      - Throttle-safe: all bulk VBR calls use Invoke-VeeamSafe (retry/backoff)
        for VBR v13's service-layer rate limiting

.NOTES
    Author  : Benjamin McGuire / Veeam
    Version : 3.0
    Requires: Veeam Backup & Replication v13 on Windows
              PowerShell 7.0 or later (pwsh.exe)
              Must be run on the VBR server (or machine with VBR console).
              Run as Administrator.

    Key changes from v2 (VBR v12 / PS 5.1):
      - PowerShell 7.x required (Set-StrictMode, ternary ops, null coalescing)
      - Set-VBRJobScheduleOptions removed (obsolete) -> Set-VBRJobSchedule
      - Enable/Disable-VBRJob for schedule -> Enable/Disable-VBRJobSchedule
      - Apply/Enable/Disable-VBRIndependentRetention ->
            Apply/Enable/Disable-VBRBackgroundRetention
      - PSSnapin fallback removed (not available in PS7)
      - Invoke-VeeamSafe wrapper for throttle-safe bulk cmdlet calls
        (VBR v13 routes all PS cmdlets through the REST service layer)

.STRUCTURE
    VeeamJobManager/
    +-- VeeamJobManager.ps1      <- entry point (this file)
    +-- Globals.ps1              <- shared state, column constants, Invoke-VeeamSafe
    +-- Functions/
        +-- ConsoleHelpers.ps1
        +-- VBRConnection.ps1
        +-- JobRetrieval.ps1
        +-- JobSnapshot.ps1
        +-- ShowComparison.ps1
        +-- EditHelpers.ps1
        +-- EditRepository.ps1
        +-- EditRetention.ps1
        +-- EditGfsRetention.ps1
        +-- EditNotifications.ps1
        +-- EditSchedule.ps1
        +-- SingleJobMenu.ps1
        +-- BulkCopy.ps1
        +-- JobControl.ps1
        +-- ChangeLog.ps1
        +-- MassEditHelpers.ps1
        +-- MassEditRetention.ps1
        +-- MassEditRepository.ps1
        +-- MassEditSchedule.ps1
        +-- MassEditNotifications.ps1
        +-- MassEditGfs.ps1
        +-- MassEditMenu.ps1
        +-- ReplicationJobs.ps1
        +-- ReplicationJobSettings.ps1
        +-- DiskConsumption.ps1
        +-- MainMenu.ps1

    To add a new function: create a new .ps1 file in Functions/ - it loads automatically.
    To remove a function: delete its .ps1 file from Functions/.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Load shared globals (VBRServer, ChangeLog, column constants, Invoke-VeeamSafe)
. "$PSScriptRoot\Globals.ps1"

# Auto-load every function file from the Functions folder
Get-ChildItem "$PSScriptRoot\Functions" -Filter *.ps1 |
    Sort-Object Name |
    ForEach-Object { . $_.FullName }

# ============================================================
#  ENTRY POINT
# ============================================================
Clear-Host
Initialize-VBRConnection
Invoke-MainMenu
