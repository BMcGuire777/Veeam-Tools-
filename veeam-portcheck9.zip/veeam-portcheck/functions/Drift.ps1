# =============================================================================
#  Drift.ps1 - the blueprint drift engine.
#
#  Dot-sourced by veeam-blueprint.ps1.
#
#  Compare-VeeamBlueprint diffs two blueprint JSON documents section by
#  section, keyed so rows are matched by WHAT they are (a service name, a
#  proto/address:port, a config path) rather than by array position.
#  Every finding carries a severity:
#    Critical - a third-party listener took a port, a Veeam service or
#               database vanished, the DB engine changed
#    Warning  - config hash / setting / account / firewall / cert changes
#    Info     - expected additions, state changes, observed-connection churn
#  Metrics (sizes, counts) are reported as deltas, never as drift.
# =============================================================================

function Get-DriftRowLabel {
    param([string]$Section, $Row)
    switch ($Section) {
        'listeners'       { return ('{0} {1} {2}' -f $Row.ownerClass, $Row.process, $Row.service).Trim() }
        'services'        { return ('{0}/{1} account={2}' -f $Row.state, $Row.startType, $Row.account) }
        'veeamProducts'   { return ('v{0}' -f $Row.version) }
        'trunk'           { return ('backend {0} {1}' -f $Row.backProcess, $Row.backService).Trim() }
        'remoteEndpoints' { return ('{0} conn(s)' -f $Row.connections) }
        'configHashes'    { return ('{0}' -f $Row.hash) }
        'certificates'    { return ('{0} exp {1}' -f $Row.thumbprint, $Row.notAfter) }
        'firewall'        { return ('{0}' -f $Row.summary) }
        'vbrTopology'     { return ('{0}' -f $Row.type) }
    }
    return ''
}

function Get-DriftSeverity {
    param([string]$Section, [string]$ChangeType, $Row, [string]$Field, [string]$Before, [string]$After)
    switch ($Section) {
        'listeners' {
            if ($ChangeType -eq 'ADDED') {
                if (@('veeam','os','db') -contains [string]$Row.ownerClass) { return 'Info' }
                return 'Critical'
            }
            if ($ChangeType -eq 'REMOVED') {
                if ([string]$Row.ownerClass -eq 'veeam') { return 'Critical' }
                return 'Info'
            }
            if ($Field -eq 'ownerClass') {
                if ($After -eq 'veeam')  { return 'Info' }
                if ($Before -eq 'veeam') { return 'Critical' }
                return 'Warning'
            }
            return 'Warning'
        }
        'services' {
            if ($ChangeType -eq 'REMOVED') { return 'Critical' }
            if ($ChangeType -eq 'ADDED')   { return 'Info' }
            if (@('state','subState') -contains $Field) { return 'Info' }
            return 'Warning'
        }
        'veeamProducts' {
            if ($ChangeType -eq 'REMOVED') { return 'Critical' }
            if ($ChangeType -eq 'ADDED')   { return 'Info' }
            return 'Warning'
        }
        'database' {
            if ($Field -eq 'engine' -and $ChangeType -eq 'CHANGED') { return 'Critical' }
            if ($ChangeType -eq 'REMOVED') { return 'Critical' }
            if ($ChangeType -eq 'ADDED')   { return 'Info' }
            return 'Warning'
        }
        'configHashes'    { if ($ChangeType -eq 'ADDED') { return 'Info' }; return 'Warning' }
        'certificates'    { return 'Warning' }
        'firewall'        { return 'Warning' }
        'registryConfig'  { return 'Warning' }
        'trunk'           { if ($ChangeType -eq 'ADDED') { return 'Info' }; return 'Warning' }
        'remoteEndpoints' { return 'Info' }
        'vbrTopology'     { if ($ChangeType -eq 'REMOVED') { return 'Warning' }; return 'Info' }
        'os'              { return 'Info' }
        'tier'            { return 'Warning' }
    }
    return 'Info'
}

function New-DriftRow {
    param([string]$Section, [string]$ChangeType, [string]$Key,
          [string]$Field = '', [string]$Before = '', [string]$After = '', $Row = $null)
    return [pscustomobject]@{
        Severity   = (Get-DriftSeverity -Section $Section -ChangeType $ChangeType -Row $Row `
                        -Field $Field -Before $Before -After $After)
        Section    = $Section
        ChangeType = $ChangeType
        Key        = $Key
        Field      = $Field
        Before     = $Before
        After      = $After
    }
}

# Build key->row map from a section array; duplicate keys get a '+' suffix so
# nothing is silently dropped.
function ConvertTo-KeyedMap {
    param($Rows, [scriptblock]$KeyFn)
    $map = [ordered]@{}
    foreach ($r in @($Rows)) {
        if ($null -eq $r) { continue }
        $k = [string]($r | ForEach-Object $KeyFn)
        while ($map.Contains($k)) { $k = $k + '+' }
        $map[$k] = $r
    }
    return $map
}

function Compare-KeyedSection {
    param([string]$Section, $RefRows, $CurRows, [scriptblock]$KeyFn, [string[]]$Fields)

    $out = @()
    $refMap = ConvertTo-KeyedMap -Rows $RefRows -KeyFn $KeyFn
    $curMap = ConvertTo-KeyedMap -Rows $CurRows -KeyFn $KeyFn

    foreach ($k in @($refMap.Keys)) {
        if (-not $curMap.Contains($k)) {
            $out += New-DriftRow -Section $Section -ChangeType 'REMOVED' -Key $k `
                        -Before (Get-DriftRowLabel -Section $Section -Row $refMap[$k]) -Row $refMap[$k]
        }
    }
    foreach ($k in @($curMap.Keys)) {
        if (-not $refMap.Contains($k)) {
            $out += New-DriftRow -Section $Section -ChangeType 'ADDED' -Key $k `
                        -After (Get-DriftRowLabel -Section $Section -Row $curMap[$k]) -Row $curMap[$k]
            continue
        }
        $refRow = $refMap[$k]; $curRow = $curMap[$k]
        foreach ($f in $Fields) {
            $b = [string]$refRow.$f; $a = [string]$curRow.$f
            if ($b -cne $a) {
                $out += New-DriftRow -Section $Section -ChangeType 'CHANGED' -Key $k `
                            -Field $f -Before $b -After $a -Row $curRow
            }
        }
    }
    return $out
}

# Compare two flat name->value objects (db settings, registry values).
function Compare-ValueMap {
    param([string]$Section, [string]$Prefix, $RefObj, $CurObj)
    $out = @()
    $refProps = @{}; $curProps = @{}
    if ($RefObj) { foreach ($p in $RefObj.PSObject.Properties) { $refProps[$p.Name] = [string]$p.Value } }
    if ($CurObj) { foreach ($p in $CurObj.PSObject.Properties) { $curProps[$p.Name] = [string]$p.Value } }
    foreach ($k in @($refProps.Keys)) {
        if (-not $curProps.ContainsKey($k)) {
            $out += New-DriftRow -Section $Section -ChangeType 'REMOVED' -Key ($Prefix + $k) -Before $refProps[$k]
        } elseif ($refProps[$k] -cne $curProps[$k]) {
            $out += New-DriftRow -Section $Section -ChangeType 'CHANGED' -Key ($Prefix + $k) `
                        -Field 'value' -Before $refProps[$k] -After $curProps[$k]
        }
    }
    foreach ($k in @($curProps.Keys)) {
        if (-not $refProps.ContainsKey($k)) {
            $out += New-DriftRow -Section $Section -ChangeType 'ADDED' -Key ($Prefix + $k) -After $curProps[$k]
        }
    }
    return $out
}

# -----------------------------------------------------------------------------
#  The comparison itself
# -----------------------------------------------------------------------------
function Compare-VeeamBlueprint {
    param(
        [Parameter(Mandatory)][string]$ReferencePath,
        [Parameter(Mandatory)][string]$CurrentPath
    )

    foreach ($p in @($ReferencePath, $CurrentPath)) {
        if (-not (Test-Path $p)) { Write-Host ('  Not found: {0}' -f $p) -ForegroundColor Red; return $null }
    }
    try {
        $ref = Get-Content $ReferencePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        $cur = Get-Content $CurrentPath   -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    } catch {
        Write-Host ('  Could not read blueprints: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
    foreach ($d in @($ref, $cur)) {
        if ([string]$d.schema -notlike 'veeam-blueprint/*') {
            Write-Host '  One of the files is not a veeam-blueprint document.' -ForegroundColor Red
            return $null
        }
    }

    $rows = @()

    # -- capture-tier guard: never diff a full capture against a degraded one --
    $skipOwnerSections = $false
    $skipDbSection     = $false
    if ([bool]$ref.tier.elevated -ne [bool]$cur.tier.elevated) {
        $skipOwnerSections = $true
        $rows += New-DriftRow -Section 'tier' -ChangeType 'CHANGED' -Key 'elevated' -Field 'elevated' `
                    -Before ([string]$ref.tier.elevated) -After ([string]$cur.tier.elevated)
        $rows += New-DriftRow -Section 'tier' -ChangeType 'CHANGED' -Key 'note' -Field 'note' `
                    -Before '' -After 'Capture tiers differ - listener/trunk/config sections were NOT compared. Re-capture at the same elevation.'
    }
    if ([bool]$ref.tier.dbAccess -ne [bool]$cur.tier.dbAccess) {
        $skipDbSection = $true
        $rows += New-DriftRow -Section 'tier' -ChangeType 'CHANGED' -Key 'dbAccess' -Field 'dbAccess' `
                    -Before ([string]$ref.tier.dbAccess) -After ([string]$cur.tier.dbAccess)
    }

    # -- os / platform ----------------------------------------------------------
    foreach ($f in @('caption','kernel','arch')) {
        $b = [string]$ref.identity.os.$f; $a = [string]$cur.identity.os.$f
        if ($b -cne $a) {
            $rows += New-DriftRow -Section 'os' -ChangeType 'CHANGED' -Key $f -Field $f -Before $b -After $a
        }
    }

    # -- keyed sections -----------------------------------------------------------
    $rows += Compare-KeyedSection -Section 'veeamProducts' `
                -RefRows $ref.identity.veeamProducts -CurRows $cur.identity.veeamProducts `
                -KeyFn { $_.name } -Fields @('version')

    $rows += Compare-KeyedSection -Section 'services' `
                -RefRows $ref.identity.services -CurRows $cur.identity.services `
                -KeyFn { $_.name } -Fields @('startType','account','path','binaryHash','state')

    if (-not $skipOwnerSections) {
        $rows += Compare-KeyedSection -Section 'listeners' `
                    -RefRows $ref.identity.listeners -CurRows $cur.identity.listeners `
                    -KeyFn { '{0}/{1}:{2}' -f $_.proto, $_.address, $_.port } `
                    -Fields @('scope','ownerClass','process','service','exe')

        $rows += Compare-KeyedSection -Section 'trunk' `
                    -RefRows $ref.identity.trunk -CurRows $cur.identity.trunk `
                    -KeyFn { '{0} -> :{1}' -f $_.frontProcess, $_.backPort } `
                    -Fields @('backProcess','backService')

        $rows += Compare-KeyedSection -Section 'remoteEndpoints' `
                    -RefRows $ref.identity.remoteEndpoints -CurRows $cur.identity.remoteEndpoints `
                    -KeyFn { '{0} {1}:{2} {3}' -f $_.direction, $_.remoteHost, $_.remotePort, $_.process } `
                    -Fields @()

        $rows += Compare-KeyedSection -Section 'configHashes' `
                    -RefRows $ref.identity.configHashes -CurRows $cur.identity.configHashes `
                    -KeyFn { $_.path } -Fields @('hash')
    }

    $rows += Compare-KeyedSection -Section 'certificates' `
                -RefRows $ref.identity.certificates -CurRows $cur.identity.certificates `
                -KeyFn { '{0} {1}' -f $_.binding, $_.subject } -Fields @('thumbprint','notAfter')

    $rows += Compare-KeyedSection -Section 'firewall' `
                -RefRows $ref.identity.firewall -CurRows $cur.identity.firewall `
                -KeyFn { $_.name } -Fields @('hash','summary')

    $rows += Compare-KeyedSection -Section 'vbrTopology' `
                -RefRows $ref.identity.vbrTopology -CurRows $cur.identity.vbrTopology `
                -KeyFn { '{0}/{1}' -f $_.role, $_.name } -Fields @('type')

    # -- database -------------------------------------------------------------------
    if (-not $skipDbSection) {
        foreach ($f in @('engine','version','dataDir')) {
            $b = [string]$ref.identity.database.$f; $a = [string]$cur.identity.database.$f
            if ($b -cne $a) {
                $rows += New-DriftRow -Section 'database' -ChangeType 'CHANGED' -Key $f -Field $f -Before $b -After $a
            }
        }
        $rows += Compare-ValueMap -Section 'database' -Prefix 'setting:' `
                    -RefObj $ref.identity.database.settings -CurObj $cur.identity.database.settings
        $refDbs = @($ref.identity.database.databases); $curDbs = @($cur.identity.database.databases)
        foreach ($d in $refDbs) { if ($curDbs -notcontains $d) {
            $rows += New-DriftRow -Section 'database' -ChangeType 'REMOVED' -Key ('db:' + $d) -Before $d } }
        foreach ($d in $curDbs) { if ($refDbs -notcontains $d) {
            $rows += New-DriftRow -Section 'database' -ChangeType 'ADDED' -Key ('db:' + $d) -After $d } }
    }

    # -- registry config (Windows captures only) -----------------------------------
    if ($ref.identity.registryConfig -and $cur.identity.registryConfig) {
        $rows += Compare-ValueMap -Section 'registryConfig' -Prefix '' `
                    -RefObj $ref.identity.registryConfig.values -CurObj $cur.identity.registryConfig.values
    }

    # -- metrics: deltas, not drift ---------------------------------------------------
    $metricRows = @()
    $refMet = @{}; $curMet = @{}
    if ($ref.metrics) { foreach ($p in $ref.metrics.PSObject.Properties) {
        if ($p.Name -ne 'databaseSizesMB') { $refMet[$p.Name] = [string]$p.Value } } }
    if ($cur.metrics) { foreach ($p in $cur.metrics.PSObject.Properties) {
        if ($p.Name -ne 'databaseSizesMB') { $curMet[$p.Name] = [string]$p.Value } } }
    foreach ($k in @(@($refMet.Keys) + @($curMet.Keys) | Sort-Object -Unique)) {
        $b = ''; $a = ''; $delta = ''
        if ($refMet.ContainsKey($k)) { $b = $refMet[$k] }
        if ($curMet.ContainsKey($k)) { $a = $curMet[$k] }
        $bd = 0.0; $ad = 0.0
        if ([double]::TryParse($b, [ref]$bd) -and [double]::TryParse($a, [ref]$ad)) {
            $delta = ('{0:+0.##;-0.##;0}' -f ($ad - $bd))
        }
        $metricRows += [pscustomobject]@{ Metric=$k; Reference=$b; Current=$a; Delta=$delta }
    }
    $refSizes = $null; $curSizes = $null
    if ($ref.metrics) { $refSizes = $ref.metrics.databaseSizesMB }
    if ($cur.metrics) { $curSizes = $cur.metrics.databaseSizesMB }
    $dbNames = @()
    if ($refSizes) { $dbNames += @($refSizes.PSObject.Properties | ForEach-Object { $_.Name }) }
    if ($curSizes) { $dbNames += @($curSizes.PSObject.Properties | ForEach-Object { $_.Name }) }
    foreach ($k in @($dbNames | Sort-Object -Unique)) {
        $b = ''; $a = ''
        if ($refSizes -and $refSizes.PSObject.Properties[$k]) { $b = [string]$refSizes.$k }
        if ($curSizes -and $curSizes.PSObject.Properties[$k]) { $a = [string]$curSizes.$k }
        $delta = ''
        $bd = 0.0; $ad = 0.0
        if ([double]::TryParse($b, [ref]$bd) -and [double]::TryParse($a, [ref]$ad)) {
            $delta = ('{0:+0.##;-0.##;0}' -f ($ad - $bd))
        }
        $metricRows += [pscustomobject]@{ Metric=('db_size_mb:' + $k); Reference=$b; Current=$a; Delta=$delta }
    }

    return @{
        Rows      = @($rows | Sort-Object @{e={ switch ($_.Severity) {
                        'Critical' {0}; 'Warning' {1}; default {2} } }}, Section, Key)
        Metrics   = $metricRows
        Reference = $ref
        Current   = $cur
    }
}

# -----------------------------------------------------------------------------
#  Rendering + export
# -----------------------------------------------------------------------------
function Show-DriftReport {
    param([Parameter(Mandatory)]$Result, [int]$InfoCap = 40)

    $ref = $Result.Reference; $cur = $Result.Current
    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host '  Blueprint Drift Report' -ForegroundColor Cyan
    Write-Host ('  reference : {0}  {1}  ({2})' -f $ref.host, $ref.capturedUtc, $ref.platform) -ForegroundColor DarkCyan
    Write-Host ('  current   : {0}  {1}  ({2})' -f $cur.host, $cur.capturedUtc, $cur.platform) -ForegroundColor DarkCyan
    Write-Host '=======================================================' -ForegroundColor Cyan
    if ([string]$ref.host -ne [string]$cur.host) {
        Write-Host '  ! The two blueprints are from DIFFERENT hosts.' -ForegroundColor Yellow
    }

    $crit = @($Result.Rows | Where-Object { $_.Severity -eq 'Critical' })
    $warn = @($Result.Rows | Where-Object { $_.Severity -eq 'Warning' })
    $info = @($Result.Rows | Where-Object { $_.Severity -eq 'Info' })

    function Write-DriftRows($rows, $color) {
        foreach ($r in $rows) {
            $line = '  [{0,-8}] {1,-16} {2}' -f $r.ChangeType, $r.Section, $r.Key
            Write-Host $line -ForegroundColor $color
            if ($r.ChangeType -eq 'CHANGED') {
                Write-Host ('             {0}: {1}  ->  {2}' -f $r.Field, $r.Before, $r.After) -ForegroundColor DarkGray
            } elseif ($r.ChangeType -eq 'ADDED' -and $r.After) {
                Write-Host ('             {0}' -f $r.After) -ForegroundColor DarkGray
            } elseif ($r.ChangeType -eq 'REMOVED' -and $r.Before) {
                Write-Host ('             was: {0}' -f $r.Before) -ForegroundColor DarkGray
            }
        }
    }

    Write-Host ''
    Write-Host ('-- CRITICAL ({0}) --------------------------------------' -f $crit.Count) -ForegroundColor Red
    if ($crit.Count -eq 0) { Write-Host '  none' -ForegroundColor DarkGray } else { Write-DriftRows $crit 'Red' }

    Write-Host ''
    Write-Host ('-- WARNING ({0}) ---------------------------------------' -f $warn.Count) -ForegroundColor Yellow
    if ($warn.Count -eq 0) { Write-Host '  none' -ForegroundColor DarkGray } else { Write-DriftRows $warn 'Yellow' }

    Write-Host ''
    Write-Host ('-- INFO ({0}) ------------------------------------------' -f $info.Count) -ForegroundColor White
    if ($info.Count -eq 0) {
        Write-Host '  none' -ForegroundColor DarkGray
    } else {
        Write-DriftRows @($info | Select-Object -First $InfoCap) 'Gray'
        if ($info.Count -gt $InfoCap) {
            Write-Host ('  ... and {0} more Info row(s) - export to CSV for the full list.' -f ($info.Count - $InfoCap)) -ForegroundColor DarkGray
        }
    }

    Write-Host ''
    Write-Host '-- METRICS (deltas, not drift) ------------------------' -ForegroundColor Cyan
    foreach ($m in @($Result.Metrics)) {
        $suffix = ''
        if ($m.Delta -and $m.Delta -ne '0') { $suffix = ('  ({0})' -f $m.Delta) }
        Write-Host ('  {0,-28} {1,14} -> {2,14}{3}' -f $m.Metric, $m.Reference, $m.Current, $suffix) -ForegroundColor DarkCyan
    }

    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    if ($crit.Count -eq 0 -and $warn.Count -eq 0) {
        Write-Host '  RESULT: No drift beyond informational changes.' -ForegroundColor Green
    } else {
        Write-Host ('  RESULT: {0} critical, {1} warning, {2} info drift item(s).' -f
            $crit.Count, $warn.Count, $info.Count) -ForegroundColor $(if ($crit.Count -gt 0) { 'Red' } else { 'Yellow' })
        Write-Host '  Review, remediate or accept, then promote the new capture to baseline.' -ForegroundColor DarkCyan
    }
    Write-Host '=======================================================' -ForegroundColor Cyan

    return [pscustomobject]@{ Critical=$crit.Count; Warning=$warn.Count; Info=$info.Count }
}

function Export-DriftReport {
    param([Parameter(Mandatory)]$Result, [Parameter(Mandatory)][string]$Path)
    try {
        @($Result.Rows) |
            Select-Object Severity, Section, ChangeType, Key, Field, Before, After |
            Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8
        Write-Host ('  Drift rows exported to {0}' -f $Path) -ForegroundColor Green
    } catch {
        Write-Host ('  Export failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
    }
}
