# =============================================================================
#  Collector.ps1 - the $collector scriptblock (local + Invoke-Command runs).
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

# =============================================================================
#  THE COLLECTOR
#  Self-contained so it can run locally or via Invoke-Command against a
#  Windows host. Returns a hashtable: @{ Results=<pscustomobject[]>; Meta=@{} }
#  No dependency on anything outside this scriptblock.
# =============================================================================

$collector = {
    param(
        [object[]]$PortTable,
        [bool]$CheckRange   = $true,
        [int]$RangeLo       = 2500,
        [int]$RangeHi       = 3300,
        [hashtable]$Squatters = @{}
    )

    function Get-Listeners {
        $tcp = @{}; $udp = @{}; $fallback = $false; $collectError = ''

        if (Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue) {
            try {
                foreach ($c in @(Get-NetTCPConnection -State Listen -ErrorAction Stop)) {
                    $p = [int]$c.LocalPort
                    if (-not $tcp.ContainsKey($p)) { $tcp[$p] = @() }
                    if ($tcp[$p] -notcontains [int]$c.OwningProcess) { $tcp[$p] += [int]$c.OwningProcess }
                }
            } catch { $collectError = $_.Exception.Message }
            try {
                foreach ($u in @(Get-NetUDPEndpoint -ErrorAction Stop)) {
                    $p = [int]$u.LocalPort
                    if (-not $udp.ContainsKey($p)) { $udp[$p] = @() }
                    if ($udp[$p] -notcontains [int]$u.OwningProcess) { $udp[$p] += [int]$u.OwningProcess }
                }
            } catch { if (-not $collectError) { $collectError = $_.Exception.Message } }
        }

        # An empty TCP table means the modern path is missing or failed. A host
        # with zero TCP listeners is not a real scenario, so fall back rather
        # than reporting every port FREE (which would read as "no conflicts").
        if ($tcp.Count -eq 0) {
            if (-not (Get-Command netstat -ErrorAction SilentlyContinue)) {
                return @{ TCP=$tcp; UDP=$udp; Fallback=$false
                          Error=("Could not enumerate listeners. " + $collectError).Trim() }
            }
            $fallback = $true
            try {
                foreach ($line in (netstat -ano)) {
                    $t = $line.Trim()
                    if ($t -match '^TCP\s+\S+:(\d+)\s+\S+\s+LISTENING\s+(\d+)$') {
                        $p = [int]$Matches[1]; $procId = [int]$Matches[2]
                        if (-not $tcp.ContainsKey($p)) { $tcp[$p] = @() }
                        if ($tcp[$p] -notcontains $procId) { $tcp[$p] += $procId }
                    } elseif ($t -match '^UDP\s+\S+:(\d+)\s+\S+\s+(\d+)$') {
                        $p = [int]$Matches[1]; $procId = [int]$Matches[2]
                        if (-not $udp.ContainsKey($p)) { $udp[$p] = @() }
                        if ($udp[$p] -notcontains $procId) { $udp[$p] += $procId }
                    }
                }
            } catch { $collectError = $_.Exception.Message }
            if ($tcp.Count -eq 0) {
                return @{ TCP=$tcp; UDP=$udp; Fallback=$true
                          Error=("Listener enumeration returned nothing. " + $collectError).Trim() }
            }
        }

        return @{ TCP = $tcp; UDP = $udp; Fallback = $fallback; Error = '' }
    }

    function Get-Processes {
        $map = @{}; $svcByPid = @{}
        try {
            foreach ($s in @(Get-CimInstance Win32_Service -ErrorAction Stop |
                             Where-Object { $_.ProcessId -and $_.ProcessId -gt 0 })) {
                $k = [int]$s.ProcessId
                if (-not $svcByPid.ContainsKey($k)) { $svcByPid[$k] = @() }
                $svcByPid[$k] += $s.Name
            }
        } catch { }
        foreach ($p in @(Get-Process -ErrorAction SilentlyContinue)) {
            $path = ''; $company = ''
            try { $path    = $p.Path }    catch { }
            try { $company = $p.Company } catch { }
            $map[[int]$p.Id] = @{
                Name     = $p.ProcessName
                Path     = $path
                Company  = $company
                Services = @(if ($svcByPid.ContainsKey([int]$p.Id)) { $svcByPid[[int]$p.Id] })
            }
        }
        return $map
    }

    function Get-Class($procId, $map) {
        if ($procId -eq 0 -or $procId -eq 4) { return 'Windows' }
        if (-not $map.ContainsKey([int]$procId)) { return 'Unknown' }
        $i   = $map[[int]$procId]
        $hay = '{0} {1} {2} {3}' -f $i.Name, $i.Path, $i.Company, ($i.Services -join ' ')
        if ($hay -match '(?i)veeam') { return 'Veeam' }
        if ($i.Name -match '(?i)^(postgres|postmaster|sqlservr|mysqld|mariadbd)$') { return 'Database' }
        if ($i.Name -match '(?i)^(System|Idle|svchost|lsass|services|spoolsv|wininit|dns|Registry|dfsrs|inetinfo)$') { return 'Windows' }
        if ($i.Path -and $i.Path -match '(?i)^[A-Z]:\\Windows\\') { return 'Windows' }
        return 'ThirdParty'
    }

    function Get-Owner($procId, $map) {
        if ($procId -eq 0 -or $procId -eq 4) { return 'System (kernel)' }
        if (-not $map.ContainsKey([int]$procId)) { return "PID $procId (unresolved - run elevated)" }
        $i = $map[[int]$procId]
        $d = '{0} (PID {1})' -f $i.Name, $procId
        if ($i.Services.Count -gt 0) { $d += ' svc:' + ($i.Services -join ',') }
        if ($i.Path) { $d += ' [' + $i.Path + ']' }
        return $d
    }

    $elevated = $false
    try {
        $elevated = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                    ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { }

    $listeners = Get-Listeners
    $procs     = Get-Processes
    $results   = @()

    foreach ($entry in $PortTable) {
        $protos = @()
        if ([string]$entry.Proto -like '*TCP*') { $protos += 'TCP' }
        if ([string]$entry.Proto -like '*UDP*') { $protos += 'UDP' }

        foreach ($proto in $protos) {
            $table = if ($proto -eq 'TCP') { $listeners.TCP } else { $listeners.UDP }
            $port  = [int]$entry.Port
            $pids  = @(if ($table.ContainsKey($port)) { $table[$port] })

            if ($pids.Count -eq 0) {
                $results += [pscustomobject]@{
                    Port=$port; Protocol=$proto; Status='FREE'; OwnerType=''; Owner=''
                    Component=[string]$entry.Component; Verified=[bool]$entry.Verified
                    Notes=[string]$entry.Notes; InRange=$false
                }
                continue
            }
            foreach ($procId in $pids) {
                $cls = Get-Class $procId $procs
                $st  = if ($cls -eq 'Unknown') { 'UNKNOWN' }
                       elseif ($cls -eq [string]$entry.ExpectedOwner) { 'OK' }
                       else { 'CONFLICT' }
                $results += [pscustomobject]@{
                    Port=$port; Protocol=$proto; Status=$st; OwnerType=$cls
                    Owner=(Get-Owner $procId $procs)
                    Component=[string]$entry.Component; Verified=[bool]$entry.Verified
                    Notes=[string]$entry.Notes; InRange=$false
                }
            }
        }
    }

    if ($CheckRange) {
        foreach ($port in @($listeners.TCP.Keys | Where-Object { $_ -ge $RangeLo -and $_ -le $RangeHi } | Sort-Object)) {
            foreach ($procId in $listeners.TCP[[int]$port]) {
                $cls = Get-Class $procId $procs
                if ($cls -eq 'Veeam') { continue }
                $note = if ($Squatters.ContainsKey([int]$port)) { $Squatters[[int]$port] } else { '' }
                $rangeStatus = if ($cls -eq 'Unknown') { 'UNKNOWN' } else { 'CONFLICT' }
                $results += [pscustomobject]@{
                    Port=[int]$port; Protocol='TCP'
                    Status=$rangeStatus
                    OwnerType=$cls; Owner=(Get-Owner $procId $procs)
                    Component=("Data transfer range {0}-{1}" -f $RangeLo, $RangeHi)
                    Verified=$true; Notes=$note; InRange=$true
                }
            }
        }
    }

    $veeamSvcs = @()
    try {
        $veeamSvcs = @(Get-Service -ErrorAction SilentlyContinue |
                       Where-Object { $_.Name -like 'Veeam*' -or $_.DisplayName -like 'Veeam*' } |
                       ForEach-Object { [pscustomobject]@{ Name=$_.Name; DisplayName=$_.DisplayName; Status=[string]$_.Status } })
    } catch { }

    $osCaption = ''
    try { $osCaption = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).Caption } catch { }

    return @{
        Results = $results
        Meta    = @{
            Host         = $env:COMPUTERNAME
            OS           = $osCaption
            Elevated     = $elevated
            Fallback     = $listeners.Fallback
            CollectError = [string]$listeners.Error
            RangeChecked = $CheckRange
            TcpCount     = $listeners.TCP.Count
            UdpCount     = $listeners.UDP.Count
            ProcCount    = $procs.Count
            Services     = $veeamSvcs
            Collected    = (Get-Date)
        }
    }
}
