# =============================================================================
#  Menu.ps1 - the interactive menu.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

function Invoke-InteractiveMenu {

$menuTarget = ''
$optEM = $false; $optCC = $false; $optWan = $false
$quit  = $false

while (-not $quit) {

    $vbrDisplay = if ($script:VbrConnected) {
        '{0}  [{1}]' -f $script:VbrServerName, $script:VbrPlatform
    } else { '(not connected)' }
    $targetDisplay = if ($menuTarget) { $menuTarget } else { '(not set)' }
    $extras = @()
    if ($optEM)  { $extras += 'EM' }
    if ($optCC)  { $extras += 'CloudConnect' }
    if ($optWan) { $extras += 'WAN' }
    $extrasDisplay = if ($extras.Count -gt 0) { $extras -join ', ' } else { 'none' }

    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host '  Veeam Port Diagnostic' -ForegroundColor Cyan
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ('  This host      : {0}' -f $env:COMPUTERNAME)  -ForegroundColor White
    Write-Host ('  VBR connection : {0}' -f $vbrDisplay)        -ForegroundColor White
    Write-Host ('  Scan target    : {0}' -f $targetDisplay)     -ForegroundColor White
    Write-Host ('  Extra profiles : {0}' -f $extrasDisplay)     -ForegroundColor White
    Write-Host ''
    Write-Host '  VBR SERVER' -ForegroundColor Magenta
    Write-Host '  [1] Connect to VBR server and run the conflict check' -ForegroundColor Green
    Write-Host '       Connect-VBRServer, detect Windows vs VSA, then check that host'
    Write-Host '  [2] Show managed servers (Get-VBRServer)' -ForegroundColor Green
    Write-Host '  [3] Check a named Windows host directly (no VBR API)' -ForegroundColor Green
    Write-Host '  [4] Linux / VSA - push over SSH, or emit the script' -ForegroundColor Green
    Write-Host '  [5] Disconnect from VBR' -ForegroundColor Yellow
    Write-Host '  -----------------------------------------------'
    Write-Host '  THIS MACHINE' -ForegroundColor Magenta
    Write-Host '  [6] Port conflict check on this machine' -ForegroundColor Green
    Write-Host '  [7] Export results to CSV (last check, or the whole session)' -ForegroundColor Green
    Write-Host '  [8] Toggle extra profiles (EM / Cloud Connect / WAN)' -ForegroundColor Yellow
    Write-Host '  -----------------------------------------------'
    Write-Host '  REACHABILITY' -ForegroundColor Magenta
    Write-Host '  [9] Set / change scan target' -ForegroundColor Yellow
    Write-Host '  [10] Core ports only (adds EM ports when the EM profile is on)' -ForegroundColor Green
    Write-Host '  [11] Core ports + full dynamic range (2500-3300)' -ForegroundColor Green
    Write-Host '  [12] Core ports + custom range' -ForegroundColor Green
    Write-Host '  [13] Remote server probe - DNS check + ports + HTTP, no login' -ForegroundColor Green
    Write-Host '  -----------------------------------------------'
    Write-Host '  [Q] Quit' -ForegroundColor Red
    Write-Host ''

    $choice = (Read-Host '  Select').Trim().ToUpper()

    switch ($choice) {

        '1' {
            $srv = (Read-Host '  VBR server hostname or IP').Trim()
            if (-not $srv) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $pRaw = (Read-Host '  Port [Enter=443, use 9392 for v12 and older]').Trim()
            $prt  = if ($pRaw -match '^\d+$') { [int]$pRaw } else { 443 }
            $ac   = (Read-Host '  Accept the server TLS certificate? [Y/n]').Trim().ToUpper()
            Invoke-VbrConnectAndCheck -Server $srv -Port $prt -AcceptCert:($ac -ne 'N') `
                -WithEM:$optEM -WithCC:$optCC -WithWan:$optWan
            Write-Footer
        }

        '2' { Show-VbrInfrastructure; Write-Footer }

        '3' {
            $cn = (Read-Host '  Windows host to check').Trim()
            if (-not $cn) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $prompt = if ($script:VbrCred) {
                '  Credentials: [Enter] reuse the VBR credential, [C] current Windows user, [N] prompt me'
            } else {
                '  Credentials: [Enter] current Windows user, [N] prompt me'
            }
            Write-Host $prompt -ForegroundColor DarkCyan
            $ans = (Read-Host '  Choice').Trim().ToUpper()
            $cred = switch ($ans) {
                'N'     { Get-Credential -Message "Admin on $cn" }
                'C'     { $null }
                default { if ($script:VbrCred) { $script:VbrCred } else { $null } }
            }
            Write-Banner 'Veeam Port Conflict Check' $cn
            $payload = Invoke-RemoteCollector -Computer $cn -Credential $cred `
                -WithEM:$optEM -WithCC:$optCC -WithWan:$optWan
            if ($payload) { Save-Results $payload; Show-ConflictReport $payload }
            Write-Footer
        }

        '4' { Invoke-VsaWorkflow -ServerName $script:VbrServerName; Write-Footer }

        '5' { Disconnect-Vbr }

        '6' {
            Write-Banner 'Veeam Port Conflict Check' $env:COMPUTERNAME
            $payload = Invoke-LocalCollector -WithEM:$optEM -WithCC:$optCC -WithWan:$optWan
            Save-Results $payload
            Show-ConflictReport $payload
            Write-Footer
        }

        '7' {
            Write-Host ''
            Write-Host ('  [Enter] last check only ({0})' -f
                $(if ($script:LastResultHost) { $script:LastResultHost } else { 'nothing yet' })) -ForegroundColor Gray
            Write-Host ('  [A]     every check this session ({0} rows, mixed Windows + Linux)' -f
                $script:AllResults.Count) -ForegroundColor Gray
            $which = (Read-Host '  Choice').Trim().ToUpper()

            $tag = if ($which -eq 'A') { 'AllHosts' }
                   elseif ($script:LastResultHost) { $script:LastResultHost }
                   else { $env:COMPUTERNAME }
            $default = Join-Path $env:TEMP ('VeeamPortCheck_{0}_{1}.csv' -f
                        $tag, (Get-Date -Format 'yyyyMMdd_HHmmss'))
            $path = (Read-Host "  CSV path [Enter=$default]").Trim()
            if (-not $path) { $path = $default }
            if ($which -eq 'A') { Export-AllResults $path } else { Export-Results $path }
        }

        '8' {
            Write-Host ''
            Write-Host '  [A] Enterprise Manager  [B] Cloud Connect  [C] WAN Accelerator' -ForegroundColor DarkCyan
            $t = (Read-Host '  Toggle which').Trim().ToUpper()
            switch ($t) {
                'A' { $optEM  = -not $optEM;  Write-Host "  Enterprise Manager: $optEM" -ForegroundColor DarkCyan }
                'B' { $optCC  = -not $optCC;  Write-Host "  Cloud Connect: $optCC"      -ForegroundColor DarkCyan }
                'C' { $optWan = -not $optWan; Write-Host "  WAN Accelerator: $optWan"   -ForegroundColor DarkCyan }
                default { Write-Host '  No change.' -ForegroundColor Red }
            }
        }

        '9' {
            $val = (Read-Host '  Enter hostname or IP').Trim()
            if ($val) { $menuTarget = $val; Write-Host "  Target set to: $menuTarget" -ForegroundColor DarkCyan }
        }

        '10' {
            $t = Ensure-Target $menuTarget
            if ($t) { $menuTarget = $t; Write-Banner 'Veeam Port Reachability' $t; Invoke-CoreScan $t -IncludeEM:$optEM; Write-Footer }
        }

        '11' {
            $t = Ensure-Target $menuTarget
            if ($t) {
                $menuTarget = $t; Write-Banner 'Veeam Port Reachability' $t
                Invoke-CoreScan $t -IncludeEM:$optEM; Invoke-RangeScan $t 2500 3300; Write-Footer
            }
        }

        '12' {
            Write-Host ''
            Write-Host '  Enter the sub-range to scan (within 2500-3300):' -ForegroundColor DarkCyan
            $s = Read-PortNumber 'Start port' 2500 3300 2500
            $e = Read-PortNumber 'End port  ' $s   3300 3300
            $t = Ensure-Target $menuTarget
            if ($t) {
                $menuTarget = $t
                Write-Host ''
                Write-Host ('  About to scan {0} ports ({1}-{2}) on {3}.' -f ($e-$s+1), $s, $e, $t) -ForegroundColor DarkCyan
                $confirm = (Read-Host '  Press Enter to start, or [B] to go back').Trim().ToUpper()
                if ($confirm -ne 'B') {
                    Write-Banner 'Veeam Port Reachability' $t
                    Invoke-CoreScan $t -IncludeEM:$optEM; Invoke-RangeScan $t $s $e; Write-Footer
                }
            }
        }

        '13' {
            Write-Host ''
            Write-Host '  Probes the server from here with no login: DNS lookup (forward +' -ForegroundColor DarkCyan
            Write-Host '  reverse), TCP port tests, and an HTTP(S) check on the web ports.' -ForegroundColor DarkCyan
            $default = if ($menuTarget) { " [Enter=$menuTarget]" } else { '' }
            $val = (Read-Host "  Hostname or IP address$default").Trim()
            if (-not $val -and $menuTarget) { $val = $menuTarget }
            if (-not $val) { Write-Host '  No target entered.' -ForegroundColor Red; continue }
            $menuTarget = $val
            Invoke-RemoteProbe $val -IncludeEM:$optEM
            Write-Footer
        }

        'Q' { $quit = $true }

        default { Write-Host '  Invalid choice.' -ForegroundColor Red }
    }
}
}
