# =============================================================================
#  Blueprint.ps1 - capture orchestration and the blueprint document model.
#
#  Dot-sourced by veeam-blueprint.ps1 (and harmlessly by portest3.ps1).
#
#  A blueprint is one JSON document per capture:
#    blueprints\<host>\<yyyyMMdd_HHmmss>_blueprint.json
#    blueprints\<host>\baseline.json          (the promoted reference copy)
#
#  The document splits IDENTITY (compared by the drift engine) from METRICS
#  (sizes, counts, uptime - reported but never diffed as drift). Volatile
#  values in identity sections would make every drift report 90% noise.
# =============================================================================

$script:BlueprintScriptName = 'veeam-blueprint.sh'
$script:BlueprintSchema     = 'veeam-blueprint/1'

function Get-BlueprintScriptPath {
    $p = Join-Path $script:ScriptDir $script:BlueprintScriptName
    if (Test-Path $p) { return $p }
    return $null
}

# -----------------------------------------------------------------------------
#  Parse veeam-blueprint.sh --report output into the same payload shape the
#  Windows $blueprintCollector returns.
# -----------------------------------------------------------------------------
function ConvertFrom-LinuxBlueprint {
    param([Parameter(Mandatory)][AllowEmptyCollection()][string[]]$Lines)

    $meta = @{ Host='(unknown)'; Os=''; Kernel=''; Arch=''; Elevated=$false; DbAccess=$false
               Captured=(Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'); Notes=@() }
    $products = @(); $services = @(); $listeners = @(); $trunk = @(); $rconn = @()
    $certs = @(); $firewall = @(); $cfg = @(); $notes = @()
    $database = @{ Engine=''; Version=''; DataDir=''; Settings=@{}; SizesMB=@{}; ConnectionCount=-1; DataDirMB=-1 }
    $metrics = @{}
    $sawEnd = $false

    foreach ($raw in $Lines) {
        if ($null -eq $raw) { continue }
        $line = ([string]$raw).TrimEnd()
        if (-not $line.StartsWith('#')) { continue }
        $p = $line.Split('|')

        switch ($p[0]) {
            '#META' {
                if ($p.Count -ge 9) {
                    $meta.Host     = $p[2]; $meta.Os = $p[3]; $meta.Kernel = $p[4]; $meta.Arch = $p[5]
                    $meta.Elevated = ($p[6] -eq '1')
                    $meta.DbAccess = ($p[7] -eq '1')
                    $meta.Captured = $p[8]
                }
            }
            '#VEEAMPKG' {
                if ($p.Count -ge 4) { $products += @{ Name=$p[1]; Version=$p[2]; Arch=$p[3] } }
            }
            '#SVC' {
                if ($p.Count -ge 9) {
                    $services += @{
                        Name=$p[1]; DisplayName=$p[2]; State=$p[3]; SubState=$p[4]
                        StartType=$p[5]; Account=$p[6]; Path=$p[7]; UnitHash=$p[8]
                    }
                }
            }
            '#LISTEN' {
                if ($p.Count -ge 9) {
                    $listeners += @{
                        Proto=$p[1]; Scope=$p[2]; Address=$p[3]; Port=[int]($p[4] -as [int])
                        OwnerClass=$p[5]; Process=$p[6]; Service=$p[7]; Exe=$p[8]
                    }
                }
            }
            '#TRUNK' {
                if ($p.Count -ge 7) {
                    $trunk += @{
                        FrontProcess=$p[1]; FrontService=$p[2]; BackPort=[int]($p[3] -as [int])
                        BackProcess=$p[4]; BackService=$p[5]; Connections=[int]($p[6] -as [int])
                    }
                }
            }
            '#RCONN' {
                if ($p.Count -ge 7) {
                    $rconn += @{
                        RemoteHost=$p[1]; RemotePort=[int]($p[2] -as [int]); Direction=$p[3]
                        Process=$p[4]; Service=$p[5]; Connections=[int]($p[6] -as [int])
                    }
                }
            }
            '#DBINFO' { if ($p.Count -ge 4) { $database.Engine=$p[1]; $database.Version=$p[2]; $database.DataDir=$p[3] } }
            '#DBSET'  { if ($p.Count -ge 3) { $database.Settings[$p[1]] = $p[2] } }
            '#DBSIZE' { if ($p.Count -ge 3) { $database.SizesMB[$p[1]] = [int]($p[2] -as [int]) } }
            '#DBCONN' { if ($p.Count -ge 2) { $database.ConnectionCount = [int]($p[1] -as [int]) } }
            '#CFG' {
                if ($p.Count -ge 4) { $cfg += @{ Path=$p[1]; Hash=$p[2]; Bytes=[long]($p[3] -as [long]) } }
            }
            '#CERT' {
                if ($p.Count -ge 6) {
                    $certs += @{ Binding=('port:'+$p[1]); Subject=$p[2]; Issuer=$p[3]; NotAfter=$p[4]; Thumbprint=$p[5] }
                }
            }
            '#FWZONE' {
                if ($p.Count -ge 4) { $firewall += @{ Name=$p[1]; Hash=$p[2]; Summary=$p[3] } }
            }
            '#METRIC' { if ($p.Count -ge 3 -and $p[1]) { $metrics[$p[1]] = $p[2] } }
            '#NOTE'   { if ($p.Count -ge 2) { $notes += $p[1] } }
            '#END'    { $sawEnd = $true }
        }
    }

    if (-not $sawEnd) {
        $notes += 'The remote blueprint was truncated - no #END marker. Treat this capture as incomplete.'
    }
    $meta.Notes = @($notes)
    if ($database.ConnectionCount -ge 0) { $metrics['db_connections'] = $database.ConnectionCount }

    return @{
        Platform='Linux'; Meta=$meta; VeeamProducts=$products; Services=$services
        Listeners=$listeners; Trunk=$trunk; RemoteEndpoints=$rconn; Database=$database
        Certificates=$certs; Firewall=$firewall; ConfigHashes=$cfg
        RegistryConfig=$null; Metrics=$metrics; Complete=$sawEnd
    }
}

# -----------------------------------------------------------------------------
#  Normalise a collector payload (either platform) into the blueprint document.
#  Arrays are sorted so two captures of an unchanged host serialise to
#  identical JSON - a plain file diff is then also meaningful.
# -----------------------------------------------------------------------------
function New-BlueprintDocument {
    param([Parameter(Mandatory)][hashtable]$Payload)

    function Sorted-Map($h) {
        $o = [ordered]@{}
        if ($h) { foreach ($k in @($h.Keys | Sort-Object)) { $o[[string]$k] = $h[$k] } }
        return $o
    }

    $doc = [ordered]@{
        schema      = $script:BlueprintSchema
        capturedUtc = [string]$Payload.Meta.Captured
        host        = [string]$Payload.Meta.Host
        platform    = [string]$Payload.Platform
        tier        = [ordered]@{
            elevated = [bool]$Payload.Meta.Elevated
            dbAccess = [bool]$Payload.Meta.DbAccess
            complete = if ($Payload.ContainsKey('Complete')) { [bool]$Payload.Complete } else { $true }
            notes    = @($Payload.Meta.Notes)
        }
        identity    = [ordered]@{}
        metrics     = [ordered]@{}
    }

    $doc.identity.os = [ordered]@{
        caption = [string]$Payload.Meta.Os
        kernel  = [string]$Payload.Meta.Kernel
        arch    = [string]$Payload.Meta.Arch
    }

    $doc.identity.veeamProducts = @(@($Payload.VeeamProducts) | Where-Object { $_ } |
        Sort-Object { [string]$_.Name } | ForEach-Object {
            [ordered]@{ name=[string]$_.Name; version=[string]$_.Version; arch=[string]$_.Arch } })

    $doc.identity.services = @(@($Payload.Services) | Where-Object { $_ } |
        Sort-Object { [string]$_.Name } | ForEach-Object {
            [ordered]@{
                name=[string]$_.Name; displayName=[string]$_.DisplayName; state=[string]$_.State
                subState=[string]$_.SubState; startType=[string]$_.StartType
                account=[string]$_.Account; path=[string]$_.Path; binaryHash=[string]$_.UnitHash
            } })

    $doc.identity.listeners = @(@($Payload.Listeners) | Where-Object { $_ } |
        Sort-Object { '{0}|{1}|{2:d6}|{3}' -f [string]$_.Proto, [string]$_.Address, [int]$_.Port, [string]$_.Process } |
        ForEach-Object {
            [ordered]@{
                proto=[string]$_.Proto; scope=[string]$_.Scope; address=[string]$_.Address
                port=[int]$_.Port; ownerClass=[string]$_.OwnerClass; process=[string]$_.Process
                service=[string]$_.Service; exe=[string]$_.Exe
            } })

    $doc.identity.trunk = @(@($Payload.Trunk) | Where-Object { $_ } |
        Sort-Object { '{0:d6}|{1}' -f [int]$_.BackPort, [string]$_.FrontProcess } | ForEach-Object {
            [ordered]@{
                frontProcess=[string]$_.FrontProcess; frontService=[string]$_.FrontService
                backPort=[int]$_.BackPort; backProcess=[string]$_.BackProcess
                backService=[string]$_.BackService; connections=[int]$_.Connections
            } })

    $doc.identity.remoteEndpoints = @(@($Payload.RemoteEndpoints) | Where-Object { $_ } |
        Sort-Object { '{0}|{1}|{2:d6}|{3}' -f [string]$_.Direction, [string]$_.RemoteHost, [int]$_.RemotePort, [string]$_.Process } |
        ForEach-Object {
            [ordered]@{
                direction=[string]$_.Direction; remoteHost=[string]$_.RemoteHost
                remotePort=[int]$_.RemotePort; process=[string]$_.Process
                service=[string]$_.Service; connections=[int]$_.Connections
            } })

    $dbSizes = if ($Payload.Database -and $Payload.Database.SizesMB) { $Payload.Database.SizesMB } else { @{} }
    $doc.identity.database = [ordered]@{
        engine    = [string]$Payload.Database.Engine
        version   = [string]$Payload.Database.Version
        dataDir   = [string]$Payload.Database.DataDir
        settings  = (Sorted-Map $Payload.Database.Settings)
        databases = @(@($dbSizes.Keys) | Sort-Object | ForEach-Object { [string]$_ })
    }

    $doc.identity.configHashes = @(@($Payload.ConfigHashes) | Where-Object { $_ } |
        Sort-Object { [string]$_.Path } | ForEach-Object {
            [ordered]@{ path=[string]$_.Path; hash=[string]$_.Hash; bytes=[long]$_.Bytes } })

    $doc.identity.certificates = @(@($Payload.Certificates) | Where-Object { $_ } |
        Sort-Object { '{0}|{1}' -f [string]$_.Binding, [string]$_.Thumbprint } | ForEach-Object {
            [ordered]@{
                binding=[string]$_.Binding; subject=[string]$_.Subject; issuer=[string]$_.Issuer
                notAfter=[string]$_.NotAfter; thumbprint=[string]$_.Thumbprint
            } })

    $doc.identity.firewall = @(@($Payload.Firewall) | Where-Object { $_ } |
        Sort-Object { [string]$_.Name } | ForEach-Object {
            [ordered]@{ name=[string]$_.Name; hash=[string]$_.Hash; summary=[string]$_.Summary } })

    if ($Payload.RegistryConfig) {
        $doc.identity.registryConfig = [ordered]@{
            values = (Sorted-Map $Payload.RegistryConfig.Values)
            hash   = [string]$Payload.RegistryConfig.Hash
        }
    } else {
        $doc.identity.registryConfig = $null
    }

    # Topology declared by the VBR API (filled in by Add-VbrTopologyToBlueprint
    # when a VBR connection exists at capture time; empty otherwise).
    $doc.identity.vbrTopology = @()

    $doc.metrics = Sorted-Map $Payload.Metrics
    $doc.metrics.databaseSizesMB = Sorted-Map $dbSizes

    return $doc
}

# -----------------------------------------------------------------------------
#  Declared topology from the VBR API (optional enrichment). Uses the existing
#  VBR connection from Vbr.ps1; a cmdlet that does not exist in the connected
#  module version is skipped silently.
# -----------------------------------------------------------------------------
function Add-VbrTopologyToBlueprint {
    param([Parameter(Mandatory)]$Document)

    if (-not $script:VbrConnected) { return $Document }
    $topo = @()
    $sources = @(
        @{ Cmd='Get-VBRServer';            Role='ManagedServer' }
        @{ Cmd='Get-VBRBackupProxy';       Role='BackupProxy' }
        @{ Cmd='Get-VBRBackupRepository';  Role='Repository' }
        @{ Cmd='Get-VBRWANAccelerator';    Role='WanAccelerator' }
        @{ Cmd='Get-VBRTapeServer';        Role='TapeServer' }
    )
    foreach ($s in $sources) {
        if (-not (Get-Command $s.Cmd -ErrorAction SilentlyContinue)) { continue }
        try {
            foreach ($o in @(& $s.Cmd -ErrorAction Stop)) {
                $t = ''; try { $t = [string]$o.Type } catch { }
                $topo += [ordered]@{ role=[string]$s.Role; name=[string]$o.Name; type=$t }
            }
        } catch { }
    }
    $Document.identity.vbrTopology = @($topo | Sort-Object { '{0}|{1}' -f $_.role, $_.name })
    Write-Host ('  VBR API topology: {0} object(s) recorded in the blueprint.' -f @($topo).Count) -ForegroundColor DarkCyan
    return $Document
}

# -----------------------------------------------------------------------------
#  Storage: save, list, baseline promotion
# -----------------------------------------------------------------------------
function Get-BlueprintHostDir {
    param([Parameter(Mandatory)][string]$OutDir, [Parameter(Mandatory)][string]$HostName)
    return (Join-Path $OutDir (($HostName -replace '[^\w.\-]', '_').ToLower()))
}

function Save-Blueprint {
    param([Parameter(Mandatory)]$Document, [Parameter(Mandatory)][string]$OutDir)
    try {
        $hostDir = Get-BlueprintHostDir -OutDir $OutDir -HostName $Document.host
        if (-not (Test-Path $hostDir)) { New-Item -ItemType Directory -Path $hostDir -Force -ErrorAction Stop | Out-Null }
        $file = Join-Path $hostDir ('{0}_blueprint.json' -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
        $Document | ConvertTo-Json -Depth 12 | Set-Content -Path $file -Encoding UTF8 -ErrorAction Stop
        Write-Host ('  Blueprint saved: {0}' -f $file) -ForegroundColor Green
        $baseline = Join-Path $hostDir 'baseline.json'
        if (-not (Test-Path $baseline)) {
            Copy-Item $file $baseline -ErrorAction Stop
            Write-Host '  No baseline existed for this host - this capture IS now the baseline.' -ForegroundColor Cyan
        }
        return $file
    } catch {
        Write-Host ('  Could not save the blueprint: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}

function Get-BlueprintBaselinePath {
    param([Parameter(Mandatory)][string]$OutDir, [Parameter(Mandatory)][string]$HostName)
    $p = Join-Path (Get-BlueprintHostDir -OutDir $OutDir -HostName $HostName) 'baseline.json'
    if (Test-Path $p) { return $p }
    return $null
}

function Set-BlueprintBaseline {
    # Promotion is DELIBERATELY explicit: after an upgrade you review the drift
    # first, then promote - never auto-promote, or drift becomes the new normal.
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path $Path)) {
        Write-Host ('  Not found: {0}' -f $Path) -ForegroundColor Red; return $false
    }
    $baseline = Join-Path (Split-Path $Path -Parent) 'baseline.json'
    try {
        Copy-Item $Path $baseline -Force -ErrorAction Stop
        Write-Host ('  Promoted to baseline: {0}' -f $baseline) -ForegroundColor Green
        return $true
    } catch {
        Write-Host ('  Promotion failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $false
    }
}

# Numbered picker over every blueprint in the store. Returns a full path, or
# $null on cancel. A typed path is accepted too, for files outside the store.
function Select-BlueprintFile {
    param(
        [Parameter(Mandatory)][string]$OutDir,
        [string]$Prompt = 'Select a blueprint',
        [switch]$ExcludeBaseline
    )
    $files = @()
    if (Test-Path $OutDir) {
        foreach ($hostDir in @(Get-ChildItem $OutDir -Directory -ErrorAction SilentlyContinue | Sort-Object Name)) {
            foreach ($f in @(Get-ChildItem $hostDir.FullName -Filter '*.json' -File -ErrorAction SilentlyContinue | Sort-Object Name)) {
                if ($ExcludeBaseline -and $f.Name -eq 'baseline.json') { continue }
                $files += $f
            }
        }
    }
    Write-Host ''
    Write-Host ('  {0}' -f $Prompt) -ForegroundColor DarkCyan
    if (@($files).Count -eq 0) {
        Write-Host ('  Nothing stored under {0} yet.' -f $OutDir) -ForegroundColor DarkCyan
        $p = (Read-Host '  Path to a blueprint JSON [Enter = cancel]').Trim()
        if (-not $p) { return $null }
        if (Test-Path $p) { return $p }
        Write-Host '  Not found.' -ForegroundColor Red
        return $null
    }
    $i = 0
    foreach ($f in $files) {
        $i++
        $hostName = Split-Path (Split-Path $f.FullName -Parent) -Leaf
        $tag = ''
        if ($f.Name -eq 'baseline.json') { $tag = '   <- BASELINE' }
        Write-Host ('  [{0,2}] {1}  {2}{3}' -f $i, $hostName, $f.Name, $tag) -ForegroundColor Green
    }
    $ans = (Read-Host '  Select a number, type a path, or [Enter] to cancel').Trim()
    if (-not $ans) { return $null }
    if ($ans -match '^\d+$') {
        $n = [int]$ans
        if ($n -ge 1 -and $n -le @($files).Count) { return $files[$n - 1].FullName }
        Write-Host '  Not one of the listed numbers.' -ForegroundColor Red
        return $null
    }
    if (Test-Path $ans) { return $ans }
    Write-Host '  Not found.' -ForegroundColor Red
    return $null
}

function Show-BlueprintStore {
    param([Parameter(Mandatory)][string]$OutDir)
    if (-not (Test-Path $OutDir)) {
        Write-Host ('  No blueprint store yet at {0}' -f $OutDir) -ForegroundColor DarkCyan; return
    }
    foreach ($hostDir in @(Get-ChildItem $OutDir -Directory -ErrorAction SilentlyContinue)) {
        Write-Host ('  {0}' -f $hostDir.Name) -ForegroundColor White
        foreach ($f in @(Get-ChildItem $hostDir.FullName -Filter '*.json' -ErrorAction SilentlyContinue | Sort-Object Name)) {
            $tag = if ($f.Name -eq 'baseline.json') { ' <- BASELINE' } else { '' }
            Write-Host ('    {0}{1}' -f $f.Name, $tag) -ForegroundColor DarkCyan
        }
    }
}

# -----------------------------------------------------------------------------
#  Rendering a capture summary
# -----------------------------------------------------------------------------
function Show-BlueprintSummary {
    param([Parameter(Mandatory)]$Document)

    Write-Host ''
    Write-Rule 'Blueprint Summary'
    Write-Host ('  Host      : {0}  ({1})' -f $Document.host, $Document.platform) -ForegroundColor White
    Write-Host ('  Captured  : {0}' -f $Document.capturedUtc) -ForegroundColor DarkCyan
    Write-Host ('  OS        : {0}  {1}' -f $Document.identity.os.caption, $Document.identity.os.kernel) -ForegroundColor DarkCyan
    $tierBits = @()
    if ($Document.tier.elevated) { $tierBits += 'elevated' } else { $tierBits += 'NOT ELEVATED' }
    if ($Document.tier.dbAccess) { $tierBits += 'db access' } else { $tierBits += 'no db access' }
    $tierColor = if ($Document.tier.elevated -and $Document.tier.dbAccess) { 'Green' } else { 'Yellow' }
    Write-Host ('  Tier      : {0}' -f ($tierBits -join ', ')) -ForegroundColor $tierColor
    Write-Host ('  Products  : {0}   Services: {1}   Listeners: {2}' -f
        @($Document.identity.veeamProducts).Count,
        @($Document.identity.services).Count,
        @($Document.identity.listeners).Count) -ForegroundColor DarkCyan
    Write-Host ('  Trunk map : {0} internal hop(s)   Data plane: {1} remote endpoint(s)' -f
        @($Document.identity.trunk).Count,
        @($Document.identity.remoteEndpoints).Count) -ForegroundColor DarkCyan
    if ($Document.identity.database.engine) {
        Write-Host ('  Database  : {0} {1}  ({2} database(s))' -f
            $Document.identity.database.engine, $Document.identity.database.version,
            @($Document.identity.database.databases).Count) -ForegroundColor DarkCyan
    }
    Write-Host ('  Config    : {0} file hash(es)   Certs: {1}   Firewall: {2}' -f
        @($Document.identity.configHashes).Count,
        @($Document.identity.certificates).Count,
        @($Document.identity.firewall).Count) -ForegroundColor DarkCyan
    foreach ($n in @($Document.tier.notes)) {
        Write-Host ('  note: {0}' -f $n) -ForegroundColor Yellow
    }
}

# -----------------------------------------------------------------------------
#  Capture front doors
# -----------------------------------------------------------------------------
function Invoke-LocalBlueprintCapture {
    if ($PSVersionTable.PSEdition -eq 'Core' -and -not $IsWindows) {
        Write-Host '  Local capture uses the Windows collector; on a Linux box run' -ForegroundColor Red
        Write-Host ('  {0} directly (or capture over SSH with -SshServer).' -f $script:BlueprintScriptName) -ForegroundColor Red
        return $null
    }
    Write-Host ''
    Write-Host '  Collecting the local blueprint (this can take a minute)...' -ForegroundColor DarkCyan
    return (& $blueprintCollector $true)
}

function Invoke-RemoteBlueprintCapture {
    param(
        [Parameter(Mandatory)][string]$Computer,
        [System.Management.Automation.PSCredential]$Credential
    )
    Write-Host ''
    Write-Host ('  Opening a PowerShell remoting session to {0}...' -f $Computer) -ForegroundColor DarkCyan
    $icmArgs = @{
        ComputerName = $Computer
        ScriptBlock  = $blueprintCollector
        ArgumentList = @($true)
        ErrorAction  = 'Stop'
    }
    if ($Credential) { $icmArgs['Credential'] = $Credential }
    try {
        return (Invoke-Command @icmArgs)
    } catch {
        Write-Host ''
        Write-Host ('  Remoting to {0} failed: {1}' -f $Computer, $_.Exception.Message) -ForegroundColor Red
        Write-Host '  Same checklist as the port check: Enable-PSRemoting on the target,' -ForegroundColor DarkCyan
        Write-Host '  TCP 5985/5986 open, admin account, TrustedHosts for non-domain.' -ForegroundColor DarkCyan
        return $null
    }
}

function Invoke-LinuxBlueprintCapture {
    param(
        [Parameter(Mandatory)][string]$Server,
        [string]$User,
        [int]$Port = 22,
        [System.Management.Automation.PSCredential]$Credential,
        [string]$KeyFile,
        [ValidateSet('Stream','UploadDelete','UploadKeep')][string]$Mode = 'Stream',
        [string]$RemotePath = '/tmp/veeam-blueprint.sh',
        [switch]$UseSudo,
        [switch]$NonInteractive
    )

    $src = Get-BlueprintScriptPath
    if (-not $src) {
        Write-Host ''
        Write-Host ('  {0} must sit in the same folder as this script.' -f $script:BlueprintScriptName) -ForegroundColor Red
        Write-Host ('  Expected at: {0}' -f (Join-Path $script:ScriptDir $script:BlueprintScriptName)) -ForegroundColor DarkCyan
        return $null
    }

    $cap = Get-SshCapability
    if (-not $cap.PoshSsh -and -not $cap.NativeSsh) {
        Show-SshCapability | Out-Null
        return $null
    }

    $raw = $null
    if ($cap.PoshSsh) {
        if (-not $Credential -and -not $KeyFile) {
            if ($NonInteractive) {
                Write-Host '  No -SshCredential and no -SshKeyFile supplied, and this is a' -ForegroundColor Red
                Write-Host '  non-interactive run. Nothing to authenticate with.' -ForegroundColor Red
                return $null
            }
            $Credential = if ($User) { Get-Credential -UserName $User -Message "SSH to $Server" }
                          else       { Get-Credential -Message "SSH to $Server" }
            if (-not $Credential) { Write-Host '  Cancelled.' -ForegroundColor Red; return $null }
        }
        if ($KeyFile -and -not $Credential -and $User) {
            $Credential = New-Object System.Management.Automation.PSCredential(
                $User, (New-Object System.Security.SecureString))
        }
        $raw = Invoke-LinuxCheckViaPoshSsh -Server $Server -Port $Port -Credential $Credential `
                   -KeyFile $KeyFile -Mode $Mode -RemotePath $RemotePath -UseSudo:$UseSudo `
                   -LocalScriptFile $src -Raw
    } else {
        if (-not $User) {
            if ($Credential) { $User = $Credential.UserName }
            elseif (-not $NonInteractive) { $User = (Read-Host '  SSH user').Trim() }
        }
        if (-not $User) { Write-Host '  No SSH user.' -ForegroundColor Red; return $null }
        $raw = Invoke-LinuxCheckViaNativeSsh -Server $Server -Port $Port -User $User `
                   -KeyFile $KeyFile -Mode $Mode -RemotePath $RemotePath -UseSudo:$UseSudo `
                   -LocalScriptFile $src -Raw
    }

    if (-not $raw) { return $null }

    $payload = ConvertFrom-LinuxBlueprint -Lines @($raw.Lines)
    if (-not $payload.Meta.Elevated) {
        Write-Host ''
        Write-Host '  The remote script did not run as root - owners, hashes and the DB' -ForegroundColor Yellow
        Write-Host '  section are degraded. Re-run with -UseSudo, or connect as root.' -ForegroundColor Yellow
    }
    return $payload
}
