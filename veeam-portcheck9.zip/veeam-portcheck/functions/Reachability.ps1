# =============================================================================
#  Reachability.ps1 - plain TCP reachability scans (portest2 behaviour).
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

# =============================================================================
#  REMOTE REACHABILITY (portest2 behaviour)
# =============================================================================

function Test-PortOpen($server, $port) {
    $tcp = New-Object System.Net.Sockets.TcpClient
    try {
        $ar = $tcp.BeginConnect($server, $port, $null, $null)
        if ($ar.AsyncWaitHandle.WaitOne(500, $false)) { $tcp.EndConnect($ar); return $true }
        return $false
    } catch { return $false } finally { $tcp.Close() }
}

function Compress-Ranges($ports) {
    if (-not $ports -or $ports.Count -eq 0) { return }
    $sorted = @($ports | Sort-Object)
    $start = $sorted[0]; $prev = $sorted[0]
    if ($sorted.Count -gt 1) {
        foreach ($p in $sorted[1..($sorted.Count - 1)]) {
            if ($p -ne $prev + 1) {
                if ($start -eq $prev) { "$start" } else { "$start - $prev" }
                $start = $p
            }
            $prev = $p
        }
    }
    if ($start -eq $prev) { "$start" } else { "$start - $prev" }
}

function Read-PortNumber($prompt, $min, $max, $default) {
    while ($true) {
        $raw = (Read-Host "  $prompt [$min-$max, Enter=$default]").Trim()
        if ($raw -eq '') { return $default }
        if ($raw -match '^\d+$') {
            $n = [int]$raw
            if ($n -ge $min -and $n -le $max) { return $n }
        }
        Write-Host "  Invalid - enter a number between $min and $max." -ForegroundColor Red
    }
}

function Ensure-Target($current) {
    if ($current) { return $current }
    $val = (Read-Host '  Enter VBR server hostname or IP').Trim()
    if (-not $val) { Write-Host '  No target entered.' -ForegroundColor Red; return $null }
    return $val
}

function Invoke-CoreScan($testTarget, [switch]$IncludeEM) {
    Write-Host ''
    Write-Rule 'Core Ports'
    $fail = @()
    foreach ($e in $corePorts) {
        $open   = Test-PortOpen $testTarget $e.Port
        $status = if ($open) { '  OPEN  ' } else { ' FAILED ' }
        $color  = if ($open) { 'Green' }    else { 'Red' }
        Write-Host ('[{0}] {1,-8} {2}' -f $status, $e.Port, $e.Description) -ForegroundColor $color
        if (-not $open) { $fail += $e.Port }
    }

    if ($IncludeEM) {
        Write-Host ''
        Write-Rule 'Enterprise Manager Ports'
        foreach ($e in $emPorts) {
            $open   = Test-PortOpen $testTarget $e.Port
            $status = if ($open) { '  OPEN  ' } else { ' FAILED ' }
            $color  = if ($open) { 'Green' }    else { 'Red' }
            Write-Host ('[{0}] {1,-8} {2}' -f $status, $e.Port, $e.Description) -ForegroundColor $color
            if (-not $open) { $fail += $e.Port }
        }
        Write-Host ''
        Write-Host '  EM outbound dependencies (test against the DC/DNS/vCenter host, not EM):' -ForegroundColor DarkCyan
        foreach ($line in $emDependencyReference) { Write-Host "    $line" -ForegroundColor DarkCyan }
    }

    Write-Host ''
    if ($fail.Count -eq 0) { Write-Host '  All scanned ports OPEN.' -ForegroundColor Green }
    else { Write-Host ("  Blocked ports: {0}" -f ($fail -join ', ')) -ForegroundColor Red }
}

function Invoke-RangeScan($testTarget, $scanStart, $scanEnd) {
    $total  = $scanEnd - $scanStart + 1
    $estMin = [math]::Round($total * 0.5 / 60, 1)

    Write-Host ''
    Write-Rule ('Dynamic Range Scan (TCP {0}-{1})' -f $scanStart, $scanEnd)
    Write-Host ('  Scanning {0} ports, est. ~{1} min...' -f $total, $estMin) -ForegroundColor DarkCyan
    Write-Host '  Press Ctrl+C to abort and return to the menu.' -ForegroundColor DarkCyan
    Write-Host ''

    $failed = @(); $open = @(); $i = 0; $aborted = $false
    try {
        foreach ($port in $scanStart..$scanEnd) {
            try {
                if ($Host.UI.RawUI.KeyAvailable) {
                    $key = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
                    if ($key.VirtualKeyCode -eq 67 -and
                        ($key.ControlKeyState -band [System.Management.Automation.Host.ControlKeyStates]::LeftCtrlPressed -or
                         $key.ControlKeyState -band [System.Management.Automation.Host.ControlKeyStates]::RightCtrlPressed)) {
                        $aborted = $true; break
                    }
                }
            } catch { }
            $i++
            Write-Progress -Id 1 -Activity "Scanning $testTarget" -Status "Port $port  ($i of $total)" `
                           -PercentComplete (($i / $total) * 100)
            if (Test-PortOpen $testTarget $port) { $open += $port } else { $failed += $port }
        }
    } catch { $aborted = $true }
    Write-Progress -Id 1 -Activity "Scanning $testTarget" -Completed

    if ($aborted) {
        Write-Host ''
        Write-Host "  ** Scan aborted after $i of $total ports." -ForegroundColor Yellow
    }
    Write-Host ('  OPEN  : {0} ports' -f $open.Count)   -ForegroundColor Green
    Write-Host ('  FAILED: {0} ports' -f $failed.Count) -ForegroundColor Red
    if ($failed.Count -gt 0) {
        Write-Host ''
        Write-Host '  Blocked ranges:' -ForegroundColor Red
        Compress-Ranges $failed | ForEach-Object { Write-Host "    $_" -ForegroundColor Red }
    }
    if (-not $aborted -and $open.Count -eq $total) {
        Write-Host ('  Full range {0}-{1} is open.' -f $scanStart, $scanEnd) -ForegroundColor Green
    }
}
