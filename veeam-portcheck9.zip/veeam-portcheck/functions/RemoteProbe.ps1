# =============================================================================
#  RemoteProbe.ps1 - credential-less remote server probe.
#
#  DNS validation + plain TCP port tests + HTTP(S) endpoint probes (the
#  PowerShell equivalent of nslookup / Test-NetConnection / curl -k).
#  NO login of any kind - no WinRM, no SSH, no credentials. Safe to point at
#  production servers.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables ($corePorts / $emPorts) and reuse
#  Test-PortOpen from Reachability.ps1.
# =============================================================================

function Test-IsIpAddress($value) {
    $ip = $null
    return [System.Net.IPAddress]::TryParse($value, [ref]$ip)
}

# Forward lookup. Prefers Resolve-DnsName -DnsOnly (real DNS query, ignores
# the hosts file); falls back to .NET resolution on systems without the
# DnsClient module (non-Windows PS7, Server Core variants).
function Resolve-ForwardDns($name) {
    if (Get-Command Resolve-DnsName -ErrorAction SilentlyContinue) {
        try {
            $recs = @(Resolve-DnsName -Name $name -DnsOnly -ErrorAction Stop |
                      Where-Object { $_.QueryType -in @('A','AAAA') })
            if ($recs.Count -gt 0) { return @($recs | ForEach-Object { $_.IPAddress }) }
        } catch { }
        return $null
    }
    try {
        return @([System.Net.Dns]::GetHostAddresses($name) |
                 ForEach-Object { $_.IPAddressToString })
    } catch { return $null }
}

# Reverse (PTR) lookup for an IP. Returns the host name or $null.
function Resolve-ReverseDns($ip) {
    if (Get-Command Resolve-DnsName -ErrorAction SilentlyContinue) {
        try {
            $rec = Resolve-DnsName -Name $ip -Type PTR -DnsOnly -ErrorAction Stop |
                   Where-Object { $_.Type -eq 'PTR' } | Select-Object -First 1
            if ($rec) { return $rec.NameHost }
        } catch { }
        return $null
    }
    try { return ([System.Net.Dns]::GetHostEntry($ip)).HostName } catch { return $null }
}

# DNS health check for a target that may be a hostname or an IP.
#   Hostname -> forward lookup (is it in DNS?), then PTR round-trip.
#   IP       -> PTR lookup (is it in reverse DNS?), then forward round-trip.
# Returns $true when the target is resolvable enough to trust, $false when
# the hostname is simply not in DNS.
function Invoke-DnsProbe($target) {
    Write-Host ''
    Write-Rule 'DNS Check'

    if (Test-IsIpAddress $target) {
        Write-Host ('  Input is an IP address: {0}' -f $target) -ForegroundColor Gray
        $ptr = Resolve-ReverseDns $target
        if (-not $ptr) {
            Write-Host '  [ WARN ] No reverse DNS (PTR) record. The server is not in reverse DNS -' -ForegroundColor Yellow
            Write-Host '           either it is missing from DNS or the reverse zone does not exist.' -ForegroundColor Yellow
            Write-Host '           Port tests below still run against the raw IP.' -ForegroundColor Yellow
            return $true
        }
        Write-Host ('  [  OK  ] Reverse DNS (PTR): {0} -> {1}' -f $target, $ptr) -ForegroundColor Green
        $fwd = Resolve-ForwardDns $ptr
        if ($fwd -and ($fwd -contains $target)) {
            Write-Host ('  [  OK  ] Round-trip:        {0} -> {1}' -f $ptr, ($fwd -join ', ')) -ForegroundColor Green
        } elseif ($fwd) {
            Write-Host ('  [ WARN ] Round-trip mismatch: {0} resolves to {1}, not {2}.' -f $ptr, ($fwd -join ', '), $target) -ForegroundColor Yellow
            Write-Host '           Stale PTR or duplicate A record - worth fixing before an upgrade.' -ForegroundColor Yellow
        } else {
            Write-Host ('  [ WARN ] PTR name {0} does not resolve forward (stale PTR record).' -f $ptr) -ForegroundColor Yellow
        }
        return $true
    }

    # Hostname path
    $fwd = Resolve-ForwardDns $target
    if (-not $fwd) {
        Write-Host ('  [FAILED] {0} is NOT in DNS (no A/AAAA record).' -f $target) -ForegroundColor Red
        Write-Host '           Fix DNS or use the IP address directly.' -ForegroundColor Red
        return $false
    }
    Write-Host ('  [  OK  ] Forward DNS:  {0} -> {1}' -f $target, ($fwd -join ', ')) -ForegroundColor Green

    $ptr = Resolve-ReverseDns $fwd[0]
    if (-not $ptr) {
        Write-Host ('  [ WARN ] No PTR record for {0} - reverse DNS missing (cosmetic for most' -f $fwd[0]) -ForegroundColor Yellow
        Write-Host '           Veeam operations, but breaks Kerberos in some setups).' -ForegroundColor Yellow
    } elseif (($ptr -ieq $target) -or ($ptr.Split('.')[0] -ieq $target.Split('.')[0])) {
        Write-Host ('  [  OK  ] Reverse DNS:  {0} -> {1}' -f $fwd[0], $ptr) -ForegroundColor Green
    } else {
        Write-Host ('  [ WARN ] Reverse DNS mismatch: {0} -> {1} (expected {2}).' -f $fwd[0], $ptr, $target) -ForegroundColor Yellow
    }
    return $true
}

# curl-style probe: does an HTTP(S) service actually answer on the port?
# Any HTTP status (200, 302, 401, 403...) counts as alive - we only care that
# a web service responded, not that we are authorised. Certificate validation
# is skipped (Veeam defaults to self-signed certs).
function Test-HttpEndpoint($targetHost, $port, [bool]$UseHttps) {
    $scheme = if ($UseHttps) { 'https' } else { 'http' }
    $url    = '{0}://{1}:{2}/' -f $scheme, $targetHost, $port
    try {
        if ($PSVersionTable.PSVersion.Major -ge 6) {
            $resp = Invoke-WebRequest -Uri $url -SkipCertificateCheck -TimeoutSec 5 `
                        -UseBasicParsing -ErrorAction Stop
        } else {
            $old = [System.Net.ServicePointManager]::ServerCertificateValidationCallback
            [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
            try {
                $resp = Invoke-WebRequest -Uri $url -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
            } finally {
                [System.Net.ServicePointManager]::ServerCertificateValidationCallback = $old
            }
        }
        return @{ Ok = $true; Status = [int]$resp.StatusCode; Url = $url }
    } catch {
        # 4xx/5xx still means a live web service - dig the status out of the exception.
        $status = $null
        try { $status = [int]$_.Exception.Response.StatusCode } catch { }
        if ($status) { return @{ Ok = $true; Status = $status; Url = $url } }
        return @{ Ok = $false; Url = $url; Error = $_.Exception.GetBaseException().Message }
    }
}

function Invoke-HttpProbes($testTarget, [switch]$IncludeEM) {
    Write-Host ''
    Write-Rule 'HTTP(S) Service Probe'

    $webPorts = @(
        @{Port=443;  Https=$true;  Description='v13 backup server / appliance web (HTTPS)'}
        @{Port=9419; Https=$true;  Description='VBR RESTful API (HTTPS)'}
    )
    if ($IncludeEM) {
        $webPorts += @(
            @{Port=9443; Https=$true;  Description='EM web UI (HTTPS, Windows)'}
            @{Port=9080; Https=$false; Description='EM web UI (HTTP, Windows)'}
            @{Port=9398; Https=$true;  Description='EM RESTful API (HTTPS)'}
            @{Port=9399; Https=$false; Description='EM RESTful API (HTTP, Windows)'}
        )
    }

    foreach ($w in $webPorts) {
        if (-not (Test-PortOpen $testTarget $w.Port)) {
            Write-Host ('[  SKIP  ] {0,-8} {1} - TCP port closed' -f $w.Port, $w.Description) -ForegroundColor DarkGray
            continue
        }
        $r = Test-HttpEndpoint $testTarget $w.Port $w.Https
        if ($r.Ok) {
            Write-Host ('[  LIVE  ] {0,-8} {1} - HTTP {2}' -f $w.Port, $w.Description, $r.Status) -ForegroundColor Green
        } else {
            Write-Host ('[NO REPLY] {0,-8} {1} - TCP open but no HTTP response ({2})' -f $w.Port, $w.Description, $r.Error) -ForegroundColor Yellow
        }
    }
    Write-Host ''
    Write-Host '  LIVE means a web service answered - any HTTP status counts, including 401/403.' -ForegroundColor Gray
}

# The full credential-less probe: DNS -> TCP ports -> HTTP endpoints.
function Invoke-RemoteProbe($target, [switch]$IncludeEM) {
    Write-Banner 'Remote Server Probe (no login)' $target

    $dnsOk = Invoke-DnsProbe $target
    if (-not $dnsOk) {
        Write-Host ''
        Write-Host '  Skipping port tests - the hostname does not resolve, so every port' -ForegroundColor Red
        Write-Host '  test would fail for the wrong reason. Re-run with the IP address.' -ForegroundColor Red
        return
    }

    Invoke-CoreScan $target -IncludeEM:$IncludeEM
    Invoke-HttpProbes $target -IncludeEM:$IncludeEM
}
