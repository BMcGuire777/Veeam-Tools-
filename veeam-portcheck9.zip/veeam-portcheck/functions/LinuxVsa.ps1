# =============================================================================
#  LinuxVsa.ps1 - Linux / Veeam Software Appliance guidance and workflows.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

# =============================================================================
#  LINUX / VSA PATH
# =============================================================================

function Get-LinuxScriptPath {
    $p = Join-Path $script:ScriptDir $script:LinuxScriptName
    if (Test-Path $p) { return $p }
    return $null
}

function Show-VsaGuidance {
    param([string]$ServerName = '(the appliance)')

    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host '  Linux / Veeam Software Appliance' -ForegroundColor Cyan
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host '  There is no supported remote command execution path into a' -ForegroundColor Yellow
    Write-Host '  locked-down VSA. Per Veeam documentation:' -ForegroundColor Yellow
    Write-Host ''
    Write-Host '    - SSH is off by default. Enabling it is a Host Administrator' -ForegroundColor DarkCyan
    Write-Host '      action in Host Management (web UI or TUI), and where a' -ForegroundColor DarkCyan
    Write-Host '      Security Officer account exists it needs their approval.' -ForegroundColor DarkCyan
    Write-Host '    - The TUI root shell cannot be reached over SSH at all -' -ForegroundColor DarkCyan
    Write-Host '      only a physical or virtual console. Approved root access' -ForegroundColor DarkCyan
    Write-Host '      lasts 8 hours from first login.' -ForegroundColor DarkCyan
    Write-Host '    - Veeam PowerShell modules are not available in pre/post-job' -ForegroundColor DarkCyan
    Write-Host '      scripts on the appliance.' -ForegroundColor DarkCyan
    Write-Host ''
    Write-Host '  Connect-VBRServer on 443 reaches the VBR API, not a shell, so it' -ForegroundColor DarkCyan
    Write-Host '  cannot enumerate OS listeners. Use one of the options below.' -ForegroundColor DarkCyan
    Write-Host ''
    Write-Host '  Ports checked on Linux:' -ForegroundColor White
    foreach ($l in $linuxPortsReference) { Write-Host ('    ' + $l) -ForegroundColor DarkGray }
}

function Copy-LinuxScript($destination) {
    $src = Get-LinuxScriptPath
    if (-not $src) {
        Write-Host ''
        Write-Host ('  {0} not found next to this script.' -f $script:LinuxScriptName) -ForegroundColor Red
        Write-Host ('  Expected at: {0}' -f (Join-Path $script:ScriptDir $script:LinuxScriptName)) -ForegroundColor DarkCyan
        return $null
    }
    if (-not $destination) { return $src }
    try {
        # Resolve against the PowerShell location, not the process working dir.
        $dest = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($destination)

        # Treat it as a directory if it exists as one, ends in a separator, or
        # has no file extension. Otherwise it is a full target file path.
        $looksLikeDir = (Test-Path $dest -PathType Container) -or
                        ($dest -match '[\\/]$') -or
                        ([string]::IsNullOrEmpty([IO.Path]::GetExtension($dest)))
        if ($looksLikeDir) {
            if (-not (Test-Path $dest -PathType Container)) {
                New-Item -ItemType Directory -Path $dest -Force -ErrorAction Stop | Out-Null
            }
            $dest = Join-Path $dest $script:LinuxScriptName
        } else {
            $parent = Split-Path $dest -Parent
            if ($parent -and -not (Test-Path $parent -PathType Container)) {
                New-Item -ItemType Directory -Path $parent -Force -ErrorAction Stop | Out-Null
            }
        }

        # Force LF endings so bash on the appliance is happy.
        $text = [IO.File]::ReadAllText($src) -replace "`r`n", "`n"
        [IO.File]::WriteAllText($dest, $text, (New-Object Text.UTF8Encoding($false)))
        Write-Host ('  Wrote {0}' -f $dest) -ForegroundColor Green
        return $dest
    } catch {
        Write-Host ('  Copy failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}

function Show-VsaConsoleOneLiner {
    Write-Host ''
    Write-Rule 'Console paste version (no file transfer needed)'
    Write-Host ''
    Write-Host '  Type or paste this at the TUI root shell. It is the essential check' -ForegroundColor DarkCyan
    Write-Host '  only - the full script gives systemd unit mapping and exit codes.' -ForegroundColor DarkCyan
    Write-Host ''
    $oneLiner = @'
for p in 443 6160 6162 6172 9419 10006 10443 5432; do o=$(ss -Hlntup "sport = :$p" 2>/dev/null | grep -o '"[^"]*"' | head -1); if [ -z "$o" ]; then echo "FREE      $p"; else case "$o" in *[Vv]eeam*) echo "OK        $p  $o";; *) echo "CONFLICT  $p  $o";; esac; fi; done; echo "-- non-Veeam in 2500-3300 --"; ss -Hlntup 2>/dev/null | awk '{n=split($5,a,":"); if(a[n]+0>=2500 && a[n]+0<=3300) print a[n], $NF}' | grep -vi veeam; echo "-- veeam units --"; systemctl list-units --all --type=service --no-legend --no-pager 'veeam*' 2>/dev/null | awk '{print "  "$3"  "$1}'
'@
    Write-Host $oneLiner -ForegroundColor Gray
    Write-Host ''
    Write-Host '  Reminder: vPower NFS (111 / 1058 / 2049) is a Windows service and is' -ForegroundColor DarkGray
    Write-Host '  deliberately not checked on Linux.' -ForegroundColor DarkGray
}

function Invoke-VsaWorkflow {
    param([string]$ServerName)
    Show-VsaGuidance -ServerName $ServerName

    Write-Host ''
    Write-Rule 'How do you want to run the Linux check'
    Write-Host '  [1] Push over SSH and run it  <- results merge into the same report' -ForegroundColor Green
    Write-Host '  [2] Write veeam-portcheck.sh somewhere I can copy from' -ForegroundColor Green
    Write-Host '  [3] Show the console paste one-liner (no SSH needed)' -ForegroundColor Green
    Write-Host '  [4] Show SSH transport status' -ForegroundColor Yellow
    Write-Host '  [B] Back' -ForegroundColor Red
    Write-Host ''
    $c = (Read-Host '  Select').Trim().ToUpper()

    switch ($c) {
        '1' { Invoke-SshPushWorkflow -ServerName $ServerName }

        '2' {
            $default = Join-Path ([Environment]::GetFolderPath('Desktop')) $script:LinuxScriptName
            $p = (Read-Host "  Destination [Enter=$default]").Trim()
            if (-not $p) { $p = $default }
            $written = Copy-LinuxScript $p
            if ($written) {
                Write-Host ''
                Write-Host '  On the appliance, in the TUI root shell:' -ForegroundColor DarkCyan
                Write-Host '    bash /path/to/veeam-portcheck.sh' -ForegroundColor Gray
                Write-Host '    bash /path/to/veeam-portcheck.sh --csv    # machine readable' -ForegroundColor Gray
                Write-Host '    bash /path/to/veeam-portcheck.sh --all    # every listener' -ForegroundColor Gray
            }
        }
        '3' { Show-VsaConsoleOneLiner }
        '4' { Show-SshCapability | Out-Null }
        default { }
    }
}

function Invoke-SshPushWorkflow {
    param([string]$ServerName)

    $srv = if ($ServerName) {
        $t = (Read-Host ("  Appliance hostname or IP [Enter={0}]" -f $ServerName)).Trim()
        if ($t) { $t } else { $ServerName }
    } else {
        (Read-Host '  Appliance hostname or IP').Trim()
    }
    if (-not $srv) { Write-Host '  Cancelled.' -ForegroundColor Red; return }

    $pRaw = (Read-Host '  SSH port [Enter=22]').Trim()
    $sshPort = if ($pRaw -match '^\d+$') { [int]$pRaw } else { 22 }

    Write-Host ''
    Write-Host '  How should the script get there?' -ForegroundColor DarkCyan
    Write-Host '    [Enter] Stream it - nothing is ever written to the appliance' -ForegroundColor Gray
    Write-Host '    [D]     Upload to /tmp, run, then delete' -ForegroundColor Gray
    Write-Host '    [K]     Upload to /tmp and keep it there for re-runs' -ForegroundColor Gray
    $mRaw = (Read-Host '  Choice').Trim().ToUpper()
    $mode = switch ($mRaw) {
        'D'     { 'UploadDelete' }
        'K'     { 'UploadKeep' }
        default { 'Stream' }
    }

    $remotePath = '/tmp/veeam-portcheck.sh'
    if ($mode -ne 'Stream') {
        $rp = (Read-Host "  Remote path [Enter=$remotePath]").Trim()
        if ($rp) { $remotePath = $rp }
    }

    $sudoAns = (Read-Host '  Run it through sudo? Needed unless you log in as root [y/N]').Trim().ToUpper()
    $useSudo = ($sudoAns -eq 'Y')

    $keyFile = ''
    $cap = Get-SshCapability
    if (-not $cap.PoshSsh -and $cap.NativeSsh) {
        $k = (Read-Host '  Private key file for key auth [Enter = password prompt]').Trim()
        if ($k) { $keyFile = $k }
    }

    Invoke-LinuxCheckOverSsh -Server $srv -Port $sshPort -Mode $mode `
        -RemotePath $remotePath -UseSudo:$useSudo -KeyFile $keyFile | Out-Null
}
