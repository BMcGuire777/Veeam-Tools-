# =============================================================================
#  Reporting.ps1 - console rendering: banners, rules, the conflict report.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

# =============================================================================
#  RENDERING
# =============================================================================

function Write-Rule($text, $color = 'Yellow') {
    $pad = [math]::Max(0, 54 - $text.Length)
    Write-Host ('-- {0} {1}' -f $text, ('-' * $pad)) -ForegroundColor $color
}

function Write-Banner($title, $subject) {
    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host ("  {0}  ->  {1}" -f $title, $subject) -ForegroundColor Cyan
    Write-Host ("  {0}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) -ForegroundColor DarkCyan
    Write-Host '=======================================================' -ForegroundColor Cyan
}

function Show-ConflictReport($payload) {
    if (-not $payload) { Write-Host '  No data returned.' -ForegroundColor Red; return }

    $results = @($payload.Results)
    $meta    = $payload.Meta

    Write-Host ''
    Write-Host ('  Host      : {0}' -f $meta.Host) -ForegroundColor White
    if ($meta.OS) { Write-Host ('  OS        : {0}' -f $meta.OS) -ForegroundColor DarkCyan }
    if ($meta.ProcCount -gt 0) {
        Write-Host ('  Listeners : {0} TCP, {1} UDP across {2} processes' -f
            $meta.TcpCount, $meta.UdpCount, $meta.ProcCount) -ForegroundColor DarkCyan
    } else {
        Write-Host ('  Listeners : {0} TCP, {1} UDP' -f $meta.TcpCount, $meta.UdpCount) -ForegroundColor DarkCyan
    }
    if (-not $meta.Elevated) {
        Write-Host '  ! Collector was not elevated - some owners may read UNKNOWN.' -ForegroundColor Yellow
    }
    if ($meta.Fallback) {
        Write-Host '  (NetTCPIP unavailable or empty on target - used netstat fallback.)' -ForegroundColor DarkYellow
    }
    if ($meta.CollectError) {
        Write-Host ''
        Write-Host '  ***********************************************************' -ForegroundColor Red
        Write-Host '  LISTENER ENUMERATION FAILED - RESULTS BELOW ARE NOT VALID.' -ForegroundColor Red
        Write-Host ('  {0}' -f $meta.CollectError) -ForegroundColor Red
        Write-Host '  Every port will read FREE. Do not treat this as an all-clear.' -ForegroundColor Red
        Write-Host '  ***********************************************************' -ForegroundColor Red
    }

    Write-Host ''
    Write-Rule 'Veeam Port Ownership'
    Write-Host ''
    Write-Host ('  {0,-6} {1,-5} {2,-9} {3}' -f 'PORT','PROTO','STATUS','OWNER / COMPONENT') -ForegroundColor White
    Write-Host ('  ' + ('-' * 84)) -ForegroundColor DarkGray

    foreach ($r in ($results | Where-Object { -not $_.InRange })) {
        $color = switch ($r.Status) {
            'CONFLICT' { 'Red' }
            'UNKNOWN'  { 'Yellow' }
            'OK'       { 'Green' }
            default    { 'DarkGray' }
        }
        $right = if ($r.Owner) { $r.Owner } else { $r.Component }
        $flag  = if (-not $r.Verified) { '~' } else { ' ' }
        Write-Host ('  {0,-6}{1}{2,-5} {3,-9} {4}' -f $r.Port, $flag, $r.Protocol, $r.Status, $right) -ForegroundColor $color
        if ($r.Status -eq 'CONFLICT' -or $r.Status -eq 'UNKNOWN') {
            Write-Host ('           -> needs: {0}' -f $r.Component) -ForegroundColor DarkGray
        }
    }
    Write-Host ''
    Write-Host '  ~ = port number not confirmed against v13 docs (see header notes)' -ForegroundColor DarkGray

    # -- range ----------------------------------------------------------------
    $rangeRows = @($results | Where-Object { $_.InRange })
    Write-Host ''
    Write-Rule 'Data Transfer Range 2500-3300'
    if (-not $meta.RangeChecked) {
        Write-Host '  NOT CHECKED - the range scan was skipped for this run.' -ForegroundColor Yellow
    } elseif ($rangeRows.Count -eq 0) {
        Write-Host '  No non-Veeam process is listening in the range.' -ForegroundColor Green
    } else {
        Write-Host ('  {0} non-Veeam listener(s) inside the range:' -f $rangeRows.Count) -ForegroundColor Red
        foreach ($r in $rangeRows) {
            $line = '    {0,-6} {1}' -f $r.Port, $r.Owner
            if ($r.Notes) { $line += '  [' + $r.Notes + ']' }
            Write-Host $line -ForegroundColor Red
        }
        Write-Host ''
        Write-Host '  Veeam takes one port from this range per job TCP connection. A few' -ForegroundColor DarkCyan
        Write-Host '  occupied ports are tolerable; large blocks are not.' -ForegroundColor DarkCyan
    }

    # -- services -------------------------------------------------------------
    $svcs = @($meta.Services)
    Write-Host ''
    Write-Rule 'Veeam Services On That Host'
    if ($svcs.Count -eq 0) {
        Write-Host '  No Veeam services found - treating as a pre-install host.' -ForegroundColor DarkCyan
    } else {
        foreach ($s in $svcs) {
            $c = if ($s.Status -eq 'Running') { 'Green' } else { 'Yellow' }
            Write-Host ('  {0,-9} {1}' -f $s.Status, $s.DisplayName) -ForegroundColor $c
        }
        $stopped = @($svcs | Where-Object { $_.Status -ne 'Running' })
        if ($stopped.Count -gt 0) {
            Write-Host ''
            Write-Host ('  {0} Veeam service(s) not running. A port they own reads FREE now but' -f $stopped.Count) -ForegroundColor Yellow
            Write-Host '  must still be free when the upgrade restarts them.' -ForegroundColor Yellow
        }
    }

    # -- verdict --------------------------------------------------------------
    $conflicts = @($results | Where-Object { $_.Status -eq 'CONFLICT' })
    $unknowns  = @($results | Where-Object { $_.Status -eq 'UNKNOWN' })

    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    if ($meta.CollectError) {
        Write-Host '  RESULT: INCONCLUSIVE - listeners could not be enumerated.' -ForegroundColor Red
    } elseif ($conflicts.Count -eq 0 -and $unknowns.Count -eq 0) {
        if ($meta.RangeChecked) {
            Write-Host '  RESULT: No port conflicts detected.' -ForegroundColor Green
        } else {
            Write-Host '  RESULT: No conflicts on the named ports. Range 2500-3300 NOT checked.' -ForegroundColor Yellow
        }
    } else {
        if ($conflicts.Count -gt 0) {
            Write-Host ('  RESULT: {0} CONFLICT(S) - resolve before upgrading VBR.' -f $conflicts.Count) -ForegroundColor Red
            Write-Host ''
            foreach ($c in $conflicts) {
                Write-Host ('  * {0}/{1} held by {2}' -f $c.Port, $c.Protocol, $c.Owner) -ForegroundColor Red
                Write-Host ('    Needed by: {0}' -f $c.Component) -ForegroundColor DarkGray
                if ($c.Notes) { Write-Host ('    {0}' -f $c.Notes) -ForegroundColor DarkGray }
            }
        }
        if ($unknowns.Count -gt 0) {
            Write-Host ''
            Write-Host ('  {0} port(s) have an unresolvable owner - re-run with admin rights on the target.' -f $unknowns.Count) -ForegroundColor Yellow
        }
    }
    Write-Host '=======================================================' -ForegroundColor Cyan
}

function Write-Footer {
    Write-Host ''
    Write-Host '  Press Enter to return to the menu.' -ForegroundColor Cyan
    $null = Read-Host
}
