# =============================================================================
#  Results.ps1 - session result state and CSV export.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

function Export-Results($path) {
    if (-not $script:LastResults -or $script:LastResults.Count -eq 0) {
        Write-Host '  Nothing to export - run a conflict check first.' -ForegroundColor Red
        return
    }
    try {
        $script:LastResults |
            Select-Object @{n='Host';e={$script:LastResultHost}}, Port, Protocol, Status,
                          OwnerType, Owner, Component, Verified, Notes |
            Sort-Object Status, Port |
            Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
        Write-Host ('  Exported {0} rows to {1}' -f $script:LastResults.Count, $path) -ForegroundColor Green
    } catch {
        Write-Host ('  Export failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
    }
}

function Save-Results($payload) {
    # Always overwrite, so a failed run cannot leave a previous host's rows
    # sitting there waiting to be exported as if they were current.
    if ($payload) {
        $script:LastResults    = @($payload.Results)
        $script:LastResultHost = [string]$payload.Meta.Host

        # Accumulate for the mixed-estate CSV - but never accumulate a run we
        # already know is invalid, or the CSV would look clean while the
        # console said the results were not valid.
        if ($payload.Meta.CollectError) {
            Write-Host '  (Not adding this run to the session CSV - the collection failed.)' -ForegroundColor DarkYellow
            return
        }
        $hostName = [string]$payload.Meta.Host
        $platform = if ($payload.Meta.Platform) { [string]$payload.Meta.Platform } else { 'Windows' }
        $stamp    = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        foreach ($r in @($payload.Results)) {
            $script:AllResults += [pscustomobject]@{
                Host=$hostName; Platform=$platform; Checked=$stamp
                Port=$r.Port; Protocol=$r.Protocol; Status=$r.Status
                OwnerType=$r.OwnerType; Owner=$r.Owner; Component=$r.Component
                Verified=$r.Verified; Notes=$r.Notes
            }
        }
    } else {
        $script:LastResults    = @()
        $script:LastResultHost = ''
    }
}

function Export-AllResults($path) {
    if (-not $script:AllResults -or $script:AllResults.Count -eq 0) {
        Write-Host '  Nothing accumulated yet - run at least one conflict check.' -ForegroundColor Red
        return
    }
    try {
        $script:AllResults |
            Sort-Object Host, Status, Port |
            Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
        $hosts = @($script:AllResults | Select-Object -ExpandProperty Host -Unique).Count
        Write-Host ('  Exported {0} rows across {1} host(s) to {2}' -f
            $script:AllResults.Count, $hosts, $path) -ForegroundColor Green
    } catch {
        Write-Host ('  Export failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
    }
}
