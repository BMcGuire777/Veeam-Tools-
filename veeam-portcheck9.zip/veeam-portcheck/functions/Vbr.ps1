# =============================================================================
#  Vbr.ps1 - VBR connection layer and connect-and-check orchestration.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

# =============================================================================
#  VBR CONNECTION LAYER
# =============================================================================

function Import-VeeamModule {
    if (Get-Module Veeam.Backup.PowerShell) { return $true }
    try {
        $path = [Environment]::GetEnvironmentVariable('PSModulePath','Machine')
        if ($path) { $env:PSModulePath += [System.IO.Path]::PathSeparator + $path }
    } catch { }
    $m = Get-Module -ListAvailable -Name 'Veeam.Backup.PowerShell' -ErrorAction SilentlyContinue |
         Sort-Object Version -Descending | Select-Object -First 1
    if (-not $m) {
        Write-Host ''
        Write-Host '  Veeam.Backup.PowerShell module not found.' -ForegroundColor Red
        Write-Host '  On Windows it installs with the Veeam Backup & Replication console.' -ForegroundColor DarkCyan
        Write-Host '  v13 also requires PowerShell 7.6.3 or later for Veeam cmdlets.' -ForegroundColor DarkCyan
        Write-Host ('  This session is PowerShell {0}.' -f $PSVersionTable.PSVersion) -ForegroundColor DarkCyan
        if ($PSVersionTable.PSVersion.Major -lt 7) {
            Write-Host '  On a v13 console machine, relaunch this script under PowerShell 7:' -ForegroundColor Yellow
            Write-Host '    pwsh -File .\portest3.ps1  (or .\veeam-blueprint.ps1)' -ForegroundColor DarkCyan
        }
        return $false
    }
    try {
        Import-Module $m.Path -DisableNameChecking -ErrorAction Stop
        return $true
    } catch {
        Write-Host ('  Failed to import Veeam module: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $false
    }
}

function Connect-Vbr {
    param(
        [Parameter(Mandatory)][string]$Server,
        [int]$Port = 443,
        [System.Management.Automation.PSCredential]$Credential,
        [switch]$AcceptCert
    )

    if (-not (Import-VeeamModule)) { return $false }

    if (-not $Credential) {
        Write-Host ''
        Write-Host '  Credentials for the Veeam backup server.' -ForegroundColor DarkCyan
        Write-Host '  Use DOMAIN\User or UPN format. MFA and SAML accounts are not supported' -ForegroundColor DarkCyan
        Write-Host '  by Veeam PowerShell. The account needs the Backup Administrator role.' -ForegroundColor DarkCyan
        $Credential = Get-Credential -Message "Veeam backup server: $Server"
        if (-not $Credential) { Write-Host '  Cancelled.' -ForegroundColor Red; return $false }
    }
    $script:VbrCred = $Credential

    # One VBR connection per PowerShell session - drop any existing one.
    try {
        if (Get-Command Get-VBRServerSession -ErrorAction SilentlyContinue) {
            if (Get-VBRServerSession -ErrorAction SilentlyContinue) {
                Disconnect-VBRServer -ErrorAction SilentlyContinue
            }
        }
    } catch { }

    $connArgs = @{ Server = $Server; Port = $Port; Credential = $Credential; ErrorAction = 'Stop' }
    if ($AcceptCert) {
        $connectCmd = Get-Command Connect-VBRServer -ErrorAction SilentlyContinue
        if ($connectCmd -and $connectCmd.Parameters -and
            $connectCmd.Parameters.ContainsKey('ForceAcceptTlsCertificate')) {
            $connArgs['ForceAcceptTlsCertificate'] = $true
        } else {
            Write-Host '  -ForceAcceptTlsCertificate not available in this module version (v13+ only) - skipping.' -ForegroundColor DarkYellow
        }
    }

    Write-Host ''
    Write-Host ('  Connecting to {0}:{1} ...' -f $Server, $Port) -ForegroundColor DarkCyan
    try {
        Connect-VBRServer @connArgs | Out-Null
    } catch {
        Write-Host ('  Connect-VBRServer failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        if ($_.Exception.Message -match '(?i)certificate|trust|ssl|tls') {
            Write-Host '  Looks like a certificate trust problem - retry with -ForceAcceptCert.' -ForegroundColor Yellow
        }
        if ($Port -ne 9392) {
            Write-Host '  If this is a v12 or older server, try -VbrPort 9392 (v13 default is 443).' -ForegroundColor Yellow
        }
        return $false
    }

    $script:VbrConnected  = $true
    $script:VbrServerName = $Server
    Write-Host '  Connected.' -ForegroundColor Green

    $script:VbrPlatform = Get-VbrPlatform
    Write-Host ('  Backup server platform: {0}' -f $script:VbrPlatform) -ForegroundColor Cyan
    return $true
}

function Get-VbrPlatform {
    # Get-VBRLinuxPackage is a v13 cmdlet that returns the Linux components
    # installed on the backup server - a non-empty result means Linux/VSA.
    # CHost properties are explicitly undocumented, so .Type is only a hint.
    try {
        if (Get-Command Get-VBRLinuxPackage -ErrorAction SilentlyContinue) {
            $pkgs = @(Get-VBRLinuxPackage -ErrorAction Stop)
            if ($pkgs.Count -gt 0) { return 'Linux' }
        }
    } catch { }

    try {
        $lh = Get-VBRLocalhost -ErrorAction Stop
        $t  = [string]$lh.Type
        if ($t -match '(?i)linux')             { return 'Linux' }
        if ($t -match '(?i)windows|^Local$')   { return 'Windows' }
        if ($t) { return "Unknown (Type=$t)" }
    } catch { }

    return 'Unknown'
}

function Disconnect-Vbr {
    try {
        if (Get-Command Disconnect-VBRServer -ErrorAction SilentlyContinue) {
            Disconnect-VBRServer -ErrorAction SilentlyContinue
        }
    } catch { }
    $script:VbrConnected  = $false
    $script:VbrServerName = ''
    $script:VbrPlatform   = 'Unknown'
    Write-Host '  Disconnected from VBR.' -ForegroundColor DarkCyan
}

function Show-VbrInfrastructure {
    if (-not $script:VbrConnected) { Write-Host '  Not connected.' -ForegroundColor Red; return }
    Write-Host ''
    Write-Rule 'Managed Servers (Get-VBRServer)'
    try {
        $srv = @(Get-VBRServer -ErrorAction Stop)
        if ($srv.Count -eq 0) { Write-Host '  None returned.' -ForegroundColor DarkCyan; return }
        foreach ($s in $srv) {
            Write-Host ('  {0,-14} {1}' -f [string]$s.Type, [string]$s.Name) -ForegroundColor DarkCyan
        }
        Write-Host ''
        Write-Host ('  {0} managed server(s). Windows ones can be checked with menu option 3.' -f $srv.Count) -ForegroundColor White
    } catch {
        Write-Host ('  Get-VBRServer failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
    }
}

# =============================================================================
#  CONNECT-AND-CHECK ORCHESTRATION
# =============================================================================

function Invoke-VbrConnectAndCheck {
    param(
        [Parameter(Mandatory)][string]$Server,
        [int]$Port = 443,
        [System.Management.Automation.PSCredential]$Credential,
        [switch]$AcceptCert,
        [switch]$WithEM, [switch]$WithCC, [switch]$WithWan, [switch]$NoRange
    )

    Write-Banner 'Veeam Port Conflict Check' $Server

    if (-not (Connect-Vbr -Server $Server -Port $Port -Credential $Credential -AcceptCert:$AcceptCert)) {
        Write-Host ''
        Write-Host '  Could not use the VBR API. You can still check the host directly with' -ForegroundColor Yellow
        Write-Host ('    .\portest3.ps1 -ComputerName {0} -RemoteCheck' -f $Server) -ForegroundColor DarkCyan
        return
    }

    Show-VbrInfrastructure

    if ($script:VbrPlatform -eq 'Linux') {
        Invoke-VsaWorkflow -ServerName $Server
        return
    }

    if ($script:VbrPlatform -ne 'Windows') {
        Write-Host ''
        Write-Host ('  Platform came back as "{0}". Get-VBRLinuxPackage returned nothing and' -f $script:VbrPlatform) -ForegroundColor Yellow
        Write-Host '  CHost properties are undocumented, so this is inconclusive.' -ForegroundColor Yellow
        $a = (Read-Host '  Treat as Windows and try PowerShell remoting? [Y/n]').Trim().ToUpper()
        if ($a -eq 'N') { Invoke-VsaWorkflow -ServerName $Server; return }
    }

    $payload = Invoke-RemoteCollector -Computer $Server -Credential $script:VbrCred `
                                      -WithEM:$WithEM -WithCC:$WithCC -WithWan:$WithWan -NoRange:$NoRange
    if ($payload) {
        Save-Results $payload
        Show-ConflictReport $payload
    }
}
