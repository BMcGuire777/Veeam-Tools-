# =============================================================================
#  BlueprintCollector.ps1 - the Windows blueprint collector.
#
#  Dot-sourced by veeam-blueprint.ps1. Runs in the main script scope.
#
#  $blueprintCollector is self-contained (no dependency on anything outside
#  the scriptblock) so it can run locally or via Invoke-Command against a
#  Windows backup server - same pattern as $collector in Collector.ps1.
#
#  RUNTIMES: runs under Windows PowerShell 5.1 AND PowerShell 7 (v13 backup
#  servers standardise on PS7). It is deliberately kept 5.1-compatible even
#  so, because Invoke-Command's default WinRM endpoint is Windows PowerShell
#  on every Windows target - including a v13 server - so remote captures
#  execute under 5.1 no matter which runtime launched them.
#
#  It returns one hashtable with the same section shapes that
#  ConvertFrom-LinuxBlueprint produces, so New-BlueprintDocument can
#  normalise either platform into one JSON blueprint schema.
# =============================================================================

$blueprintCollector = {
    param([bool]$IncludeDb = $true)

    $notes = New-Object System.Collections.ArrayList

    # -- elevation ------------------------------------------------------------
    $elevated = $false
    try {
        $elevated = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                    ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { }

    # -- process map (pid -> name/path/company/services) -----------------------
    $procs = @{}; $svcByPid = @{}
    try {
        foreach ($s in @(Get-CimInstance Win32_Service -ErrorAction Stop |
                         Where-Object { $_.ProcessId -and $_.ProcessId -gt 0 })) {
            $k = [int]$s.ProcessId
            if (-not $svcByPid.ContainsKey($k)) { $svcByPid[$k] = @() }
            $svcByPid[$k] += $s.Name
        }
    } catch { }
    foreach ($p in @(Get-Process -ErrorAction SilentlyContinue)) {
        $path = ''; $company = ''
        try { $path    = $p.Path }    catch { }
        try { $company = $p.Company } catch { }
        $procs[[int]$p.Id] = @{
            Name     = $p.ProcessName
            Path     = $path
            Company  = $company
            Services = @(if ($svcByPid.ContainsKey([int]$p.Id)) { $svcByPid[[int]$p.Id] })
        }
    }

    function Get-Class($procId) {
        if ($procId -eq 0 -or $procId -eq 4) { return 'os' }
        if (-not $procs.ContainsKey([int]$procId)) { return 'unknown' }
        $i   = $procs[[int]$procId]
        $hay = '{0} {1} {2} {3}' -f $i.Name, $i.Path, $i.Company, ($i.Services -join ' ')
        if ($hay -match '(?i)veeam') { return 'veeam' }
        if ($i.Name -match '(?i)^(postgres|postmaster|sqlservr|mysqld|mariadbd)$') { return 'db' }
        if ($i.Name -match '(?i)^(System|Idle|svchost|lsass|services|spoolsv|wininit|dns|Registry|dfsrs|inetinfo)$') { return 'os' }
        if ($i.Path -and $i.Path -match '(?i)^[A-Z]:\\Windows\\') { return 'os' }
        return 'thirdparty'
    }
    function Get-ProcName($procId) {
        if ($procId -eq 0 -or $procId -eq 4) { return 'System' }
        if ($procs.ContainsKey([int]$procId)) { return $procs[[int]$procId].Name }
        return '-'
    }
    function Get-ProcSvc($procId) {
        if ($procs.ContainsKey([int]$procId)) { return ($procs[[int]$procId].Services -join ',') }
        return ''
    }
    function Get-ProcExe($procId) {
        if ($procs.ContainsKey([int]$procId)) { return [string]$procs[[int]$procId].Path }
        return ''
    }
    function Test-Loopback($addr) {
        return ([string]$addr -match '^(127\.|::1$|::ffff:127\.)')
    }

    # -- listeners (tcp + udp, with address so scope can be derived) -----------
    $tcpListen = @(); $udpListen = @(); $estab = @()
    $usedFallback = $false
    if (Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue) {
        try {
            foreach ($c in @(Get-NetTCPConnection -State Listen -ErrorAction Stop)) {
                $tcpListen += @{ Address=[string]$c.LocalAddress; Port=[int]$c.LocalPort; Pid=[int]$c.OwningProcess }
            }
            foreach ($c in @(Get-NetTCPConnection -State Established -ErrorAction Stop)) {
                $estab += @{ LAddr=[string]$c.LocalAddress; LPort=[int]$c.LocalPort
                             RAddr=[string]$c.RemoteAddress; RPort=[int]$c.RemotePort; Pid=[int]$c.OwningProcess }
            }
        } catch { [void]$notes.Add(('Get-NetTCPConnection failed: {0}' -f $_.Exception.Message)) }
        try {
            foreach ($u in @(Get-NetUDPEndpoint -ErrorAction Stop)) {
                $udpListen += @{ Address=[string]$u.LocalAddress; Port=[int]$u.LocalPort; Pid=[int]$u.OwningProcess }
            }
        } catch { }
    }
    if ($tcpListen.Count -eq 0 -and (Get-Command netstat -ErrorAction SilentlyContinue)) {
        $usedFallback = $true
        try {
            foreach ($line in (netstat -ano)) {
                $t = $line.Trim()
                if ($t -match '^TCP\s+(\S+):(\d+)\s+\S+\s+LISTENING\s+(\d+)$') {
                    $tcpListen += @{ Address=$Matches[1]; Port=[int]$Matches[2]; Pid=[int]$Matches[3] }
                } elseif ($t -match '^TCP\s+(\S+):(\d+)\s+(\S+):(\d+)\s+ESTABLISHED\s+(\d+)$') {
                    $estab += @{ LAddr=$Matches[1]; LPort=[int]$Matches[2]
                                 RAddr=$Matches[3]; RPort=[int]$Matches[4]; Pid=[int]$Matches[5] }
                } elseif ($t -match '^UDP\s+(\S+):(\d+)\s+\S+\s+(\d+)$') {
                    $udpListen += @{ Address=$Matches[1]; Port=[int]$Matches[2]; Pid=[int]$Matches[3] }
                }
            }
        } catch { [void]$notes.Add(('netstat fallback failed: {0}' -f $_.Exception.Message)) }
    }
    if ($tcpListen.Count -eq 0) {
        [void]$notes.Add('LISTENER ENUMERATION RETURNED NOTHING - the blueprint is incomplete.')
    }

    $listeners = @()
    $tcpPortOwner = @{}   # tcp port -> @{Process; Service} for the trunk join
    foreach ($l in $tcpListen) {
        $scope = 'external'; if (Test-Loopback $l.Address) { $scope = 'loopback' }
        $entry = @{
            Proto='tcp'; Scope=$scope; Address=[string]$l.Address; Port=[int]$l.Port
            OwnerClass=(Get-Class $l.Pid); Process=(Get-ProcName $l.Pid)
            Service=(Get-ProcSvc $l.Pid); Exe=(Get-ProcExe $l.Pid)
        }
        $listeners += $entry
        if (-not $tcpPortOwner.ContainsKey([int]$l.Port)) {
            $tcpPortOwner[[int]$l.Port] = @{ Process=$entry.Process; Service=$entry.Service }
        }
    }
    foreach ($l in $udpListen) {
        $scope = 'external'; if (Test-Loopback $l.Address) { $scope = 'loopback' }
        $listeners += @{
            Proto='udp'; Scope=$scope; Address=[string]$l.Address; Port=[int]$l.Port
            OwnerClass=(Get-Class $l.Pid); Process=(Get-ProcName $l.Pid)
            Service=(Get-ProcSvc $l.Pid); Exe=(Get-ProcExe $l.Pid)
        }
    }

    # -- trunk map + remote data-plane map from established connections --------
    $trunkAgg = @{}; $rconnAgg = @{}
    foreach ($c in $estab) {
        if ((Test-Loopback $c.LAddr) -and (Test-Loopback $c.RAddr)) {
            # Socket whose PEER port is a known listener = the client (frontend)
            # side of an internal service hop: frontend process -> backend port.
            if ($tcpPortOwner.ContainsKey([int]$c.RPort)) {
                $key = '{0}|{1}|{2}' -f (Get-ProcName $c.Pid), (Get-ProcSvc $c.Pid), $c.RPort
                if (-not $trunkAgg.ContainsKey($key)) { $trunkAgg[$key] = 0 }
                $trunkAgg[$key]++
            }
        } elseif (-not (Test-Loopback $c.RAddr)) {
            $cls = Get-Class $c.Pid
            if ($cls -ne 'veeam' -and $cls -ne 'db') { continue }
            # Inbound (they hit one of our listener ports): record OUR port -
            # the peer's ephemeral port would read as false drift every run.
            $dir = 'out'; $port = [int]$c.RPort
            if ($tcpPortOwner.ContainsKey([int]$c.LPort)) { $dir = 'in'; $port = [int]$c.LPort }
            $key = '{0}|{1}|{2}|{3}|{4}' -f $c.RAddr, $port, $dir, (Get-ProcName $c.Pid), (Get-ProcSvc $c.Pid)
            if (-not $rconnAgg.ContainsKey($key)) { $rconnAgg[$key] = 0 }
            $rconnAgg[$key]++
        }
    }
    $trunk = @()
    foreach ($key in $trunkAgg.Keys) {
        $p = $key.Split('|')
        $owner = $tcpPortOwner[[int]$p[2]]
        $trunk += @{
            FrontProcess=$p[0]; FrontService=$p[1]; BackPort=[int]$p[2]
            BackProcess=[string]$owner.Process; BackService=[string]$owner.Service
            Connections=[int]$trunkAgg[$key]
        }
    }
    $remoteEndpoints = @()
    foreach ($key in $rconnAgg.Keys) {
        $p = $key.Split('|')
        $remoteEndpoints += @{
            RemoteHost=$p[0]; RemotePort=[int]$p[1]; Direction=$p[2]
            Process=$p[3]; Service=$p[4]; Connections=[int]$rconnAgg[$key]
        }
    }

    # -- installed Veeam products ----------------------------------------------
    $products = @()
    foreach ($root in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                        'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
        try {
            foreach ($k in @(Get-ChildItem $root -ErrorAction Stop)) {
                $v = Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue
                if ($v -and $v.DisplayName -and $v.DisplayName -match '(?i)veeam') {
                    $products += @{ Name=[string]$v.DisplayName; Version=[string]$v.DisplayVersion; Arch='' }
                }
            }
        } catch { }
    }
    $products = @($products | Sort-Object { $_.Name } -Unique)

    # -- Veeam registry configuration (names/hosts only - never credentials) ---
    $regValues = @{}
    $regRoots = @('HKLM:\SOFTWARE\Veeam\Veeam Backup and Replication')
    try {
        $dbCfgRoot = 'HKLM:\SOFTWARE\Veeam\Veeam Backup and Replication\DatabaseConfigurations'
        if (Test-Path $dbCfgRoot) {
            $regRoots += $dbCfgRoot
            $regRoots += @(Get-ChildItem $dbCfgRoot -Recurse -ErrorAction SilentlyContinue |
                           ForEach-Object { $_.PSPath })
        }
    } catch { }
    foreach ($rk in $regRoots) {
        try {
            $item = Get-Item $rk -ErrorAction Stop
            foreach ($vn in $item.GetValueNames()) {
                if ($vn -match '(?i)(password|pwd|secret|salt|key$|login|credential)') { continue }
                if ($vn -notmatch '(?i)(sql|postgre|database|instance|host|port|path|edition|configuration)') { continue }
                $label = ($item.Name -replace '^HKEY_LOCAL_MACHINE\\SOFTWARE\\Veeam\\', '') + '::' + $vn
                $regValues[$label] = [string]$item.GetValue($vn)
            }
        } catch { }
    }
    $regHash = ''
    try {
        $flat = ($regValues.Keys | Sort-Object | ForEach-Object { '{0}={1}' -f $_, $regValues[$_] }) -join "`n"
        $sha = [Security.Cryptography.SHA256]::Create()
        $regHash = ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($flat))) -replace '-','').ToLower()
    } catch { }

    # -- services ---------------------------------------------------------------
    $services = @()
    try {
        foreach ($s in @(Get-CimInstance Win32_Service -ErrorAction Stop | Where-Object {
                $_.Name -like 'Veeam*' -or $_.DisplayName -like 'Veeam*' -or
                $_.Name -like 'postgresql*' -or $_.Name -like 'MSSQL*' -or $_.Name -eq 'SQLBrowser' })) {
            $exe = ''
            if ($s.PathName -match '^"([^"]+)"') { $exe = $Matches[1] }
            elseif ($s.PathName -match '^(\S+)')  { $exe = $Matches[1] }
            $binHash = ''
            try { if ($exe -and (Test-Path $exe)) { $binHash = (Get-FileHash $exe -Algorithm SHA256 -ErrorAction Stop).Hash.ToLower() } } catch { }
            $services += @{
                Name=[string]$s.Name; DisplayName=[string]$s.DisplayName
                State=[string]$s.State; SubState=''
                StartType=[string]$s.StartMode; Account=[string]$s.StartName
                Path=$exe; UnitHash=$binHash
            }
        }
    } catch { [void]$notes.Add(('Service inventory failed: {0}' -f $_.Exception.Message)) }

    # -- database ----------------------------------------------------------------
    $database = @{ Engine=''; Version=''; DataDir=''; Settings=@{}; SizesMB=@{}; ConnectionCount=-1; DataDirMB=-1 }
    $dbAccess = $false
    $engine = ''
    if ($regValues.Keys -match 'SqlActiveConfiguration') {
        foreach ($k in $regValues.Keys) {
            if ($k -match 'SqlActiveConfiguration') { $engine = [string]$regValues[$k]; break }
        }
    }
    if (-not $engine) {
        if (@($services | Where-Object { $_.Name -like 'postgresql*' }).Count -gt 0) { $engine = 'PostgreSql' }
        elseif (@($services | Where-Object { $_.Name -like 'MSSQL*' }).Count -gt 0)  { $engine = 'MsSql' }
    }

    if ($IncludeDb -and $engine -match '(?i)mssql') {
        $database.Engine = 'mssql'
        $sqlServer = '.'
        foreach ($k in $regValues.Keys) {
            if ($k -match 'MsSql::SqlServerName$')   { $sqlServer = [string]$regValues[$k] }
        }
        foreach ($k in $regValues.Keys) {
            if ($k -match 'MsSql::SqlInstanceName$' -and $regValues[$k] -and $regValues[$k] -ne 'MSSQLSERVER') {
                $sqlServer = '{0}\{1}' -f $sqlServer, $regValues[$k]
            }
        }
        # System.Data.SqlClient ships with Windows PowerShell 5.1 and is still
        # bundled with PowerShell 7, but it is deprecated upstream - fall back
        # to Microsoft.Data.SqlClient if a future pwsh drops the old driver.
        # TrustServerCertificate keeps the newer driver's encrypt-by-default
        # from failing this local loopback inventory connection.
        function New-SqlConnection($connStr) {
            try { return New-Object System.Data.SqlClient.SqlConnection($connStr) } catch { }
            try { return New-Object Microsoft.Data.SqlClient.SqlConnection($connStr) } catch { }
            return $null
        }
        try {
            $conn = New-SqlConnection(
                'Server={0};Database=master;Integrated Security=SSPI;Connect Timeout=10;TrustServerCertificate=True' -f $sqlServer)
            if (-not $conn) { throw 'No SQL client driver available (System.Data.SqlClient / Microsoft.Data.SqlClient).' }
            $conn.Open()
            $cmd = $conn.CreateCommand()
            $cmd.CommandText = "SELECT CAST(SERVERPROPERTY('ProductVersion') AS varchar(64))"
            $database.Version = [string]$cmd.ExecuteScalar()
            $cmd.CommandText = 'SELECT d.name, CAST(SUM(CAST(mf.size AS bigint))*8/1024 AS int) FROM sys.master_files mf JOIN sys.databases d ON d.database_id = mf.database_id GROUP BY d.name ORDER BY d.name'
            $r = $cmd.ExecuteReader()
            while ($r.Read()) { $database.SizesMB[[string]$r.GetValue(0)] = [int]$r.GetValue(1) }
            $r.Close()
            $cmd.CommandText = "SELECT name, CAST(value_in_use AS varchar(64)) FROM sys.configurations WHERE name IN ('max server memory (MB)','user connections','max degree of parallelism')"
            $r = $cmd.ExecuteReader()
            while ($r.Read()) { $database.Settings[[string]$r.GetValue(0)] = [string]$r.GetValue(1) }
            $r.Close()
            $cmd.CommandText = 'SELECT COUNT(*) FROM sys.dm_exec_sessions WHERE is_user_process = 1'
            $database.ConnectionCount = [int]$cmd.ExecuteScalar()
            $conn.Close()
            $dbAccess = $true
        } catch {
            [void]$notes.Add(('MSSQL detected but queries failed ({0}) - database section is service-level only.' -f $_.Exception.Message))
        }
    } elseif ($IncludeDb -and $engine -match '(?i)postgre') {
        $database.Engine = 'postgresql'
        $pgSvc = @($services | Where-Object { $_.Name -like 'postgresql*' } | Select-Object -First 1)
        $pgBin = ''
        if ($pgSvc.Count -gt 0) {
            try {
                $raw = (Get-CimInstance Win32_Service -Filter ("Name='{0}'" -f $pgSvc[0].Name) -ErrorAction Stop).PathName
                if ($raw -match '-D\s+"([^"]+)"') { $database.DataDir = $Matches[1] }
                elseif ($raw -match '-D\s+(\S+)') { $database.DataDir = $Matches[1] }
                if ($raw -match '^"([^"]+)\\[^"\\]+"') { $pgBin = $Matches[1] }
            } catch { }
        }
        $psql = $null
        try { $psql = (Get-Command psql -ErrorAction SilentlyContinue).Source } catch { }
        if (-not $psql -and $pgBin -and (Test-Path (Join-Path $pgBin 'psql.exe'))) { $psql = Join-Path $pgBin 'psql.exe' }
        if ($psql) {
            function Invoke-Pg($q) { & $psql -w -h 127.0.0.1 -U postgres -tAc $q 2>$null }
            $ver = [string](Invoke-Pg 'SHOW server_version' | Select-Object -First 1)
            if ($ver) {
                $dbAccess = $true
                $database.Version = $ver
                if (-not $database.DataDir) { $database.DataDir = [string](Invoke-Pg 'SHOW data_directory' | Select-Object -First 1) }
                foreach ($s in @('max_connections','shared_buffers','work_mem','effective_cache_size','maintenance_work_mem','max_wal_size')) {
                    $v = [string](Invoke-Pg ('SHOW {0}' -f $s) | Select-Object -First 1)
                    if ($v) { $database.Settings[$s] = $v }
                }
                foreach ($row in @(Invoke-Pg "SELECT datname||'|'||pg_database_size(datname) FROM pg_database ORDER BY datname")) {
                    $p = ([string]$row).Split('|')
                    if ($p.Count -ge 2) { $database.SizesMB[$p[0]] = [int]([long]$p[1] / 1048576) }
                }
                $cc = [string](Invoke-Pg 'SELECT count(*) FROM pg_stat_activity' | Select-Object -First 1)
                if ($cc -match '^\d+$') { $database.ConnectionCount = [int]$cc }
            } else {
                [void]$notes.Add('PostgreSQL detected but psql could not authenticate (-w) - database section is service-level only.')
            }
        } else {
            [void]$notes.Add('PostgreSQL detected but psql.exe not found - database section is service-level only.')
        }
        if ($database.DataDir -and (Test-Path $database.DataDir)) {
            try {
                $bytes = (Get-ChildItem $database.DataDir -Recurse -File -ErrorAction SilentlyContinue |
                          Measure-Object -Property Length -Sum).Sum
                $database.DataDirMB = [int]($bytes / 1048576)
            } catch { }
        }
    }

    # -- config file hashes (hashes only - no contents, so no secrets) ----------
    $cfgHashes = @()
    $cfgRoots = @()
    if ($env:ProgramFiles)          { $cfgRoots += (Join-Path $env:ProgramFiles 'Veeam') }
    if (${env:ProgramFiles(x86)})   { $cfgRoots += (Join-Path ${env:ProgramFiles(x86)} 'Veeam') }
    if ($env:ProgramData)           { $cfgRoots += (Join-Path $env:ProgramData 'Veeam') }
    $cfgFiles = @()
    foreach ($root in $cfgRoots) {
        if (-not (Test-Path $root)) { continue }
        try {
            $cfgFiles += @(Get-ChildItem $root -Recurse -File -Include '*.config','*.ini','*.json','*.xml' -ErrorAction SilentlyContinue |
                           Where-Object { $_.Length -lt 1MB })
        } catch { }
    }
    foreach ($f in @($cfgFiles | Sort-Object FullName | Select-Object -First 400)) {
        try {
            $cfgHashes += @{
                Path=[string]$f.FullName
                Hash=(Get-FileHash $f.FullName -Algorithm SHA256 -ErrorAction Stop).Hash.ToLower()
                Bytes=[long]$f.Length
            }
        } catch { }
    }

    # -- certificates -------------------------------------------------------------
    $certs = @()
    try {
        foreach ($c in @(Get-ChildItem Cert:\LocalMachine\My -ErrorAction Stop | Where-Object {
                $_.FriendlyName -match '(?i)veeam' -or $_.Subject -match '(?i)veeam' })) {
            $certs += @{
                Binding='store:LocalMachine\My'; Subject=[string]$c.Subject; Issuer=[string]$c.Issuer
                NotAfter=$c.NotAfter.ToString('yyyy-MM-ddTHH:mm:ssZ'); Thumbprint=[string]$c.Thumbprint
            }
        }
    } catch { }

    # -- firewall rules -------------------------------------------------------------
    $firewall = @()
    if (Get-Command Get-NetFirewallRule -ErrorAction SilentlyContinue) {
        try {
            foreach ($r in @(Get-NetFirewallRule -ErrorAction Stop | Where-Object {
                    $_.DisplayName -like 'Veeam*' -or $_.DisplayGroup -like 'Veeam*' })) {
                $summary = 'enabled={0} dir={1} action={2}' -f $r.Enabled, $r.Direction, $r.Action
                $flat = '{0}|{1}' -f $r.DisplayName, $summary
                $sha = [Security.Cryptography.SHA256]::Create()
                $h = ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($flat))) -replace '-','').ToLower()
                $firewall += @{ Name=[string]$r.DisplayName; Hash=$h; Summary=$summary }
            }
        } catch { [void]$notes.Add(('Firewall inventory failed: {0}' -f $_.Exception.Message)) }
    }

    # -- OS + metrics ------------------------------------------------------------
    $osCaption = ''; $osBuild = ''; $arch = ''; $uptime = -1
    $memTotalKb = -1; $memFreeKb = -1
    try {
        $osInfo = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $osCaption  = [string]$osInfo.Caption
        $osBuild    = [string]$osInfo.BuildNumber
        $arch       = [string]$osInfo.OSArchitecture
        $memTotalKb = [long]$osInfo.TotalVisibleMemorySize
        $memFreeKb  = [long]$osInfo.FreePhysicalMemory
        $uptime     = [int]((Get-Date) - $osInfo.LastBootUpTime).TotalSeconds
    } catch { }
    $diskUsedMb = -1; $diskSizeMb = -1
    try {
        $sys = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction Stop
        $diskSizeMb = [int]($sys.Size / 1MB)
        $diskUsedMb = [int](($sys.Size - $sys.FreeSpace) / 1MB)
    } catch { }

    $metrics = @{
        uptime_seconds    = $uptime
        mem_total_kb      = $memTotalKb
        mem_available_kb  = $memFreeKb
        disk_root_used_mb = $diskUsedMb
        disk_root_size_mb = $diskSizeMb
        tcp_listeners     = @($listeners | Where-Object { $_.Proto -eq 'tcp' }).Count
        udp_listeners     = @($listeners | Where-Object { $_.Proto -eq 'udp' }).Count
    }
    if ($database.ConnectionCount -ge 0) { $metrics['db_connections'] = $database.ConnectionCount }
    if ($database.DataDirMB -ge 0)       { $metrics['db_datadir_mb']  = $database.DataDirMB }
    if ($usedFallback) { [void]$notes.Add('NetTCPIP unavailable - netstat fallback was used for listeners.') }
    if (-not $elevated) { [void]$notes.Add('Collector was not elevated - owners and hashes are degraded.') }

    return @{
        Platform        = 'Windows'
        Meta            = @{
            Host=$env:COMPUTERNAME; Os=$osCaption; Kernel=('build ' + $osBuild); Arch=$arch
            Elevated=$elevated; DbAccess=$dbAccess
            Captured=(Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
            Notes=@($notes)
        }
        VeeamProducts   = $products
        Services        = $services
        Listeners       = $listeners
        Trunk           = $trunk
        RemoteEndpoints = $remoteEndpoints
        Database        = $database
        Certificates    = $certs
        Firewall        = $firewall
        ConfigHashes    = $cfgHashes
        RegistryConfig  = @{ Values=$regValues; Hash=$regHash }
        Metrics         = $metrics
    }
}
