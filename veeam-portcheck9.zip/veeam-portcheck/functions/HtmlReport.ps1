# =============================================================================
#  HtmlReport.ps1 - the dependency-free blueprint report engine.
#
#  Dot-sourced by veeam-blueprint.ps1. Runs in the main script scope.
#
#  WHY HTML: report generation must work on any box that can already run the
#  capture - no Python, no Excel, no PSGallery module, no unsigned executable.
#  This file is plain PowerShell (Windows PowerShell 5.1 and PowerShell 7 -
#  the v13 default - alike); its output is a single self-contained .html
#  document (charts are inline SVG, styling is inline CSS, zero JavaScript)
#  that opens in any browser, prints to PDF, and attaches to a ticket.
#  A document, not an app - nothing new to sign.
#
#  Export-BlueprintHtml  : blueprint JSON (+ optional drift rows) -> .html
#  Export-BlueprintCsv   : blueprint JSON -> one CSV per section (for Excel)
#
#  ANNOTATION DATA: $script:PortKnowledge mirrors functions\PortTables.ps1;
#  setting/service notes are operational guidance - verify against the Veeam
#  docs for your build before acting on them.
# =============================================================================

# --- palette (validated data-viz defaults; single accent hue for magnitude,
#     status colors reserved for severity) ------------------------------------
$script:HtmlAccent   = '#2a78d6'
$script:HtmlHeader   = '#184f95'
$script:HtmlStatus   = @{ Critical = '#d03b3b'; Warning = '#fab219'; Info = '#898781' }

# --- impact knowledge ---------------------------------------------------------
# port -> @(expected owner class, documented use)
$script:PortKnowledge = @{
    22    = @('os',    'SSH')
    111   = @('veeam', 'vPower NFS - RPC portmapper. From v13 vPower NFS fails to start if this is taken.')
    135   = @('os',    'RPC Endpoint Mapper (component/agent deploy)')
    139   = @('os',    'NetBIOS session service')
    443   = @('veeam', 'Backup server connection / certificate port; the v13 trunk front door')
    445   = @('os',    'SMB - component deploy / upgrade file copy')
    1058  = @('veeam', 'vPower NFS mount service')
    1433  = @('db',    'Microsoft SQL Server - VBR configuration database (if MSSQL)')
    2049  = @('veeam', 'vPower NFS server - any other NFS server collides here')
    5432  = @('db',    'PostgreSQL - VBR configuration database')
    6160  = @('veeam', 'Veeam Installer / Deployer Service; v13 aggregates deployment traffic here')
    6161  = @('veeam', 'vPower NFS control')
    6162  = @('veeam', 'Veeam Data Mover / Transport Service')
    6164  = @('veeam', 'WAN Accelerator (control)')
    6165  = @('veeam', 'WAN Accelerator (data)')
    6172  = @('veeam', 'Backup server DB communication (Kasten plug-in)')
    6180  = @('veeam', 'Cloud Connect Service')
    9380  = @('veeam', 'Distribution Service (agent management)')
    9392  = @('veeam', 'Windows backup server initial connection (console / EM)')
    9393  = @('veeam', 'Guest Catalog Service')
    9394  = @('veeam', 'Enterprise Manager Service')
    9398  = @('veeam', 'Enterprise Manager REST API (HTTPS)')
    9399  = @('veeam', 'Enterprise Manager REST API (HTTP)')
    9401  = @('veeam', 'Mount Service (mount server <-> backup server)')
    9405  = @('veeam', 'Certificate port - EM collecting from v12 backup servers')
    9419  = @('veeam', 'Veeam RESTful API Service (HTTPS)')
    9443  = @('veeam', 'Enterprise Manager web UI (HTTPS)')
    10003 = @('veeam', 'Cloud Gateway')
    10006 = @('veeam', 'Backup server connection port')
    10443 = @('veeam', 'Veeam Host Management')
}
$script:PortRangeLo = 2500
$script:PortRangeHi = 3300

$script:DbSettingImpact = @{
    'max_connections'      = 'Ceiling on concurrent DB sessions. Veeam tunes this high (3000 is its default) because every running job and service holds sessions - too low and jobs fail with connection errors; each slot costs a little RAM and multiplies work_mem exposure.'
    'shared_buffers'       = "PostgreSQL's own page cache. Undersized -> heavy disk I/O on the config DB during job bursts. Rule of thumb ~25% of RAM on a dedicated DB box; less when VBR shares the host."
    'work_mem'             = 'Memory per sort/hash operation PER CONNECTION. Its impact multiplies with max_connections - raising both together can exhaust host RAM under load.'
    'effective_cache_size' = 'Planner hint (usually 50-75% of RAM), not an allocation. Set too low the planner avoids indexes and config queries slow down.'
    'maintenance_work_mem' = 'Memory for VACUUM and index builds - governs how quickly the config DB reclaims space after job-session churn.'
    'max_wal_size'         = 'Checkpoint spacing. Too small -> frequent checkpoints and I/O stalls exactly during busy job windows.'
    'max server memory (MB)'    = 'Hard cap on SQL Server memory. Unset (2PB default) SQL will squeeze the VBR services on a shared host; too low starves the config DB cache.'
    'user connections'          = '0 = unlimited (SQL manages). A hard value that is too low fails Veeam sessions.'
    'max degree of parallelism' = 'Parallel query fan-out. Usually left at vendor default for VBR config workloads.'
}

$script:ServiceRoles = @(
    @('veeambackupsvc',         'Core Backup & Replication engine - job orchestration (9392/443)'),
    @('veeambrokersvc',         'Broker Service - virtual infrastructure connection cache'),
    @('veeamcatalogsvc',        'Guest Catalog - indexing data (9393)'),
    @('veeamcloudsvc',          'Cloud Connect service'),
    @('veeambackupcdpsvc',      'CDP coordinator service'),
    @('veeamcdpsvc',            'CDP proxy/coordinator'),
    @('veeamdeploysvc',         'Installer / Deployer Service (6160)'),
    @('veeamdeploymentservice', 'Installer / Deployer Service (6160)'),
    @('veeamtransportsvc',      'Data Mover / Transport (6162, data range 2500-3300)'),
    @('veeamnfssvc',            'vPower NFS (111 / 1058 / 2049 / 6161) - instant recovery mounts'),
    @('veeammountsvc',          'Mount Service (9401) - file-level recovery mounts'),
    @('veeamdistributionsvc',   'Distribution Service (9380) - agent deployment'),
    @('veeamrestsvc',           'REST API service (9419)'),
    @('veeamdataanalyzersvc',   'Data Analyzer (malware detection scans)'),
    @('veeamfilesysvsssvc',     'Guest VSS integration helper'),
    @('veeamguestcontrolsvc',   'Guest interaction control'),
    @('veeamoneagentsvc',       'Veeam ONE monitoring agent'),
    @('veeamexplorersrecoverysvc', 'Explorers recovery service'),
    @('veeamvsssupport',        'VSS support provider'),
    @('postgresql',             'VBR configuration database (PostgreSQL, 5432)'),
    @('mssql',                  'VBR configuration database (SQL Server, 1433)'),
    @('sqlbrowser',             'SQL Server instance browser')
)

# -----------------------------------------------------------------------------
#  Small helpers
# -----------------------------------------------------------------------------
function ConvertTo-HtmlText {
    param($Value)
    return [System.Net.WebUtility]::HtmlEncode([string]$Value)
}

function Get-BlueprintPortInfo {
    # -> @{ Expected = 'veeam|os|db|'' '; Component = '...' }
    param([int]$Port)
    if ($script:PortKnowledge.ContainsKey($Port)) {
        $k = $script:PortKnowledge[$Port]
        return @{ Expected = $k[0]; Component = $k[1] }
    }
    if ($Port -ge $script:PortRangeLo -and $Port -le $script:PortRangeHi) {
        return @{ Expected = ''
                  Component = ('Data transfer range {0}-{1} (one port per job TCP connection)' -f $script:PortRangeLo, $script:PortRangeHi) }
    }
    return @{ Expected = ''; Component = '' }
}

function Get-BlueprintServiceRole {
    param([string]$Name, [string]$DisplayName)
    $hay = ('{0} {1}' -f $Name, $DisplayName).ToLower()
    foreach ($pair in $script:ServiceRoles) {
        if ($hay.Contains($pair[0])) { return $pair[1] }
    }
    return ''
}

# -> @{ Text = '...'; Level = ''|'warn'|'crit' }
function Get-BlueprintListenerAttention {
    param($Row)
    $cls  = ([string]$Row.ownerClass).ToLower()
    $port = [int]$Row.port
    $info = Get-BlueprintPortInfo -Port $port
    $inRange = ($port -ge $script:PortRangeLo -and $port -le $script:PortRangeHi -and [string]$Row.proto -eq 'tcp')

    if ($cls -eq 'thirdparty' -or $cls -eq 'unknown') {
        if ($info.Component -and $info.Expected) {
            return @{ Text = ('INVESTIGATE: {0} process on a documented Veeam-stack port' -f $cls); Level = 'crit' }
        }
        if ($inRange) {
            return @{ Text = ('{0} listener inside the data transfer range {1}-{2}' -f $cls, $script:PortRangeLo, $script:PortRangeHi); Level = 'crit' }
        }
        return @{ Text = ('{0} listener - identify before the next upgrade' -f $cls); Level = 'warn' }
    }
    if ($info.Expected -and $info.Expected -ne $cls -and
        -not ($info.Expected -eq 'veeam' -and $cls -eq 'db') -and
        -not ($info.Expected -eq 'db' -and $cls -eq 'veeam')) {
        if ($info.Expected -eq 'veeam' -and [string]$Row.process -eq 'System') {
            return @{ Text = 'kernel-owned (PID 4) on a Veeam port - usually an HTTP.sys URL reservation for a Veeam web component; verify with: netsh http show urlacl'
                      Level = 'warn' }
        }
        return @{ Text = ('expected {0} owner on this port, found {1}' -f $info.Expected, $cls); Level = 'warn' }
    }
    if ($inRange -and $cls -ne 'veeam') {
        return @{ Text = 'non-Veeam listener inside the data transfer range'; Level = 'warn' }
    }
    return @{ Text = ''; Level = '' }
}

function ConvertFrom-BlueprintCertDate {
    param([string]$Value)
    $s = (([string]$Value) -replace '\s+', ' ').Trim() -replace ' GMT$', ''
    foreach ($fmt in @('yyyy-MM-ddTHH:mm:ssZ', 'yyyy-MM-ddTHH:mm:ss', 'MMM d HH:mm:ss yyyy')) {
        try {
            return [datetime]::ParseExact($s, $fmt, [Globalization.CultureInfo]::InvariantCulture,
                                          [Globalization.DateTimeStyles]::None)
        } catch { }
    }
    return $null
}

# -----------------------------------------------------------------------------
#  Inline SVG horizontal bar chart.
#  $Pairs: array of @{ Label=..; Value=[double]; Color=(optional '#hex') }
# -----------------------------------------------------------------------------
function New-BlueprintSvgBar {
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][AllowEmptyCollection()][array]$Pairs,
        [string]$Unit = ''
    )
    if (-not $Pairs -or @($Pairs).Count -eq 0) { return '' }
    $rows = @($Pairs | Sort-Object { [double]$_.Value } -Descending)
    $max = ($rows | ForEach-Object { [double]$_.Value } | Measure-Object -Maximum).Maximum
    if (-not $max -or $max -le 0) { $max = 1 }

    $labelW = 230; $plotW = 420; $valW = 80
    $barH = 20; $gap = 8; $top = 30
    $width = $labelW + $plotW + $valW
    $height = $top + (@($rows).Count * ($barH + $gap)) + 6

    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine(('<svg class="chart" role="img" aria-label="{0}" width="{1}" height="{2}" viewBox="0 0 {1} {2}" xmlns="http://www.w3.org/2000/svg">' -f (ConvertTo-HtmlText $Title), $width, $height))
    [void]$sb.AppendLine(('<text x="0" y="16" class="ct">{0}</text>' -f (ConvertTo-HtmlText $Title)))
    $y = $top
    foreach ($r in $rows) {
        $val = [double]$r.Value
        $w = [math]::Max(2, [math]::Round($plotW * $val / $max))
        $color = $script:HtmlAccent
        if ($r.Color) { $color = [string]$r.Color }
        $ty = $y + $barH - 6
        [void]$sb.AppendLine(('<text x="{0}" y="{1}" class="cl" text-anchor="end">{2}</text>' -f ($labelW - 8), $ty, (ConvertTo-HtmlText $r.Label)))
        [void]$sb.AppendLine(('<rect x="{0}" y="{1}" width="{2}" height="{3}" rx="3" fill="{4}"/>' -f $labelW, $y, $w, $barH, $color))
        $valTxt = '{0:#,##0}' -f $val
        if ($Unit) { $valTxt = '{0} {1}' -f $valTxt, $Unit }
        [void]$sb.AppendLine(('<text x="{0}" y="{1}" class="cv">{2}</text>' -f ($labelW + $w + 6), $ty, (ConvertTo-HtmlText $valTxt)))
        $y += $barH + $gap
    }
    [void]$sb.AppendLine('</svg>')
    return $sb.ToString()
}

# -----------------------------------------------------------------------------
#  Table builder. $Columns: array of @{ Head=..; Get={ script } ; Class={ optional script -> 'warn'|'crit'|'' } }
#  $RowClass: optional script -> 'warn'|'crit'|'' for the whole row.
# -----------------------------------------------------------------------------
function New-BlueprintHtmlTable {
    param(
        [Parameter(Mandatory)][array]$Columns,
        [Parameter(Mandatory)][AllowEmptyCollection()][array]$Rows,
        [scriptblock]$RowClass,
        [string]$EmptyText = 'none captured'
    )
    $sb = New-Object System.Text.StringBuilder
    if (-not $Rows -or @($Rows).Count -eq 0) {
        [void]$sb.AppendLine(('<p class="muted">{0}</p>' -f (ConvertTo-HtmlText $EmptyText)))
        return $sb.ToString()
    }
    [void]$sb.AppendLine('<table><thead><tr>')
    foreach ($c in $Columns) {
        [void]$sb.AppendLine(('<th>{0}</th>' -f (ConvertTo-HtmlText $c.Head)))
    }
    [void]$sb.AppendLine('</tr></thead><tbody>')
    foreach ($row in $Rows) {
        $cls = ''
        if ($RowClass) { $cls = [string]($row | ForEach-Object $RowClass) }
        if ($cls) { [void]$sb.Append(('<tr class="{0}">' -f $cls)) } else { [void]$sb.Append('<tr>') }
        foreach ($c in $Columns) {
            $v = $row | ForEach-Object $c.Get
            [void]$sb.Append(('<td>{0}</td>' -f (ConvertTo-HtmlText $v)))
        }
        [void]$sb.AppendLine('</tr>')
    }
    [void]$sb.AppendLine('</tbody></table>')
    return $sb.ToString()
}

# -----------------------------------------------------------------------------
#  The document
# -----------------------------------------------------------------------------
function ConvertTo-BlueprintHtml {
    param(
        [Parameter(Mandatory)]$Doc,
        [object[]]$DriftRows,
        [string]$SourceName = ''
    )

    $ident = $Doc.identity
    $met = $Doc.metrics
    $listeners = @($ident.listeners)
    $services  = @($ident.services)
    $trunk     = @($ident.trunk)
    $remote    = @($ident.remoteEndpoints)
    $products  = @($ident.veeamProducts)
    $certs     = @($ident.certificates)
    $firewall  = @($ident.firewall)
    $cfg       = @($ident.configHashes)
    $now       = Get-Date

    # ---- pre-compute attention + cert expiry --------------------------------
    $attn = @{ unexpected = 0; mismatch = 0; range = 0; stoppedAuto = 0 }
    foreach ($l in $listeners) {
        $a = Get-BlueprintListenerAttention -Row $l
        $cls = ([string]$l.ownerClass).ToLower()
        if ($cls -eq 'thirdparty' -or $cls -eq 'unknown') { $attn.unexpected++ }
        elseif ($a.Level -eq 'warn' -and $a.Text -notmatch 'data transfer range') { $attn.mismatch++ }
        if ([int]$l.port -ge $script:PortRangeLo -and [int]$l.port -le $script:PortRangeHi -and
            [string]$l.proto -eq 'tcp' -and $cls -ne 'veeam') { $attn.range++ }
    }
    foreach ($s in $services) {
        $auto = ([string]$s.startType).ToLower().StartsWith('auto') -or ([string]$s.startType).ToLower() -eq 'enabled'
        $state = ([string]$s.state).ToLower()
        if ($auto -and $state -ne 'running' -and $state -ne 'active') { $attn.stoppedAuto++ }
    }
    $certSoon = 0
    foreach ($c in $certs) {
        $exp = ConvertFrom-BlueprintCertDate -Value $c.notAfter
        if ($exp -and ($exp - $now).TotalDays -lt 90) { $certSoon++ }
    }
    $driftCrit = 0; $driftWarn = 0; $driftInfo = 0
    if ($DriftRows) {
        $driftCrit = @($DriftRows | Where-Object { $_.Severity -eq 'Critical' }).Count
        $driftWarn = @($DriftRows | Where-Object { $_.Severity -eq 'Warning' }).Count
        $driftInfo = @($DriftRows | Where-Object { $_.Severity -eq 'Info' }).Count
    }

    $h = New-Object System.Text.StringBuilder
    function AL([string]$s) { [void]$h.AppendLine($s) }

    # ---- head + css ----------------------------------------------------------
    AL '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
    AL '<meta name="viewport" content="width=device-width, initial-scale=1">'
    AL ('<title>Veeam Blueprint - {0}</title>' -f (ConvertTo-HtmlText $Doc.host))
    AL '<style>'
    AL 'body{font-family:"Segoe UI",system-ui,Arial,sans-serif;color:#0b0b0b;background:#f4f4f2;margin:0;font-size:14px}'
    AL '.page{max-width:1180px;margin:0 auto;padding:24px 28px 60px}'
    AL 'h1{font-size:24px;margin:0 0 2px}h2{font-size:17px;color:#184f95;margin:0 0 10px}'
    AL '.sub{color:#898781;font-size:12.5px;margin-bottom:14px}'
    AL '.card{background:#fcfcfb;border:1px solid #e1e0d9;border-radius:8px;padding:16px 18px;margin:0 0 18px}'
    AL '.tierok{display:inline-block;background:#e2f1e2;border-radius:4px;padding:3px 10px;font-weight:600}'
    AL '.tierwarn{display:inline-block;background:#fcf0d4;border-radius:4px;padding:3px 10px;font-weight:600}'
    AL '.kpis{display:flex;flex-wrap:wrap;gap:12px;margin:14px 0 4px}'
    AL '.kpi{background:#fcfcfb;border:1px solid #e1e0d9;border-radius:8px;padding:10px 16px;min-width:120px}'
    AL '.kpi .v{font-size:22px;font-weight:700;color:#184f95}.kpi .l{font-size:11.5px;color:#52514e}'
    AL 'table{border-collapse:collapse;width:100%;font-size:12.5px;margin:6px 0 4px}'
    AL 'th{background:#184f95;color:#fff;text-align:left;padding:6px 9px;font-weight:600;position:sticky;top:0}'
    AL 'td{border-bottom:1px solid #e1e0d9;padding:5px 9px;vertical-align:top}'
    AL 'tbody tr:nth-child(even){background:#f7f7f4}'
    AL 'tr.warn td{background:#fcf0d4}tr.crit td{background:#f7dede}'
    AL 'tr.sevCritical td{background:#f7dede}tr.sevWarning td{background:#fcf0d4}'
    AL '.muted{color:#898781}.small{font-size:12px}'
    AL '.chart .ct{font:600 13.5px "Segoe UI",system-ui,sans-serif;fill:#0b0b0b}'
    AL '.chart .cl{font:12px "Segoe UI",system-ui,sans-serif;fill:#52514e}'
    AL '.chart .cv{font:600 12px "Segoe UI",system-ui,sans-serif;fill:#0b0b0b}'
    AL 'details{margin:8px 0}summary{cursor:pointer;font-weight:600;color:#184f95;padding:4px 0}'
    AL 'nav{font-size:12.5px;margin:0 0 16px}nav a{color:#184f95;text-decoration:none;margin-right:14px}'
    AL 'code{background:#f0efec;border-radius:3px;padding:1px 5px;font-size:12px}'
    AL '.attn{margin:8px 0}.attn td:first-child{width:56%}'
    AL '.ok{color:#006300;font-weight:600}.bad{color:#b02a2a;font-weight:700}'
    AL '@media print{.card{border:none;padding:0}body{background:#fff}th{position:static}}'
    AL '</style></head><body><div class="page">'

    # ---- header ---------------------------------------------------------------
    AL ('<h1>Veeam Configuration Blueprint &mdash; {0}</h1>' -f (ConvertTo-HtmlText $Doc.host))
    AL ('<div class="sub">Captured {0} &nbsp;|&nbsp; {1} &nbsp;|&nbsp; {2} {3}</div>' -f `
        (ConvertTo-HtmlText $Doc.capturedUtc), (ConvertTo-HtmlText $Doc.platform),
        (ConvertTo-HtmlText $ident.os.caption), (ConvertTo-HtmlText $ident.os.kernel))
    $tierOk = ([bool]$Doc.tier.elevated -and [bool]$Doc.tier.dbAccess)
    $elevTxt = 'NOT ELEVATED'; if ([bool]$Doc.tier.elevated) { $elevTxt = 'elevated' }
    $dbTxt = 'NO database access'; if ([bool]$Doc.tier.dbAccess) { $dbTxt = 'database access' }
    $tierCls = 'tierwarn'; if ($tierOk) { $tierCls = 'tierok' }
    AL ('<div class="{0}">Capture tier: {1}, {2}</div>' -f $tierCls, $elevTxt, $dbTxt)
    foreach ($n in @($Doc.tier.notes)) {
        AL ('<div class="muted small">note: {0}</div>' -f (ConvertTo-HtmlText $n))
    }

    $navItems = @('overview', 'listeners', 'trunk', 'services', 'database', 'products', 'certs', 'config', 'metrics')
    if ($DriftRows) { $navItems = @('overview', 'drift') + ($navItems | Select-Object -Skip 1) }
    AL '<nav>'
    foreach ($n in $navItems) { AL ('<a href="#{0}">{1}</a>' -f $n, $n) }
    AL '</nav>'

    # ---- overview ---------------------------------------------------------------
    AL '<div class="card" id="overview">'
    $running = @($services | Where-Object { ([string]$_.state).ToLower() -in @('running', 'active') }).Count
    $dbLabel = ('{0} {1}' -f $ident.database.engine, $ident.database.version).Trim()
    if (-not $dbLabel) { $dbLabel = '-' }
    $vbSize = '-'
    if ($met.databaseSizesMB -and $met.databaseSizesMB.PSObject.Properties['VeeamBackup']) {
        $vbSize = ('{0} MB' -f $met.databaseSizesMB.VeeamBackup)
    }
    AL '<div class="kpis">'
    foreach ($kpi in @(
            @(@($products).Count, 'Veeam products'),
            @(('{0}/{1} running' -f $running, @($services).Count), 'Services'),
            @([string]$met.tcp_listeners, 'TCP listeners'),
            @([string]$met.udp_listeners, 'UDP listeners'),
            @(@($trunk).Count, 'Trunk hops'),
            @($dbLabel, 'Config DB'),
            @($vbSize, 'VeeamBackup DB'))) {
        AL ('<div class="kpi"><div class="v">{0}</div><div class="l">{1}</div></div>' -f `
            (ConvertTo-HtmlText $kpi[0]), (ConvertTo-HtmlText $kpi[1]))
    }
    AL '</div>'

    AL '<h2>Needs attention</h2><table class="attn"><tbody>'
    $attnRows = @(
        @('Third-party / unknown listeners', $attn.unexpected, 'See Listeners - red rows.'),
        @('Listeners on documented Veeam ports with a different owner', $attn.mismatch, 'See Listeners - amber rows.'),
        @(('Non-Veeam TCP listeners in the data range {0}-{1}' -f $script:PortRangeLo, $script:PortRangeHi), $attn.range, 'Each one shrinks the pool Veeam draws from per job connection.'),
        @('Auto-start services not running', $attn.stoppedAuto, "A stopped service's ports read free NOW but must be free when it restarts."),
        @('Certificates expiring within 90 days', $certSoon, 'See Certificates - the days-left column.')
    )
    if ($DriftRows) {
        $attnRows += , @('Drift vs reference (Critical / Warning)', ('{0} / {1}' -f $driftCrit, $driftWarn), 'See the Drift section.')
    }
    foreach ($r in $attnRows) {
        $numPart = ([string]$r[1]).Split('/')[0].Trim()
        $isBad = $false
        $parsed = 0
        if ([int]::TryParse($numPart, [ref]$parsed)) { $isBad = ($parsed -gt 0) }
        $vCls = 'ok'; if ($isBad) { $vCls = 'bad' }
        AL ('<tr><td>{0}</td><td class="{1}">{2}</td><td class="muted">{3}</td></tr>' -f `
            (ConvertTo-HtmlText $r[0]), $vCls, (ConvertTo-HtmlText $r[1]), (ConvertTo-HtmlText $r[2]))
    }
    AL '</tbody></table>'

    # capacity
    AL '<h2>Host capacity</h2><table class="attn"><tbody>'
    $capRows = @()
    $du = 0.0; $ds = 0.0; $ma = 0.0; $mt = 0.0
    if ([double]::TryParse([string]$met.disk_root_used_mb, [ref]$du) -and
        [double]::TryParse([string]$met.disk_root_size_mb, [ref]$ds) -and $ds -gt 0) {
        $capRows += , @('Disk (system volume)', ('{0:N0} / {1:N0} MB used ({2:P1})' -f $du, $ds, ($du / $ds)))
    }
    if ([double]::TryParse([string]$met.mem_available_kb, [ref]$ma) -and
        [double]::TryParse([string]$met.mem_total_kb, [ref]$mt) -and $mt -gt 0) {
        $capRows += , @('Memory', ('{0:N0} of {1:N0} MB free ({2:P1})' -f ($ma / 1024), ($mt / 1024), ($ma / $mt)))
    }
    $up = 0.0
    if ([double]::TryParse([string]$met.uptime_seconds, [ref]$up) -and $up -gt 0) {
        $capRows += , @('Uptime', ('{0:N1} days' -f ($up / 86400)))
    }
    foreach ($r in $capRows) {
        AL ('<tr><td>{0}</td><td>{1}</td><td></td></tr>' -f (ConvertTo-HtmlText $r[0]), (ConvertTo-HtmlText $r[1]))
    }
    AL '</tbody></table></div>'

    # ---- drift ---------------------------------------------------------------
    if ($DriftRows) {
        AL '<div class="card" id="drift">'
        AL '<h2>Drift vs reference blueprint</h2>'
        $sevPairs = @()
        foreach ($sev in @('Critical', 'Warning', 'Info')) {
            $cnt = @($DriftRows | Where-Object { $_.Severity -eq $sev }).Count
            if ($cnt -gt 0) { $sevPairs += , @{ Label = $sev; Value = $cnt; Color = $script:HtmlStatus[$sev] } }
        }
        AL (New-BlueprintSvgBar -Title 'Drift items by severity' -Pairs $sevPairs)
        $sorted = @($DriftRows | Sort-Object @{e = { switch ([string]$_.Severity) { 'Critical' { 0 }; 'Warning' { 1 }; default { 2 } } }}, Section, Key)
        AL (New-BlueprintHtmlTable -Rows $sorted -RowClass { 'sev' + [string]$_.Severity } -Columns @(
                @{ Head = 'Severity';  Get = { $_.Severity } },
                @{ Head = 'Section';   Get = { $_.Section } },
                @{ Head = 'Change';    Get = { $_.ChangeType } },
                @{ Head = 'Key';       Get = { $_.Key } },
                @{ Head = 'Field';     Get = { $_.Field } },
                @{ Head = 'Before';    Get = { $_.Before } },
                @{ Head = 'After';     Get = { $_.After } }))
        AL '<p class="muted small">Review, remediate or accept, then promote the new capture to baseline (veeam-blueprint.ps1 -Promote).</p>'
        AL '</div>'
    }

    # ---- listeners -------------------------------------------------------------
    AL '<div class="card" id="listeners">'
    AL '<h2>Listeners &mdash; every TCP/UDP endpoint, with the Veeam component that documents the port</h2>'
    $clsPairs = @()
    foreach ($g in ($listeners | Group-Object { [string]$_.ownerClass })) {
        $clsPairs += , @{ Label = $g.Name; Value = $g.Count }
    }
    AL (New-BlueprintSvgBar -Title 'Listeners by owner class' -Pairs $clsPairs)
    AL (New-BlueprintHtmlTable -Rows $listeners -RowClass { (Get-BlueprintListenerAttention -Row $_).Level } -Columns @(
            @{ Head = 'Proto';   Get = { $_.proto } },
            @{ Head = 'Scope';   Get = { $_.scope } },
            @{ Head = 'Address'; Get = { $_.address } },
            @{ Head = 'Port';    Get = { $_.port } },
            @{ Head = 'Class';   Get = { $_.ownerClass } },
            @{ Head = 'Process'; Get = { $_.process } },
            @{ Head = 'Service'; Get = { $_.service } },
            @{ Head = 'Component (documented use)'; Get = { (Get-BlueprintPortInfo -Port ([int]$_.port)).Component } },
            @{ Head = 'Attention'; Get = { (Get-BlueprintListenerAttention -Row $_).Text } }))
    AL '</div>'

    # ---- trunk -------------------------------------------------------------------
    AL '<div class="card" id="trunk">'
    AL '<h2>Port &amp; trunk map &mdash; which frontend feeds which backend service over loopback</h2>'
    AL '<p class="muted small">This is how v13-style port aggregation actually wires up on this host: each row is an observed loopback connection from a frontend process into a backend listener.</p>'
    $fan = @{}
    foreach ($t in $trunk) {
        $key = ('{0} :{1}' -f $t.backProcess, $t.backPort)
        if (-not $fan.ContainsKey($key)) { $fan[$key] = 0 }
        $fan[$key] += [int]$t.connections
    }
    $fanPairs = @()
    foreach ($k in $fan.Keys) { $fanPairs += , @{ Label = $k; Value = $fan[$k] } }
    AL (New-BlueprintSvgBar -Title 'Trunk fan-in: connections per backend' -Pairs $fanPairs)
    AL (New-BlueprintHtmlTable -Rows @($trunk | Sort-Object { [int]$_.backPort }, { [string]$_.frontProcess }) -Columns @(
            @{ Head = 'Frontend process'; Get = { $_.frontProcess } },
            @{ Head = 'Frontend service'; Get = { $_.frontService } },
            @{ Head = 'Backend port';     Get = { $_.backPort } },
            @{ Head = 'Backend process';  Get = { $_.backProcess } },
            @{ Head = 'Backend service';  Get = { $_.backService } },
            @{ Head = 'Conns';            Get = { $_.connections } },
            @{ Head = "Backend port's documented use"; Get = { (Get-BlueprintPortInfo -Port ([int]$_.backPort)).Component } }) `
            -EmptyText 'No loopback service hops were active at capture time.')
    AL '<h2 style="margin-top:16px">Observed data plane &mdash; established connections to/from remote hosts</h2>'
    AL '<p class="muted small">Point-in-time: idle infrastructure shows nothing. Capture during a job window to map managed-server traffic; merge several captures for the full picture.</p>'
    AL (New-BlueprintHtmlTable -Rows $remote -Columns @(
            @{ Head = 'Direction';    Get = { $_.direction } },
            @{ Head = 'Remote host';  Get = { $_.remoteHost } },
            @{ Head = 'Port';         Get = { $_.remotePort } },
            @{ Head = 'Local process';Get = { $_.process } },
            @{ Head = 'Local service';Get = { $_.service } },
            @{ Head = 'Conns';        Get = { $_.connections } },
            @{ Head = "Port's documented use"; Get = { (Get-BlueprintPortInfo -Port ([int]$_.remotePort)).Component } }))
    if (@($ident.vbrTopology).Count -gt 0) {
        AL '<h2 style="margin-top:16px">Declared topology (VBR API)</h2>'
        AL (New-BlueprintHtmlTable -Rows @($ident.vbrTopology) -Columns @(
                @{ Head = 'Role'; Get = { $_.role } },
                @{ Head = 'Name'; Get = { $_.name } },
                @{ Head = 'Type'; Get = { $_.type } }))
    }
    AL '</div>'

    # ---- services ------------------------------------------------------------------
    AL '<div class="card" id="services">'
    AL '<h2>Services &mdash; state, identity, and role</h2>'
    $accPairs = @()
    foreach ($g in ($services | Group-Object { [string]$_.account })) {
        $lbl = $g.Name; if (-not $lbl) { $lbl = '(none)' }
        $accPairs += , @{ Label = $lbl; Value = $g.Count }
    }
    AL (New-BlueprintSvgBar -Title 'Services per run-as account' -Pairs $accPairs)
    AL (New-BlueprintHtmlTable -Rows $services -RowClass {
            $auto = ([string]$_.startType).ToLower().StartsWith('auto') -or ([string]$_.startType).ToLower() -eq 'enabled'
            $st = ([string]$_.state).ToLower()
            if ($auto -and $st -ne 'running' -and $st -ne 'active') { 'warn' } else { '' }
        } -Columns @(
            @{ Head = 'Service';      Get = { $_.name } },
            @{ Head = 'Display name'; Get = { $_.displayName } },
            @{ Head = 'State';        Get = { $_.state } },
            @{ Head = 'Start type';   Get = { $_.startType } },
            @{ Head = 'Account';      Get = { $_.account } },
            @{ Head = 'Role';         Get = { Get-BlueprintServiceRole -Name $_.name -DisplayName $_.displayName } },
            @{ Head = 'Binary path';  Get = { $_.path } }))
    AL '</div>'

    # ---- database ---------------------------------------------------------------------
    AL '<div class="card" id="database">'
    AL '<h2>Configuration database</h2>'
    if ([string]$ident.database.engine) {
        AL '<table class="attn"><tbody>'
        foreach ($pair in @(
                @('Engine', $ident.database.engine), @('Version', $ident.database.version),
                @('Data directory', $ident.database.dataDir),
                @('Data dir size (MB)', $met.db_datadir_mb),
                @('Active connections at capture', $met.db_connections))) {
            AL ('<tr><td>{0}</td><td>{1}</td><td></td></tr>' -f (ConvertTo-HtmlText $pair[0]), (ConvertTo-HtmlText $pair[1]))
        }
        AL '</tbody></table>'
        $sizePairs = @()
        if ($met.databaseSizesMB) {
            foreach ($p in $met.databaseSizesMB.PSObject.Properties) {
                $sizePairs += , @{ Label = $p.Name; Value = [double]$p.Value }
            }
        }
        AL (New-BlueprintSvgBar -Title 'Database sizes (MB)' -Pairs $sizePairs -Unit 'MB')
        AL '<h2 style="margin-top:14px">Engine settings and what they mean for VBR</h2>'
        $setRows = @()
        if ($ident.database.settings) {
            foreach ($p in ($ident.database.settings.PSObject.Properties | Sort-Object Name)) {
                $setRows += , ([pscustomobject]@{ Setting = $p.Name; Value = $p.Value
                                                  Impact = [string]$script:DbSettingImpact[$p.Name] })
            }
        }
        AL (New-BlueprintHtmlTable -Rows $setRows -Columns @(
                @{ Head = 'Setting'; Get = { $_.Setting } },
                @{ Head = 'Value';   Get = { $_.Value } },
                @{ Head = 'Impact';  Get = { $_.Impact } }) `
                -EmptyText 'No engine settings captured (no DB access at capture time).')
    } else {
        AL '<p class="muted">No database engine detected in this capture.</p>'
    }
    AL '</div>'

    # ---- products ------------------------------------------------------------------------
    AL '<div class="card" id="products">'
    AL '<h2>Installed Veeam products / packages</h2>'
    $famPairs = @()
    foreach ($g in ($products | Group-Object {
                $m = [regex]::Match([string]$_.version, '^(\d+)\.')
                if ($m.Success) { $m.Groups[1].Value + '.x' } else { 'unversioned' } })) {
        $famPairs += , @{ Label = $g.Name; Value = $g.Count }
    }
    AL (New-BlueprintSvgBar -Title 'Products per major version' -Pairs $famPairs)
    AL (New-BlueprintHtmlTable -Rows $products -Columns @(
            @{ Head = 'Product / package'; Get = { $_.name } },
            @{ Head = 'Version';           Get = { $_.version } },
            @{ Head = 'Arch';              Get = { $_.arch } }))
    AL '</div>'

    # ---- certs + firewall --------------------------------------------------------------------
    AL '<div class="card" id="certs">'
    AL '<h2>Certificates</h2>'
    $certRows = @()
    foreach ($c in $certs) {
        $exp = ConvertFrom-BlueprintCertDate -Value $c.notAfter
        $days = ''
        $lvl = ''
        if ($exp) {
            $days = [int][math]::Floor(($exp - $now).TotalDays)
            if ($days -lt 90) { $lvl = 'crit' } elseif ($days -lt 365) { $lvl = 'warn' }
        }
        $certRows += , ([pscustomobject]@{
                Binding = $c.binding; Subject = $c.subject; Issuer = $c.issuer
                Expires = $c.notAfter; DaysLeft = $days; Thumbprint = $c.thumbprint; Level = $lvl })
    }
    AL (New-BlueprintHtmlTable -Rows $certRows -RowClass { $_.Level } -Columns @(
            @{ Head = 'Binding';    Get = { $_.Binding } },
            @{ Head = 'Subject';    Get = { $_.Subject } },
            @{ Head = 'Issuer';     Get = { $_.Issuer } },
            @{ Head = 'Expires';    Get = { $_.Expires } },
            @{ Head = 'Days left';  Get = { $_.DaysLeft } },
            @{ Head = 'Thumbprint / fingerprint'; Get = { $_.Thumbprint } }))
    AL '<h2 style="margin-top:16px">Firewall rules (Veeam-related)</h2>'
    AL (New-BlueprintHtmlTable -Rows $firewall -RowClass {
            if (([string]$_.summary) -match 'enabled=False') { 'warn' } else { '' }
        } -Columns @(
            @{ Head = 'Rule / zone'; Get = { $_.name } },
            @{ Head = 'Summary';     Get = { $_.summary } },
            @{ Head = 'Hash';        Get = { $_.hash } }))
    AL '</div>'

    # ---- config hashes + registry (collapsed - long) -------------------------------------------
    AL '<div class="card" id="config">'
    AL ('<details><summary>Config file hashes ({0}) &mdash; the drift engine''s tripwire (contents are never captured)</summary>' -f @($cfg).Count)
    AL (New-BlueprintHtmlTable -Rows $cfg -Columns @(
            @{ Head = 'Path';    Get = { $_.path } },
            @{ Head = 'Bytes';   Get = { $_.bytes } },
            @{ Head = 'SHA-256'; Get = { $_.hash } }))
    AL '</details>'
    if ($ident.registryConfig -and $ident.registryConfig.values) {
        $regRows = @()
        foreach ($p in ($ident.registryConfig.values.PSObject.Properties | Sort-Object Name)) {
            $regRows += , ([pscustomobject]@{ K = $p.Name; V = $p.Value })
        }
        AL ('<details><summary>Veeam registry configuration ({0} non-secret values)</summary>' -f @($regRows).Count)
        AL (New-BlueprintHtmlTable -Rows $regRows -Columns @(
                @{ Head = 'Key :: value name'; Get = { $_.K } },
                @{ Head = 'Value';             Get = { $_.V } }))
        AL '</details>'
    }
    AL '</div>'

    # ---- metrics ------------------------------------------------------------------------------
    AL '<div class="card" id="metrics">'
    AL '<h2>Host metrics &mdash; reported for trending, never treated as drift</h2>'
    $metRows = @()
    if ($met) {
        foreach ($p in ($met.PSObject.Properties | Sort-Object Name)) {
            if ($p.Name -eq 'databaseSizesMB') { continue }
            $metRows += , ([pscustomobject]@{ K = $p.Name; V = $p.Value })
        }
        if ($met.databaseSizesMB) {
            foreach ($p in ($met.databaseSizesMB.PSObject.Properties | Sort-Object Name)) {
                $metRows += , ([pscustomobject]@{ K = ('db_size_mb:' + $p.Name); V = $p.Value })
            }
        }
    }
    AL (New-BlueprintHtmlTable -Rows $metRows -Columns @(
            @{ Head = 'Metric'; Get = { $_.K } },
            @{ Head = 'Value';  Get = { $_.V } }))
    AL '</div>'

    AL ('<p class="muted small">Generated {0} by veeam-blueprint.ps1 (HtmlReport.ps1) from {1}. Port and setting annotations mirror functions\PortTables.ps1 and general operational guidance &mdash; verify against the Veeam docs for your build.</p>' -f `
        (ConvertTo-HtmlText ($now.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'))), (ConvertTo-HtmlText $SourceName))
    AL '</div></body></html>'
    return $h.ToString()
}

# -----------------------------------------------------------------------------
#  Public entry points
# -----------------------------------------------------------------------------
function Export-BlueprintHtml {
    param(
        [Parameter(Mandatory)][string]$JsonPath,
        [string]$OutPath,
        [object[]]$DriftRows
    )
    if (-not (Test-Path $JsonPath)) {
        Write-Host ('  Not found: {0}' -f $JsonPath) -ForegroundColor Red
        return $null
    }
    try {
        $doc = Get-Content $JsonPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    } catch {
        Write-Host ('  Could not read the blueprint: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
    if ([string]$doc.schema -notlike 'veeam-blueprint/*') {
        Write-Host ('  {0} is not a veeam-blueprint document.' -f $JsonPath) -ForegroundColor Red
        return $null
    }
    if (-not $OutPath) { $OutPath = [IO.Path]::ChangeExtension($JsonPath, 'html') }
    try {
        $html = ConvertTo-BlueprintHtml -Doc $doc -DriftRows $DriftRows `
                    -SourceName ([IO.Path]::GetFileName($JsonPath))
        [IO.File]::WriteAllText($OutPath, $html, (New-Object Text.UTF8Encoding($false)))
        Write-Host ('  HTML report written: {0}' -f $OutPath) -ForegroundColor Green
        return $OutPath
    } catch {
        Write-Host ('  HTML report failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}

function Export-BlueprintCsv {
    param(
        [Parameter(Mandatory)][string]$JsonPath,
        [Parameter(Mandatory)][string]$OutDir
    )
    if (-not (Test-Path $JsonPath)) {
        Write-Host ('  Not found: {0}' -f $JsonPath) -ForegroundColor Red
        return $false
    }
    try {
        $doc = Get-Content $JsonPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir -Force -ErrorAction Stop | Out-Null }
    } catch {
        Write-Host ('  CSV export failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $false
    }
    $stem = [IO.Path]::GetFileNameWithoutExtension($JsonPath)
    $ident = $doc.identity
    $written = 0

    $sections = @(
        @{ Name = 'listeners';        Rows = @($ident.listeners) },
        @{ Name = 'trunk';            Rows = @($ident.trunk) },
        @{ Name = 'remote_endpoints'; Rows = @($ident.remoteEndpoints) },
        @{ Name = 'services';         Rows = @($ident.services) },
        @{ Name = 'products';         Rows = @($ident.veeamProducts) },
        @{ Name = 'certificates';     Rows = @($ident.certificates) },
        @{ Name = 'firewall';         Rows = @($ident.firewall) },
        @{ Name = 'config_hashes';    Rows = @($ident.configHashes) }
    )
    foreach ($s in $sections) {
        if (@($s.Rows).Count -eq 0) { continue }
        $p = Join-Path $OutDir ('{0}_{1}.csv' -f $stem, $s.Name)
        try {
            @($s.Rows) | Export-Csv -Path $p -NoTypeInformation -Encoding UTF8
            $written++
        } catch {
            Write-Host ('  Could not write {0}: {1}' -f $p, $_.Exception.Message) -ForegroundColor Red
        }
    }
    # db settings + metrics are maps, not row arrays - flatten them
    $flat = @()
    if ($ident.database -and $ident.database.settings) {
        foreach ($p in $ident.database.settings.PSObject.Properties) {
            $flat += , ([pscustomobject]@{ Setting = $p.Name; Value = $p.Value })
        }
    }
    if (@($flat).Count -gt 0) {
        $flat | Export-Csv -Path (Join-Path $OutDir ('{0}_db_settings.csv' -f $stem)) -NoTypeInformation -Encoding UTF8
        $written++
    }
    $metRows = @()
    if ($doc.metrics) {
        foreach ($p in $doc.metrics.PSObject.Properties) {
            if ($p.Name -eq 'databaseSizesMB') {
                foreach ($q in $p.Value.PSObject.Properties) {
                    $metRows += , ([pscustomobject]@{ Metric = ('db_size_mb:' + $q.Name); Value = $q.Value })
                }
            } else {
                $metRows += , ([pscustomobject]@{ Metric = $p.Name; Value = $p.Value })
            }
        }
    }
    if (@($metRows).Count -gt 0) {
        $metRows | Export-Csv -Path (Join-Path $OutDir ('{0}_metrics.csv' -f $stem)) -NoTypeInformation -Encoding UTF8
        $written++
    }
    Write-Host ('  {0} CSV file(s) written to {1}' -f $written, $OutDir) -ForegroundColor Green
    return $true
}
