# =============================================================================
#  PortTables.ps1 - shared port data. THE SOURCE OF TRUTH for every check.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

# =============================================================================
#  PORT TABLES
# =============================================================================
# ExpectedOwner : Veeam | Windows | Database
# Profile       : Core | EnterpriseManager | CloudConnect | WanAccelerator
# Verified      : $true if confirmed against v13 documentation

$windowsPorts = @(
    # -- vPower NFS - the classic upgrade blockers ----------------------------
    @{Port=111;   Proto='TCP+UDP'; ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Veeam vPower NFS Service (RPC portmapper)'
      Notes='HIGHEST RISK. From v13 the service fails to start if 111 is locked and the port cannot be changed. Common squatters: ONC/RPC Portmapper (portmap.exe), Windows "Server for NFS" / Services for UNIX, hanewin NFS, Arcserve, Cygwin rpcbind.'}
    @{Port=1058;  Proto='TCP+UDP'; ExpectedOwner='Veeam'; Profile='Core'; Verified=$false
      Component='Veeam vPower NFS mount service'
      Notes='Can be taken by RPC dynamic allocation or third-party NFS.'}
    @{Port=2049;  Proto='TCP+UDP'; ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Veeam vPower NFS server'
      Notes='HIGH RISK. Standard NFS port - any other NFS server on the box takes it.'}
    @{Port=6161;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$false
      Component='Veeam vPower NFS Service (control)'; Notes=''}

    # -- Backup server services ----------------------------------------------
    @{Port=9392;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Windows backup server - initial connection (console / EM)'; Notes=''}
    @{Port=443;   Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='v13 certificate/connection port; Connect-VBRServer default'
      Notes='Frequently taken by IIS, other web consoles, or an existing HTTPS binding.'}
    @{Port=9405;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Certificate port for EM collecting from v12 backup servers'; Notes=''}
    @{Port=9393;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$false
      Component='Veeam Guest Catalog Service'; Notes=''}
    @{Port=9401;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$false
      Component='Veeam Mount Service (mount server <-> backup server)'; Notes=''}
    @{Port=9419;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Veeam RESTful API Service (HTTPS)'; Notes='Optional at install - skip if REST API not installed.'}
    @{Port=6172;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Backup server database communication (Veeam Plug-in for Kasten)'; Notes=''}
    @{Port=10006; Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Backup server connection port'; Notes=''}
    @{Port=9380;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$false
      Component='Veeam Distribution Service (agent management)'; Notes=''}
    @{Port=6160;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Veeam Installer / Deployer Service'; Notes=''}
    @{Port=6162;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Veeam Data Mover / Transport Service'; Notes=''}

    # -- Configuration database ----------------------------------------------
    @{Port=5432;  Proto='TCP';     ExpectedOwner='Database'; Profile='Core'; Verified=$true
      Component='PostgreSQL - VBR configuration database (v12+)'
      Notes='A second PostgreSQL instance bundled with another product will collide.'}
    @{Port=1433;  Proto='TCP';     ExpectedOwner='Database'; Profile='Core'; Verified=$false
      Component='Microsoft SQL Server - VBR configuration database'
      Notes='Only relevant if the config DB is MSSQL.'}

    # -- OS ports Veeam depends on -------------------------------------------
    @{Port=135;   Proto='TCP';     ExpectedOwner='Windows'; Profile='Core'; Verified=$true
      Component='RPC Endpoint Mapper (component/agent deploy)'; Notes='Owned by svchost - expected.'}
    @{Port=445;   Proto='TCP';     ExpectedOwner='Windows'; Profile='Core'; Verified=$true
      Component='SMB (component deploy / upgrade file copy)'; Notes='Owned by System - expected.'}
    @{Port=139;   Proto='TCP';     ExpectedOwner='Windows'; Profile='Core'; Verified=$false
      Component='NetBIOS session service'; Notes='Owned by System - expected.'}

    # -- Enterprise Manager ---------------------------------------------------
    # Verified against the v13 EM Used Ports page:
    # https://helpcenter.veeam.com/docs/vbr/em/used_ports.html?ver=13
    @{Port=9394;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='EnterpriseManager'; Verified=$true
      Component='Enterprise Manager Service <-> IIS extension (internal)'; Notes=''}
    @{Port=9080;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='EnterpriseManager'; Verified=$true
      Component='Enterprise Manager web UI (HTTP, Windows default website port)'
      Notes='Customisable at install. Commonly taken by other web apps / dev servers bound to 9080.'}
    @{Port=9443;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='EnterpriseManager'; Verified=$true
      Component='Enterprise Manager web UI (HTTPS, Windows default website port)'
      Notes='Commonly taken by VMware appliances and other web consoles. On the v13 Linux appliance the web UI is on 443 (Nginx) instead.'}
    @{Port=9398;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='EnterpriseManager'; Verified=$true
      Component='Enterprise Manager RESTful API (HTTPS) / vSphere plug-in'; Notes=''}
    @{Port=9399;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='EnterpriseManager'; Verified=$true
      Component='Enterprise Manager RESTful API (HTTP)'; Notes='Windows only - the Linux appliance exposes REST on 9398/HTTPS only.'}
    @{Port=10443; Proto='TCP';     ExpectedOwner='Veeam'; Profile='EnterpriseManager'; Verified=$true
      Component='Veeam Host Management'; Notes=''}

    # -- Cloud Connect --------------------------------------------------------
    @{Port=6180;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='CloudConnect'; Verified=$false
      Component='Veeam Cloud Connect Service'; Notes=''}
    @{Port=10003; Proto='TCP';     ExpectedOwner='Veeam'; Profile='CloudConnect'; Verified=$false
      Component='Veeam Cloud Gateway'; Notes=''}

    # -- WAN accelerator ------------------------------------------------------
    @{Port=6164;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='WanAccelerator'; Verified=$false
      Component='Veeam WAN Accelerator Service (control)'; Notes=''}
    @{Port=6165;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='WanAccelerator'; Verified=$false
      Component='Veeam WAN Accelerator Service (data)'; Notes=''}
)

# Reference only - the Linux check runs inside veeam-portcheck.sh
$linuxPortsReference = @(
    '443   Backup server initial connection + Identity Service; Guest Catalog replication'
    '6160  Veeam Deployer Service (veeamdeployment)'
    '6162  Veeam Transport Service / Data Mover (veeamtransport)'
    '6172  Backup server database communication'
    '9419  Veeam RESTful API Service'
    '10006 Backup server connection port'
    '10443 Veeam Host Management'
    '5432  PostgreSQL configuration database'
    '2500-3300  Data transfer range'
    '--- Enterprise Manager on the v13 Linux appliance ---'
    '443   EM web UI (Nginx, HTTPS) - NOT 9443 as on Windows'
    '9398  EM RESTful API (HTTPS) / vSphere plug-in'
    '9394  EM gRPC (internal, Nginx <-> EM service)'
    '50001 Veeam ONE monitoring collection (gRPC, optional)'
    'NOT CHECKED on Linux: 111 / 1058 / 2049 - vPower NFS is a Windows service.'
)

$knownRangeSquatters = @{
    2598 = 'Citrix ICA session reliability'
    2701 = 'SCCM / SMS remote control'
    2702 = 'SCCM / SMS remote control'
    2869 = 'Windows UPnP / SSDP event notification'
    2967 = 'Symantec Endpoint Protection'
    3050 = 'Firebird / InterBase database'
    3260 = 'iSCSI target'
    3268 = 'Active Directory Global Catalog (LDAP)'
    3269 = 'Active Directory Global Catalog (LDAPS)'
    3306 = 'MySQL / MariaDB'
}

# Remote reachability list
$corePorts = @(
    @{Port=443;   Description='v13 backup server connection / certificate port'}
    @{Port=9392;  Description='Windows backup server initial connection'}
    @{Port=9393;  Description='Veeam Guest Catalog Service'}
    @{Port=9401;  Description='Veeam Mount Service'}
    @{Port=9419;  Description='Veeam RESTful API Service'}
    @{Port=9380;  Description='Veeam Distribution Service'}
    @{Port=6160;  Description='Veeam Installer / Deployer Service'}
    @{Port=6162;  Description='Veeam Data Mover / Transport Service'}
    @{Port=6161;  Description='Veeam vPower NFS Service'}
    @{Port=2500;  Description='Data transfer range start (2500-3300)'}
    @{Port=3300;  Description='Data transfer range end   (2500-3300)'}
    @{Port=445;   Description='SMB - component deploy/upgrade'}
    @{Port=135;   Description='RPC Endpoint Mapper'}
)

# Enterprise Manager reachability - scanned in addition to $corePorts when the
# EM profile is enabled. Windows EM defaults; on the v13 Linux appliance the
# web UI is on 443 (already in $corePorts) and REST stays on 9398.
$emPorts = @(
    @{Port=9080;  Description='EM web UI (HTTP, Windows)'}
    @{Port=9443;  Description='EM web UI (HTTPS, Windows)'}
    @{Port=9398;  Description='EM RESTful API (HTTPS) / vSphere plug-in'}
    @{Port=9399;  Description='EM RESTful API (HTTP, Windows)'}
    @{Port=9394;  Description='EM service internal port (IIS extension / Nginx gRPC)'}
    @{Port=10443; Description='Veeam Host Management'}
)

# Outbound dependencies EM needs to reach (per the v13 Used Ports page).
# These are scanned against the DEPENDENCY host (DC, DNS, vCenter...), not the
# EM server itself, so they are surfaced as guidance rather than auto-scanned.
$emDependencyReference = @(
    '53        UDP  DNS name resolution'
    '389       TCP+UDP  LDAP (Active Directory)'
    '636       TCP  LDAPS (LDAP over TLS)'
    '3268      TCP  LDAP Global Catalog'
    '3269      TCP  LDAP Global Catalog (TLS)'
    '443       TCP  vCenter Server / Veeam License Server / Update Repository'
    '80        TCP  License certificate validation / local update mirror'
    '5432      TCP  PostgreSQL configuration database'
    '1433      TCP  Microsoft SQL Server configuration database (if used)'
    '49152-65535  TCP  Dynamic RPC (AD + Windows backup server communication)'
)
