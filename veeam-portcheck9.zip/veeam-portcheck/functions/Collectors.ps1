# =============================================================================
#  Collectors.ps1 - scoping the port table and running the collector.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

# =============================================================================
#  RUNNING THE COLLECTOR
# =============================================================================

function Get-ScopedPortTable {
    param([switch]$WithEM, [switch]$WithCC, [switch]$WithWan)
    $profiles = @('Core')
    if ($WithEM)  { $profiles += 'EnterpriseManager' }
    if ($WithCC)  { $profiles += 'CloudConnect' }
    if ($WithWan) { $profiles += 'WanAccelerator' }
    return @($windowsPorts | Where-Object { $profiles -contains $_.Profile })
}

function Invoke-LocalCollector {
    param([switch]$WithEM, [switch]$WithCC, [switch]$WithWan, [switch]$NoRange)
    $table = Get-ScopedPortTable -WithEM:$WithEM -WithCC:$WithCC -WithWan:$WithWan
    return (& $collector $table (-not $NoRange) 2500 3300 $knownRangeSquatters)
}

function Invoke-RemoteCollector {
    param(
        [Parameter(Mandatory)][string]$Computer,
        [System.Management.Automation.PSCredential]$Credential,
        [switch]$WithEM, [switch]$WithCC, [switch]$WithWan, [switch]$NoRange
    )
    $table = Get-ScopedPortTable -WithEM:$WithEM -WithCC:$WithCC -WithWan:$WithWan

    Write-Host ''
    Write-Host ('  Opening a PowerShell remoting session to {0}...' -f $Computer) -ForegroundColor DarkCyan

    $icmArgs = @{
        ComputerName = $Computer
        ScriptBlock  = $collector
        ArgumentList = @($table, (-not $NoRange), 2500, 3300, $knownRangeSquatters)
        ErrorAction  = 'Stop'
    }
    if ($Credential) { $icmArgs['Credential'] = $Credential }

    try {
        return (Invoke-Command @icmArgs)
    } catch {
        Write-Host ''
        Write-Host ('  Remoting to {0} failed: {1}' -f $Computer, $_.Exception.Message) -ForegroundColor Red
        Write-Host ''
        Write-Host '  Things to check on the target:' -ForegroundColor Yellow
        Write-Host '    Enable-PSRemoting -Force            (run on the backup server)' -ForegroundColor DarkCyan
        Write-Host '    Test-WSMan -ComputerName <server>   (run from here)' -ForegroundColor DarkCyan
        Write-Host '    TCP 5985/5986 open, and the account is a local admin on the target.' -ForegroundColor DarkCyan
        Write-Host '    For a non-domain target, add it to TrustedHosts:' -ForegroundColor DarkCyan
        Write-Host '      Set-Item WSMan:\localhost\Client\TrustedHosts -Value <server> -Concatenate' -ForegroundColor DarkCyan
        return $null
    }
}
