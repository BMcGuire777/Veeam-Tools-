# =============================================================================
#  SshTransport.ps1 - Posh-SSH / native ssh transports + --report parsing.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

# =============================================================================
#  SSH TRANSPORT
#  Two transports, auto-detected:
#    Posh-SSH   - takes a PSCredential, so it works unattended. Preferred.
#    native ssh - ssh.exe / scp.exe. No dependency, but OpenSSH prompts for
#                 the password on the console itself; only key auth is
#                 genuinely unattended.
# =============================================================================

function Get-SshCapability {
    $poshVersion = $null
    $m = Get-Module -ListAvailable -Name 'Posh-SSH' -ErrorAction SilentlyContinue |
         Sort-Object Version -Descending | Select-Object -First 1
    if ($m) { $poshVersion = $m.Version }

    # Invoke-SSHCommand only splits .Output into a string array from 2.0 on.
    # On 1.x it returns one multi-line blob, which would parse as a single
    # truncated line and silently report "no result rows". Treat 1.x as absent.
    $poshUsable = [bool]($m -and $m.Version -ge [version]'2.0')

    return [pscustomobject]@{
        PoshSsh        = $poshUsable
        PoshSshPresent = [bool]$m
        PoshSshVersion = $poshVersion
        NativeSsh      = [bool](Get-Command ssh -ErrorAction SilentlyContinue)
        NativeScp      = [bool](Get-Command scp -ErrorAction SilentlyContinue)
    }
}

function Show-SshCapability {
    $c = Get-SshCapability
    Write-Host ''
    Write-Rule 'SSH transport'
    if ($c.PoshSsh) {
        Write-Host ('  Posh-SSH      : available (v{0}) - preferred, accepts a credential object' -f $c.PoshSshVersion) -ForegroundColor Green
    } elseif ($c.PoshSshPresent) {
        Write-Host ('  Posh-SSH      : v{0} found but too old (needs 2.0+) - will not be used' -f $c.PoshSshVersion) -ForegroundColor DarkYellow
    } else {
        Write-Host '  Posh-SSH      : not installed' -ForegroundColor DarkYellow
    }
    if ($c.NativeSsh) {
        Write-Host '  ssh.exe       : available' -ForegroundColor Green
    } else {
        Write-Host '  ssh.exe       : not found' -ForegroundColor DarkYellow
    }
    if ($c.NativeScp) {
        Write-Host '  scp.exe       : available' -ForegroundColor Green
    } else {
        Write-Host '  scp.exe       : not found (upload modes need this)' -ForegroundColor DarkYellow
    }
    if (-not $c.PoshSsh -and -not $c.NativeSsh) {
        Write-Host ''
        Write-Host '  No SSH transport at all. Either:' -ForegroundColor Red
        Write-Host '    Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0' -ForegroundColor DarkCyan
        Write-Host '    Install-Module Posh-SSH -Scope CurrentUser' -ForegroundColor DarkCyan
    }
    return $c
}

function Install-PoshSshInteractive {
    Write-Host ''
    Write-Host '  Posh-SSH comes from the PowerShell Gallery. It is not required -' -ForegroundColor DarkCyan
    Write-Host '  native ssh.exe works too, it just cannot accept a credential object.' -ForegroundColor DarkCyan
    $a = (Read-Host '  Install Posh-SSH for the current user now? [y/N]').Trim().ToUpper()
    if ($a -ne 'Y') { Write-Host '  Skipped.' -ForegroundColor DarkCyan; return $false }
    try {
        Install-Module -Name Posh-SSH -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
        Import-Module Posh-SSH -ErrorAction Stop
        Write-Host '  Posh-SSH installed.' -ForegroundColor Green
        return $true
    } catch {
        Write-Host ('  Install failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        Write-Host '  A locked-down server often blocks PSGallery. Use native ssh.exe instead.' -ForegroundColor DarkCyan
        return $false
    }
}

# -----------------------------------------------------------------------------
#  Parse the bash --report output into the same payload the Windows collector
#  returns, so one renderer and one CSV cover a mixed estate.
# -----------------------------------------------------------------------------
function ConvertFrom-LinuxReport {
    param([Parameter(Mandatory)][AllowEmptyCollection()][string[]]$Lines)

    $results  = @()
    $services = @()
    $meta     = @{
        Host='(unknown)'; OS=''; Elevated=$false; Fallback=$false; CollectError=''
        RangeChecked=$true; TcpCount=0; UdpCount=0; ProcCount=0
        Services=@(); Collected=(Get-Date); Platform='Linux'
    }
    $sawEnd = $false

    foreach ($raw in $Lines) {
        if ($null -eq $raw) { continue }
        $line = $raw.TrimEnd()
        if (-not $line.StartsWith('#')) { continue }
        $p = $line.Split('|')

        switch ($p[0]) {
            '#META' {
                if ($p.Count -ge 7) {
                    $meta.Host         = $p[1]
                    $meta.OS           = $p[2]
                    $meta.Elevated     = ($p[3] -eq '1')
                    $meta.TcpCount     = [int]($p[4] -as [int])
                    $meta.UdpCount     = [int]($p[5] -as [int])
                    $meta.RangeChecked = ($p[6] -eq '1')
                }
            }
            '#SVC' {
                if ($p.Count -ge 3) {
                    # systemd "active"/"inactive" -> the Running/Stopped the
                    # renderer already understands.
                    $state = if ($p[2] -eq 'active') { 'Running' } else { $p[2] }
                    $services += [pscustomobject]@{ Name=$p[1]; DisplayName=$p[1]; Status=$state }
                }
            }
            '#ROW' {
                if ($p.Count -ge 8) {
                    # Rejoin any trailing fields in case a note still held a pipe.
                    $notes = if ($p.Count -gt 8) { ($p[7..($p.Count-1)] -join '|') } else { $p[7] }
                    $results += [pscustomobject]@{
                        Port      = [int]($p[2] -as [int])
                        Protocol  = $p[3].ToUpper()
                        Status    = $p[1]
                        OwnerType = $p[4]
                        Owner     = $p[5]
                        Component = $p[6]
                        Verified  = $true
                        Notes     = $notes
                        InRange   = ($p[6] -like 'Data transfer range*')
                    }
                }
            }
            '#END' { $sawEnd = $true }
        }
    }

    if (-not $sawEnd) {
        $meta.CollectError = 'The remote report was truncated - no #END marker. Treat the results as incomplete.'
    }
    if ($results.Count -eq 0 -and -not $meta.CollectError) {
        $meta.CollectError = 'The remote script produced no result rows.'
    }
    $meta.Services  = $services
    $meta.ProcCount = 0

    return @{ Results = $results; Meta = $meta }
}

# -----------------------------------------------------------------------------
#  Build the remote command for a given mode.
#  Stream mode leaves nothing on the appliance filesystem.
# -----------------------------------------------------------------------------
function Get-RemoteCommand {
    param(
        [Parameter(Mandatory)][ValidateSet('Stream','UploadDelete','UploadKeep')][string]$Mode,
        [string]$RemotePath = '/tmp/veeam-portcheck.sh',
        [switch]$UseSudo,
        [switch]$ForPoshSsh,
        [string]$Base64Body
    )
    $bash = if ($UseSudo) { 'sudo -n bash' } else { 'bash' }

    if ($Mode -eq 'Stream') {
        if ($ForPoshSsh) {
            # Posh-SSH has no stdin channel, so carry the script inside the
            # command as base64 and decode it into bash on the far side.
            return ("echo '{0}' | base64 -d | {1} -s -- --report" -f $Base64Body, $bash)
        }
        return ('{0} -s -- --report' -f $bash)
    }

    # Single-quote for the REMOTE shell. PowerShell does not escape embedded
    # double quotes when building a native command line, so double quotes here
    # would be eaten before ssh saw them - and a path containing ';' would then
    # be executed by the remote shell. $RemotePath is also pattern-validated in
    # param(), so it cannot contain a quote to break out with.
    $q = "'" + $RemotePath + "'"
    $cmd = '{0} {1} --report' -f $bash, $q
    if ($Mode -eq 'UploadDelete') {
        # Capture the exit code before rm so conflicts still surface.
        $cmd = '{0}; __rc=$?; rm -f {1}; exit $__rc' -f $cmd, $q
    }
    return $cmd
}

# Split a POSIX remote path. Never use Split-Path here - on Windows the
# FileSystem provider rewrites '/tmp/x.sh' to '\tmp', which would upload to a
# bogus directory and only fail in the Upload modes.
function Split-PosixPath {
    param([Parameter(Mandatory)][string]$Path)
    $dir  = if ($Path -match '^(.*)/[^/]+$' -and $Matches[1]) { $Matches[1] } else { '/tmp' }
    $leaf = if ($Path -match '([^/]+)$') { $Matches[1] } else { 'veeam-portcheck.sh' }
    return [pscustomobject]@{ Directory = $dir; Leaf = $leaf }
}

function Invoke-LinuxCheckViaPoshSsh {
    param(
        [Parameter(Mandatory)][string]$Server,
        [int]$Port = 22,
        [System.Management.Automation.PSCredential]$Credential,
        [string]$KeyFile,
        [ValidateSet('Stream','UploadDelete','UploadKeep')][string]$Mode = 'Stream',
        [string]$RemotePath = '/tmp/veeam-portcheck.sh',
        [switch]$UseSudo,
        # Generic transport hooks (used by veeam-blueprint.ps1): push a
        # different script, and/or return raw output lines instead of the
        # parsed port-check payload. Defaults preserve the original behaviour.
        [string]$LocalScriptFile,
        [switch]$Raw
    )

    try { Import-Module Posh-SSH -ErrorAction Stop } catch {
        Write-Host ('  Could not load Posh-SSH: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }

    $src = if ($LocalScriptFile) { $LocalScriptFile } else { Get-LinuxScriptPath }
    if (-not $src) { return $null }
    if (-not (Test-Path $src)) {
        Write-Host ('  Script to push not found: {0}' -f $src) -ForegroundColor Red
        return $null
    }
    $body = [IO.File]::ReadAllText($src) -replace "`r`n", "`n"

    $remote = Split-PosixPath -Path $RemotePath

    $session = $null
    try {
        $who = if ($Credential) { $Credential.UserName } else { '(key auth)' }
        Write-Host ('  Opening SSH session to {0}@{1}:{2} (Posh-SSH) ...' -f
            $who, $Server, $Port) -ForegroundColor DarkCyan

        $sessArgs = @{
            ComputerName = $Server
            Port         = $Port
            AcceptKey    = $true
            ErrorAction  = 'Stop'
        }
        if ($Credential) { $sessArgs['Credential'] = $Credential }
        if ($KeyFile) {
            if (-not (Test-Path $KeyFile)) {
                Write-Host ('  Key file not found: {0}' -f $KeyFile) -ForegroundColor Red
                return $null
            }
            $sessArgs['KeyFile'] = $KeyFile
        }
        $session = New-SSHSession @sessArgs

        $b64 = ''
        if ($Mode -eq 'Stream') {
            $b64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($body))
            Write-Host '  Streaming the script (nothing written to the appliance).' -ForegroundColor DarkCyan
        } else {
            Write-Host ('  Uploading to {0} ...' -f $RemotePath) -ForegroundColor DarkCyan
            # Set-SCPItem -Destination is a DIRECTORY and the file keeps its
            # local leaf name, so the temp file must be named after the remote
            # leaf or the subsequent bash call would miss it.
            $tmp = Join-Path ([IO.Path]::GetTempPath()) $remote.Leaf
            [IO.File]::WriteAllText($tmp, $body, (New-Object Text.UTF8Encoding($false)))
            $scpArgs = @{
                ComputerName = $Server
                Port         = $Port
                Path         = $tmp
                Destination  = $remote.Directory
                AcceptKey    = $true
                ErrorAction  = 'Stop'
            }
            if ($Credential) { $scpArgs['Credential'] = $Credential }
            if ($KeyFile)    { $scpArgs['KeyFile']    = $KeyFile }
            Set-SCPItem @scpArgs
            Remove-Item $tmp -Force -ErrorAction SilentlyContinue
        }

        $cmd = Get-RemoteCommand -Mode $Mode -RemotePath $RemotePath -UseSudo:$UseSudo `
                                 -ForPoshSsh -Base64Body $b64

        $r = Invoke-SSHCommand -SessionId $session.SessionId -Command $cmd -TimeOut 300 -ErrorAction Stop
        # Normalise: split any multi-line element so a single blob still parses.
        $out = @(@($r.Output) | ForEach-Object { [string]$_ -split "`r?`n" })

        if ($r.ExitStatus -gt 1) {
            Write-Host ('  Remote command exited {0}.' -f $r.ExitStatus) -ForegroundColor Red
            if ($r.Error) { Write-Host ('  {0}' -f ($r.Error -join ' ')) -ForegroundColor Red }
            if ($UseSudo) {
                Write-Host '  sudo -n fails when the account needs a password for sudo.' -ForegroundColor Yellow
                Write-Host '  Connect as root, or drop sudo and accept UNKNOWN owners.' -ForegroundColor Yellow
            }
        }
        if ($Mode -eq 'UploadKeep') {
            Write-Host ('  Left the script at {0} on the appliance.' -f $RemotePath) -ForegroundColor DarkCyan
        }
        if ($Raw) {
            return @{ Lines = @($out | ForEach-Object { [string]$_ }); ExitStatus = [int]$r.ExitStatus }
        }
        return (ConvertFrom-LinuxReport -Lines @($out))
    } catch {
        Write-Host ('  Posh-SSH run failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    } finally {
        if ($session) { Remove-SSHSession -SessionId $session.SessionId -ErrorAction SilentlyContinue | Out-Null }
    }
}

function Invoke-LinuxCheckViaNativeSsh {
    param(
        [Parameter(Mandatory)][string]$Server,
        [int]$Port = 22,
        [Parameter(Mandatory)][string]$User,
        [string]$KeyFile,
        [ValidateSet('Stream','UploadDelete','UploadKeep')][string]$Mode = 'Stream',
        [string]$RemotePath = '/tmp/veeam-portcheck.sh',
        [switch]$UseSudo,
        # Generic transport hooks - see Invoke-LinuxCheckViaPoshSsh.
        [string]$LocalScriptFile,
        [switch]$Raw
    )

    if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) {
        Write-Host '  ssh.exe not found.' -ForegroundColor Red
        return $null
    }
    $src = if ($LocalScriptFile) { $LocalScriptFile } else { Get-LinuxScriptPath }
    if (-not $src) { return $null }
    if (-not (Test-Path $src)) {
        Write-Host ('  Script to push not found: {0}' -f $src) -ForegroundColor Red
        return $null
    }
    $body = [IO.File]::ReadAllText($src) -replace "`r`n", "`n"

    $target  = '{0}@{1}' -f $User, $Server
    $sshOpts = @('-o','StrictHostKeyChecking=accept-new','-o','ConnectTimeout=15','-p',"$Port")
    if ($KeyFile) {
        if (-not (Test-Path $KeyFile)) {
            Write-Host ('  Key file not found: {0}' -f $KeyFile) -ForegroundColor Red
            return $null
        }
        $sshOpts += @('-i', $KeyFile)
        # With a key supplied, never fall through to an interactive password
        # prompt - that would hang an unattended run forever, because
        # ConnectTimeout only bounds the handshake, not the prompt.
        $sshOpts += @('-o','BatchMode=yes')
    } else {
        Write-Host '  No key file given - ssh.exe will prompt for the password itself.' -ForegroundColor DarkYellow
    }

    # Probe before streaming. If ssh cannot connect at all (the common VSA
    # case: SSH not enabled -> exit 255) it dies immediately, and writing 15 KB
    # of script into the closed pipe would raise an IOException that masks the
    # real cause with a generic failure message.
    Write-Host ('  Testing SSH reachability of {0}:{1} ...' -f $Server, $Port) -ForegroundColor DarkCyan
    & ssh @sshOpts $target 'true' 2>&1 | Out-Null
    $probeRc = $LASTEXITCODE
    if ($probeRc -eq 255) {
        Write-Host '  ssh could not connect or authenticate (exit 255).' -ForegroundColor Red
        Write-Host '  On a VSA, SSH must be enabled in Host Management -> Remote Access ->' -ForegroundColor DarkCyan
        Write-Host '  SSH Server, and approved by the Security Officer if that account exists.' -ForegroundColor DarkCyan
        Write-Host '  Also check the user, the port, and the key if you supplied one.' -ForegroundColor DarkCyan
        return $null
    }

    $cmd = Get-RemoteCommand -Mode $Mode -RemotePath $RemotePath -UseSudo:$UseSudo
    $out = @()

    try {
        if ($Mode -eq 'Stream') {
            Write-Host '  Streaming the script over stdin (nothing written to the appliance).' -ForegroundColor DarkCyan
            $out = @($body | & ssh @sshOpts $target $cmd 2>&1)
        } else {
            if (-not (Get-Command scp -ErrorAction SilentlyContinue)) {
                Write-Host '  scp.exe not found - upload modes need it. Use stream mode.' -ForegroundColor Red
                return $null
            }
            $tmp = Join-Path ([IO.Path]::GetTempPath()) (Split-Path $src -Leaf)
            [IO.File]::WriteAllText($tmp, $body, (New-Object Text.UTF8Encoding($false)))

            $scpOpts = @('-o','StrictHostKeyChecking=accept-new','-o','ConnectTimeout=15','-P',"$Port")
            if ($KeyFile) { $scpOpts += @('-i', $KeyFile) }

            Write-Host ('  Uploading to {0}:{1} ...' -f $Server, $RemotePath) -ForegroundColor DarkCyan
            & scp @scpOpts $tmp ('{0}:{1}' -f $target, $RemotePath) 2>&1 | ForEach-Object {
                Write-Host ('    ' + $_) -ForegroundColor DarkGray
            }
            $scpRc = $LASTEXITCODE
            Remove-Item $tmp -Force -ErrorAction SilentlyContinue
            if ($scpRc -ne 0) {
                Write-Host ('  scp failed (exit {0}).' -f $scpRc) -ForegroundColor Red
                return $null
            }
            $out = @(& ssh @sshOpts $target $cmd 2>&1)
        }

        $rc = $LASTEXITCODE
        if ($rc -eq 255) {
            Write-Host '  ssh could not connect (exit 255).' -ForegroundColor Red
            Write-Host '  On a VSA, SSH must be enabled in Host Management -> Remote Access,' -ForegroundColor DarkCyan
            Write-Host '  and approved by the Security Officer if that account is configured.' -ForegroundColor DarkCyan
            $nonReport = @($out | Where-Object { $_ -and -not ([string]$_).StartsWith('#') })
            foreach ($l in $nonReport) { Write-Host ('    ' + $l) -ForegroundColor DarkGray }
            return $null
        }
        if ($rc -gt 1 -and $UseSudo) {
            Write-Host ('  Remote command exited {0} - sudo -n fails when sudo needs a password.' -f $rc) -ForegroundColor Yellow
        }
        if ($Mode -eq 'UploadKeep') {
            Write-Host ('  Left the script at {0} on the appliance.' -f $RemotePath) -ForegroundColor DarkCyan
        }
        if ($Raw) {
            return @{ Lines = @($out | ForEach-Object { [string]$_ }); ExitStatus = [int]$rc }
        }
        # @() so that no output at all binds as an empty array rather than
        # $null, which AllowEmptyCollection does not cover.
        return (ConvertFrom-LinuxReport -Lines @($out | ForEach-Object { [string]$_ }))
    } catch {
        Write-Host ('  SSH run failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}

# -----------------------------------------------------------------------------
#  Front door: pick a transport, run, render, accumulate.
# -----------------------------------------------------------------------------
function Invoke-LinuxCheckOverSsh {
    param(
        [Parameter(Mandatory)][string]$Server,
        [string]$User,
        [int]$Port = 22,
        [System.Management.Automation.PSCredential]$Credential,
        [string]$KeyFile,
        [ValidateSet('Stream','UploadDelete','UploadKeep')][string]$Mode = 'Stream',
        [string]$RemotePath = '/tmp/veeam-portcheck.sh',
        [switch]$UseSudo,
        [switch]$NonInteractive
    )

    if (-not (Get-LinuxScriptPath)) {
        Write-Host ''
        Write-Host ('  {0} must sit in the same folder as this script.' -f $script:LinuxScriptName) -ForegroundColor Red
        Write-Host ('  Expected at: {0}' -f (Join-Path $script:ScriptDir $script:LinuxScriptName)) -ForegroundColor DarkCyan
        return $null
    }

    $cap = Get-SshCapability
    if (-not $cap.PoshSsh -and -not $cap.NativeSsh) {
        Show-SshCapability | Out-Null
        return $null
    }
    if (-not $cap.PoshSsh -and -not $NonInteractive) {
        Write-Host ''
        Write-Host '  Posh-SSH is not installed, so native ssh.exe will be used and will' -ForegroundColor DarkYellow
        Write-Host '  prompt for the password on the console rather than taking a credential.' -ForegroundColor DarkYellow
        if (Install-PoshSshInteractive) { $cap = Get-SshCapability }
    }

    Write-Host ''
    Write-Host '  Reminder: on a Veeam Software Appliance, SSH is off by default. Enable it' -ForegroundColor DarkCyan
    Write-Host '  in Host Management -> Remote Access -> SSH Server. Where a Security Officer' -ForegroundColor DarkCyan
    Write-Host '  account exists the request needs their approval first.' -ForegroundColor DarkCyan

    $payload = $null

    if ($cap.PoshSsh) {
        # Key auth needs no credential. Only prompt when we have neither, and
        # never prompt in a non-interactive run - fail loudly instead.
        if (-not $Credential -and -not $KeyFile) {
            if ($NonInteractive) {
                Write-Host '  No -SshCredential and no -SshKeyFile supplied, and this is a' -ForegroundColor Red
                Write-Host '  non-interactive run. Nothing to authenticate with.' -ForegroundColor Red
                return $null
            }
            $Credential = if ($User) {
                Get-Credential -UserName $User -Message "SSH to $Server"
            } else {
                Get-Credential -Message "SSH to $Server"
            }
            if (-not $Credential) { Write-Host '  Cancelled.' -ForegroundColor Red; return $null }
        }
        if ($KeyFile -and -not $Credential -and $User) {
            # Posh-SSH still wants a user name alongside a key file.
            $Credential = New-Object System.Management.Automation.PSCredential(
                $User, (New-Object System.Security.SecureString))
        }
        $payload = Invoke-LinuxCheckViaPoshSsh -Server $Server -Port $Port -Credential $Credential `
                       -KeyFile $KeyFile -Mode $Mode -RemotePath $RemotePath -UseSudo:$UseSudo
    } else {
        if (-not $User) {
            if ($Credential) { $User = $Credential.UserName }
            else { $User = (Read-Host '  SSH user').Trim() }
        }
        if (-not $User) { Write-Host '  Cancelled.' -ForegroundColor Red; return $null }
        $payload = Invoke-LinuxCheckViaNativeSsh -Server $Server -Port $Port -User $User `
                       -KeyFile $KeyFile -Mode $Mode -RemotePath $RemotePath -UseSudo:$UseSudo
    }

    if (-not $payload) { return $null }

    if (-not $payload.Meta.Elevated) {
        Write-Host ''
        Write-Host '  The remote script did not run as root, so listener owners it could not' -ForegroundColor Yellow
        Write-Host '  read are reported UNKNOWN. Re-run with sudo, or connect as root.' -ForegroundColor Yellow
    }

    Save-Results $payload
    Show-ConflictReport $payload
    return $payload
}
