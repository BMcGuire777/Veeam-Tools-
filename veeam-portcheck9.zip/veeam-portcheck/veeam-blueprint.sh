#!/usr/bin/env bash
# =============================================================================
#  veeam-blueprint.sh
#  Configuration blueprint collector for a Linux-based Veeam backup server
#  (including the v13 Veeam Software Appliance).
#
#  WHY THIS EXISTS
#    Every VBR install or update changes the OS-level footprint: services,
#    listeners, the internal port trunk behind 443/6160, PostgreSQL settings,
#    config files, firewall rules. This script captures that footprint as a
#    machine-readable snapshot. veeam-blueprint.ps1 turns the snapshot into a
#    JSON blueprint document and diffs two documents to surface config drift.
#
#    Like veeam-portcheck.sh it is deliberately ONE dependency-free file
#    (bash + coreutils + iproute2; everything else is probed and optional) so
#    it can be pasted into the VSA console or streamed over SSH stdin.
#
#  WHAT IT CAPTURES
#    #META      host, OS, kernel, capture tier (root? db access?)
#    #VEEAMPKG  installed veeam packages (rpm or dpkg)
#    #SVC       veeam*/postgres* systemd units: state, enablement, user,
#               main executable, unit-file hash
#    #LISTEN    EVERY tcp/udp listener: scope (external vs loopback), owner
#    #TRUNK     established loopback->loopback connections joined to the
#               listener table: which frontend process feeds which backend
#               service - the v13 port-aggregation map behind 443/6160
#    #RCONN     established connections from Veeam/db processes to remote
#               hosts - the observed data-plane map to managed servers
#    #DBINFO/#DBSET/#DBSIZE/#DBCONN  PostgreSQL version, data dir, key
#               settings, per-database sizes, connection count
#    #CFG       sha256 of config files under /etc/veeam + /opt/veeam
#    #CERT      certificate presented on 443/9419/10443 (needs openssl)
#    #FWZONE    firewalld zone summaries (or nft/iptables ruleset hash)
#    #METRIC    uptime, memory, disk - reported, never diffed as drift
#
#  USAGE
#    bash veeam-blueprint.sh              # human-readable summary
#    bash veeam-blueprint.sh --report     # pipe-delimited, for veeam-blueprint.ps1
#    bash veeam-blueprint.sh --no-color
#
#  Exit code: 0 = captured, 2 = could not capture.
#  Run as root. Without root, process owners, config hashes and the whole
#  database section degrade - the blueprint records its own capture tier so
#  the drift engine never compares a full capture against a degraded one.
# =============================================================================

set -uo pipefail

REPORT_MODE=0
USE_COLOR=1

for arg in "$@"; do
  case "$arg" in
    --report)   REPORT_MODE=1; USE_COLOR=0 ;;
    --no-color) USE_COLOR=0 ;;
    -h|--help)  sed -n '2,46p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *)          echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

[ -t 1 ] || USE_COLOR=0
if [ "$USE_COLOR" -eq 1 ]; then
  C_GRN=$'\033[32m'; C_YEL=$'\033[33m'; C_CYN=$'\033[36m'; C_DIM=$'\033[2m'; C_RST=$'\033[0m'
else
  C_GRN=''; C_YEL=''; C_CYN=''; C_DIM=''; C_RST=''
fi

# -----------------------------------------------------------------------------
#  PRE-FLIGHT
# -----------------------------------------------------------------------------
if ! command -v ss >/dev/null 2>&1; then
  echo "ERROR: 'ss' not found (package iproute2). Cannot enumerate listeners." >&2
  exit 2
fi

AM_ROOT=1
[ "$(id -u)" -eq 0 ] || AM_ROOT=0

HAVE_SYSTEMCTL=0
command -v systemctl >/dev/null 2>&1 && HAVE_SYSTEMCTL=1

# -----------------------------------------------------------------------------
#  RECORD ACCUMULATOR
#  Records are pipe-delimited; strip '|' and newlines from every field at the
#  point of insertion, same as veeam-portcheck.sh.
# -----------------------------------------------------------------------------
RECORDS=""
rec() {
  local out="#$1" f
  shift
  for f in "$@"; do
    out="${out}|$(printf '%s' "${f:-}" | tr '|' '/' | tr -d '\r\n')"
  done
  RECORDS="${RECORDS}${out}
"
}
note() { rec NOTE "$1"; }

hash_file() {
  [ -r "${1:-}" ] || { echo ""; return; }
  sha256sum "$1" 2>/dev/null | awk '{print $1}'
}
hash_text() { printf '%s' "${1:-}" | sha256sum | awk '{print $1}'; }

# -----------------------------------------------------------------------------
#  PROCESS RESOLUTION (cached - established-connection loops hit this a lot)
# -----------------------------------------------------------------------------
declare -A UNIT_CACHE EXE_CACHE CLS_CACHE

unit_for_pid() {
  local pid="$1"
  [ "$pid" = "0" ] && { echo ""; return; }
  if [ -n "${UNIT_CACHE[$pid]+x}" ]; then echo "${UNIT_CACHE[$pid]}"; return; fi
  local unit=""
  if [ -r "/proc/$pid/cgroup" ]; then
    unit=$(grep -oE '[a-zA-Z0-9@_.\-]+\.service' "/proc/$pid/cgroup" 2>/dev/null | tail -n1)
  fi
  UNIT_CACHE[$pid]="$unit"
  echo "$unit"
}

exe_for_pid() {
  local pid="$1"
  [ "$pid" = "0" ] && { echo ""; return; }
  if [ -n "${EXE_CACHE[$pid]+x}" ]; then echo "${EXE_CACHE[$pid]}"; return; fi
  local exe
  exe=$(readlink -f "/proc/$pid/exe" 2>/dev/null || echo "")
  EXE_CACHE[$pid]="$exe"
  echo "$exe"
}

# classify <pid> <procname> -> veeam | os | db | thirdparty | unknown
classify() {
  local pid="$1" name="$2"
  if [ "$pid" = "0" ] || [ ! -d "/proc/$pid" ]; then echo "unknown"; return; fi
  if [ -n "${CLS_CACHE[$pid]+x}" ]; then echo "${CLS_CACHE[$pid]}"; return; fi
  local exe unit hay cls="thirdparty"
  exe=$(exe_for_pid "$pid")
  unit=$(unit_for_pid "$pid")
  hay="$name $exe $unit"
  case "$hay" in
    *[Vv]eeam*) cls="veeam" ;;
    *)
      case "$name" in
        postgres|postmaster|mysqld|mariadbd) cls="db" ;;
        systemd|systemd-*|sshd|rpcbind|chronyd|dbus-daemon|firewalld|NetworkManager|rsyslogd|auditd)
          cls="os" ;;
        *)
          case "$exe" in
            /usr/lib/systemd/*|/lib/systemd/*) cls="os" ;;
          esac ;;
      esac ;;
  esac
  CLS_CACHE[$pid]="$cls"
  echo "$cls"
}

is_loopback() {
  case "$1" in
    127.*|::1|::ffff:127.*) return 0 ;;
    *) return 1 ;;
  esac
}

# -----------------------------------------------------------------------------
#  META
# -----------------------------------------------------------------------------
OS_NAME="unknown"
[ -r /etc/os-release ] && OS_NAME=$(. /etc/os-release; echo "${PRETTY_NAME:-unknown}")
KERNEL=$(uname -r 2>/dev/null || echo "")
ARCH=$(uname -m 2>/dev/null || echo "")
STAMP=$(date -u '+%Y-%m-%dT%H:%M:%SZ')

# -----------------------------------------------------------------------------
#  PACKAGES
# -----------------------------------------------------------------------------
PKG_LINES=""
if command -v rpm >/dev/null 2>&1; then
  PKG_LINES=$(rpm -qa --qf '%{NAME}|%{VERSION}-%{RELEASE}|%{ARCH}\n' 'veeam*' 'Veeam*' 2>/dev/null | sort -u)
elif command -v dpkg-query >/dev/null 2>&1; then
  PKG_LINES=$(dpkg-query -W -f='${Package}|${Version}|${Architecture}\n' 2>/dev/null | grep -i '^veeam' | sort -u)
fi
while IFS='|' read -r pn pv pa; do
  [ -z "${pn:-}" ] && continue
  rec VEEAMPKG "$pn" "$pv" "$pa"
done <<< "$PKG_LINES"

# -----------------------------------------------------------------------------
#  SERVICES  (veeam* + postgres* systemd units)
# -----------------------------------------------------------------------------
SVC_UNITS=""
if [ "$HAVE_SYSTEMCTL" -eq 1 ]; then
  SVC_UNITS=$(systemctl list-units --all --type=service --no-legend --no-pager 'veeam*' 'postgres*' 2>/dev/null |
    awk '{ if ($1 ~ /\.service$/) print $1; else if ($2 ~ /\.service$/) print $2 }' | sort -u)
else
  note "systemctl unavailable - service inventory skipped."
fi
while read -r u; do
  [ -z "${u:-}" ] && continue
  desc=""; active=""; sub=""; enabled=""; svcuser=""; frag=""; mainpid="0"
  while IFS='=' read -r k v; do
    case "$k" in
      Description)   desc="$v" ;;
      ActiveState)   active="$v" ;;
      SubState)      sub="$v" ;;
      UnitFileState) enabled="$v" ;;
      User)          svcuser="$v" ;;
      FragmentPath)  frag="$v" ;;
      MainPID)       mainpid="$v" ;;
    esac
  done < <(systemctl show "$u" \
      --property=Description,ActiveState,SubState,UnitFileState,User,FragmentPath,MainPID 2>/dev/null)
  exe=$(exe_for_pid "${mainpid:-0}")
  rec SVC "$u" "$desc" "$active" "$sub" "$enabled" "$svcuser" "$exe" "$(hash_file "$frag")"
done <<< "$SVC_UNITS"

# -----------------------------------------------------------------------------
#  LISTENERS
#  proto TAB addr TAB port TAB pid TAB procname   (one row per owning pid)
# -----------------------------------------------------------------------------
LISTENERS=$(ss -H -lntupn 2>/dev/null | awk '
  {
    proto = $1
    local_addr = $5
    n = split(local_addr, a, ":")
    port = a[n]
    if (port !~ /^[0-9]+$/) next
    addr = local_addr
    sub(":" port "$", "", addr)
    gsub(/[\[\]]/, "", addr)
    if (addr == "" || addr == "*") addr = "0.0.0.0"
    users = ""
    for (i = 6; i <= NF; i++) users = users $i
    if (users ~ /users:/) {
      tmp = users
      while (match(tmp, /\("[^"]+",pid=[0-9]+/)) {
        seg = substr(tmp, RSTART, RLENGTH)
        split(seg, b, "\"")
        nm = b[2]
        split(seg, c, "pid=")
        pid = c[2]
        print proto "\t" addr "\t" port "\t" pid "\t" nm
        tmp = substr(tmp, RSTART + RLENGTH)
      }
    } else {
      print proto "\t" addr "\t" port "\t" "0" "\t" "-"
    }
  }' | sort -u)

TCP_COUNT=0; UDP_COUNT=0
declare -A LPORT_PROC LPORT_UNIT   # tcp listener port -> owner (for the trunk join)
while IFS=$'\t' read -r l_proto l_addr l_port l_pid l_name; do
  [ -z "${l_port:-}" ] && continue
  scope="external"
  is_loopback "$l_addr" && scope="loopback"
  cls=$(classify "$l_pid" "$l_name")
  unit=$(unit_for_pid "$l_pid")
  exe=$(exe_for_pid "$l_pid")
  rec LISTEN "$l_proto" "$scope" "$l_addr" "$l_port" "$cls" "$l_name" "$unit" "$exe"
  if [ "$l_proto" = "tcp" ]; then
    TCP_COUNT=$((TCP_COUNT + 1))
    LPORT_PROC[$l_port]="$l_name"
    LPORT_UNIT[$l_port]="$unit"
  else
    UDP_COUNT=$((UDP_COUNT + 1))
  fi
done <<< "$LISTENERS"

# -----------------------------------------------------------------------------
#  ESTABLISHED CONNECTIONS -> TRUNK MAP + REMOTE DATA-PLANE MAP
#  ss -Htnp keeps the State column in every ss version, so filter on ESTAB in
#  awk rather than relying on 'state established' column layout.
#  Emits: laddr TAB lport TAB raddr TAB rport TAB pid TAB name
# -----------------------------------------------------------------------------
ESTAB=$(ss -Htnp 2>/dev/null | awk '
  $1 == "ESTAB" {
    la = $4; ra = $5
    n = split(la, x, ":"); lport = x[n]; laddr = la; sub(":" lport "$", "", laddr); gsub(/[\[\]]/, "", laddr)
    m = split(ra, y, ":"); rport = y[m]; raddr = ra; sub(":" rport "$", "", raddr); gsub(/[\[\]]/, "", raddr)
    if (lport !~ /^[0-9]+$/ || rport !~ /^[0-9]+$/) next
    users = ""
    for (i = 6; i <= NF; i++) users = users $i
    pid = "0"; nm = "-"
    if (users ~ /users:/) {
      if (match(users, /\("[^"]+",pid=[0-9]+/)) {
        seg = substr(users, RSTART, RLENGTH)
        split(seg, b, "\""); nm = b[2]
        split(seg, c, "pid="); pid = c[2]
      }
    }
    print laddr "\t" lport "\t" raddr "\t" rport "\t" pid "\t" nm
  }' | sort -u)

# Map keys use the ASCII unit separator: unlike tab it is not IFS whitespace,
# so empty fields (e.g. a process with no systemd unit) survive the readback.
SEP=$'\x1f'
declare -A TRUNK_MAP RCONN_MAP
while IFS=$'\t' read -r e_laddr e_lport e_raddr e_rport e_pid e_name; do
  [ -z "${e_lport:-}" ] && continue
  if is_loopback "$e_laddr" && is_loopback "$e_raddr"; then
    # The socket whose PEER port is a known listener is the client side:
    # client process (frontend) -> backend listener. That join, aggregated,
    # is the port-aggregation ("trunking") map.
    if [ -n "${LPORT_PROC[$e_rport]:-}" ]; then
      unit=$(unit_for_pid "$e_pid")
      key="${e_name}${SEP}${unit}${SEP}${e_rport}"
      TRUNK_MAP[$key]=$(( ${TRUNK_MAP[$key]:-0} + 1 ))
    fi
  elif ! is_loopback "$e_raddr"; then
    cls=$(classify "$e_pid" "$e_name")
    case "$cls" in veeam|db) ;; *) continue ;; esac
    unit=$(unit_for_pid "$e_pid")
    # Direction: a connection landing on one of our own listener ports is
    # inbound (a managed server talking to us); anything else is outbound.
    # For inbound, record OUR service port, not the peer's ephemeral port -
    # ephemeral ports change every capture and would read as false drift.
    dir="out"; port="$e_rport"
    if [ -n "${LPORT_PROC[$e_lport]:-}" ]; then dir="in"; port="$e_lport"; fi
    key="${e_raddr}${SEP}${port}${SEP}${dir}${SEP}${e_name}${SEP}${unit}"
    RCONN_MAP[$key]=$(( ${RCONN_MAP[$key]:-0} + 1 ))
  fi
done <<< "$ESTAB"

for key in "${!TRUNK_MAP[@]}"; do
  IFS="$SEP" read -r t_front t_funit t_bport <<< "$key"
  [ -z "${t_bport:-}" ] && continue
  rec TRUNK "$t_front" "$t_funit" "$t_bport" "${LPORT_PROC[$t_bport]:-}" "${LPORT_UNIT[$t_bport]:-}" "${TRUNK_MAP[$key]}"
done
for key in "${!RCONN_MAP[@]}"; do
  IFS="$SEP" read -r r_addr r_port r_dir r_name r_unit <<< "$key"
  rec RCONN "$r_addr" "$r_port" "$r_dir" "$r_name" "$r_unit" "${RCONN_MAP[$key]}"
done

# -----------------------------------------------------------------------------
#  DATABASE (PostgreSQL - the VBR configuration DB on Linux/VSA)
# -----------------------------------------------------------------------------
DB_ACCESS=0
DB_PRESENT=0
if echo "$LISTENERS" | awk -F'\t' '$5 ~ /^post(gres|master)/ {found=1} END {exit !found}' ||
   echo "$SVC_UNITS" | grep -q '^postgres'; then
  DB_PRESENT=1
fi

pg_query() {
  runuser -u postgres -- psql -tAc "$1" 2>/dev/null && return 0
  su -s /bin/sh postgres -c "psql -tAc \"$1\"" 2>/dev/null
}

if [ "$DB_PRESENT" -eq 1 ]; then
  if [ "$AM_ROOT" -eq 1 ] && command -v psql >/dev/null 2>&1; then
    db_ver=$(pg_query 'SHOW server_version' | head -n1)
    if [ -n "$db_ver" ]; then
      DB_ACCESS=1
      db_dir=$(pg_query 'SHOW data_directory' | head -n1)
      rec DBINFO "postgresql" "$db_ver" "$db_dir"
      for s in max_connections shared_buffers work_mem effective_cache_size maintenance_work_mem max_wal_size; do
        v=$(pg_query "SHOW $s" | head -n1)
        [ -n "$v" ] && rec DBSET "$s" "$v"
      done
      while IFS='|' read -r dbn dbb; do
        [ -z "${dbn:-}" ] && continue
        rec DBSIZE "$dbn" "$(( ${dbb:-0} / 1048576 ))"
      done < <(pg_query "SELECT datname||'|'||pg_database_size(datname) FROM pg_database ORDER BY datname")
      conns=$(pg_query 'SELECT count(*) FROM pg_stat_activity' | head -n1)
      rec DBCONN "${conns:-0}"
      if [ -n "$db_dir" ] && [ -d "$db_dir" ]; then
        rec METRIC "db_datadir_mb" "$(du -sm "$db_dir" 2>/dev/null | awk '{print $1}')"
      fi
    else
      rec DBINFO "postgresql" "" ""
      note "PostgreSQL detected but psql queries failed - database section is service-level only."
    fi
  else
    rec DBINFO "postgresql" "" ""
    note "PostgreSQL detected but no root/psql access - database section is service-level only."
  fi
fi

# -----------------------------------------------------------------------------
#  CONFIG FILE HASHES
#  Everything under /etc/veeam, plus config-shaped files under /opt/veeam.
#  Hashes, never contents, so no secret ever lands in a blueprint. Capped so
#  a pathological tree cannot balloon the snapshot.
# -----------------------------------------------------------------------------
CFG_COUNT=0
while read -r f; do
  [ -z "${f:-}" ] && continue
  h=$(hash_file "$f")
  [ -z "$h" ] && continue
  rec CFG "$f" "$h" "$(stat -c %s "$f" 2>/dev/null || echo 0)"
  CFG_COUNT=$((CFG_COUNT + 1))
done < <(
  { # -size in bytes, not -1M: find rounds size UP to whole M-units first, so
    # '-size -1M' would match only empty files.
    [ -d /etc/veeam ] && find /etc/veeam -type f -size -1048576c 2>/dev/null
    [ -d /opt/veeam ] && find /opt/veeam -type f \( -name '*.conf' -o -name '*.config' \
        -o -name '*.xml' -o -name '*.json' -o -name '*.ini' -o -name '*.properties' \
        -o -name '*.yml' -o -name '*.yaml' \) -size -1048576c 2>/dev/null
  } | sort | head -n 400
)

# -----------------------------------------------------------------------------
#  CERTIFICATES presented on the Veeam HTTPS endpoints
# -----------------------------------------------------------------------------
if command -v openssl >/dev/null 2>&1; then
  for p in 443 9419 10443; do
    echo "$LISTENERS" | awk -F'\t' -v po="$p" '$1=="tcp" && $3==po {found=1} END {exit !found}' || continue
    x509=$(printf '' | timeout 6 openssl s_client -connect "127.0.0.1:$p" 2>/dev/null |
           openssl x509 -noout -subject -issuer -enddate -fingerprint -sha256 2>/dev/null)
    [ -z "$x509" ] && continue
    c_subj=$(echo "$x509" | grep -i '^subject='    | head -n1 | cut -d= -f2-)
    c_iss=$( echo "$x509" | grep -i '^issuer='     | head -n1 | cut -d= -f2-)
    c_end=$( echo "$x509" | grep -i '^notAfter='   | head -n1 | cut -d= -f2-)
    c_fp=$(  echo "$x509" | grep -i 'Fingerprint=' | head -n1 | cut -d= -f2-)
    rec CERT "$p" "$c_subj" "$c_iss" "$c_end" "$c_fp"
  done
else
  note "openssl unavailable - certificate section skipped."
fi

# -----------------------------------------------------------------------------
#  FIREWALL
# -----------------------------------------------------------------------------
if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
  while read -r z; do
    [ -z "${z:-}" ] && continue
    dump=$(firewall-cmd --zone="$z" --list-all 2>/dev/null)
    fsvc=$(echo "$dump" | grep -E '^\s*services:' | sed 's/^[[:space:]]*services:[[:space:]]*//')
    fprt=$(echo "$dump" | grep -E '^\s*ports:'    | sed 's/^[[:space:]]*ports:[[:space:]]*//')
    rec FWZONE "$z" "$(hash_text "$dump")" "services=${fsvc} ports=${fprt}"
  done < <(firewall-cmd --get-active-zones 2>/dev/null | awk 'NR % 2 == 1 {print $1}')
elif command -v nft >/dev/null 2>&1 && nft list ruleset >/dev/null 2>&1; then
  ruleset=$(nft list ruleset 2>/dev/null)
  rec FWZONE "nftables" "$(hash_text "$ruleset")" "rules=$(echo "$ruleset" | grep -c .)"
elif command -v iptables-save >/dev/null 2>&1 && iptables-save >/dev/null 2>&1; then
  ruleset=$(iptables-save 2>/dev/null | grep -v '^#')
  rec FWZONE "iptables" "$(hash_text "$ruleset")" "rules=$(echo "$ruleset" | grep -c '^-A')"
else
  note "No readable firewall backend (firewalld/nft/iptables) - firewall section skipped."
fi

# -----------------------------------------------------------------------------
#  HOST METRICS (reported alongside the blueprint, never diffed as drift)
# -----------------------------------------------------------------------------
rec METRIC "uptime_seconds"    "$(cut -d. -f1 /proc/uptime 2>/dev/null || echo 0)"
rec METRIC "mem_total_kb"      "$(awk '/^MemTotal:/     {print $2}' /proc/meminfo 2>/dev/null)"
rec METRIC "mem_available_kb"  "$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo 2>/dev/null)"
rec METRIC "disk_root_used_mb" "$(df -Pm / 2>/dev/null | awk 'NR==2 {print $3}')"
rec METRIC "disk_root_size_mb" "$(df -Pm / 2>/dev/null | awk 'NR==2 {print $2}')"
rec METRIC "tcp_listeners"     "$TCP_COUNT"
rec METRIC "udp_listeners"     "$UDP_COUNT"

[ "$AM_ROOT" -eq 0 ] && note "Not root - listener owners, unit hashes and config hashes are degraded."

# -----------------------------------------------------------------------------
#  OUTPUT
# -----------------------------------------------------------------------------
count_tag() { printf '%s' "$RECORDS" | grep -c "^#$1|"; }
N_SVC=$(count_tag SVC); N_LSN=$(count_tag LISTEN); N_TRK=$(count_tag TRUNK)
N_RCN=$(count_tag RCONN); N_CFG=$(count_tag CFG); N_PKG=$(count_tag VEEAMPKG)

if [ "$REPORT_MODE" -eq 1 ]; then
  echo "#META|1|$(hostname)|${OS_NAME}|${KERNEL}|${ARCH}|${AM_ROOT}|${DB_ACCESS}|${STAMP}" | tr -d '\r'
  printf '%s' "$RECORDS"
  echo "#END|${N_PKG}|${N_SVC}|${N_LSN}|${N_TRK}|${N_RCN}|${N_CFG}"
  exit 0
fi

# -- human-readable summary ----------------------------------------------------
echo
echo "${C_CYN}=======================================================${C_RST}"
echo "${C_CYN}  Veeam Configuration Blueprint  ->  $(hostname)${C_RST}"
echo "${C_DIM}  ${STAMP}  |  ${OS_NAME}  |  kernel ${KERNEL}${C_RST}"
echo "${C_CYN}=======================================================${C_RST}"
[ "$AM_ROOT" -eq 0 ] && echo "${C_YEL}  ! Not root - owners, hashes and the DB section are degraded.${C_RST}"

echo
echo "${C_YEL}-- Veeam Packages (${N_PKG}) ---------------------------------${C_RST}"
printf '%s' "$RECORDS" | awk -F'|' '$1=="#VEEAMPKG" {printf "  %-40s %s\n", $2, $3}'

echo
echo "${C_YEL}-- Services (${N_SVC}) ---------------------------------------${C_RST}"
printf '%s' "$RECORDS" | awk -F'|' '$1=="#SVC" {printf "  %-9s %-9s %-34s %s\n", $4, $6, $2, $8}'

echo
echo "${C_YEL}-- Listeners (${N_LSN}: ${TCP_COUNT} tcp, ${UDP_COUNT} udp) --------------------${C_RST}"
printf '  %-5s %-9s %-16s %-6s %-11s %s\n' "PROTO" "SCOPE" "ADDRESS" "PORT" "CLASS" "PROCESS"
printf '%s' "$RECORDS" | awk -F'|' '$1=="#LISTEN" {printf "  %-5s %-9s %-16s %-6s %-11s %s %s\n", $2, $3, $4, $5, $6, $7, ($8!=""?"["$8"]":"")}' | sort -k4,4n

echo
echo "${C_YEL}-- Port Trunk Map (loopback aggregation) (${N_TRK}) ----------${C_RST}"
if [ "$N_TRK" -eq 0 ]; then
  echo "  ${C_DIM}No loopback-to-loopback service connections observed right now.${C_RST}"
else
  printf '  %-24s -> :%-6s %-24s (%s conns)\n' "FRONTEND" "PORT" "BACKEND" "N" >/dev/null
  printf '%s' "$RECORDS" | awk -F'|' '$1=="#TRUNK" {printf "  %-24s -> :%-6s %-24s (%s conns)\n", $2, $4, $5, $7}' | sort
fi

echo
echo "${C_YEL}-- Remote Data-Plane Connections (${N_RCN}) ------------------${C_RST}"
if [ "$N_RCN" -eq 0 ]; then
  echo "  ${C_DIM}No established Veeam/db connections to remote hosts right now.${C_RST}"
  echo "  ${C_DIM}(Point-in-time: idle infrastructure shows nothing - capture during a job.)${C_RST}"
else
  printf '%s' "$RECORDS" | awk -F'|' '$1=="#RCONN" {printf "  %-4s %-24s %s:%s (%s conns)\n", $4, $5, $2, $3, $7}' | sort
fi

echo
echo "${C_YEL}-- Database ---------------------------------------------${C_RST}"
if [ "$DB_PRESENT" -eq 0 ]; then
  echo "  ${C_DIM}No PostgreSQL detected on this host.${C_RST}"
else
  printf '%s' "$RECORDS" | awk -F'|' '$1=="#DBINFO" {printf "  engine=%s version=%s datadir=%s\n", $2, $3, $4}'
  printf '%s' "$RECORDS" | awk -F'|' '$1=="#DBSET"  {printf "    %-24s = %s\n", $2, $3}'
  printf '%s' "$RECORDS" | awk -F'|' '$1=="#DBSIZE" {printf "    %-32s %6s MB\n", $2, $3}'
  printf '%s' "$RECORDS" | awk -F'|' '$1=="#DBCONN" {printf "    active connections: %s\n", $2}'
fi

echo
echo "${C_YEL}-- Config Hashes / Certs / Firewall ----------------------${C_RST}"
echo "  ${CFG_COUNT} config file(s) hashed."
printf '%s' "$RECORDS" | awk -F'|' '$1=="#CERT"   {printf "  cert :%s  %s  expires %s\n", $2, $3, $5}'
printf '%s' "$RECORDS" | awk -F'|' '$1=="#FWZONE" {printf "  fw   %-12s %s\n", $2, $4}'
printf '%s' "$RECORDS" | awk -F'|' '$1=="#NOTE"   {printf "  note %s\n", $2}'

echo
echo "${C_GRN}  Blueprint captured. Re-run with --report to feed veeam-blueprint.ps1.${C_RST}"
echo
exit 0
