#!/usr/bin/env python3
# =============================================================================
#  veeam-blueprint-report.py
#  Excel viewer for veeam-blueprint JSON documents.
#
#  Turns a blueprint captured by veeam-blueprint.ps1 / veeam-blueprint.sh into
#  a formatted .xlsx workbook with charts and, more importantly, IMPACT
#  annotations: what each port is for, what each PostgreSQL/MSSQL setting
#  does to VBR behaviour, what each service's role is, and which listeners
#  deserve attention. Optionally renders a drift CSV (from
#  veeam-blueprint.ps1 -DriftCsv) as a color-coded sheet.
#
#  USAGE
#    python veeam-blueprint-report.py blueprint.json
#    python veeam-blueprint-report.py blueprint.json -o report.xlsx
#    python veeam-blueprint-report.py blueprint.json --drift drift.csv
#
#  Requires: Python 3.8+, openpyxl  (pip install openpyxl)
#
#  ANNOTATION DATA: the PORT_KNOWLEDGE table mirrors the port tables in
#  functions\PortTables.ps1 (the toolkit's source of truth). Setting/service
#  notes are operational guidance - verify against the Veeam docs for your
#  build before acting on them.
# =============================================================================

import argparse
import csv
import json
import re
import sys
from collections import Counter
from datetime import datetime, timezone

try:
    from openpyxl import Workbook
    from openpyxl.chart import BarChart, Reference
    from openpyxl.chart.label import DataLabelList
    from openpyxl.chart.marker import DataPoint
    from openpyxl.chart.shapes import GraphicalProperties
    from openpyxl.formatting.rule import CellIsRule
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
except ImportError:
    sys.exit("openpyxl is required:  pip install openpyxl")

# -----------------------------------------------------------------------------
#  Palette (validated data-viz defaults; single accent hue for magnitude bars,
#  status colors reserved for severity).
# -----------------------------------------------------------------------------
ACCENT      = "2A78D6"   # chart bars
HEADER_BG   = "184F95"   # table headers
STATUS      = {"Critical": "D03B3B", "Warning": "FAB219", "Info": "898781"}
WASH_CRIT   = PatternFill("solid", fgColor="F7DEDE")
WASH_WARN   = PatternFill("solid", fgColor="FCF0D4")
WASH_OK     = PatternFill("solid", fgColor="E2F1E2")
FONT_NAME   = "Arial"

F_TITLE  = Font(name=FONT_NAME, size=16, bold=True, color="0B0B0B")
F_H2     = Font(name=FONT_NAME, size=12, bold=True, color="184F95")
F_HEAD   = Font(name=FONT_NAME, size=10, bold=True, color="FFFFFF")
F_BODY   = Font(name=FONT_NAME, size=10)
F_BOLD   = Font(name=FONT_NAME, size=10, bold=True)
F_MUTED  = Font(name=FONT_NAME, size=9, color="898781")
F_KPI    = Font(name=FONT_NAME, size=20, bold=True, color="184F95")
F_KPILBL = Font(name=FONT_NAME, size=9, color="52514E")

# -----------------------------------------------------------------------------
#  Impact knowledge. PORT_KNOWLEDGE mirrors functions\PortTables.ps1.
#  expected: which owner class should hold the port on a backup server.
# -----------------------------------------------------------------------------
PORT_KNOWLEDGE = {
    22:    ("os",    "SSH"),
    111:   ("veeam", "vPower NFS - RPC portmapper. From v13 vPower NFS fails to start if this is taken."),
    135:   ("os",    "RPC Endpoint Mapper (component/agent deploy)"),
    139:   ("os",    "NetBIOS session service"),
    443:   ("veeam", "Backup server connection / certificate port; the v13 trunk front door"),
    445:   ("os",    "SMB - component deploy / upgrade file copy"),
    1058:  ("veeam", "vPower NFS mount service"),
    1433:  ("db",    "Microsoft SQL Server - VBR configuration database (if MSSQL)"),
    2049:  ("veeam", "vPower NFS server - any other NFS server collides here"),
    5432:  ("db",    "PostgreSQL - VBR configuration database"),
    6160:  ("veeam", "Veeam Installer / Deployer Service; v13 aggregates deployment traffic here"),
    6161:  ("veeam", "vPower NFS control"),
    6162:  ("veeam", "Veeam Data Mover / Transport Service"),
    6164:  ("veeam", "WAN Accelerator (control)"),
    6165:  ("veeam", "WAN Accelerator (data)"),
    6172:  ("veeam", "Backup server DB communication (Kasten plug-in)"),
    6180:  ("veeam", "Cloud Connect Service"),
    9380:  ("veeam", "Distribution Service (agent management)"),
    9392:  ("veeam", "Windows backup server initial connection (console / EM)"),
    9393:  ("veeam", "Guest Catalog Service"),
    9394:  ("veeam", "Enterprise Manager Service"),
    9398:  ("veeam", "Enterprise Manager REST API (HTTPS)"),
    9399:  ("veeam", "Enterprise Manager REST API (HTTP)"),
    9401:  ("veeam", "Mount Service (mount server <-> backup server)"),
    9405:  ("veeam", "Certificate port - EM collecting from v12 backup servers"),
    9419:  ("veeam", "Veeam RESTful API Service (HTTPS)"),
    9443:  ("veeam", "Enterprise Manager web UI (HTTPS)"),
    10003: ("veeam", "Cloud Gateway"),
    10006: ("veeam", "Backup server connection port"),
    10443: ("veeam", "Veeam Host Management"),
}
RANGE_LO, RANGE_HI = 2500, 3300

DB_SETTING_IMPACT = {
    "max_connections":      "Ceiling on concurrent DB sessions. Veeam tunes this high (3000 is its default) because every running job and service holds sessions - too low and jobs fail with connection errors; each slot costs a little RAM and multiplies work_mem exposure.",
    "shared_buffers":       "PostgreSQL's own page cache. Undersized -> heavy disk I/O on the config DB during job bursts. Rule of thumb ~25% of RAM on a dedicated DB box; less when VBR shares the host.",
    "work_mem":             "Memory per sort/hash operation PER CONNECTION. Its impact multiplies with max_connections - raising both together can exhaust host RAM under load.",
    "effective_cache_size": "Planner hint (usually 50-75% of RAM), not an allocation. Set too low the planner avoids indexes and config queries slow down.",
    "maintenance_work_mem": "Memory for VACUUM and index builds - governs how quickly the config DB reclaims space after job-session churn.",
    "max_wal_size":         "Checkpoint spacing. Too small -> frequent checkpoints and I/O stalls exactly during busy job windows.",
    "max server memory (MB)":     "Hard cap on SQL Server memory. Unset (2PB default) SQL will squeeze the VBR services on a shared host; too low starves the config DB cache.",
    "user connections":           "0 = unlimited (SQL manages). A hard value that is too low fails Veeam sessions.",
    "max degree of parallelism":  "Parallel query fan-out. Usually left at vendor default for VBR config workloads.",
}

SERVICE_ROLES = [
    ("veeambackupsvc",        "Core Backup & Replication engine - job orchestration (9392/443)"),
    ("veeambrokersvc",        "Broker Service - virtual infrastructure connection cache"),
    ("veeamcatalogsvc",       "Guest Catalog - indexing data (9393)"),
    ("veeamcloudsvc",         "Cloud Connect service"),
    ("veeambackupcdpsvc",     "CDP coordinator service"),
    ("veeamcdpsvc",           "CDP proxy/coordinator"),
    ("veeamdeploysvc",        "Installer / Deployer Service (6160)"),
    ("veeamdeploymentservice","Installer / Deployer Service (6160)"),
    ("veeamtransportsvc",     "Data Mover / Transport (6162, data range 2500-3300)"),
    ("veeamnfssvc",           "vPower NFS (111 / 1058 / 2049 / 6161) - instant recovery mounts"),
    ("veeammountsvc",         "Mount Service (9401) - file-level recovery mounts"),
    ("veeamdistributionsvc",  "Distribution Service (9380) - agent deployment"),
    ("veeamrestsvc",          "REST API service (9419)"),
    ("veeamdataanalyzersvc",  "Data Analyzer (malware detection scans)"),
    ("veeamfilesysvsssvc",    "Guest VSS integration helper"),
    ("veeamguestcontrolsvc",  "Guest interaction control"),
    ("veeamoneagentsvc",      "Veeam ONE monitoring agent"),
    ("veeamexplorersrecoverysvc", "Explorers recovery service"),
    ("veeamvsssupport",       "VSS support provider"),
    ("postgresql",            "VBR configuration database (PostgreSQL, 5432)"),
    ("mssql",                 "VBR configuration database (SQL Server, 1433)"),
    ("sqlbrowser",            "SQL Server instance browser"),
]

GENERATOR_VERSION = "1.0"


# -----------------------------------------------------------------------------
#  Helpers
# -----------------------------------------------------------------------------
def load_blueprint(path):
    # PowerShell 5.1's Set-Content -Encoding UTF8 writes a BOM: utf-8-sig
    # handles both BOM and BOM-less files.
    with open(path, encoding="utf-8-sig") as fh:
        doc = json.load(fh)
    if not str(doc.get("schema", "")).startswith("veeam-blueprint/"):
        sys.exit(f"{path} is not a veeam-blueprint document (schema={doc.get('schema')!r})")
    return doc


def service_role(name, display=""):
    hay = (name or "").lower() + " " + (display or "").lower()
    for needle, role in SERVICE_ROLES:
        if needle in hay:
            return role
    return ""


def listener_attention(row):
    """Return (attention_text, wash_fill_or_None) for a listener row."""
    cls = (row.get("ownerClass") or "").lower()
    port = int(row.get("port") or 0)
    known = PORT_KNOWLEDGE.get(port)
    if cls in ("thirdparty", "unknown"):
        if known:
            return (f"INVESTIGATE: {cls} process on a documented Veeam-stack port", WASH_CRIT)
        if RANGE_LO <= port <= RANGE_HI and row.get("proto") == "tcp":
            return (f"{cls} listener inside the data transfer range {RANGE_LO}-{RANGE_HI}", WASH_CRIT)
        return (f"{cls} listener - identify before the next upgrade", WASH_WARN)
    if known and known[0] != cls and not (known[0] == "veeam" and cls == "db") \
            and not (known[0] == "db" and cls == "veeam"):
        if known[0] == "veeam" and (row.get("process") or "") == "System":
            return ("kernel-owned (PID 4) on a Veeam port - usually an HTTP.sys URL "
                    "reservation for a Veeam web component; verify with: netsh http show urlacl",
                    WASH_WARN)
        return (f"expected {known[0]} owner on this port, found {cls}", WASH_WARN)
    if RANGE_LO <= port <= RANGE_HI and row.get("proto") == "tcp" and cls != "veeam":
        return (f"non-Veeam listener inside the data transfer range", WASH_WARN)
    return ("", None)


def port_component(port):
    k = PORT_KNOWLEDGE.get(int(port or 0))
    if k:
        return k[1]
    if RANGE_LO <= int(port or 0) <= RANGE_HI:
        return f"Data transfer range {RANGE_LO}-{RANGE_HI} (one port per job TCP connection)"
    return ""


def parse_when(s):
    s = re.sub(r"\s+", " ", str(s or "").strip())
    for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S", "%b %d %H:%M:%S %Y %Z", "%b %d %H:%M:%S %Y"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def sheet(wb, title, tab_color=None):
    ws = wb.create_sheet(title=title[:31])
    if tab_color:
        ws.sheet_properties.tabColor = tab_color
    ws.sheet_view.showGridLines = False
    return ws


def put(ws, row, col, value, font=F_BODY, fill=None, fmt=None, align=None):
    c = ws.cell(row=row, column=col, value=value)
    c.font = font
    if fill:
        c.fill = fill
    if fmt:
        c.number_format = fmt
    if align:
        c.alignment = align
    return c


def header_row(ws, row, headers, widths=None):
    for i, h in enumerate(headers, start=1):
        c = put(ws, row, i, h, font=F_HEAD, fill=PatternFill("solid", fgColor=HEADER_BG))
        c.alignment = Alignment(vertical="center")
    if widths:
        for i, w in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[row].height = 18


def finish_table(ws, header_rownum, last_row, last_col):
    ws.auto_filter.ref = (f"A{header_rownum}:"
                          f"{get_column_letter(last_col)}{max(last_row, header_rownum)}")
    ws.freeze_panes = ws.cell(row=header_rownum + 1, column=1)


def bar_chart(ws, title, anchor, cat_ref, data_ref, per_point_colors=None,
              horizontal=True, height=None, width=16, unit=""):
    ch = BarChart()
    ch.type = "bar" if horizontal else "col"
    ch.title = title
    ch.legend = None            # single series: the title names it
    ch.gapWidth = 60
    ch.add_data(data_ref, titles_from_data=True)
    ch.set_categories(cat_ref)
    ser = ch.series[0]
    ser.graphicalProperties = GraphicalProperties(solidFill=ACCENT)
    if per_point_colors:
        pts = []
        for idx, hexcol in per_point_colors:
            dp = DataPoint(idx=idx)
            dp.graphicalProperties = GraphicalProperties(solidFill=hexcol)
            pts.append(dp)
        ser.data_points = pts
    ch.dataLabels = DataLabelList()
    ch.dataLabels.showVal = True
    n_cats = cat_ref.max_row - cat_ref.min_row + 1
    ch.height = height if height else max(5, min(18, 1.6 + 0.75 * n_cats))
    ch.width = width
    if unit:
        (ch.x_axis if horizontal else ch.y_axis).title = unit
    ws.add_chart(ch, anchor)


def summary_block(ws, start_row, title, pairs):
    """Small two-column key/count table used as a chart's data source.
    Returns (header_row, first_data_row, last_data_row)."""
    put(ws, start_row, 1, title, font=F_H2)
    hdr = start_row + 1
    put(ws, hdr, 1, "Category", font=F_BOLD)
    put(ws, hdr, 2, "Count", font=F_BOLD)
    r = hdr
    for k, v in pairs:
        r += 1
        put(ws, r, 1, k)
        put(ws, r, 2, v, fmt="#,##0")
    return hdr, hdr + 1, r


# -----------------------------------------------------------------------------
#  Sheets
# -----------------------------------------------------------------------------
def build_overview(wb, doc, attention_counts, cert_soon, src_name, drift_counts):
    ws = wb.active
    ws.title = "Overview"
    ws.sheet_view.showGridLines = False
    ident = doc["identity"]
    met = doc.get("metrics", {}) or {}
    tier = doc.get("tier", {}) or {}

    put(ws, 1, 1, f"Veeam Configuration Blueprint - {doc.get('host','')}", font=F_TITLE)
    put(ws, 2, 1, f"Captured {doc.get('capturedUtc','')} | {doc.get('platform','')} | "
                  f"{ident.get('os',{}).get('caption','')} {ident.get('os',{}).get('kernel','')}",
        font=F_MUTED)

    # capture tier
    elev = bool(tier.get("elevated")); dba = bool(tier.get("dbAccess"))
    tier_txt = f"Capture tier: {'elevated' if elev else 'NOT ELEVATED'}, {'database access' if dba else 'NO database access'}"
    put(ws, 3, 1, tier_txt, font=F_BOLD, fill=(WASH_OK if (elev and dba) else WASH_WARN))
    r = 4
    for n in (tier.get("notes") or []):
        put(ws, r, 1, f"note: {n}", font=F_MUTED); r += 1

    # KPI tiles
    services = ident.get("services") or []
    listeners = ident.get("listeners") or []
    running = sum(1 for s in services if str(s.get("state","")).lower() in ("running","active"))
    db = ident.get("database") or {}
    sizes = (met.get("databaseSizesMB") or {})
    kpis = [
        ("Veeam products",  len(ident.get("veeamProducts") or [])),
        ("Services",        f"{running}/{len(services)} running"),
        ("TCP listeners",   met.get("tcp_listeners", "")),
        ("UDP listeners",   met.get("udp_listeners", "")),
        ("Trunk hops",      len(ident.get("trunk") or [])),
        ("Config DB",       f"{db.get('engine','-')} {db.get('version','')}".strip()),
        ("VeeamBackup DB",  f"{sizes.get('VeeamBackup','-')} MB"),
    ]
    kr = r + 1
    for i, (label, val) in enumerate(kpis):
        col = 1 + i * 2
        put(ws, kr, col, val, font=F_KPI)
        put(ws, kr + 1, col, label, font=F_KPILBL)

    # attention summary
    ar = kr + 3
    put(ws, ar, 1, "Needs attention", font=F_H2)
    ar += 1
    rows = [
        ("Third-party / unknown listeners", attention_counts["unexpected"],
         "See the Listeners sheet - red rows."),
        ("Listeners on documented Veeam ports with a different owner", attention_counts["mismatch"],
         "See the Listeners sheet - amber rows."),
        (f"Non-Veeam TCP listeners in the data range {RANGE_LO}-{RANGE_HI}", attention_counts["range"],
         "Each one shrinks the pool Veeam draws from per job connection."),
        ("Auto-start services not running", attention_counts["stopped_auto"],
         "A stopped service's ports read free NOW but must be free when it restarts."),
        ("Certificates expiring within 90 days", cert_soon,
         "See Certificates - the Days-left column."),
    ]
    if drift_counts is not None:
        rows.append(("Drift vs baseline (Critical / Warning)",
                     f"{drift_counts.get('Critical',0)} / {drift_counts.get('Warning',0)}",
                     "See the Drift sheet."))
    for label, count, hint in rows:
        bad = False
        try:
            bad = float(str(count).split("/")[0]) > 0
        except ValueError:
            bad = False
        put(ws, ar, 1, label)
        put(ws, ar, 2, count, font=F_BOLD, fill=(WASH_WARN if bad else WASH_OK))
        put(ws, ar, 3, hint, font=F_MUTED)
        ar += 1

    # capacity block with live formulas
    cr = ar + 1
    put(ws, cr, 1, "Host capacity", font=F_H2)
    cap = [
        ("Disk used (MB)",  met.get("disk_root_used_mb")),
        ("Disk size (MB)",  met.get("disk_root_size_mb")),
        ("Memory available (KB)", met.get("mem_available_kb")),
        ("Memory total (KB)",     met.get("mem_total_kb")),
    ]
    for i, (label, val) in enumerate(cap):
        put(ws, cr + 1 + i, 1, label)
        try:
            put(ws, cr + 1 + i, 2, float(val), fmt="#,##0")
        except (TypeError, ValueError):
            put(ws, cr + 1 + i, 2, val)
    put(ws, cr + 5, 1, "Disk used %")
    put(ws, cr + 5, 2, f"=IF(B{cr+2}>0,B{cr+1}/B{cr+2},\"\")", fmt="0.0%")
    put(ws, cr + 6, 1, "Memory free %")
    put(ws, cr + 6, 2, f"=IF(B{cr+4}>0,B{cr+3}/B{cr+4},\"\")", fmt="0.0%")

    put(ws, cr + 8, 1,
        f"Generated by veeam-blueprint-report.py v{GENERATOR_VERSION} from {src_name}. "
        "Port/setting annotations mirror functions\\PortTables.ps1 and general operational guidance - "
        "verify against the Veeam docs for your build.", font=F_MUTED)

    for col, w in zip("ABCDEFGHIJKLMN", (34, 16, 14, 16, 12, 16, 14, 16, 12, 12, 12, 12, 12, 12)):
        ws.column_dimensions[col].width = w
    return ws


def build_listeners(wb, doc):
    ws = sheet(wb, "Listeners", "2A78D6")
    listeners = doc["identity"].get("listeners") or []
    counts = Counter((l.get("ownerClass") or "?") for l in listeners)

    put(ws, 1, 1, "Listeners - every TCP/UDP endpoint, with the Veeam component that documents the port", font=F_H2)
    hdr, first, last = summary_block(ws, 3, "Listeners by owner class",
                                     sorted(counts.items(), key=lambda kv: kv[1]))
    bar_chart(ws, "Listeners by owner class", "D3",
              Reference(ws, min_col=1, min_row=first, max_row=last),
              Reference(ws, min_col=2, min_row=hdr, max_row=last))

    t = last + 3
    headers = ["Proto", "Scope", "Address", "Port", "Class", "Process", "Service",
               "Component (documented use)", "Attention"]
    header_row(ws, t, headers, widths=(7, 10, 22, 8, 11, 26, 26, 55, 48))
    counts_attention = 0
    r = t
    for l in listeners:
        r += 1
        att, wash = listener_attention(l)
        vals = [l.get("proto"), l.get("scope"), l.get("address"), l.get("port"),
                l.get("ownerClass"), l.get("process"), l.get("service"),
                port_component(l.get("port")), att]
        for c, v in enumerate(vals, start=1):
            put(ws, r, c, v, fmt=("0" if c == 4 else None))
        if wash:
            counts_attention += 1
            for c in range(1, len(headers) + 1):
                ws.cell(row=r, column=c).fill = wash
    finish_table(ws, t, r, len(headers))
    return ws


def build_trunk(wb, doc):
    ws = sheet(wb, "Port & Trunk Map", "1BAF7A")
    trunk = doc["identity"].get("trunk") or []
    remote = doc["identity"].get("remoteEndpoints") or []

    put(ws, 1, 1, "Internal trunk map - which frontend feeds which backend service over loopback", font=F_H2)
    put(ws, 2, 1, "This is how v13-style port aggregation actually wires up on this host: "
                  "each row is an observed loopback connection from a frontend process into a backend listener.",
        font=F_MUTED)

    # fan-in per backend (the aggregation view)
    fanin = Counter()
    for tr in trunk:
        key = f"{tr.get('backProcess') or '?'} :{tr.get('backPort')}"
        fanin[key] += int(tr.get("connections") or 0)
    if fanin:
        hdr, first, last = summary_block(ws, 4, "Connections into each backend (fan-in)",
                                         sorted(fanin.items(), key=lambda kv: kv[1]))
        bar_chart(ws, "Trunk fan-in: connections per backend", "D4",
                  Reference(ws, min_col=1, min_row=first, max_row=last),
                  Reference(ws, min_col=2, min_row=hdr, max_row=last))
        t = last + 3
    else:
        put(ws, 4, 1, "No loopback service hops were active at capture time.", font=F_MUTED)
        t = 6

    headers = ["Frontend process", "Frontend service", "Backend port", "Backend process",
               "Backend service", "Connections", "Backend port's documented use"]
    header_row(ws, t, headers, widths=(30, 26, 13, 26, 26, 12, 52))
    r = t
    for tr in sorted(trunk, key=lambda x: (x.get("backPort") or 0, x.get("frontProcess") or "")):
        r += 1
        for c, v in enumerate([tr.get("frontProcess"), tr.get("frontService"), tr.get("backPort"),
                               tr.get("backProcess"), tr.get("backService"), tr.get("connections"),
                               port_component(tr.get("backPort"))], start=1):
            put(ws, r, c, v)
    finish_table(ws, t, r, len(headers))

    dr = r + 3
    put(ws, dr, 1, "Observed data plane - established connections to/from remote hosts", font=F_H2)
    put(ws, dr + 1, 1, "Point-in-time: idle infrastructure shows nothing. Capture during a job window "
                       "to map managed-server traffic; merge several captures for the full picture.", font=F_MUTED)
    t2 = dr + 3
    headers2 = ["Direction", "Remote host", "Port", "Local process", "Local service",
                "Connections", "Port's documented use"]
    header_row(ws, t2, headers2, widths=None)
    r = t2
    for e in remote:
        r += 1
        for c, v in enumerate([e.get("direction"), e.get("remoteHost"), e.get("remotePort"),
                               e.get("process"), e.get("service"), e.get("connections"),
                               port_component(e.get("remotePort"))], start=1):
            put(ws, r, c, v)
    if not remote:
        put(ws, t2 + 1, 1, "none captured", font=F_MUTED)
    return ws


def build_services(wb, doc):
    ws = sheet(wb, "Services", "EDA100")
    services = doc["identity"].get("services") or []

    put(ws, 1, 1, "Services - state, identity, and role", font=F_H2)
    by_account = Counter((s.get("account") or "?") for s in services)
    hdr, first, last = summary_block(ws, 3, "Services per run-as account",
                                     sorted(by_account.items(), key=lambda kv: kv[1]))
    bar_chart(ws, "Services per run-as account", "D3",
              Reference(ws, min_col=1, min_row=first, max_row=last),
              Reference(ws, min_col=2, min_row=hdr, max_row=last))

    t = last + 3
    headers = ["Service", "Display name", "State", "Start type", "Account", "Role", "Binary path"]
    header_row(ws, t, headers, widths=(28, 42, 10, 11, 26, 52, 60))
    r = t
    for s in services:
        r += 1
        role = service_role(s.get("name"), s.get("displayName"))
        for c, v in enumerate([s.get("name"), s.get("displayName"), s.get("state"),
                               s.get("startType"), s.get("account"), role, s.get("path")], start=1):
            put(ws, r, c, v)
        state = str(s.get("state","")).lower()
        auto = str(s.get("startType","")).lower().startswith("auto") or \
               str(s.get("startType","")).lower() == "enabled"
        if auto and state not in ("running", "active"):
            for c in range(1, len(headers) + 1):
                ws.cell(row=r, column=c).fill = WASH_WARN
            put(ws, r, 3, s.get("state"), font=F_BOLD, fill=WASH_WARN)
    finish_table(ws, t, r, len(headers))
    return ws


def build_database(wb, doc):
    ws = sheet(wb, "Database", "4A3AA7")
    db = doc["identity"].get("database") or {}
    met = doc.get("metrics", {}) or {}
    sizes = met.get("databaseSizesMB") or {}

    put(ws, 1, 1, "Configuration database", font=F_H2)
    info = [("Engine", db.get("engine")), ("Version", db.get("version")),
            ("Data directory", db.get("dataDir")),
            ("Data dir size (MB)", met.get("db_datadir_mb")),
            ("Active connections at capture", met.get("db_connections"))]
    r = 2
    for k, v in info:
        put(ws, r, 1, k, font=F_BOLD); put(ws, r, 2, v); r += 1

    if sizes:
        pairs = sorted(((k, int(v)) for k, v in sizes.items()), key=lambda kv: kv[1])
        hdr, first, last = summary_block(ws, r + 1, "Database sizes (MB)", pairs)
        bar_chart(ws, "Database sizes (MB)", "D" + str(r + 1),
                  Reference(ws, min_col=1, min_row=first, max_row=last),
                  Reference(ws, min_col=2, min_row=hdr, max_row=last), unit="MB")
        r = last + 2

    t = r + 2
    put(ws, t - 1, 1, "Engine settings and what they mean for VBR", font=F_H2)
    headers = ["Setting", "Value", "Impact"]
    header_row(ws, t, headers, widths=(26, 14, 110))
    settings = db.get("settings") or {}
    rr = t
    for k in sorted(settings.keys()):
        rr += 1
        put(ws, rr, 1, k, font=F_BOLD)
        put(ws, rr, 2, settings[k])
        put(ws, rr, 3, DB_SETTING_IMPACT.get(k, ""))
        ws.cell(row=rr, column=3).alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[rr].height = 30
    if not settings:
        put(ws, t + 1, 1, "No engine settings captured (no DB access at capture time).", font=F_MUTED)
    return ws


def build_products(wb, doc):
    ws = sheet(wb, "Products", "E87BA4")
    products = doc["identity"].get("veeamProducts") or []

    put(ws, 1, 1, "Installed Veeam products / packages", font=F_H2)
    fams = Counter()
    for p in products:
        m = re.match(r"^(\d+)\.", str(p.get("version") or ""))
        fams[f"{m.group(1)}.x" if m else "unversioned"] += 1
    if fams:
        hdr, first, last = summary_block(ws, 3, "Products per major version",
                                         sorted(fams.items(), key=lambda kv: kv[1]))
        bar_chart(ws, "Products per major version", "D3",
                  Reference(ws, min_col=1, min_row=first, max_row=last),
                  Reference(ws, min_col=2, min_row=hdr, max_row=last))
        t = last + 3
    else:
        t = 4

    headers = ["Product / package", "Version", "Arch"]
    header_row(ws, t, headers, widths=(72, 16, 10))
    r = t
    for p in products:
        r += 1
        put(ws, r, 1, p.get("name")); put(ws, r, 2, p.get("version")); put(ws, r, 3, p.get("arch"))
    finish_table(ws, t, r, len(headers))
    return ws


def build_certs_firewall(wb, doc):
    ws = sheet(wb, "Certs & Firewall", "E34948")
    certs = doc["identity"].get("certificates") or []
    fw = doc["identity"].get("firewall") or []

    put(ws, 1, 1, "Certificates", font=F_H2)
    t = 2
    headers = ["Binding", "Subject", "Issuer", "Expires", "Days left", "Thumbprint / fingerprint"]
    header_row(ws, t, headers, widths=(26, 42, 42, 13, 10, 50))
    r = t
    cert_soon = 0
    for cinfo in certs:
        r += 1
        exp = parse_when(cinfo.get("notAfter"))
        put(ws, r, 1, cinfo.get("binding"))
        put(ws, r, 2, cinfo.get("subject"))
        put(ws, r, 3, cinfo.get("issuer"))
        if exp:
            put(ws, r, 4, exp.date(), fmt="yyyy-mm-dd")
            put(ws, r, 5, f"=D{r}-TODAY()", fmt="0")
            if (exp - datetime.now()).days < 90:
                cert_soon += 1
        else:
            put(ws, r, 4, cinfo.get("notAfter"))
        put(ws, r, 6, cinfo.get("thumbprint"))
    if r > t:
        rng = f"E{t+1}:E{r}"
        ws.conditional_formatting.add(rng, CellIsRule(operator="lessThan", formula=["90"], fill=WASH_CRIT))
        ws.conditional_formatting.add(rng, CellIsRule(operator="between", formula=["90", "365"], fill=WASH_WARN))
    else:
        put(ws, t + 1, 1, "none captured", font=F_MUTED)

    fr = r + 3
    put(ws, fr, 1, "Firewall rules (Veeam-related)", font=F_H2)
    t2 = fr + 1
    header_row(ws, t2, ["Rule / zone", "Summary", "Hash"], widths=None)
    r = t2
    for f in fw:
        r += 1
        put(ws, r, 1, f.get("name")); put(ws, r, 2, f.get("summary")); put(ws, r, 3, f.get("hash"))
        if "enabled=False" in str(f.get("summary", "")):
            for c in range(1, 4):
                ws.cell(row=r, column=c).fill = WASH_WARN
    if not fw:
        put(ws, t2 + 1, 1, "none captured", font=F_MUTED)
    return ws, cert_soon


def build_config(wb, doc):
    ws = sheet(wb, "Config Hashes")
    rows = doc["identity"].get("configHashes") or []
    put(ws, 1, 1, "Config file hashes - the drift engine's tripwire (contents are never captured)", font=F_H2)
    t = 3
    header_row(ws, t, ["Path", "Bytes", "SHA-256"], widths=(95, 12, 68))
    r = t
    for cfg in rows:
        r += 1
        put(ws, r, 1, cfg.get("path"))
        put(ws, r, 2, cfg.get("bytes"), fmt="#,##0")
        put(ws, r, 3, cfg.get("hash"), font=F_MUTED)
    finish_table(ws, t, r, 3)

    reg = doc["identity"].get("registryConfig")
    if reg and reg.get("values"):
        rr = r + 3
        put(ws, rr, 1, "Veeam registry configuration (non-secret values)", font=F_H2)
        t2 = rr + 1
        header_row(ws, t2, ["Key :: value name", "Value"], widths=None)
        r = t2
        for k in sorted(reg["values"].keys()):
            r += 1
            put(ws, r, 1, k)
            put(ws, r, 2, reg["values"][k])
    return ws


def build_metrics(wb, doc):
    ws = sheet(wb, "Metrics")
    met = doc.get("metrics", {}) or {}
    put(ws, 1, 1, "Host metrics - reported for trending, never treated as drift", font=F_H2)
    t = 3
    header_row(ws, t, ["Metric", "Value"], widths=(30, 18))
    r = t
    for k in sorted(met.keys()):
        if k == "databaseSizesMB":
            continue
        r += 1
        put(ws, r, 1, k)
        try:
            put(ws, r, 2, float(met[k]), fmt="#,##0")
        except (TypeError, ValueError):
            put(ws, r, 2, met[k])
    for name, mb in sorted((met.get("databaseSizesMB") or {}).items()):
        r += 1
        put(ws, r, 1, f"db_size_mb:{name}")
        put(ws, r, 2, mb, fmt="#,##0")
    return ws


def build_drift(wb, drift_rows):
    ws = sheet(wb, "Drift", "D03B3B")
    put(ws, 1, 1, "Drift vs baseline (from veeam-blueprint.ps1 -DriftCsv)", font=F_H2)

    sev_counts = Counter(row.get("Severity", "") for row in drift_rows)
    order = [s for s in ("Info", "Warning", "Critical") if sev_counts.get(s)]
    if order:
        hdr, first, last = summary_block(ws, 3, "Drift items by severity",
                                         [(s, sev_counts[s]) for s in order])
        per_point = [(i, STATUS[s]) for i, s in enumerate(order)]
        bar_chart(ws, "Drift items by severity", "D3",
                  Reference(ws, min_col=1, min_row=first, max_row=last),
                  Reference(ws, min_col=2, min_row=hdr, max_row=last),
                  per_point_colors=per_point)
        t = last + 3
    else:
        put(ws, 3, 1, "No drift rows in the CSV.", font=F_MUTED)
        t = 5

    headers = ["Severity", "Section", "Change", "Key", "Field", "Before", "After"]
    header_row(ws, t, headers, widths=(10, 16, 10, 42, 12, 46, 46))
    r = t
    for row in sorted(drift_rows, key=lambda x: {"Critical": 0, "Warning": 1}.get(x.get("Severity"), 2)):
        r += 1
        for c, k in enumerate(["Severity", "Section", "ChangeType", "Key", "Field", "Before", "After"], start=1):
            put(ws, r, c, row.get(k, ""))
        wash = {"Critical": WASH_CRIT, "Warning": WASH_WARN}.get(row.get("Severity"))
        if wash:
            for c in range(1, len(headers) + 1):
                ws.cell(row=r, column=c).fill = wash
    finish_table(ws, t, r, len(headers))
    return ws, dict(sev_counts)


# -----------------------------------------------------------------------------
#  Main
# -----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="Render a veeam-blueprint JSON as an Excel workbook.")
    ap.add_argument("blueprint", help="blueprint JSON produced by veeam-blueprint.ps1 / New-BlueprintDocument")
    ap.add_argument("-o", "--out", help="output .xlsx path (default: <blueprint>_report.xlsx)")
    ap.add_argument("--drift", help="optional drift CSV from veeam-blueprint.ps1 -DriftCsv")
    args = ap.parse_args()

    doc = load_blueprint(args.blueprint)
    out = args.out or re.sub(r"\.json$", "", args.blueprint) + "_report.xlsx"

    drift_rows = None
    if args.drift:
        with open(args.drift, encoding="utf-8-sig", newline="") as fh:
            drift_rows = list(csv.DictReader(fh))

    # pre-compute attention counts for the overview
    listeners = doc["identity"].get("listeners") or []
    services = doc["identity"].get("services") or []
    att = {"unexpected": 0, "mismatch": 0, "range": 0, "stopped_auto": 0}
    for l in listeners:
        cls = (l.get("ownerClass") or "").lower()
        port = int(l.get("port") or 0)
        if cls in ("thirdparty", "unknown"):
            att["unexpected"] += 1
        elif port in PORT_KNOWLEDGE and PORT_KNOWLEDGE[port][0] != cls \
                and not (PORT_KNOWLEDGE[port][0] in ("veeam", "db") and cls in ("veeam", "db")):
            att["mismatch"] += 1
        if RANGE_LO <= port <= RANGE_HI and l.get("proto") == "tcp" and cls != "veeam":
            att["range"] += 1
    for s in services:
        auto = str(s.get("startType", "")).lower().startswith("auto") or \
               str(s.get("startType", "")).lower() == "enabled"
        if auto and str(s.get("state", "")).lower() not in ("running", "active"):
            att["stopped_auto"] += 1

    wb = Workbook()
    for ws in wb.worksheets:      # style default sheet
        ws.sheet_view.showGridLines = False

    build_listeners(wb, doc)
    build_trunk(wb, doc)
    build_services(wb, doc)
    build_database(wb, doc)
    build_products(wb, doc)
    _, cert_soon = build_certs_firewall(wb, doc)
    build_config(wb, doc)
    build_metrics(wb, doc)
    drift_counts = None
    if drift_rows is not None:
        _, drift_counts = build_drift(wb, drift_rows)

    import os
    build_overview(wb, doc, att, cert_soon, os.path.basename(args.blueprint), drift_counts)

    # default font on any cell we did not style explicitly
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is not None and (cell.font is None or cell.font.name != FONT_NAME):
                    f = cell.font or Font()
                    cell.font = Font(name=FONT_NAME, size=f.size or 10, bold=f.bold,
                                     color=f.color, italic=f.italic)

    wb.save(out)
    print(f"Wrote {out}")
    print("Sheets:", ", ".join(ws.title for ws in wb.worksheets))
    if att["unexpected"] or att["range"]:
        print(f"Attention: {att['unexpected']} unexpected listener(s), "
              f"{att['range']} non-Veeam in {RANGE_LO}-{RANGE_HI}.")


if __name__ == "__main__":
    main()
