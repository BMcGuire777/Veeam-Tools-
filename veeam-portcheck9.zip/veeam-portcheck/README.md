# veeam-portcheck

Veeam server diagnostics in one modular toolkit: port conflict / reachability
checks (`portest3.ps1`) and configuration blueprints with drift detection
(`veeam-blueprint.ps1`). Both entry points share the same `functions\` folder.

```
veeam-portcheck/
├── portest3.ps1            Port checks: conflicts, reachability, VBR connect.
├── veeam-blueprint.ps1     Config blueprint capture + drift detection.
├── veeam-portcheck.sh      Linux / VSA port check. Deliberately ONE file - see below.
├── veeam-blueprint.sh      Linux / VSA blueprint collector. Also ONE file.
└── functions/              Everything else. Auto-loaded, one file per area.
    ├── PortTables.ps1           Port data - the source of truth for port checks.
    ├── Collector.ps1            Port-check collector ($collector scriptblock).
    ├── Collectors.ps1           Table scoping + local/remote collector runners.
    ├── Reporting.ps1            Console rendering: banner, rules, conflict report.
    ├── Results.ps1              Session result state and CSV export.
    ├── Vbr.ps1                  VBR connection layer + connect-and-check flow.
    ├── LinuxVsa.ps1             VSA guidance, script emit, SSH-push workflows.
    ├── SshTransport.ps1         Posh-SSH / native ssh transports (shared by both tools).
    ├── Reachability.ps1         Plain TCP reachability scans (portest2 behaviour).
    ├── Menu.ps1                 portest3's interactive menu.
    ├── BlueprintCollector.ps1   Windows blueprint collector ($blueprintCollector).
    ├── Blueprint.ps1            Blueprint document model, storage, capture front doors.
    └── Drift.ps1                The drift engine (Compare-VeeamBlueprint + report).
```

## How loading works

`portest3.ps1` dot-sources **every `*.ps1` under `functions\`** (sorted by
name) before doing anything else:

```powershell
foreach ($functionFile in @(Get-ChildItem $script:FunctionsDir -Filter '*.ps1' -File | Sort-Object Name)) {
    . $functionFile.FullName
}
```

Dot-sourcing runs each file in the *entry script's* scope, which means:

- Functions in any file can call functions from any other file - load order
  does not matter, because nothing is invoked until after the loader finishes.
- Shared data defined at the top level of a file (the tables in
  `PortTables.ps1`) lands in the script scope, exactly where the single-file
  version kept it.
- `$script:` state (`$script:LastResults`, `$script:VbrConnected`, ...) keeps
  working unchanged.

## Adding a new function

1. Drop a new `.ps1` file into `functions\` (or add to an existing area file).
2. Define plain `function Verb-Noun { ... }` functions. No registration,
   no manifest, no dot-source line to add - the loader picks it up.
3. Wire it in where it should be reachable: a new menu entry in
   `functions\Menu.ps1`, and/or a new parameter + dispatch block in
   `portest3.ps1` for non-interactive use.

Keep top-level executable code out of function files: anything outside a
`function` block runs at load time, before the mode dispatch. Data
definitions (like the port tables) are the only intended exception.

## Blueprints and config drift (veeam-blueprint.ps1)

Capture a VBR server's full OS + component footprint as a JSON document,
then diff captures across updates:

- **What a blueprint holds**: Veeam packages/products and versions; every
  Veeam/database service (state, start type, account, binary hash); every
  TCP/UDP listener split external vs loopback with its owner; the **trunk
  map** - which frontend process multiplexes which loopback backend services
  (how v13 aggregates ports behind 443/6160), derived from live
  loopback-to-loopback connections joined to the listener table; observed
  data-plane connections to managed servers (in/out); PostgreSQL or MSSQL
  version, key settings, database list and sizes; config file hashes (never
  contents); certificates; firewall rules; and host metrics.
- **Identity vs metrics**: identity sections are diffed for drift; metrics
  (sizes, counts, uptime) are reported as deltas, never as drift - that
  split is what keeps the reports readable.
- **Baseline workflow**: the first capture of a host becomes its baseline
  automatically. Every later capture is compared against it and drift is
  reported as Critical / Warning / Info. After a reviewed upgrade, run
  `-Promote <capture.json>` to make the new state the reference. Promotion
  is always explicit - never automatic.
- **Capture tiers**: the document records whether it was captured elevated
  and with DB access. The drift engine refuses to diff sections across
  different tiers instead of reporting false drift.
- **VBR API topology**: add `-VbrServer` to a capture to record the declared
  topology (managed servers, proxies, repositories) alongside the observed
  connection map.

```powershell
.\veeam-blueprint.ps1 -LocalCapture                          # Windows VBR server
.\veeam-blueprint.ps1 -ComputerName vbr01                    # over PS remoting
.\veeam-blueprint.ps1 -SshServer vsa01 -SshUser admin -UseSudo   # VSA over SSH
.\veeam-blueprint.ps1 -Promote .\blueprints\vbr01\<stamp>_blueprint.json
```

Exit codes: 0 clean, 1 drift (Warning/Critical), 2 capture/compare failed -
safe to schedule after every patch window.

### Reports without dependencies (functions\HtmlReport.ps1)

The primary report path is **plain PowerShell producing a single
self-contained HTML file** - charts as inline SVG, inline CSS, zero
JavaScript, zero installs. It runs anywhere the capture already runs (no
Python, no Excel, no PSGallery module, no unsigned executable - the output
is a document, so there is nothing new for AppLocker or code-signing policy
to evaluate). Sections mirror the blueprint with **impact annotations**:
what each port is documented to carry, what each PostgreSQL / MSSQL setting
does to VBR behaviour, each service's role, which listeners deserve
attention (red/amber rows), cert days-to-expiry, and a color-coded drift
section when a comparison ran.

```powershell
.\veeam-blueprint.ps1 -LocalCapture -HtmlReport            # capture -> JSON + HTML (+ drift if a baseline exists)
.\veeam-blueprint.ps1 -RenderJson .\blueprints\vbr01\baseline.json          # re-render any stored blueprint
.\veeam-blueprint.ps1 -RenderJson bp.json -IncludeDriftCsv drift.csv        # embed an exported drift CSV
.\veeam-blueprint.ps1 -CompareReference base.json -CompareWith new.json -HtmlReport
.\veeam-blueprint.ps1 -RenderJson bp.json -CsvDir C:\temp\vbr01             # + one CSV per section, for Excel
```

`-ReportOut <path>` picks the output file (default: next to the JSON);
`-CsvDir` drops each section as CSV so Excel users can pivot without any
tooling. Menu option [8] does the same interactively.

### Optional Excel workbook (veeam-blueprint-report.py)

For workstations that do have Python (`pip install openpyxl`), the same
report is available as a charted .xlsx:

```
python veeam-blueprint-report.py blueprint.json                 # -> blueprint_report.xlsx
python veeam-blueprint-report.py blueprint.json --drift d.csv   # + color-coded Drift sheet
```

Both report engines share the same annotation data, which mirrors
`functions\PortTables.ps1`.

Blueprints land in `blueprints\<host>\` next to the script. They contain
hostnames, ports, service accounts and config *hashes* (never file contents
or credentials); decide deliberately whether to commit them to git - a
committed history doubles as a drift audit trail.

## Why the .sh collectors stay single files

`veeam-portcheck.sh` and `veeam-blueprint.sh` are self-contained **by
design**, not by accident:

- On a locked-down v13 Veeam Software Appliance the only supported path may
  be pasting them into a physical/virtual console - a multi-file layout
  cannot be pasted.
- The PowerShell entry points stream them to `bash -s` over SSH stdin
  (Stream mode), and base64-embed them for Posh-SSH. Both transports carry
  exactly one file.

If you extend the Linux checks, edit the .sh files in place and keep them
dependency-free (bash + coreutils + iproute2; anything else must be probed
and optional).

## PowerShell runtimes

Everything runs under **Windows PowerShell 5.1 and PowerShell 7** - written
to the 5.1 subset, verified under 7.4. Three version facts to know:

- **v13 backup servers standardise on PowerShell 7** - run the tools with
  `pwsh` there. Anything that talks to the VBR API (`-VbrServer`) *requires*
  PS 7.6.3+ on v13, because the Veeam module does; the tools detect a 5.1
  session and print the `pwsh -File ...` relaunch hint.
- **Remote captures always run under Windows PowerShell on the target**:
  `Invoke-Command`'s default WinRM endpoint is Windows PowerShell on every
  Windows host, v13 included. The collector scriptblocks are deliberately
  kept 5.1-compatible for exactly that reason - do not add PS7-only syntax
  to them.
- The MSSQL inventory tries `System.Data.SqlClient` (present in 5.1 and
  bundled with pwsh 7) and falls back to `Microsoft.Data.SqlClient` if a
  future PowerShell drops the deprecated driver.

## Deploying

The two entry scripts, the `functions\` folder, and the two `.sh` collectors
must travel together, in the same directory layout. The entry scripts refuse
to run (exit 2) if the `functions\` folder is missing, and the SSH/VSA
workflows expect the `.sh` files next to the `.ps1` files.

Usage, parameters, and examples - see the comment-based help:

```powershell
Get-Help .\portest3.ps1 -Full
Get-Help .\veeam-blueprint.ps1 -Full
```
