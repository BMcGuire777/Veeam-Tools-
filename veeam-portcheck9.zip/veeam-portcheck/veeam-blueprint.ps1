<#
.SYNOPSIS
    Veeam configuration blueprint - capture a VBR server's OS + component
    footprint as a JSON document and detect config drift between captures.

.DESCRIPTION
    Captures, from a Windows backup server (locally or over PowerShell
    remoting) or a Linux / Veeam Software Appliance (over SSH, or by running
    veeam-blueprint.sh in the console):

      - installed Veeam products / packages and their versions
      - every Veeam/database service: state, start type, account, binary hash
      - every TCP/UDP listener, split external vs loopback, with owner
      - the internal port trunk map: which frontend process multiplexes which
        loopback backend services (how v13 aggregates ports behind 443/6160)
      - observed data-plane connections to managed servers (in/out)
      - the configuration database (PostgreSQL or MSSQL): version, key
        settings, database list and sizes, connection count
      - config file hashes (never contents), certificates, firewall rules
      - host metrics (uptime, memory, disk) - reported, never diffed

    Optionally enriches the capture with the topology the VBR API declares
    (managed servers, proxies, repositories) via -VbrServer.

    Blueprints are stored under blueprints\<host>\ next to this script. The
    first capture of a host automatically becomes its baseline. Every later
    capture is diffed against the baseline and drift is reported as
    Critical / Warning / Info. After a reviewed upgrade, promote the new
    capture with -Promote so it becomes the reference - promotion is always
    an explicit, human decision.

.NOTES
    Same folder layout rules as portest3.ps1: this script, the functions\
    folder and veeam-blueprint.sh must travel together.

    RUNTIMES: everything here runs under Windows PowerShell 5.1 AND
    PowerShell 7 - v13 backup servers standardise on PS7, so run it with
    pwsh there (required anyway if you use -VbrServer: the v13 Veeam module
    needs PS 7.6.3+). Remote captures still execute under Windows PowerShell
    on the target, because that is Invoke-Command's default WinRM endpoint
    on every Windows host - the collector is deliberately 5.1-compatible for
    exactly that reason. The Linux side needs only bash, coreutils and
    iproute2 on the appliance.

    Capture tiers: run elevated (Windows) / as root or -UseSudo (Linux) and
    with database access, or the blueprint records a degraded tier. The drift
    engine refuses to diff sections across different tiers rather than
    reporting false drift.

    REPORTS: -HtmlReport (or -ReportOut <path>) writes a self-contained HTML
    report - charts as inline SVG, no JavaScript, no Python, no Excel, no
    modules; it is a document, not an app, so there is nothing new to sign.
    -CsvDir <dir> additionally drops each section as a CSV for Excel.
    -RenderJson re-renders any stored blueprint without capturing.

    Examples:
      .\veeam-blueprint.ps1                                     # menu
      .\veeam-blueprint.ps1 -LocalCapture
      .\veeam-blueprint.ps1 -LocalCapture -HtmlReport           # capture + HTML report
      .\veeam-blueprint.ps1 -ComputerName vbr01 -HtmlReport -CsvDir C:\temp\vbr01
      .\veeam-blueprint.ps1 -SshServer vsa01 -SshUser admin -UseSudo
      .\veeam-blueprint.ps1 -LocalCapture -VbrServer vbr01 -ForceAcceptCert
      .\veeam-blueprint.ps1 -CompareReference .\blueprints\vbr01\baseline.json `
                            -CompareWith .\blueprints\vbr01\20260901_083000_blueprint.json -HtmlReport
      .\veeam-blueprint.ps1 -RenderJson .\blueprints\vbr01\baseline.json
      .\veeam-blueprint.ps1 -RenderJson .\blueprints\vbr01\latest.json -IncludeDriftCsv .\drift.csv
      .\veeam-blueprint.ps1 -Promote .\blueprints\vbr01\20260901_083000_blueprint.json
      .\veeam-blueprint.ps1 -EmitLinuxScript C:\temp             # console workflow

    Exit codes: 0 = captured / no drift beyond Info, 1 = Warning or Critical
    drift found, 2 = the capture or comparison could not be completed.
#>

[CmdletBinding()]
param(
    # --- Capture this machine (Windows) --------------------------------------
    [switch]$LocalCapture,

    # --- Capture a Windows host over PowerShell remoting ---------------------
    [string]$ComputerName,
    [System.Management.Automation.PSCredential]$Credential,

    # --- Capture a Linux / VSA host over SSH ---------------------------------
    [string]$SshServer,
    [string]$SshUser,
    [int]$SshPort = 22,
    [System.Management.Automation.PSCredential]$SshCredential,
    [string]$SshKeyFile,
    [ValidateSet('Stream','UploadDelete','UploadKeep')][string]$SshMode = 'Stream',
    [ValidatePattern('^/[A-Za-z0-9._/-]+$')]
    [string]$SshRemotePath = '/tmp/veeam-blueprint.sh',
    [switch]$UseSudo,

    # --- Optional VBR API topology enrichment ---------------------------------
    [string]$VbrServer,
    [int]$VbrPort = 443,
    [System.Management.Automation.PSCredential]$VbrCredential,
    [switch]$ForceAcceptCert,

    # --- Store / compare / promote --------------------------------------------
    [string]$OutDir,
    [string]$Baseline,
    [switch]$NoCompare,
    [string]$CompareReference,
    [string]$CompareWith,
    [string]$Promote,
    [string]$DriftCsv,
    [string]$EmitLinuxScript,

    # --- Reports (dependency-free: plain PowerShell -> self-contained HTML) ---
    [switch]$HtmlReport,            # write an HTML report after a capture/compare
    [string]$ReportOut,             # where to write it (default: next to the JSON)
    [string]$RenderJson,            # standalone: render an existing blueprint JSON
    [string]$IncludeDriftCsv,       # standalone: embed this drift CSV in the render
    [string]$CsvDir                 # also export each section as CSV (for Excel)
)

$ErrorActionPreference = 'Continue'

$script:ScriptDir        = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$script:LinuxScriptName  = 'veeam-portcheck.sh'
$script:LastResults      = @()
$script:LastResultHost   = ''
$script:AllResults       = @()
$script:VbrConnected     = $false
$script:VbrServerName    = ''
$script:VbrPlatform      = 'Unknown'
$script:VbrCred          = $null

if (-not $OutDir) { $OutDir = Join-Path $script:ScriptDir 'blueprints' }

# =============================================================================
#  FUNCTION LOADER - same folder, same mechanism as portest3.ps1.
# =============================================================================
$script:FunctionsDir = Join-Path $script:ScriptDir 'functions'
if (-not (Test-Path $script:FunctionsDir -PathType Container)) {
    Write-Host ''
    Write-Host ('  ERROR: functions folder not found at {0}' -f $script:FunctionsDir) -ForegroundColor Red
    Write-Host '  veeam-blueprint.ps1 is modular - copy the functions folder along with it.' -ForegroundColor Red
    exit 2
}
foreach ($functionFile in @(Get-ChildItem -Path $script:FunctionsDir -Filter '*.ps1' -File | Sort-Object Name)) {
    try {
        . $functionFile.FullName
    } catch {
        Write-Host ('  ERROR: failed to load {0}: {1}' -f $functionFile.Name, $_.Exception.Message) -ForegroundColor Red
        exit 2
    }
}

# =============================================================================
#  SHARED PIPELINE STEPS
# =============================================================================

function Copy-BlueprintScript($destination) {
    $src = Get-BlueprintScriptPath
    if (-not $src) {
        Write-Host ('  {0} not found next to this script.' -f $script:BlueprintScriptName) -ForegroundColor Red
        return $null
    }
    try {
        $dest = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($destination)
        if ((Test-Path $dest -PathType Container) -or ($dest -match '[\\/]$') -or
            ([string]::IsNullOrEmpty([IO.Path]::GetExtension($dest)))) {
            if (-not (Test-Path $dest -PathType Container)) {
                New-Item -ItemType Directory -Path $dest -Force -ErrorAction Stop | Out-Null
            }
            $dest = Join-Path $dest $script:BlueprintScriptName
        }
        $text = [IO.File]::ReadAllText($src) -replace "`r`n", "`n"
        [IO.File]::WriteAllText($dest, $text, (New-Object Text.UTF8Encoding($false)))
        Write-Host ('  Wrote {0}' -f $dest) -ForegroundColor Green
        Write-Host '  On the appliance: bash veeam-blueprint.sh            (readable summary)' -ForegroundColor DarkCyan
        Write-Host '                    bash veeam-blueprint.sh --report   (for this tool)' -ForegroundColor DarkCyan
        return $dest
    } catch {
        Write-Host ('  Copy failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}

# Normalise -> enrich -> summarise -> save -> drift-check. Returns the exit
# code (0 clean / 1 drift / 2 failure) so both the parameter dispatch and the
# menu can share it - the menu just doesn't exit on it.
function Complete-BlueprintRun {
    param($Payload)

    if (-not $Payload) { return 2 }
    $doc = New-BlueprintDocument -Payload $Payload

    if ($VbrServer) {
        if (Connect-Vbr -Server $VbrServer -Port $VbrPort -Credential $VbrCredential -AcceptCert:$ForceAcceptCert) {
            $doc = Add-VbrTopologyToBlueprint -Document $doc
            Disconnect-Vbr
        } else {
            Write-Host '  Continuing without VBR API topology.' -ForegroundColor Yellow
        }
    }

    Show-BlueprintSummary -Document $doc

    $refPath = $Baseline
    if (-not $refPath) { $refPath = Get-BlueprintBaselinePath -OutDir $OutDir -HostName $doc.host }
    $hadBaseline = [bool]$refPath

    $file = Save-Blueprint -Document $doc -OutDir $OutDir
    if (-not $file) { return 2 }

    $result = $null
    $rc = 0
    if ($NoCompare) {
        # capture only
    } elseif (-not $hadBaseline) {
        Write-Host ''
        Write-Host '  First capture for this host - nothing to compare yet. The next run' -ForegroundColor Cyan
        Write-Host '  will diff against this baseline automatically.' -ForegroundColor Cyan
    } else {
        $result = Compare-VeeamBlueprint -ReferencePath $refPath -CurrentPath $file
        if (-not $result) {
            $rc = 2
        } else {
            $counts = Show-DriftReport -Result $result
            if ($DriftCsv) { Export-DriftReport -Result $result -Path $DriftCsv }
            if ($counts.Critical -gt 0 -or $counts.Warning -gt 0) {
                Write-Host ''
                Write-Host ('  To accept this state as the new reference:') -ForegroundColor DarkCyan
                Write-Host ('    .\veeam-blueprint.ps1 -Promote "{0}"' -f $file) -ForegroundColor DarkCyan
                $rc = 1
            }
        }
    }

    if ($HtmlReport -or $ReportOut) {
        $rows = $null
        if ($result) { $rows = @($result.Rows) }
        Export-BlueprintHtml -JsonPath $file -OutPath $ReportOut -DriftRows $rows | Out-Null
    }
    if ($CsvDir) { Export-BlueprintCsv -JsonPath $file -OutDir $CsvDir | Out-Null }
    return $rc
}

# =============================================================================
#  NON-INTERACTIVE ENTRY POINTS
# =============================================================================

if ($RenderJson) {
    $rows = $null
    if ($IncludeDriftCsv) {
        if (-not (Test-Path $IncludeDriftCsv)) {
            Write-Host ('  Drift CSV not found: {0}' -f $IncludeDriftCsv) -ForegroundColor Red
            exit 2
        }
        $rows = @(Import-Csv $IncludeDriftCsv)
    }
    $ok = [bool](Export-BlueprintHtml -JsonPath $RenderJson -OutPath $ReportOut -DriftRows $rows)
    if ($CsvDir) {
        if (-not (Export-BlueprintCsv -JsonPath $RenderJson -OutDir $CsvDir)) { $ok = $false }
    }
    if ($ok) { exit 0 }
    exit 2
}

if ($CompareReference -or $CompareWith) {
    if (-not ($CompareReference -and $CompareWith)) {
        Write-Host '  Offline compare needs both -CompareReference and -CompareWith.' -ForegroundColor Red
        exit 2
    }
    $result = Compare-VeeamBlueprint -ReferencePath $CompareReference -CurrentPath $CompareWith
    if (-not $result) { exit 2 }
    $counts = Show-DriftReport -Result $result
    if ($DriftCsv) { Export-DriftReport -Result $result -Path $DriftCsv }
    if ($HtmlReport -or $ReportOut) {
        Export-BlueprintHtml -JsonPath $CompareWith -OutPath $ReportOut -DriftRows @($result.Rows) | Out-Null
    }
    if ($counts.Critical -gt 0 -or $counts.Warning -gt 0) { exit 1 }
    exit 0
}

if ($Promote) {
    if (Set-BlueprintBaseline -Path $Promote) { exit 0 }
    exit 2
}

if ($EmitLinuxScript -and -not ($LocalCapture -or $ComputerName -or $SshServer)) {
    if (Copy-BlueprintScript $EmitLinuxScript) { exit 0 }
    exit 2
}

if ($LocalCapture) {
    Write-Banner 'Veeam Configuration Blueprint' $env:COMPUTERNAME
    exit (Complete-BlueprintRun -Payload (Invoke-LocalBlueprintCapture))
}

if ($ComputerName) {
    Write-Banner 'Veeam Configuration Blueprint (remoting)' $ComputerName
    exit (Complete-BlueprintRun -Payload (Invoke-RemoteBlueprintCapture -Computer $ComputerName -Credential $Credential))
}

if ($SshServer) {
    Write-Banner 'Veeam Configuration Blueprint (Linux over SSH)' $SshServer
    $payload = Invoke-LinuxBlueprintCapture -Server $SshServer -User $SshUser -Port $SshPort `
                   -Credential $SshCredential -KeyFile $SshKeyFile -Mode $SshMode `
                   -RemotePath $SshRemotePath -UseSudo:$UseSudo `
                   -NonInteractive:($null -ne $SshCredential -or [bool]$SshKeyFile)
    exit (Complete-BlueprintRun -Payload $payload)
}

# =============================================================================
#  INTERACTIVE MENU
# =============================================================================

$quit = $false
while (-not $quit) {
    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host '  Veeam Configuration Blueprint' -ForegroundColor Cyan
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ('  Blueprint store: {0}' -f $OutDir) -ForegroundColor White
    Write-Host ''
    Write-Host '  CAPTURE' -ForegroundColor Magenta
    Write-Host '  [1] This machine (Windows backup server)' -ForegroundColor Green
    Write-Host '  [2] A Windows host over PowerShell remoting' -ForegroundColor Green
    Write-Host '  [3] A Linux / VSA host over SSH' -ForegroundColor Green
    Write-Host '  [4] Write veeam-blueprint.sh somewhere I can copy from (console workflow)' -ForegroundColor Green
    Write-Host '  -----------------------------------------------'
    Write-Host '  DRIFT' -ForegroundColor Magenta
    Write-Host '  [5] List stored blueprints' -ForegroundColor Green
    Write-Host '  [6] Compare two blueprint files' -ForegroundColor Green
    Write-Host '  [7] Promote a blueprint to baseline' -ForegroundColor Yellow
    Write-Host '  [8] Render a blueprint to an HTML report (no dependencies)' -ForegroundColor Green
    Write-Host '  -----------------------------------------------'
    Write-Host '  [Q] Quit' -ForegroundColor Red
    Write-Host ''

    $choice = (Read-Host '  Select').Trim().ToUpper()
    switch ($choice) {

        '1' {
            Write-Banner 'Veeam Configuration Blueprint' $env:COMPUTERNAME
            Complete-BlueprintRun -Payload (Invoke-LocalBlueprintCapture) | Out-Null
            Write-Footer
        }

        '2' {
            $cn = (Read-Host '  Windows host to capture').Trim()
            if (-not $cn) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $ans = (Read-Host '  Use current Windows credentials? [Y/n]').Trim().ToUpper()
            $cred = $null
            if ($ans -eq 'N') { $cred = Get-Credential -Message "Admin on $cn" }
            Write-Banner 'Veeam Configuration Blueprint (remoting)' $cn
            Complete-BlueprintRun -Payload (Invoke-RemoteBlueprintCapture -Computer $cn -Credential $cred) | Out-Null
            Write-Footer
        }

        '3' {
            $srv = (Read-Host '  Appliance / Linux host').Trim()
            if (-not $srv) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $pRaw = (Read-Host '  SSH port [Enter=22]').Trim()
            $sPort = if ($pRaw -match '^\d+$') { [int]$pRaw } else { 22 }
            $sudoAns = (Read-Host '  Run it through sudo? Needed unless you log in as root [y/N]').Trim().ToUpper()
            Write-Banner 'Veeam Configuration Blueprint (Linux over SSH)' $srv
            $payload = Invoke-LinuxBlueprintCapture -Server $srv -Port $sPort -UseSudo:($sudoAns -eq 'Y')
            Complete-BlueprintRun -Payload $payload | Out-Null
            Write-Footer
        }

        '4' {
            $default = Join-Path ([Environment]::GetFolderPath('Desktop')) $script:BlueprintScriptName
            $p = (Read-Host "  Destination [Enter=$default]").Trim()
            if (-not $p) { $p = $default }
            Copy-BlueprintScript $p | Out-Null
        }

        '5' { Write-Host ''; Show-BlueprintStore -OutDir $OutDir; Write-Footer }

        '6' {
            $r = Select-BlueprintFile -OutDir $OutDir -Prompt 'REFERENCE blueprint (usually the baseline):'
            if (-not $r) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $c = Select-BlueprintFile -OutDir $OutDir -Prompt 'CURRENT blueprint to compare against it:'
            if (-not $c) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $result = Compare-VeeamBlueprint -ReferencePath $r -CurrentPath $c
            if ($result) {
                Show-DriftReport -Result $result | Out-Null
                $csv = (Read-Host '  Export drift rows to CSV path [Enter = skip]').Trim()
                if ($csv) { Export-DriftReport -Result $result -Path $csv }
                $h = (Read-Host '  Also write an HTML report with this drift embedded? [y/N]').Trim().ToUpper()
                if ($h -eq 'Y') {
                    Export-BlueprintHtml -JsonPath $c -DriftRows @($result.Rows) | Out-Null
                }
            }
            Write-Footer
        }

        '7' {
            # baseline.json is excluded - promoting the baseline to itself is a no-op
            $p = Select-BlueprintFile -OutDir $OutDir -Prompt 'Blueprint to PROMOTE to baseline:' -ExcludeBaseline
            if ($p) { Set-BlueprintBaseline -Path $p | Out-Null }
        }

        '8' {
            $j = Select-BlueprintFile -OutDir $OutDir -Prompt 'Blueprint to render as an HTML report:'
            if (-not $j) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $dc = (Read-Host '  Drift CSV to embed [Enter = none]').Trim()
            $rows = $null
            if ($dc) {
                if (Test-Path $dc) { $rows = @(Import-Csv $dc) }
                else { Write-Host '  Drift CSV not found - rendering without it.' -ForegroundColor Yellow }
            }
            $o = (Read-Host '  Output path [Enter = next to the JSON]').Trim()
            $written = Export-BlueprintHtml -JsonPath $j -OutPath $o -DriftRows $rows
            if ($written) {
                Write-Host '  Open it in any browser; print to PDF for change records.' -ForegroundColor DarkCyan
            }
            $cv = (Read-Host '  Also export section CSVs to a folder? [Enter = skip]').Trim()
            if ($cv) { Export-BlueprintCsv -JsonPath $j -OutDir $cv | Out-Null }
        }

        'Q' { $quit = $true }

        default { Write-Host '  Invalid choice.' -ForegroundColor Red }
    }
}

Write-Host ''
Write-Host '  Goodbye.' -ForegroundColor DarkCyan
Write-Host ''
