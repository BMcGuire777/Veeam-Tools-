#!/usr/bin/env bash
# =============================================================================
#  veeam-portcheck.sh
#  Veeam port conflict check for a Linux-based Veeam backup server
#  (including the v13 Veeam Software Appliance).
#
#  WHY THIS EXISTS
#    On the v13 Veeam Software Appliance you cannot get a shell over SSH by
#    default, and the TUI root shell is reachable only from a physical or
#    virtual console. So there is no supported remote-exec path. This script
#    is self-contained with no dependencies beyond coreutils + iproute2 so it
#    can be pasted into that console and run.
#
#  WHAT IT DOES
#    Lists every TCP/UDP listener, resolves the owning PID to an executable
#    and a systemd unit, and flags any Veeam-required port that is held by a
#    process which is not Veeam, the OS, or the config database.
#
#  USAGE
#    bash veeam-portcheck.sh              # human-readable report
#    bash veeam-portcheck.sh --csv        # CSV to stdout
#    bash veeam-portcheck.sh --report     # pipe-delimited, for portest3.ps1
#    bash veeam-portcheck.sh --all        # also dump every listener
#    bash veeam-portcheck.sh --no-color
#
#  Exit code: 0 = clean, 1 = conflicts found, 2 = bad usage.
#
#  Run as root. Without root, ss cannot show process owners and everything
#  reads UNKNOWN.
#
#  PORT DATA: the veeam_ports table below is the source of truth. Only 6160
#  (veeamdeployment) and 6162 (veeamtransport) are confirmed by name in Veeam
#  KB4519; the rest come from the v13 Ports tables. Verify against the docs
#  for your build and edit the table, not the logic.
#
#  NOTE: vPower NFS (TCP/UDP 111, 1058, 2049) is a Windows service. Those
#  ports are deliberately NOT checked here. Use portest3.ps1 for Windows
#  backup servers and Windows mount servers.
# =============================================================================

set -uo pipefail

CSV=0
REPORT=0
SHOW_ALL=0
USE_COLOR=1

for arg in "$@"; do
  case "$arg" in
    --csv)      CSV=1 ;;
    --report)   REPORT=1; USE_COLOR=0 ;;
    --all)      SHOW_ALL=1 ;;
    --no-color) USE_COLOR=0 ;;
    -h|--help)  sed -n '2,44p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *)          echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

[ -t 1 ] || USE_COLOR=0

if [ "$USE_COLOR" -eq 1 ]; then
  C_RED=$'\033[31m'; C_GRN=$'\033[32m'; C_YEL=$'\033[33m'
  C_CYN=$'\033[36m'; C_DIM=$'\033[2m';  C_RST=$'\033[0m'
else
  C_RED=''; C_GRN=''; C_YEL=''; C_CYN=''; C_DIM=''; C_RST=''
fi

# -----------------------------------------------------------------------------
#  PORT TABLE
#  port|proto|expected_owner|component|notes
#  expected_owner: veeam | os | db
# -----------------------------------------------------------------------------
veeam_ports='
443|tcp|veeam|Backup server initial connection + Identity Service; also Guest Catalog replication|v13 default. Commonly taken by nginx/httpd/podman-published containers.
6160|tcp|veeam|Veeam Deployer Service (veeamdeployment)|Confirmed service name, KB4519. Changeable via /opt/veeam/deployment/veeamdeploymentsvc --set-port
6162|tcp|veeam|Veeam Transport Service / Data Mover (veeamtransport)|Confirmed service name, KB4519.
6172|tcp|veeam|Backup server database communication (used by Veeam Plug-in for Kasten)|
9419|tcp|veeam|Veeam RESTful API Service (HTTPS)|Only if the REST API is enabled.
10006|tcp|veeam|Backup server connection port|
10443|tcp|veeam|Veeam Host Management|VSA management endpoint.
5432|tcp|db|PostgreSQL - VBR configuration database|A second PostgreSQL instance will collide.
22|tcp|os|SSH (sshd)|Informational. On a VSA this is off by default and must be enabled in Host Management.
'

# Data transfer range
RANGE_LO=2500
RANGE_HI=3300

# Known non-Veeam users of ports inside 2500-3300
range_squatters='
2598|Citrix ICA session reliability
2869|UPnP / SSDP event notification
3050|Firebird / InterBase
3260|iSCSI target
3268|LDAP Global Catalog
3269|LDAPS Global Catalog
3306|MySQL / MariaDB
'

# -----------------------------------------------------------------------------
#  PRE-FLIGHT
# -----------------------------------------------------------------------------
if ! command -v ss >/dev/null 2>&1; then
  echo "ERROR: 'ss' not found (package iproute2). Cannot enumerate listeners." >&2
  exit 1
fi

AM_ROOT=1
[ "$(id -u)" -eq 0 ] || AM_ROOT=0

HAVE_SYSTEMCTL=0
command -v systemctl >/dev/null 2>&1 && HAVE_SYSTEMCTL=1

# -----------------------------------------------------------------------------
#  COLLECT LISTENERS
#  Emits: proto<TAB>port<TAB>pid<TAB>procname
#  ss -H -lntupn sample:
#    tcp LISTEN 0 4096 0.0.0.0:6162 0.0.0.0:* users:(("veeamtransport",pid=1234,fd=7))
# -----------------------------------------------------------------------------
collect_listeners() {
  ss -H -lntupn 2>/dev/null | awk '
    {
      proto = $1
      # find the Local Address:Port field: 5th field for tcp/udp in -H output
      local_addr = $5
      # strip IPv6 brackets and take the text after the final colon
      n = split(local_addr, a, ":")
      port = a[n]
      if (port !~ /^[0-9]+$/) next

      # users:(("name",pid=N,fd=M),("name2",pid=K,fd=J))
      users = ""
      for (i = 6; i <= NF; i++) users = users $i
      if (users ~ /users:/) {
        tmp = users
        while (match(tmp, /\("[^"]+",pid=[0-9]+/)) {
          seg = substr(tmp, RSTART, RLENGTH)
          split(seg, b, "\"")
          nm = b[2]
          split(seg, c, "pid=")
          pid = c[2]
          print proto "\t" port "\t" pid "\t" nm
          tmp = substr(tmp, RSTART + RLENGTH)
        }
      } else {
        print proto "\t" port "\t" "0" "\t" "-"
      }
    }' | sort -u
}

# -----------------------------------------------------------------------------
#  OWNER RESOLUTION
# -----------------------------------------------------------------------------

# RESULTS is a pipe-delimited accumulator, so any '|' inside a field would
# corrupt the record when it is read back. Strip it at the point of insertion
# rather than at output time - a process path really can contain one.
san() { printf '%s' "${1:-}" | tr '|' '/' | tr -d '\r\n'; }
unit_for_pid() {
  local pid="$1" unit=""
  [ "$pid" = "0" ] && { echo ""; return; }
  if [ -r "/proc/$pid/cgroup" ]; then
    unit=$(grep -oE '[a-zA-Z0-9@_.\-]+\.service' "/proc/$pid/cgroup" 2>/dev/null | tail -n1)
  fi
  if [ -z "$unit" ] && [ "$HAVE_SYSTEMCTL" -eq 1 ]; then
    unit=$(systemctl status "$pid" 2>/dev/null | head -n1 | grep -oE '[a-zA-Z0-9@_.\-]+\.service' | head -n1)
  fi
  echo "$unit"
}

exe_for_pid() {
  local pid="$1"
  [ "$pid" = "0" ] && { echo ""; return; }
  readlink -f "/proc/$pid/exe" 2>/dev/null || echo ""
}

# classify <pid> <procname> -> veeam | os | db | thirdparty | unknown
classify() {
  local pid="$1" name="$2"
  if [ "$pid" = "0" ] || [ ! -d "/proc/$pid" ]; then
    echo "unknown"; return
  fi
  local exe unit hay
  exe=$(exe_for_pid "$pid")
  unit=$(unit_for_pid "$pid")
  hay="$name $exe $unit"

  case "$hay" in
    *[Vv]eeam*) echo "veeam"; return ;;
  esac
  case "$name" in
    postgres|postmaster|mysqld|mariadbd) echo "db"; return ;;
    systemd|systemd-*|sshd|rpcbind|chronyd|dbus-daemon|firewalld|NetworkManager|rsyslogd|auditd)
      echo "os"; return ;;
  esac
  case "$exe" in
    /usr/lib/systemd/*|/lib/systemd/*) echo "os"; return ;;
  esac
  echo "thirdparty"
}

describe_owner() {
  local pid="$1" name="$2" unit exe out
  if [ "$pid" = "0" ] || [ ! -d "/proc/$pid" ]; then
    echo "unresolved (run as root)"; return
  fi
  unit=$(unit_for_pid "$pid")
  exe=$(exe_for_pid "$pid")
  out="$name (pid $pid)"
  [ -n "$unit" ] && out="$out unit:$unit"
  [ -n "$exe" ]  && out="$out [$exe]"
  san "$out"
}

squatter_note() {
  local port="$1"
  echo "$range_squatters" | awk -F'|' -v p="$port" 'NF==2 && $1==p {print $2}'
}

# -----------------------------------------------------------------------------
#  RUN
# -----------------------------------------------------------------------------
LISTENERS=$(collect_listeners)
TCP_COUNT=$(echo "$LISTENERS" | awk -F'\t' '$1=="tcp"' | wc -l)
UDP_COUNT=$(echo "$LISTENERS" | awk -F'\t' '$1=="udp"' | wc -l)

RESULTS=""   # status|port|proto|owner_type|owner|component|notes
add_result() {
  RESULTS="${RESULTS}$(san "${1:-}")|$(san "${2:-}")|$(san "${3:-}")|$(san "${4:-}")|$(san "${5:-}")|$(san "${6:-}")|$(san "${7:-}")
"
}

while IFS='|' read -r p_port p_proto p_expect p_comp p_notes; do
  [ -z "${p_port:-}" ] && continue
  case "$p_port" in ''|*[!0-9]*) continue ;; esac

  matches=$(echo "$LISTENERS" | awk -F'\t' -v pr="$p_proto" -v po="$p_port" '$1==pr && $2==po')

  if [ -z "$matches" ]; then
    add_result "FREE" "$p_port" "$p_proto" "" "" "$p_comp" "$p_notes"
    continue
  fi

  while IFS=$'\t' read -r l_proto l_port l_pid l_name; do
    [ -z "${l_pid:-}" ] && continue
    cls=$(classify "$l_pid" "$l_name")
    own=$(describe_owner "$l_pid" "$l_name")
    if [ "$cls" = "unknown" ]; then
      st="UNKNOWN"
    elif [ "$cls" = "$p_expect" ]; then
      st="OK"
    else
      st="CONFLICT"
    fi
    add_result "$st" "$p_port" "$p_proto" "$cls" "$own" "$p_comp" "$p_notes"
  done <<< "$matches"
done <<< "$veeam_ports"

# -- data transfer range ------------------------------------------------------
RANGE_ROWS=""
while IFS=$'\t' read -r l_proto l_port l_pid l_name; do
  [ -z "${l_port:-}" ] && continue
  [ "$l_proto" = "tcp" ] || continue
  [ "$l_port" -ge "$RANGE_LO" ] 2>/dev/null || continue
  [ "$l_port" -le "$RANGE_HI" ] 2>/dev/null || continue
  cls=$(classify "$l_pid" "$l_name")
  [ "$cls" = "veeam" ] && continue
  own=$(describe_owner "$l_pid" "$l_name")
  note=$(squatter_note "$l_port")
  RANGE_ROWS="${RANGE_ROWS}${l_port}|${own}|${note}
"
  st="CONFLICT"; [ "$cls" = "unknown" ] && st="UNKNOWN"
  add_result "$st" "$l_port" "tcp" "$cls" "$own" "Data transfer range ${RANGE_LO}-${RANGE_HI}" "$note"
done <<< "$LISTENERS"

# -----------------------------------------------------------------------------
#  OUTPUT
# -----------------------------------------------------------------------------
CONFLICTS=$(echo "$RESULTS" | grep -c '^CONFLICT|' || true)
UNKNOWNS=$(echo "$RESULTS" | grep -c '^UNKNOWN|' || true)
RC=0
{ [ "$CONFLICTS" -gt 0 ] || [ "$UNKNOWNS" -gt 0 ]; } && RC=1

OS_NAME="unknown"
[ -r /etc/os-release ] && OS_NAME=$(. /etc/os-release; echo "${PRETTY_NAME:-unknown}")

if [ "$CSV" -eq 1 ]; then
  echo "Status,Port,Protocol,OwnerType,Owner,Component,Notes"
  echo "$RESULTS" | while IFS='|' read -r st po pr ot ow co no; do
    [ -z "${st:-}" ] && continue
    printf '%s,%s,%s,%s,"%s","%s","%s"\n' "$st" "$po" "$pr" "$ot" "$ow" "$co" "$no"
  done
  exit $RC
fi

# Machine-readable form consumed by portest3.ps1 so Linux results render
# through the same report and land in the same CSV as the Windows checks.
# Pipe-delimited; fields are sanitised of '|' before emission.
if [ "$REPORT" -eq 1 ]; then
  echo "#META|$(san "$(hostname)")|$(san "$OS_NAME")|${AM_ROOT}|${TCP_COUNT}|${UDP_COUNT}|1"
  if [ "$HAVE_SYSTEMCTL" -eq 1 ]; then
    systemctl list-units --all --type=service --no-legend --no-pager 'veeam*' 2>/dev/null |
      while read -r l; do
        [ -z "$l" ] && continue
        u=$(echo "$l" | awk '{print $1}')
        a=$(echo "$l" | awk '{print $3}')
        echo "#SVC|$(san "$u")|$(san "$a")"
      done
  fi
  echo "$RESULTS" | while IFS='|' read -r st po pr ot ow co no; do
    [ -z "${st:-}" ] && continue
    echo "#ROW|${st}|${po}|${pr}|${ot}|${ow}|${co}|${no}"
  done
  echo "#END|${CONFLICTS}|${UNKNOWNS}"
  exit $RC
fi

echo
echo "${C_CYN}=======================================================${C_RST}"
echo "${C_CYN}  Veeam Linux Port Conflict Check  ->  $(hostname)${C_RST}"
echo "${C_DIM}  $(date '+%Y-%m-%d %H:%M:%S')${C_RST}"
if [ -r /etc/os-release ]; then
  echo "${C_DIM}  $(. /etc/os-release; echo "${PRETTY_NAME:-unknown}")${C_RST}"
fi
echo "${C_CYN}=======================================================${C_RST}"

if [ "$AM_ROOT" -eq 0 ]; then
  echo "${C_YEL}  ! Not root. Process owners will read UNKNOWN. Re-run as root.${C_RST}"
fi
echo "${C_DIM}  ${TCP_COUNT} TCP listeners, ${UDP_COUNT} UDP endpoints.${C_RST}"

echo
echo "${C_YEL}-- Veeam Port Ownership -------------------------------${C_RST}"
printf '  %-6s %-5s %-9s %s\n' "PORT" "PROTO" "STATUS" "OWNER / COMPONENT"
printf '  %s\n' "------------------------------------------------------------------------"
echo "$RESULTS" | while IFS='|' read -r st po pr ot ow co no; do
  [ -z "${st:-}" ] && continue
  case "$co" in "Data transfer range"*) continue ;; esac
  case "$st" in
    CONFLICT) c="$C_RED" ;;
    UNKNOWN)  c="$C_YEL" ;;
    OK)       c="$C_GRN" ;;
    *)        c="$C_DIM" ;;
  esac
  right="$ow"; [ -z "$right" ] && right="$co"
  printf '  %s%-6s %-5s %-9s %s%s\n' "$c" "$po" "$pr" "$st" "$right" "$C_RST"
  if [ "$st" = "CONFLICT" ] || [ "$st" = "UNKNOWN" ]; then
    printf '  %s         -> needs: %s%s\n' "$C_DIM" "$co" "$C_RST"
  fi
done

echo
echo "${C_YEL}-- Data Transfer Range ${RANGE_LO}-${RANGE_HI} ------------------------${C_RST}"
if [ -z "$(echo "$RANGE_ROWS" | tr -d '[:space:]')" ]; then
  echo "  ${C_GRN}No non-Veeam process is listening in the range.${C_RST}"
else
  echo "$RANGE_ROWS" | while IFS='|' read -r po ow no; do
    [ -z "${po:-}" ] && continue
    line="    $po  $ow"
    [ -n "${no:-}" ] && line="$line  [$no]"
    echo "${C_RED}${line}${C_RST}"
  done
fi

echo
echo "${C_YEL}-- Veeam Services On This Host ------------------------${C_RST}"
if [ "$HAVE_SYSTEMCTL" -eq 1 ]; then
  found=$(systemctl list-units --all --type=service --no-legend --no-pager 'veeam*' 2>/dev/null)
  if [ -n "$found" ]; then
    echo "$found" | while read -r line; do
      unit=$(echo "$line" | awk '{print $1}')
      active=$(echo "$line" | awk '{print $3}')
      if [ "$active" = "active" ]; then
        echo "  ${C_GRN}$(printf '%-10s' "$active")${C_RST} $unit"
      else
        echo "  ${C_YEL}$(printf '%-10s' "$active")${C_RST} $unit"
      fi
    done
  else
    echo "  ${C_DIM}No veeam* systemd units found - treating as pre-install host.${C_RST}"
  fi
else
  echo "  ${C_DIM}systemctl unavailable.${C_RST}"
fi

if [ "$SHOW_ALL" -eq 1 ]; then
  echo
  echo "${C_YEL}-- All Listeners --------------------------------------${C_RST}"
  printf '  %-5s %-6s %-12s %s\n' "PROTO" "PORT" "CLASS" "OWNER"
  echo "$LISTENERS" | while IFS=$'\t' read -r l_proto l_port l_pid l_name; do
    [ -z "${l_port:-}" ] && continue
    cls=$(classify "$l_pid" "$l_name")
    printf '  %-5s %-6s %-12s %s\n' "$l_proto" "$l_port" "$cls" "$(describe_owner "$l_pid" "$l_name")"
  done
fi

echo
echo "${C_CYN}=======================================================${C_RST}"
if [ "$CONFLICTS" -eq 0 ] && [ "$UNKNOWNS" -eq 0 ]; then
  echo "  ${C_GRN}RESULT: No port conflicts detected.${C_RST}"
else
  if [ "$CONFLICTS" -gt 0 ]; then
    echo "  ${C_RED}RESULT: ${CONFLICTS} CONFLICT(S) - resolve before upgrading.${C_RST}"
    echo
    echo "$RESULTS" | while IFS='|' read -r st po pr ot ow co no; do
      [ "${st:-}" = "CONFLICT" ] || continue
      echo "  ${C_RED}* ${po}/${pr} held by ${ow}${C_RST}"
      echo "    ${C_DIM}Needed by: ${co}${C_RST}"
      [ -n "${no:-}" ] && echo "    ${C_DIM}${no}${C_RST}"
    done
  fi
  if [ "$UNKNOWNS" -gt 0 ]; then
    echo "  ${C_YEL}${UNKNOWNS} port(s) have an unresolvable owner - re-run as root.${C_RST}"
  fi
fi
echo "${C_CYN}=======================================================${C_RST}"
echo

exit $RC
