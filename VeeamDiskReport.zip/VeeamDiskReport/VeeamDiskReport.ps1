#Requires -Version 7.0
<#
.SYNOPSIS
    Veeam Backup & Replication v13 — Disk Consumption Report

.DESCRIPTION
    Standalone interactive script that connects to a VBR v13 server,
    queries all backup and Backup Copy jobs, and produces a per-job summary:

        Job Name | Job Type | Repository | Hardened |
        Restore Points | Oldest RP | Newest RP | Approx Data GB | Status

    Results are displayed as a formatted console table and exported to CSV.
    Optionally copies the CSV to a second location (network share, etc.).
    Includes a built-in scheduler that registers a Windows Scheduled Task
    to run the report unattended on a recurring schedule.

.PARAMETER Unattended
    Skips all interactive prompts. Reads settings from the config file and
    connects using Windows integrated authentication (no credential dialog).
    Used by the Windows Scheduled Task.

.PARAMETER ConfigPath
    Path to the JSON config file. Defaults to VeeamDiskReport.config.json
    in the same folder as this script.

.NOTES
    Author  : Benjamin McGuire / Veeam
    Version : 1.0
    Requires: VBR v13 console installed, PowerShell 7.0+, run as Administrator
#>
param(
    [switch]$Unattended,
    [string]$ConfigPath = "$PSScriptRoot\VeeamDiskReport.config.json"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ============================================================
#  CONSOLE HELPERS
# ============================================================
function Write-Header {
    param([string]$Title)
    $line = "=" * 66
    Write-Host ""
    Write-Host $line         -ForegroundColor Cyan
    Write-Host "  $Title"   -ForegroundColor Cyan
    Write-Host $line         -ForegroundColor Cyan
    Write-Host ""
}

function Write-Success { param([string]$Msg) Write-Host "  [OK]  $Msg" -ForegroundColor Green     }
function Write-Info    { param([string]$Msg) Write-Host "  [>>]  $Msg" -ForegroundColor Yellow    }
function Write-Warn    { param([string]$Msg) Write-Host "  [!]   $Msg" -ForegroundColor DarkYellow }
function Write-Err     { param([string]$Msg) Write-Host "  [!!]  $Msg" -ForegroundColor Red       }
function Write-Detail  { param([string]$Msg) Write-Host "        $Msg" -ForegroundColor Gray      }

function Pause-Screen {
    Write-Host ""
    $null = Read-Host "  Press Enter to continue"
}

function Select-Folder {
    param([string]$Description = "Select a folder", [string]$InitialDir = "")
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = [System.Windows.Forms.FolderBrowserDialog]::new()
    $dlg.Description  = $Description
    $dlg.ShowNewFolderButton = $true
    if ($InitialDir -and (Test-Path $InitialDir)) { $dlg.SelectedPath = $InitialDir }
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dlg.SelectedPath
    }
    return $null
}

function Truncate-String {
    param([string]$Str, [int]$MaxLen)
    if ($Str.Length -gt $MaxLen) { return $Str.Substring(0, $MaxLen - 3) + "..." }
    return $Str
}

# ============================================================
#  THROTTLE-SAFE VBR WRAPPER  (VBR v13 rate limiting)
# ============================================================
function Invoke-VeeamSafe {
    param(
        [Parameter(Mandatory)][scriptblock]$Command,
        [int]$Retry        = 5,
        [int]$DelaySeconds = 2
    )
    for ($i = 1; $i -le $Retry; $i++) {
        try {
            return & $Command
        } catch {
            if ($_.Exception.Message -match 'TooManyRequests|429') {
                $wait = $DelaySeconds * $i
                Write-Warn "VBR throttle hit (attempt $i/$Retry) — waiting ${wait}s..."
                Start-Sleep -Seconds $wait
            } else { throw }
        }
    }
    throw "Invoke-VeeamSafe: VBR throttling not cleared after $Retry attempts."
}

# ============================================================
#  CONFIG  (load / save)
# ============================================================
function Get-Config {
    if (Test-Path $ConfigPath) {
        try {
            $c = Get-Content $ConfigPath -Raw | ConvertFrom-Json
            return $c
        } catch {
            Write-Warn "Could not read config file — using defaults."
        }
    }
    return [pscustomobject]@{
        VBRServer        = ""
        OutputFolder     = ""
        CopyDestination  = ""
        UseIntegratedAuth = $true
    }
}

function Save-Config {
    param([pscustomobject]$Config)
    try {
        $Config | ConvertTo-Json | Out-File -FilePath $ConfigPath -Encoding UTF8 -Force
        Write-Success "Config saved: $ConfigPath"
    } catch {
        Write-Warn "Could not save config: $_"
    }
}

# ============================================================
#  VBR CONNECTION
# ============================================================
function Connect-VBR {
    param([pscustomobject]$Config, [switch]$Unattended)

    Write-Header "Connecting to Veeam VBR"

    # Load module
    if (-not (Get-Module -Name "Veeam.Backup.PowerShell" -ErrorAction SilentlyContinue)) {
        try {
            [System.Net.ServicePointManager]::SecurityProtocol =
                [System.Net.SecurityProtocolType]::Tls12 -bor
                [System.Net.SecurityProtocolType]::Tls13

            $modPath = "C:\Program Files\Veeam\Backup and Replication\Console\Veeam.Backup.PowerShell\Veeam.Backup.PowerShell.psd1"
            if (Test-Path $modPath) {
                Import-Module $modPath -DisableNameChecking -SkipEditionCheck -ErrorAction Stop
            } else {
                Import-Module Veeam.Backup.PowerShell -DisableNameChecking -SkipEditionCheck -ErrorAction Stop
            }
            Write-Success "Loaded Veeam.Backup.PowerShell module."
        } catch {
            Write-Err "Could not load Veeam.Backup.PowerShell module."
            Write-Err "Ensure VBR v13 console is installed and session is running as Administrator."
            Write-Err "Error: $_"
            Pause-Screen
            return
        }
    }

    # Resolve server
    $server = $Config.VBRServer
    if (-not $Unattended) {
        $input = (Read-Host "  VBR Server IP or hostname$(if ($server) { " (Enter for '$server')" })").Trim()
        if ($input -ne "") { $server = $input }
    }
    if ([string]::IsNullOrWhiteSpace($server)) {
        Write-Err "No VBR server specified."
        Pause-Screen
        return
    }
    $Config.VBRServer = $server

    # Connect — use Get-Credential (PSCredential) which works with VBR v13
    try {
        Disconnect-VBRServer -ErrorAction SilentlyContinue | Out-Null

        if ($Unattended) {
            Connect-VBRServer -Server $server -ErrorAction Stop
        } else {
            $cred = Get-Credential -Message "VBR credentials for $server"
            if (-not $cred) {
                Write-Err "No credentials provided."
                Pause-Screen
                return
            }
            Connect-VBRServer -Server $server -Credential $cred -ErrorAction Stop
        }

        Write-Success "Connected to: $server"
        Save-Config -Config $Config
    } catch {
        Write-Err "Connection failed: $_"
        Write-Warn "Check that VeeamBackupSvc is running on $server"
        Write-Warn "and your account has the Veeam Backup Administrator role."
        Pause-Screen
        return
    }
}

# ============================================================
#  REPORT
# ============================================================
function Invoke-DiskReport {
    param([string]$OutFolder)

    Write-Header "Disk Space Consumption Report"
    Write-Info "Querying jobs — this may take a moment..."
    Write-Host ""

    # Jobs
    $jobs = @(Get-VBRJob -WarningAction SilentlyContinue |
              Where-Object { $_.JobType -eq "Backup" -or $_.JobType -eq "BackupSync" } |
              Sort-Object Name)

    if ($jobs.Count -eq 0) {
        Write-Err "No backup jobs found."
        return $null
    }

    # Backup catalog (pre-fetch once)
    Write-Detail "Loading backup catalog..."
    $allBackups = @(try { Invoke-VeeamSafe { Get-VBRBackup -ErrorAction Stop } } catch { @() })

    $rows   = [System.Collections.Generic.List[pscustomobject]]::new()
    $errors = 0

    foreach ($job in $jobs) {
        $jName = $job.Name
        $jId   = $job.Id.ToString()
        Write-Detail $jName

        try {
            $backups = @($allBackups | Where-Object { $_.JobId.ToString() -eq $jId })

            $jType = if ($backups.Count -gt 0) {
                switch ($backups[0].BackupPlatform) {
                    'EVmware' { 'VMware Backup'  }
                    'EHyperV' { 'Hyper-V Backup' }
                    'EHvVim'  { 'Hyper-V Backup' }
                    default   { if ($job.JobType -eq 'BackupSync') { 'Backup Copy' } else { $backups[0].BackupPlatform } }
                }
            } else {
                if ($job.JobType -eq 'BackupSync') { 'Backup Copy' } else { 'Backup' }
            }

            $jRepo    = try { $job.GetTargetRepository().Name } catch { 'N/A' }
            $hardened = if ($backups.Count -gt 0 -and $backups[0].RepositoryType -eq 'LinuxHardened') { 'Yes' } else { 'No' }

            if ($backups.Count -eq 0) {
                $rows.Add([pscustomobject]@{
                    'Job Name'             = $jName
                    'Job Type'             = $jType
                    'Repository'           = $jRepo
                    'Hardened'             = $hardened
                    'Restore Points'       = 0
                    'Oldest Restore Point' = 'N/A'
                    'Newest Restore Point' = 'N/A'
                    'Approx Data GB'       = 0.00
                    'Status'               = 'No backups'
                })
                continue
            }

            $allRPs      = [System.Collections.Generic.List[object]]::new()
            $approxBytes = [long]0

            foreach ($backup in $backups) {
                try {
                    $rps = @(Invoke-VeeamSafe { Get-VBRRestorePoint -Backup $backup -ErrorAction Stop })
                    foreach ($rp in $rps) { $allRPs.Add($rp) }
                } catch {
                    Write-Warn "  RP query failed for '$jName': $_"
                }
            }

            $rpCount = $allRPs.Count
            $oldest  = 'N/A'
            $newest  = 'N/A'

            if ($rpCount -gt 0) {
                $sorted = @($allRPs | Sort-Object CreationTime)
                $oldest = $sorted[0].CreationTime.ToString('yyyy-MM-dd')
                $newest = $sorted[-1].CreationTime.ToString('yyyy-MM-dd')
                foreach ($rp in $allRPs) {
                    if ($rp.ApproxSize -gt 0) { $approxBytes += [long]$rp.ApproxSize }
                }
            }

            $rows.Add([pscustomobject]@{
                'Job Name'             = $jName
                'Job Type'             = $jType
                'Repository'           = $jRepo
                'Hardened'             = $hardened
                'Restore Points'       = $rpCount
                'Oldest Restore Point' = $oldest
                'Newest Restore Point' = $newest
                'Approx Data GB'       = '{0:F2}' -f ($approxBytes / 1GB)
                'Status'               = 'OK'
            })

        } catch {
            $errors++
            Write-Warn "Query failed for '$jName': $_"
            $rows.Add([pscustomobject]@{
                'Job Name'             = $jName
                'Job Type'             = 'N/A'
                'Repository'           = 'N/A'
                'Hardened'             = 'N/A'
                'Restore Points'       = 'N/A'
                'Oldest Restore Point' = 'N/A'
                'Newest Restore Point' = 'N/A'
                'Approx Data GB'       = 'N/A'
                'Status'               = "ERROR: $($_.Exception.Message)"
            })
        }
    }

    # ---- Console table ----
    Write-Host ""
    $CJ = 34; $CT = 15; $CR = 22; $CH = 9; $CRP = 7

    Write-Host ("  {0,-$CJ} {1,-$CT} {2,-$CR} {3,-$CH} {4,-$CRP} {5}" -f `
        "Job Name","Type","Repository","Hardened","Points","Approx Data (GB)") -ForegroundColor White
    Write-Host ("  {0,-$CJ} {1,-$CT} {2,-$CR} {3,-$CH} {4,-$CRP} {5}" -f `
        ("-"*($CJ-1)),("-"*($CT-1)),("-"*($CR-1)),"--------","------","----------------") -ForegroundColor DarkGray

    foreach ($r in $rows) {
        $color  = switch ($r.Status) { "OK" { "Cyan" } "No backups" { "DarkYellow" } default { "Red" } }
        $hColor = if ($r.Hardened -eq 'Yes') { "Yellow" } else { $color }
        Write-Host ("  {0,-$CJ} {1,-$CT} {2,-$CR} " -f `
            (Truncate-String $r.'Job Name'   ($CJ-1)),
            (Truncate-String $r.'Job Type'   ($CT-1)),
            (Truncate-String $r.'Repository' ($CR-1))) -ForegroundColor $color -NoNewline
        Write-Host ("{0,-$CH} " -f $r.Hardened) -ForegroundColor $hColor -NoNewline
        Write-Host ("{0,-$CRP} {1}" -f $r.'Restore Points', $r.'Approx Data GB') -ForegroundColor $color
    }

    Write-Host ""

    $okRows = @($rows | Where-Object { $_.Status -eq 'OK' })
    if ($okRows.Count -gt 0) {
        $totData = '{0:F2}' -f ($okRows | ForEach-Object { [double]$_.'Approx Data GB' } | Measure-Object -Sum).Sum
        $totRPs  = [int]($okRows | ForEach-Object { [int]$_.'Restore Points' } | Measure-Object -Sum).Sum
        Write-Host ("  +- Totals ({0}/{1} jobs)  RPs: {2}  |  Approx Data: {3} GB" -f `
            $okRows.Count, $jobs.Count, $totRPs, $totData) -ForegroundColor Cyan
    }

    if ($errors -gt 0) { Write-Host ""; Write-Warn "$errors job(s) had errors (shown in red)." }

    # ---- Export CSV ----
    Write-Host ""
    $csvName = "VeeamDiskConsumption_$(Get-Date -f 'yyyyMMdd_HHmmss').csv"
    $csvPath = Join-Path $OutFolder $csvName

    try {
        $rows | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
        Write-Success "CSV saved: $csvPath"
    } catch {
        Write-Err "CSV export failed: $_"
        return $null
    }

    return $csvPath
}

# ============================================================
#  COPY TO DESTINATION
# ============================================================
function Copy-ReportTo {
    param([string]$CsvPath, [string]$Destination)

    if ([string]::IsNullOrWhiteSpace($Destination)) { return }

    try {
        if (-not (Test-Path $Destination -PathType Container)) {
            New-Item -ItemType Directory -Path $Destination -Force | Out-Null
        }
        Copy-Item -Path $CsvPath -Destination $Destination -Force
        Write-Success "Report copied to: $Destination"
    } catch {
        Write-Err "Copy failed: $_"
    }
}

# ============================================================
#  SCHEDULER
# ============================================================
function Register-ReportTask {
    param([pscustomobject]$Config)

    Write-Header "Schedule This Report"

    Write-Info "This will create a Windows Scheduled Task that runs the report automatically."
    Write-Info "The task runs as your current Windows account using integrated authentication."
    Write-Warn "Ensure your account has the Veeam Backup Administrator role on $($Config.VBRServer)."
    Write-Host ""

    # Frequency
    Write-Host "  Frequency:" -ForegroundColor White
    Write-Host "    1. Daily"
    Write-Host "    2. Weekly"
    Write-Host "    3. Monthly (1st of each month)"
    Write-Host ""
    $freq = Read-Host "  Select (1-3)"

    # Time
    $timeStr = (Read-Host "  Run time (24h HH:MM, e.g. 07:00)").Trim()
    if ($timeStr -notmatch '^\d{2}:\d{2}$') {
        Write-Err "Invalid time format. Use HH:MM (e.g. 06:30)"
        return
    }

    # Day of week (weekly only)
    $dow = $null
    if ($freq -eq "2") {
        Write-Host "  Day of week: Mon Tue Wed Thu Fri Sat Sun"
        $dow = (Read-Host "  Day").Trim()
    }

    # Task name
    $taskName = "VeeamDiskReport_$($Config.VBRServer -replace '[^\w]','_')"
    $scriptPath = $PSCommandPath

    # Build trigger
    $trigger = switch ($freq) {
        "1" { New-ScheduledTaskTrigger -Daily  -At $timeStr }
        "2" { New-ScheduledTaskTrigger -Weekly -At $timeStr -DaysOfWeek $dow }
        "3" { New-ScheduledTaskTrigger -Monthly -DaysOfMonth 1 -At $timeStr }
        default { Write-Err "Invalid selection."; return }
    }

    $action   = New-ScheduledTaskAction `
                    -Execute  "pwsh.exe" `
                    -Argument "-NonInteractive -ExecutionPolicy Bypass -File `"$scriptPath`" -Unattended -ConfigPath `"$ConfigPath`""

    $settings = New-ScheduledTaskSettingsSet `
                    -ExecutionTimeLimit (New-TimeSpan -Hours 2) `
                    -MultipleInstances  IgnoreNew `
                    -RunOnlyIfNetworkAvailable

    try {
        # Remove existing task with same name if present
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue

        Register-ScheduledTask `
            -TaskName  $taskName `
            -Action    $action `
            -Trigger   $trigger `
            -Settings  $settings `
            -RunLevel  Highest `
            -Force | Out-Null

        Write-Success "Scheduled task registered: $taskName"
        Write-Info   "Run time: $timeStr  |  Script: $scriptPath"
        Write-Info   "View/edit in Task Scheduler under: Task Scheduler Library"
        Write-Host ""
        Write-Warn   "Note: the task runs as your current user. Make sure this account stays active"
        Write-Warn   "and has the Veeam Backup Administrator role on $($Config.VBRServer)."
    } catch {
        Write-Err "Failed to register task: $_"
        Write-Warn "Run this script as Administrator to register scheduled tasks."
    }
}

function Remove-ReportTask {
    param([pscustomobject]$Config)
    $taskName = "VeeamDiskReport_$($Config.VBRServer -replace '[^\w]','_')"
    try {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Stop
        Write-Success "Scheduled task removed: $taskName"
    } catch {
        Write-Warn "No task found with name: $taskName"
    }
}

# ============================================================
#  INTERACTIVE MENU
# ============================================================
function Invoke-Menu {
    param([pscustomobject]$Config)

    while ($true) {
        Clear-Host
        Write-Header "Veeam Disk Consumption Report  v1.0"

        $connected = try { (Get-VBRServerSession -ErrorAction Stop) -ne $null } catch { $false }
        $status    = if ($connected) { "Connected: $($Config.VBRServer)" } else { "Not connected" }
        $sched     = Get-ScheduledTask -TaskName "VeeamDiskReport_$($Config.VBRServer -replace '[^\w]','_')" -ErrorAction SilentlyContinue
        $schedStr  = if ($sched) { "Scheduled ($($sched.Triggers[0].StartBoundary -replace 'T',' ' -replace '\+.*',''))" } else { "Not scheduled" }

        Write-Host "  Status  : $status"    -ForegroundColor $(if ($connected) { "Green" } else { "DarkYellow" })
        Write-Host "  Schedule: $schedStr"  -ForegroundColor $(if ($sched) { "Green" } else { "Gray" })
        Write-Host "  Output  : $(if ($Config.OutputFolder) { $Config.OutputFolder } else { '(not set)' })"  -ForegroundColor Gray
        Write-Host "  Copy to : $(if ($Config.CopyDestination) { $Config.CopyDestination } else { '(not set)' })" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  1. Connect to VBR server"
        Write-Host "  2. Run report"
        Write-Host "  3. Change output folder"
        Write-Host "  4. Change copy destination"
        Write-Host "  5. Schedule this report"
        Write-Host "  6. Remove scheduled task"
        Write-Host "  0. Exit"
        Write-Host ""

        $sel = Read-Host "  Select"

        switch ($sel) {
            "1" {
                Connect-VBR -Config $Config
                Save-Config -Config $Config
            }
            "2" {
                if (-not $connected) {
                    Write-Warn "Not connected. Choose option 1 first."
                    Pause-Screen; continue
                }

                # Output folder
                $folder = $Config.OutputFolder
                if ([string]::IsNullOrWhiteSpace($folder)) {
                    Write-Info "Select output folder (browser dialog opening...)"
                    $folder = Select-Folder -Description "Select CSV output folder" -InitialDir $PSScriptRoot
                    if (-not $folder) { Write-Warn "No folder selected."; Pause-Screen; continue }
                    $Config.OutputFolder = $folder
                    Save-Config -Config $Config
                }

                if (-not (Test-Path $folder -PathType Container)) {
                    try { New-Item -ItemType Directory -Path $folder -Force | Out-Null }
                    catch { Write-Err "Cannot create folder: $_"; Pause-Screen; continue }
                }

                $csvPath = Invoke-DiskReport -OutFolder $folder

                # Copy destination
                if ($csvPath -and -not [string]::IsNullOrWhiteSpace($Config.CopyDestination)) {
                    Copy-ReportTo -CsvPath $csvPath -Destination $Config.CopyDestination
                } elseif ($csvPath) {
                    $ans = Read-Host "  Copy report to another location? (yes/no)"
                    if ($ans.Trim().ToLower() -eq "yes") {
                        Write-Info "Select destination folder (browser dialog opening...)"
                        $dest = Select-Folder -Description "Select copy destination"
                        if ($dest) {
                            $Config.CopyDestination = $dest
                            Save-Config -Config $Config
                            Copy-ReportTo -CsvPath $csvPath -Destination $dest
                        }
                    }
                }

                Pause-Screen
            }
            "3" {
                Write-Info "Select output folder (browser dialog opening...)"
                $folder = Select-Folder -Description "Select CSV output folder" -InitialDir $Config.OutputFolder
                if ($folder) {
                    $Config.OutputFolder = $folder
                    Save-Config -Config $Config
                    Write-Success "Output folder set to: $folder"
                } else {
                    Write-Warn "No folder selected — output folder unchanged."
                }
                Pause-Screen
            }
            "4" {
                $ans = Read-Host "  Clear copy destination? (yes to clear, no to browse)"
                if ($ans.Trim().ToLower() -eq "yes") {
                    $Config.CopyDestination = ""
                    Save-Config -Config $Config
                    Write-Success "Copy destination cleared."
                } else {
                    Write-Info "Select copy destination (browser dialog opening...)"
                    $dest = Select-Folder -Description "Select copy destination" -InitialDir $Config.CopyDestination
                    if ($dest) {
                        $Config.CopyDestination = $dest
                        Save-Config -Config $Config
                        Write-Success "Copy destination set to: $dest"
                    } else {
                        Write-Warn "No folder selected — copy destination unchanged."
                    }
                }
                Pause-Screen
            }
            "5" {
                Register-ReportTask -Config $Config
                Pause-Screen
            }
            "6" {
                Remove-ReportTask -Config $Config
                Pause-Screen
            }
            "0" { break }
        }

        if ($sel -eq "0") { break }
    }
}

# ============================================================
#  ENTRY POINT
# ============================================================
Clear-Host
$config = Get-Config

if ($Unattended) {
    # ---- Unattended (scheduled) run ----
    Write-Header "Veeam Disk Report — Unattended Run  $(Get-Date -f 'yyyy-MM-dd HH:mm')"

    if ([string]::IsNullOrWhiteSpace($config.VBRServer)) {
        Write-Err "VBRServer not set in config. Run interactively first to configure."
        exit 1
    }
    if ([string]::IsNullOrWhiteSpace($config.OutputFolder)) {
        $config.OutputFolder = $PSScriptRoot
    }

    $config.UseIntegratedAuth = $true
    Connect-VBR -Config $config -Unattended

    $csvPath = Invoke-DiskReport -OutFolder $config.OutputFolder

    if ($csvPath -and -not [string]::IsNullOrWhiteSpace($config.CopyDestination)) {
        Copy-ReportTo -CsvPath $csvPath -Destination $config.CopyDestination
    }

    Write-Host ""
    Write-Success "Unattended run complete."

} else {
    # ---- Interactive run ----
    Invoke-Menu -Config $config
}
