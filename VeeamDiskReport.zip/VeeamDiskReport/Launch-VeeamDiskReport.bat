@echo off
:: ============================================================
::  Launch-VeeamDiskReport.bat
::  Launches VeeamDiskReport.ps1 in PowerShell 7 as Administrator
:: ============================================================

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process 'cmd' -ArgumentList '/c \"%~f0\"' -Verb RunAs -Wait"
    exit /b
)

where pwsh >nul 2>&1
if %errorlevel% equ 0 (
    set PWSH=pwsh
) else if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" (
    set PWSH="%ProgramFiles%\PowerShell\7\pwsh.exe"
) else (
    echo [ERROR] PowerShell 7 not found. Install from https://aka.ms/powershell
    cmd /k
    exit /b 1
)

%PWSH% -NoProfile -ExecutionPolicy Bypass -File "%~dp0VeeamDiskReport.ps1"

echo.
echo Script exited with code %errorlevel%
cmd /k
