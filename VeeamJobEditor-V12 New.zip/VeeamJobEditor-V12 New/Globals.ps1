# Shared state and column-width constants used across all modules.
$script:VBRServer = "localhost"
$script:ChangeLog = [System.Collections.Generic.List[string]]::new()

$COL_SETTING = 26
$COL_VAL     = 32
$COL_STATUS  = 10
