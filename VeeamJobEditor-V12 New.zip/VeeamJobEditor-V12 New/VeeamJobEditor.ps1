#Requires -Version 5.1
<#
.SYNOPSIS
    Veeam Backup & Replication v12 - Interactive Job Editor v2

.DESCRIPTION
    Interactive PowerShell menu to view, edit, and bulk-apply settings for
    VMware Backup Jobs and Backup Copy Jobs in Veeam VBR v12.

    Features:
      - Edit repository and retention (simple + GFS)
      - Edit job schedule (daily, weekly, monthly, continuous)
      - Edit notification and email alert settings
      - Start / Stop jobs
      - Bulk copy settings from one source job to multiple target jobs
      - MASS EDIT: push one setting to hundreds of jobs at once
          > Scope filter: All / VMware only / Backup Copy only / Hand-pick
          > Preview table (current vs. new value per job) before any change
          > 3-phase disable -> apply -> re-enable for retention and GFS
          > Post-apply results table (SUCCESS / FAILED / SKIPPED) with export
      - Side-by-side Before / After comparison after every edit or bulk operation
      - Session change log with optional export

.NOTES
    Author  : Benjamin McGuire / Veeam
    Version : 2.2
    Requires: Veeam Backup & Replication v12 on Windows
              Must be run on the VBR server (or machine with VBR console).
              Run as Administrator.

.STRUCTURE
    VeeamJobEditor/
    +-- VeeamJobEditor.ps1       <- entry point (this file)
    +-- Globals.ps1              <- shared state and column constants
    +-- Functions/
        +-- ConsoleHelpers.ps1
        +-- VBRConnection.ps1
        +-- JobRetrieval.ps1
        +-- JobSnapshot.ps1
        +-- ShowComparison.ps1
        +-- EditHelpers.ps1
        +-- EditRepository.ps1
        +-- EditRetention.ps1
        +-- EditGfsRetention.ps1
        +-- EditNotifications.ps1
        +-- EditSchedule.ps1
        +-- SingleJobMenu.ps1
        +-- BulkCopy.ps1
        +-- JobControl.ps1
        +-- ChangeLog.ps1
        +-- MassEditHelpers.ps1
        +-- MassEditRetention.ps1
        +-- MassEditRepository.ps1
        +-- MassEditSchedule.ps1
        +-- MassEditNotifications.ps1
        +-- MassEditGfs.ps1
        +-- MassEditMenu.ps1
        +-- MainMenu.ps1

    To add a new function: create a new .ps1 file in Functions/ - it loads automatically.
    To remove a function: delete its .ps1 file from Functions/.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Load shared globals (VBRServer, ChangeLog, column constants)
. "$PSScriptRoot\Globals.ps1"

# Auto-load every function file from the Functions folder
Get-ChildItem "$PSScriptRoot\Functions" -Filter *.ps1 |
    Sort-Object Name |
    ForEach-Object { . $_.FullName }

# ============================================================
#  ENTRY POINT
# ============================================================
Clear-Host
Initialize-VBRConnection
Invoke-MainMenu
