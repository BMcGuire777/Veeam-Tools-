function Invoke-JobControl {
    Write-Header "Start / Stop a Job"

    $jobs = @(Get-AllEditableJobs)
    if ($jobs.Count -eq 0) { Write-Err "No jobs found."; return }
    Show-JobTable -Jobs $jobs

    do {
        $sel = Read-Host "  Select job (1-$($jobs.Count), 0 to cancel)"
        if ($sel -eq "0") { return }
    } while ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $jobs.Count)

    $job = $jobs[[int]$sel - 1]

    Write-Host ""
    Write-Host "  [1] Start Job" -ForegroundColor Green
    Write-Host "  [2] Stop Job"  -ForegroundColor Red
    Write-Host "  [3] Retry Job (last session)" -ForegroundColor Yellow
    Write-Host "  [0] Cancel" -ForegroundColor DarkGray
    Write-Host ""
    $action = Read-Host "  Select action"

    switch ($action) {
        "1" {
            if (Confirm-Action "Start job '$($job.Name)'?") {
                try {
                    Start-VBRJob -Job $job -ErrorAction Stop
                    Log-Change $job.Name "Job Control" "N/A" "Started"
                    Write-Success "Job '$($job.Name)' started."
                } catch { Write-Err "Failed to start: $_" }
            }
        }
        "2" {
            if (Confirm-Action "Stop job '$($job.Name)'?") {
                try {
                    Stop-VBRJob -Job $job -ErrorAction Stop
                    Log-Change $job.Name "Job Control" "Running" "Stopped"
                    Write-Success "Stop signal sent to '$($job.Name)'."
                } catch { Write-Err "Failed to stop: $_" }
            }
        }
        "3" {
            if (Confirm-Action "Retry last session for '$($job.Name)'?") {
                try {
                    Start-VBRJob -Job $job -RunAsync -ErrorAction Stop
                    Log-Change $job.Name "Job Control" "N/A" "Retry Started"
                    Write-Success "Retry started for '$($job.Name)'."
                } catch { Write-Err "Failed to retry: $_" }
            }
        }
        default { Write-Info "Cancelled." }
    }
}
