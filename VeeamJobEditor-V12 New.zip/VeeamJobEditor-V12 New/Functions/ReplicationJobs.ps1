# ============================================================
#  REPLICATION JOBS PACKAGE
#  All replication job functions in one file.
#  Covers: retrieval, snapshot, change window, single-job editing,
#          and mass editing for VMware & Hyper-V replication jobs.
# ============================================================

# ---- Job Retrieval & Selection -----------------------------

function Get-AllReplicationJobs {
    $raw = @(Get-VBRJob -WarningAction SilentlyContinue |
             Where-Object { $_.JobType -eq "Replica" -or $_.JobType -eq "HvReplica" })
    return @($raw | Sort-Object Name)
}

function Show-ReplicationJobTable {
    param([array]$Jobs)
    Write-Host ""
    Write-Host ("  {0,-4} {1,-38} {2,-16} {3,-22} {4,-6} {5}" -f "#", "Job Name", "Type", "Target Host", "Points", "Status") -ForegroundColor White
    Write-Host ("  {0,-4} {1,-38} {2,-16} {3,-22} {4,-6} {5}" -f "----", "--------", "----", "-----------", "------", "------") -ForegroundColor DarkGray

    for ($i = 0; $i -lt $Jobs.Count; $i++) {
        $j      = $Jobs[$i]
        $type   = if ($j.JobType -eq "HvReplica") { "HV Replication" } else { "VMware Replica" }
        $target = try { $j.GetTargetHost().Name } catch { "N/A" }
        $pts    = try {
            $v = $j.Options.GenerationPolicy.RestorePointsToKeep
            if ($null -eq $v -or $v -eq 0) { $j.Options.BackupStorageOptions.RetainCycles } else { $v }
        } catch { "N/A" }
        $state  = try { $j.GetLastResult() } catch { "Unknown" }
        $color  = if ($j.JobType -eq "HvReplica") { "Magenta" } else { "Cyan" }
        Write-Host ("  {0,-4} {1,-38} {2,-16} {3,-22} {4,-6} {5}" -f `
            ($i+1), (Truncate-String $j.Name 37), $type, (Truncate-String $target 21), $pts, $state) -ForegroundColor $color
    }
    Write-Host ""
}

function Select-SingleReplicationJob {
    param([string]$Prompt = "Select a replication job")
    $jobs = @(Get-AllReplicationJobs)
    if ($jobs.Count -eq 0) { Write-Err "No replication jobs found."; return $null }
    Show-ReplicationJobTable -Jobs $jobs
    do {
        $sel = Read-Host "  $Prompt (1-$($jobs.Count), 0 to cancel)"
        if ($sel -eq "0") { return $null }
    } while ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $jobs.Count)
    return $jobs[[int]$sel - 1]
}

function Select-MultipleReplicationJobs {
    param([string]$ExcludeJobName = "")
    $jobs = @(Get-AllReplicationJobs | Where-Object { $_.Name -ne $ExcludeJobName })
    if ($jobs.Count -eq 0) { Write-Err "No replication jobs available."; Pause-Screen; return @() }
    Show-ReplicationJobTable -Jobs $jobs
    Write-Info "Enter job numbers comma-separated (e.g. 1,3,5) or 'all':"
    $input = Read-Host "  Selection"
    if ($input.Trim().ToLower() -eq "all") { return $jobs }
    $selected = @()
    foreach ($idx in ($input -split "," | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' })) {
        $i = [int]$idx - 1
        if ($i -ge 0 -and $i -lt $jobs.Count) { $selected += $jobs[$i] }
    }
    return $selected
}

function Select-MassEditReplicationJobs {
    Write-SubHeader "Select Target Replication Jobs for Mass Edit"

    $allJobs = @(Get-AllReplicationJobs)
    if ($allJobs.Count -eq 0) { Write-Err "No replication jobs found."; return @() }

    $vmJobs = @($allJobs | Where-Object { $_.JobType -eq "Replica"   })
    $hvJobs = @($allJobs | Where-Object { $_.JobType -eq "HvReplica" })

    Write-Host "  Available:" -ForegroundColor White
    Write-Host "    Total    : $($allJobs.Count)" -ForegroundColor Gray
    Write-Host "    VMware   : $($vmJobs.Count)"  -ForegroundColor Cyan
    Write-Host "    Hyper-V  : $($hvJobs.Count)"  -ForegroundColor Magenta
    Write-Host ""
    Write-Host "  [1] ALL replication jobs  ($($allJobs.Count))" -ForegroundColor Yellow
    Write-Host "  [2] VMware only  ($($vmJobs.Count))"           -ForegroundColor Cyan
    Write-Host "  [3] Hyper-V only  ($($hvJobs.Count))"          -ForegroundColor Magenta
    Write-Host "  [4] Hand-pick from list"                       -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                                    -ForegroundColor DarkGray
    Write-Host ""
    $scope = Read-Host "  Select scope"

    switch ($scope) {
        "1" { return $allJobs }
        "2" { if ($vmJobs.Count -eq 0) { Write-Warn "No VMware replication jobs."; return @() }; return $vmJobs }
        "3" { if ($hvJobs.Count -eq 0) { Write-Warn "No Hyper-V replication jobs."; return @() }; return $hvJobs }
        "4" {
            Show-ReplicationJobTable -Jobs $allJobs
            Write-Info "Enter job numbers comma-separated:"
            $rawIn = Read-Host "  Selection"
            $sel = @()
            foreach ($idx in ($rawIn -split "," | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' })) {
                $i = [int]$idx - 1
                if ($i -ge 0 -and $i -lt $allJobs.Count) { $sel += $allJobs[$i] }
            }
            if ($sel.Count -eq 0) { Write-Warn "No valid jobs selected."; return @() }
            return $sel
        }
        default { Write-Info "Cancelled."; return @() }
    }
}

# ---- Snapshot & Change Window ------------------------------

function Get-ReplicationSnapshot {
    param($Job)
    $s = [ordered]@{}

    $s['Job Name']    = $Job.Name
    $s['Job Type']    = if ($Job.JobType -eq "HvReplica") { "Hyper-V Replication" } else { "VMware Replication" }
    $s['Job Enabled'] = try { $Job.IsScheduleEnabled } catch { "N/A" }
    $s['Target Host'] = try { $Job.GetTargetHost().Name } catch { "N/A" }
    $s['Replica Suffix'] = try { $Job.Options.GenerationPolicy.ReplicaNameSuffix } catch { "N/A" }
    $s['Restore Points'] = try {
        $v = $Job.Options.GenerationPolicy.RestorePointsToKeep
        if ($null -eq $v -or $v -eq 0) { $Job.Options.BackupStorageOptions.RetainCycles } else { $v }
    } catch { "N/A" }

    try {
        $s['Compression'] = $Job.Options.BackupStorageOptions.CompressionLevel
        $s['Storage Opt'] = $Job.Options.BackupStorageOptions.StgBlockSize
    } catch {
        $s['Compression'] = "N/A"
        $s['Storage Opt'] = "N/A"
    }

    $s['App-Aware']    = try { $Job.Options.ViGuestOptions.IsUseGuestAgent } catch { "N/A" }
    $s['Source Proxy'] = try { ($Job.GetSourceProxies() | Select-Object -First 1).Name } catch { "Automatic" }
    $s['Target Proxy'] = try { ($Job.GetTargetProxies() | Select-Object -First 1).Name } catch { "Automatic" }

    try {
        $sched = Get-VBRJobScheduleOptions -Job $Job
        $s['Schedule Type']   = $sched.ScheduleType
        $s['Schedule Detail'] = switch ($sched.ScheduleType) {
            "Daily"        { "Daily at $($sched.DailyOptions.Period)" }
            "Weekly"       { "Weekly: $($sched.WeeklyOptions.DaysSrv -join ',') @ $($sched.WeeklyOptions.Period)" }
            "Monthly"      { "Monthly: $($sched.MonthlyOptions.DayNumberInMonth) $($sched.MonthlyOptions.DayOfWeek)" }
            "Continuously" { "Continuously" }
            default        { $sched.ScheduleType }
        }
    } catch {
        $s['Schedule Type']   = "N/A"
        $s['Schedule Detail'] = "N/A"
    }

    try {
        $notif = $Job.Options.NotificationOptions
        $email = $notif.EmailNotificationOptions
        $s['Email Notify']    = $notif.SendEmail
        $s['Email Addresses'] = if ($email.EmailAddresses) { $email.EmailAddresses } else { "(none)" }
    } catch {
        $s['Email Notify']    = "N/A"
        $s['Email Addresses'] = "N/A"
    }

    return $s
}

function Show-PendingChangesWindow {
    <#
    Shows a formatted Setting | Current | New table BEFORE any API call is made.
    Returns $true if the user confirms, $false to cancel.
    $Changes: [ordered]@{ "Setting Name" = @{ Current = "..."; New = "..." } }
    #>
    param(
        [string]$JobName,
        [System.Collections.Specialized.OrderedDictionary]$Changes
    )

    if ($Changes.Count -eq 0) { Write-Info "No changes staged for '$JobName'."; return $false }

    $CS = 28; $CV = 28

    Write-Header "Pending Changes  - $JobName"
    Write-Host ("  {0,-$CS} {1,-$CV} {2,-$CV} {3}" -f "Setting", "Current Value", "New Value", "Action") -ForegroundColor White
    Write-Host ("  {0,-$CS} {1,-$CV} {2,-$CV} {3}" -f ("-"*($CS-1)), ("-"*($CV-1)), ("-"*($CV-1)), "---------") -ForegroundColor DarkGray

    $changeCount = 0
    foreach ($key in $Changes.Keys) {
        $cur  = "$($Changes[$key].Current)"
        $new  = "$($Changes[$key].New)"
        $diff = ($cur -ne $new)
        if ($diff) { $changeCount++ }
        $action = if ($diff) { "[WILL CHANGE]" } else { "[NO CHANGE]"  }
        $color  = if ($diff) { "Yellow"        } else { "DarkGray"     }
        Write-Host ("  {0,-$CS} {1,-$CV} {2,-$CV} {3}" -f `
            (Truncate-String $key ($CS-1)), `
            (Truncate-String $cur ($CV-1)), `
            (Truncate-String $new ($CV-1)), `
            $action) -ForegroundColor $color
    }

    Write-Host ""
    Write-Info "$changeCount change(s) pending for '$JobName'."
    Write-Host ""

    if ($changeCount -eq 0) { Write-Info "All values already at desired state  - nothing to apply."; return $false }
    return (Confirm-Action "Commit $changeCount change(s) to '$JobName'?")
}

# ---- Edit: Retention ---------------------------------------

function Edit-ReplicationRetention {
    param($Job)
    Write-Header "Edit Retention: $($Job.Name)"

    $cur = try {
        $v = $Job.Options.GenerationPolicy.RestorePointsToKeep
        if ($null -eq $v -or $v -eq 0) { $Job.Options.BackupStorageOptions.RetainCycles } else { $v }
    } catch { "Unknown" }

    Write-Info "Current restore points: $cur"
    Write-Host ""

    $wasEnabled = $false
    try { $wasEnabled = $Job.IsScheduleEnabled } catch {}

    if ($wasEnabled) {
        Write-Warn "Job is ENABLED. Retention changes require disabling the job first."
        if (-not (Confirm-Action "Disable '$($Job.Name)' now to proceed?")) { Write-Info "Cancelled."; return }
        if (-not (Invoke-ToggleJobEnabled -Job $Job -Disable $true)) { Write-Err "Could not disable job. Aborting."; return }
    }

    do {
        $input = Read-Host "  New restore point count (1-28, 0 to cancel)"
        if ($input -eq "0") {
            if ($wasEnabled) {
                Write-Warn "Cancelled. Job is still DISABLED."
                if (Confirm-Action "Re-enable '$($Job.Name)' now?") { Invoke-ToggleJobEnabled -Job $Job -Disable $false | Out-Null }
            }
            return
        }
    } while ($input -notmatch '^\d+$' -or [int]$input -lt 1 -or [int]$input -gt 28)

    $newVal  = [int]$input
    $changes = [ordered]@{ "Restore Points" = @{ Current = "$cur"; New = "$newVal" } }

    if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) {
        if ($wasEnabled) {
            Write-Warn "Cancelled. Job is still DISABLED."
            if (Confirm-Action "Re-enable '$($Job.Name)' now?") { Invoke-ToggleJobEnabled -Job $Job -Disable $false | Out-Null }
        }
        return
    }

    $saved = $false
    try {
        $opts = Get-VBRJobOptions -Job $Job -ErrorAction Stop
        $opts.GenerationPolicy.RestorePointsToKeep = $newVal
        Set-VBRJobOptions -Job $Job -Options $opts -ErrorAction Stop
        $saved = $true
    } catch {
        Write-Warn "GenerationPolicy method failed: $_"
        try {
            $opts = Get-VBRJobOptions -Job $Job -ErrorAction Stop
            $opts.BackupStorageOptions.RetainCycles = $newVal
            Set-VBRJobOptions -Job $Job -Options $opts -ErrorAction Stop
            $saved = $true
        } catch { Write-Err "All retention-save methods failed: $_" }
    }

    if ($saved) { Log-Change $Job.Name "Restore Points" "$cur" "$newVal"; Write-Success "Retention set to $newVal." }

    if ($wasEnabled) {
        Write-Host ""
        if (Confirm-Action "Re-enable '$($Job.Name)' now?") { Invoke-ToggleJobEnabled -Job $Job -Disable $false | Out-Null }
        else { Write-Warn "Job remains DISABLED. Use [8] in the edit menu to re-enable." }
    }
}

# ---- Edit: Schedule ----------------------------------------

function Edit-ReplicationSchedule {
    param($Job)
    Write-Header "Edit Schedule: $($Job.Name)"

    try {
        $cur = Get-VBRJobScheduleOptions -Job $Job
        Write-Info "Current type : $($cur.ScheduleType)"
        Write-Info "Enabled      : $($Job.IsScheduleEnabled)"
    } catch { Write-Warn "Could not read current schedule." }
    Write-Host ""

    Write-Host "  [1] Daily"                     -ForegroundColor Yellow
    Write-Host "  [2] Weekly"                    -ForegroundColor Yellow
    Write-Host "  [3] Monthly"                   -ForegroundColor Yellow
    Write-Host "  [4] Continuously"              -ForegroundColor Yellow
    Write-Host "  [5] Enable / Disable schedule" -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                    -ForegroundColor DarkGray
    Write-Host ""
    $choice = Read-Host "  Select schedule type"

    function Read-ValidTimeRepl {
        $t = ""
        do { $t = Read-Host "  Run at time (HH:mm, e.g. 22:00)" } while ($t -notmatch '^\d{2}:\d{2}$')
        return [datetime]::ParseExact($t, "HH:mm", $null)
    }

    $curType    = try { (Get-VBRJobScheduleOptions -Job $Job).ScheduleType } catch { "N/A" }
    $changes    = [ordered]@{}
    $applyRunAt = $null; $applyDays = @(); $applyOccur = ""; $applyDow = ""; $applyMonths = @(); $newDesc = ""

    switch ($choice) {
        "1" { $applyRunAt = Read-ValidTimeRepl; $newDesc = "Daily at $($applyRunAt.ToString('HH:mm'))" }
        "2" {
            $applyRunAt = Read-ValidTimeRepl
            Write-Host "  Days: Monday Tuesday Wednesday Thursday Friday Saturday Sunday" -ForegroundColor Gray
            $daysStr    = Read-Host "  Day(s), comma-separated"
            $applyDays  = @($daysStr -split "," | ForEach-Object { $_.Trim() })
            $newDesc    = "Weekly $($applyDays -join ',') @ $($applyRunAt.ToString('HH:mm'))"
        }
        "3" {
            $applyRunAt  = Read-ValidTimeRepl
            Write-Host "  Occurrence: First Second Third Fourth Last" -ForegroundColor Gray
            $applyOccur  = Read-Host "  Occurrence"
            Write-Host "  Day: Monday Tuesday Wednesday Thursday Friday Saturday Sunday Day" -ForegroundColor Gray
            $applyDow    = Read-Host "  Day of week"
            $mIn         = Read-Host "  Month(s), comma-separated or 'all'"
            $applyMonths = if ($mIn.Trim().ToLower() -eq "all") {
                @("January","February","March","April","May","June","July","August","September","October","November","December")
            } else { @($mIn -split "," | ForEach-Object { $_.Trim() }) }
            $newDesc = "Monthly $applyOccur $applyDow @ $($applyRunAt.ToString('HH:mm'))"
        }
        "4" { $newDesc = "Continuously" }
        "5" {
            $enabled = $Job.IsScheduleEnabled
            $changes["Schedule Enabled"] = @{ Current = "$enabled"; New = "$(-not $enabled)" }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                if ($enabled) { Disable-VBRJob -Job $Job -ErrorAction Stop }
                else          { Enable-VBRJob  -Job $Job -ErrorAction Stop }
                Log-Change $Job.Name "Schedule Enabled" "$enabled" "$(-not $enabled)"
                Write-Success "Schedule $(if ($enabled) { 'disabled' } else { 'enabled' })."
            } catch { Write-Err "Failed: $_" }
            return
        }
        default { Write-Info "Cancelled."; return }
    }

    $changes["Schedule Type"] = @{ Current = $curType; New = $newDesc }
    if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }

    try {
        switch ($choice) {
            "1" { Set-VBRJobScheduleOptions -Job $Job -Type Daily        -At $applyRunAt -ErrorAction Stop }
            "2" { Set-VBRJobScheduleOptions -Job $Job -Type Weekly       -At $applyRunAt -Days $applyDays -ErrorAction Stop }
            "3" { Set-VBRJobScheduleOptions -Job $Job -Type Monthly      -At $applyRunAt -Months $applyMonths -DayOfMonth $applyOccur -DayOfWeek $applyDow -ErrorAction Stop }
            "4" { Set-VBRJobScheduleOptions -Job $Job -Type Continuously -ErrorAction Stop }
        }
        Log-Change $Job.Name "Schedule" $curType $newDesc
        Write-Success "Schedule updated: $newDesc"
    } catch { Write-Err "Failed to apply schedule: $_" }
}

# ---- Edit: Notifications -----------------------------------

function Edit-ReplicationNotifications {
    param($Job)
    Write-Header "Edit Notifications: $($Job.Name)"

    try {
        $n = $Job.Options.NotificationOptions
        $e = $n.EmailNotificationOptions
        Write-SubHeader "Current Notification Settings"
        Write-Detail "Email Notify    : $($n.SendEmail)"
        Write-Detail "Email Addresses : $($e.EmailAddresses)"
        Write-Detail "On Success      : $($e.NotifyOnSuccess)"
        Write-Detail "On Warning      : $($e.NotifyOnWarning)"
        Write-Detail "On Failure      : $(try { $e.NotifyOnError } catch { $e.NotifyOnFailure })"
        Write-Detail "Subject         : $(try { $e.NotificationSubject } catch { try { $e.Subject } catch { 'N/A' } })"
    } catch { Write-Warn "Could not read current notification settings: $_" }
    Write-Host ""

    Write-Host "  [1] Enable / Disable Email Notifications"      -ForegroundColor Yellow
    Write-Host "  [2] Set Email Address(es)"                     -ForegroundColor Yellow
    Write-Host "  [3] Set Notify On Success / Warning / Failure" -ForegroundColor Yellow
    Write-Host "  [4] Set Email Subject"                         -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                                    -ForegroundColor DarkGray
    Write-Host ""
    $choice = Read-Host "  Select option"

    $notifOpts = $null; $emailOpts = $null
    try { $notifOpts = $Job.Options.NotificationOptions; $emailOpts = $notifOpts.EmailNotificationOptions }
    catch { Write-Err "Could not access notification options: $_"; return }

    $changes = [ordered]@{}

    switch ($choice) {
        "1" {
            $cur = $notifOpts.SendEmail; $new = -not $cur
            $changes["Email Notify"] = @{ Current = "$cur"; New = "$new" }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                $notifOpts.SendEmail = $new
                Set-VBRJobAdvancedNotificationOptions -Job $Job -Options $notifOpts -ErrorAction Stop
                Log-Change $Job.Name "Email Notify" "$cur" "$new"; Write-Success "Email notifications set to: $new"
            } catch { Write-Err "Failed: $_" }
        }
        "2" {
            $cur = $emailOpts.EmailAddresses; Write-Info "Current: $cur"
            $new = Read-Host "  New email address(es) (comma-separated, or Enter to cancel)"
            if ($new.Trim() -eq "") { Write-Info "Cancelled."; return }
            $changes["Email Addresses"] = @{ Current = "$cur"; New = $new.Trim() }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                $emailOpts.EmailAddresses = $new.Trim()
                Set-VBRJobAdvancedNotificationOptions -Job $Job -Options $notifOpts -ErrorAction Stop
                Log-Change $Job.Name "Email Addresses" "$cur" $new.Trim(); Write-Success "Email addresses updated."
            } catch { Write-Err "Failed: $_" }
        }
        "3" {
            $failProp = try { $null = $emailOpts.NotifyOnError; "NotifyOnError" } catch { "NotifyOnFailure" }
            $curS = $emailOpts.NotifyOnSuccess; $curW = $emailOpts.NotifyOnWarning
            $curF = try { $emailOpts.$failProp } catch { "N/A" }
            $ansS = Read-Host "  Notify on Success?  Current: $curS  (yes/no/skip)"
            $ansW = Read-Host "  Notify on Warning?  Current: $curW  (yes/no/skip)"
            $ansF = Read-Host "  Notify on Failure?  Current: $curF  (yes/no/skip)"
            $newS = if ($ansS -eq "yes") { $true } elseif ($ansS -eq "no") { $false } else { $curS }
            $newW = if ($ansW -eq "yes") { $true } elseif ($ansW -eq "no") { $false } else { $curW }
            $newF = if ($ansF -eq "yes") { $true } elseif ($ansF -eq "no") { $false } else { $curF }
            $changes["Notify On Success"] = @{ Current = "$curS"; New = "$newS" }
            $changes["Notify On Warning"] = @{ Current = "$curW"; New = "$newW" }
            $changes["Notify On Failure"] = @{ Current = "$curF"; New = "$newF" }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                $emailOpts.NotifyOnSuccess = $newS; $emailOpts.NotifyOnWarning = $newW
                try { $emailOpts.NotifyOnError = $newF } catch { $emailOpts.NotifyOnFailure = $newF }
                Set-VBRJobAdvancedNotificationOptions -Job $Job -Options $notifOpts -ErrorAction Stop
                Log-Change $Job.Name "Notify Triggers" "S:$curS W:$curW F:$curF" "S:$newS W:$newW F:$newF"
                Write-Success "Notification triggers updated."
            } catch { Write-Err "Failed: $_" }
        }
        "4" {
            $subjProp = try { $null = $emailOpts.NotificationSubject; "NotificationSubject" } catch { "Subject" }
            $cur = try { $emailOpts.$subjProp } catch { "N/A" }; Write-Info "Current subject: $cur"
            $new = Read-Host "  New subject (variables: %JobName%, %JobResult%, %JobDuration%)"
            if ($new.Trim() -eq "") { Write-Info "Cancelled."; return }
            $changes["Email Subject"] = @{ Current = "$cur"; New = $new.Trim() }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                $emailOpts.$subjProp = $new.Trim()
                Set-VBRJobAdvancedNotificationOptions -Job $Job -Options $notifOpts -ErrorAction Stop
                Log-Change $Job.Name "Email Subject" "$cur" $new.Trim(); Write-Success "Subject updated."
            } catch { Write-Err "Failed: $_" }
        }
        default { Write-Info "Cancelled." }
    }
}

# ---- Edit: Advanced (Compression / Storage / App-Aware / Suffix) ---

function Edit-ReplicationAdvanced {
    param($Job)
    Write-Header "Edit Advanced Settings: $($Job.Name)"

    try {
        $opts = $Job.Options.BackupStorageOptions
        Write-SubHeader "Current Advanced Settings"
        Write-Detail "Compression    : $($opts.CompressionLevel)"
        Write-Detail "Storage Opt    : $($opts.StgBlockSize)"
        Write-Detail "App-Aware      : $(try { $Job.Options.ViGuestOptions.IsUseGuestAgent } catch { 'N/A' })"
        Write-Detail "Replica Suffix : $(try { $Job.Options.GenerationPolicy.ReplicaNameSuffix } catch { 'N/A' })"
    } catch { Write-Warn "Could not read all current settings." }
    Write-Host ""

    Write-Host "  [1] Compression Level"            -ForegroundColor Yellow
    Write-Host "  [2] Storage Optimization"         -ForegroundColor Yellow
    Write-Host "  [3] Application-Aware Processing" -ForegroundColor Yellow
    Write-Host "  [4] Replica Name Suffix"          -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                       -ForegroundColor DarkGray
    Write-Host ""
    $choice = Read-Host "  Select option"

    $changes = [ordered]@{}

    switch ($choice) {
        "1" {
            $cur = try { "$($Job.Options.BackupStorageOptions.CompressionLevel)" } catch { "N/A" }; Write-Info "Current: $cur"
            Write-Host "  Levels: None  DedupeFriendly  Optimal  High  Extreme" -ForegroundColor Gray
            $new = Read-Host "  New compression level (or Enter to cancel)"
            if ($new.Trim() -eq "") { return }
            if ($new.Trim() -notin @("None","DedupeFriendly","Optimal","High","Extreme")) { Write-Err "Invalid level."; return }
            $changes["Compression"] = @{ Current = $cur; New = $new.Trim() }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                Set-VBRJobAdvancedBackupOptions -Job $Job -CompressionLevel $new.Trim() -ErrorAction Stop
                Log-Change $Job.Name "Compression" $cur $new.Trim(); Write-Success "Compression set to: $($new.Trim())"
            } catch { Write-Err "Failed: $_" }
        }
        "2" {
            $cur = try { "$($Job.Options.BackupStorageOptions.StgBlockSize)" } catch { "N/A" }; Write-Info "Current: $cur"
            Write-Host "  Local = >16MB blocks  |  Lan = 512KB  |  Wan = 256KB (recommended for replication)" -ForegroundColor Gray
            $new = Read-Host "  New storage optimization: Local / Lan / Wan (or Enter to cancel)"
            if ($new.Trim() -eq "") { return }
            if ($new.Trim() -notin @("Local","Lan","Wan")) { Write-Err "Invalid option."; return }
            $changes["Storage Opt"] = @{ Current = $cur; New = $new.Trim() }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                Set-VBRJobAdvancedBackupOptions -Job $Job -StorageOptimization $new.Trim() -ErrorAction Stop
                Log-Change $Job.Name "Storage Opt" $cur $new.Trim(); Write-Success "Storage optimization set to: $($new.Trim())"
            } catch { Write-Err "Failed: $_" }
        }
        "3" {
            $cur = try { "$($Job.Options.ViGuestOptions.IsUseGuestAgent)" } catch { "N/A" }
            $new = if ($cur -eq "True") { $false } else { $true }
            $changes["App-Aware Processing"] = @{ Current = $cur; New = "$new" }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                Set-VBRJobAdvancedViGuestOptions -Job $Job -UseGuestAgent $new -ErrorAction Stop
                Log-Change $Job.Name "App-Aware" $cur "$new"; Write-Success "App-aware processing set to: $new"
            } catch { Write-Err "Failed: $_" }
        }
        "4" {
            $cur = try { "$($Job.Options.GenerationPolicy.ReplicaNameSuffix)" } catch { "N/A" }
            Write-Info "Current suffix: $cur  (appended to VM name, e.g. VM_Replica)"
            $new = Read-Host "  New suffix (or Enter to cancel)"
            if ($new.Trim() -eq "") { return }
            $changes["Replica Suffix"] = @{ Current = $cur; New = $new.Trim() }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                if ($Job.JobType -eq "Replica") { Set-VBRViReplicaJob -Job $Job -Suffix $new.Trim() -ErrorAction Stop }
                else {
                    $jobOpts = Get-VBRJobOptions -Job $Job -ErrorAction Stop
                    $jobOpts.GenerationPolicy.ReplicaNameSuffix = $new.Trim()
                    Set-VBRJobOptions -Job $Job -Options $jobOpts -ErrorAction Stop
                }
                Log-Change $Job.Name "Replica Suffix" $cur $new.Trim(); Write-Success "Replica suffix set to: $($new.Trim())"
            } catch { Write-Err "Failed: $_" }
        }
        default { Write-Info "Cancelled." }
    }
}

# ---- Edit: Proxies & Target Host ---------------------------

function Edit-ReplicationProxies {
    param($Job)
    Write-Header "Edit Proxies & Target: $($Job.Name)"

    try {
        Write-SubHeader "Current Settings"
        Write-Detail "Source Proxy : $(try { ($Job.GetSourceProxies() | Select-Object -First 1).Name } catch { 'Automatic' })"
        Write-Detail "Target Proxy : $(try { ($Job.GetTargetProxies() | Select-Object -First 1).Name } catch { 'Automatic' })"
        Write-Detail "Target Host  : $(try { $Job.GetTargetHost().Name } catch { 'N/A' })"
    } catch {}
    Write-Host ""

    Write-Host "  [1] Change Source Proxy"                  -ForegroundColor Yellow
    Write-Host "  [2] Change Target Proxy"                  -ForegroundColor Yellow
    Write-Host "  [3] Change Target Host (ESXi / Cluster)"  -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                               -ForegroundColor DarkGray
    Write-Host ""
    $choice = Read-Host "  Select option"

    $changes = [ordered]@{}

    switch ($choice) {
        "1" {
            $proxies = @(Get-VBRViProxy | Sort-Object Name)
            if ($proxies.Count -eq 0) { Write-Err "No proxies found."; return }
            Write-Host ("  {0,-4} {1,-40} {2}" -f "#","Proxy Name","Type") -ForegroundColor White
            Write-Host ("  {0,-4} {1,-40} {2}" -f "----","----------","----") -ForegroundColor DarkGray
            for ($i = 0; $i -lt $proxies.Count; $i++) { Write-Host ("  {0,-4} {1,-40} {2}" -f ($i+1), $proxies[$i].Name, $proxies[$i].Type) -ForegroundColor Yellow }
            Write-Host "  [0] Automatic"; Write-Host ""
            $cur = try { ($Job.GetSourceProxies() | Select-Object -First 1).Name } catch { "Automatic" }
            do { $sel = Read-Host "  Select source proxy (1-$($proxies.Count), 0 for Automatic)" } while ($sel -notmatch '^\d+$' -or [int]$sel -gt $proxies.Count)
            $newProxy = if ([int]$sel -eq 0) { $null } else { $proxies[[int]$sel - 1] }
            $newName  = if ($null -eq $newProxy) { "Automatic" } else { $newProxy.Name }
            $changes["Source Proxy"] = @{ Current = $cur; New = $newName }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                if ($null -eq $newProxy) { Set-VBRViReplicaJob -Job $Job -AutoSourceProxy -ErrorAction Stop }
                else                     { Set-VBRViReplicaJob -Job $Job -SourceProxy $newProxy -ErrorAction Stop }
                Log-Change $Job.Name "Source Proxy" $cur $newName; Write-Success "Source proxy set to: $newName"
            } catch { Write-Err "Failed: $_" }
        }
        "2" {
            $proxies = @(Get-VBRViProxy | Sort-Object Name)
            if ($proxies.Count -eq 0) { Write-Err "No proxies found."; return }
            Write-Host ("  {0,-4} {1,-40} {2}" -f "#","Proxy Name","Type") -ForegroundColor White
            Write-Host ("  {0,-4} {1,-40} {2}" -f "----","----------","----") -ForegroundColor DarkGray
            for ($i = 0; $i -lt $proxies.Count; $i++) { Write-Host ("  {0,-4} {1,-40} {2}" -f ($i+1), $proxies[$i].Name, $proxies[$i].Type) -ForegroundColor Yellow }
            Write-Host "  [0] Automatic"; Write-Host ""
            $cur = try { ($Job.GetTargetProxies() | Select-Object -First 1).Name } catch { "Automatic" }
            do { $sel = Read-Host "  Select target proxy (1-$($proxies.Count), 0 for Automatic)" } while ($sel -notmatch '^\d+$' -or [int]$sel -gt $proxies.Count)
            $newProxy = if ([int]$sel -eq 0) { $null } else { $proxies[[int]$sel - 1] }
            $newName  = if ($null -eq $newProxy) { "Automatic" } else { $newProxy.Name }
            $changes["Target Proxy"] = @{ Current = $cur; New = $newName }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                if ($null -eq $newProxy) { Set-VBRViReplicaJob -Job $Job -AutoTargetProxy -ErrorAction Stop }
                else                     { Set-VBRViReplicaJob -Job $Job -TargetProxy $newProxy -ErrorAction Stop }
                Log-Change $Job.Name "Target Proxy" $cur $newName; Write-Success "Target proxy set to: $newName"
            } catch { Write-Err "Failed: $_" }
        }
        "3" {
            $hosts = @(Get-VBRServer | Where-Object { $_.Type -in @("ESXi","VC","HvServer","HvCluster") } | Sort-Object Name)
            if ($hosts.Count -eq 0) { Write-Err "No target hosts found."; return }
            Write-Host ("  {0,-4} {1,-42} {2}" -f "#","Host Name","Type") -ForegroundColor White
            Write-Host ("  {0,-4} {1,-42} {2}" -f "----","---------","----") -ForegroundColor DarkGray
            for ($i = 0; $i -lt $hosts.Count; $i++) { Write-Host ("  {0,-4} {1,-42} {2}" -f ($i+1), $hosts[$i].Name, $hosts[$i].Type) -ForegroundColor Yellow }
            Write-Host ""
            $cur = try { $Job.GetTargetHost().Name } catch { "N/A" }; Write-Info "Current: $cur"
            do {
                $sel = Read-Host "  Select new target host (1-$($hosts.Count), 0 to cancel)"
                if ($sel -eq "0") { return }
            } while ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $hosts.Count)
            $newHost = $hosts[[int]$sel - 1]
            $changes["Target Host"] = @{ Current = $cur; New = $newHost.Name }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                Set-VBRViReplicaJob -Job $Job -Server $newHost -ErrorAction Stop
                Log-Change $Job.Name "Target Host" $cur $newHost.Name; Write-Success "Target host set to: $($newHost.Name)"
            } catch { Write-Err "Failed: $_" }
        }
        default { Write-Info "Cancelled." }
    }
}

# ---- Edit: Network Mapping ---------------------------------

function Edit-ReplicationNetworkMap {
    param($Job)
    Write-Header "Edit Network Mapping: $($Job.Name)"

    if ($Job.JobType -ne "Replica") { Write-Warn "Network mapping is only supported for VMware replication jobs."; return }

    Write-SubHeader "Current Network Mappings"
    $existingMaps = @()
    try {
        $existingMaps = @(Get-VBRViNetworkMappingRule -Job $Job -ErrorAction SilentlyContinue)
        if ($existingMaps.Count -eq 0) {
            Write-Info "No network mappings configured."
        } else {
            Write-Host ("  {0,-4} {1,-36} {2}" -f "#","Source Network","Target Network") -ForegroundColor White
            Write-Host ("  {0,-4} {1,-36} {2}" -f "----","---------------","---------------") -ForegroundColor DarkGray
            for ($i = 0; $i -lt $existingMaps.Count; $i++) {
                Write-Host ("  {0,-4} {1,-36} {2}" -f ($i+1), $existingMaps[$i].SourceNetwork, $existingMaps[$i].TargetNetwork) -ForegroundColor Cyan
            }
        }
    } catch { Write-Warn "Could not retrieve network mappings: $_" }
    Write-Host ""

    Write-Host "  [1] Add a new network mapping"  -ForegroundColor Yellow
    Write-Host "  [2] Remove a network mapping"   -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                     -ForegroundColor DarkGray
    Write-Host ""
    $choice = Read-Host "  Select option"

    switch ($choice) {
        "1" {
            Write-SubHeader "Add Network Mapping"
            $srcNet = (Read-Host "  Source network (port group on source host, e.g. 'VM Network')").Trim()
            if ($srcNet -eq "") { Write-Info "Cancelled."; return }
            $tgtNet = (Read-Host "  Target network (port group on target host, e.g. 'VM Network Replica')").Trim()
            if ($tgtNet -eq "") { Write-Info "Cancelled."; return }
            $changes = [ordered]@{ "New Mapping" = @{ Current = "(none)"; New = "$srcNet -> $tgtNet" } }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                New-VBRViNetworkMappingRule -Job $Job -SourceNetwork $srcNet -TargetNetwork $tgtNet -ErrorAction Stop
                Log-Change $Job.Name "Network Map (Add)" "(none)" "$srcNet -> $tgtNet"
                Write-Success "Mapping added: $srcNet -> $tgtNet"
            } catch { Write-Err "Failed: $_" }
        }
        "2" {
            if ($existingMaps.Count -eq 0) { Write-Info "No mappings to remove."; return }
            do {
                $sel = Read-Host "  Select mapping to remove (1-$($existingMaps.Count), 0 to cancel)"
                if ($sel -eq "0") { return }
            } while ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $existingMaps.Count)
            $mapToRemove = $existingMaps[[int]$sel - 1]
            $mapDesc     = "$($mapToRemove.SourceNetwork) -> $($mapToRemove.TargetNetwork)"
            $changes = [ordered]@{ "Remove Mapping" = @{ Current = $mapDesc; New = "(removed)" } }
            if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
            try {
                Remove-VBRViNetworkMappingRule -Rule $mapToRemove -ErrorAction Stop
                Log-Change $Job.Name "Network Map (Remove)" $mapDesc "(removed)"
                Write-Success "Mapping removed: $mapDesc"
            } catch { Write-Err "Failed: $_" }
        }
        default { Write-Info "Cancelled." }
    }
}

# ---- Edit: Source Type (Production vs. Backup) -------------

function Edit-ReplicationSource {
    param($Job)
    Write-Header "Edit Source Type: $($Job.Name)"

    $currentSrcType = try { $Job.SourceType } catch { "Unknown" }
    $isFromBackup   = ($currentSrcType -ne "VDDK" -and $currentSrcType -ne "San" -and $currentSrcType -ne "Unknown")

    Write-Info "Current source type : $currentSrcType"
    if ($isFromBackup) {
        Write-Info "Job appears to be replicating FROM BACKUP."
    } else {
        Write-Info "Job appears to be replicating FROM PRODUCTION (direct from VM)."
    }
    Write-Host ""
    Write-Host "  [1] Production  - replicate directly from the live VM"    -ForegroundColor Yellow
    Write-Host "  [2] From Backup - replicate using a backup as the source"  -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                                                -ForegroundColor DarkGray
    Write-Host ""
    $choice = Read-Host "  Select"
    if ($choice -eq "0") { Write-Info "Cancelled."; return }
    if ($choice -notin @("1","2")) { Write-Info "Invalid selection."; return }

    if ($choice -eq "1") {
        $changes = [ordered]@{
            "Source Type" = @{ Current = $currentSrcType; New = "Production (VDDK)" }
        }
        if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
        try {
            Set-VBRViReplicaJob -Job $Job -ReplicateFromBackup:$false -ErrorAction Stop
            Log-Change $Job.Name "Source Type" $currentSrcType "Production (VDDK)"
            Write-Success "Source changed to production. Job will replicate directly from the live VM."
        } catch { Write-Err "Failed to change source type: $_" }
        return
    }

    # -- choice 2: from backup --
    Write-Host ""
    Write-Host "  Select the backup repository that holds the source backups." -ForegroundColor White
    $repos = @(Get-VBRBackupRepository | Sort-Object Name)
    if ($repos.Count -eq 0) { Write-Err "No backup repositories found."; return }

    Write-Host ""
    Write-Host ("  {0,-4} {1,-40} {2}" -f "#", "Repository Name", "Type") -ForegroundColor White
    Write-Host ("  {0,-4} {1,-40} {2}" -f "----", "---------------", "----") -ForegroundColor DarkGray
    for ($i = 0; $i -lt $repos.Count; $i++) {
        Write-Host ("  {0,-4} {1,-40} {2}" -f ($i+1), $repos[$i].Name, $repos[$i].Type) -ForegroundColor Yellow
    }
    Write-Host ""
    do {
        $rSel = Read-Host "  Select repository (1-$($repos.Count), 0 to cancel)"
        if ($rSel -eq "0") { Write-Info "Cancelled."; return }
    } while ($rSel -notmatch '^\d+$' -or [int]$rSel -lt 1 -or [int]$rSel -gt $repos.Count)

    $srcRepo = $repos[[int]$rSel - 1]

    $changes = [ordered]@{
        "Source Type"       = @{ Current = $currentSrcType;     New = "Backup" }
        "Source Repository" = @{ Current = "(none)";            New = $srcRepo.Name }
    }
    if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }

    try {
        Set-VBRViReplicaJob -Job $Job -ReplicateFromBackup -SourceRepository @($srcRepo) -ErrorAction Stop
        Log-Change $Job.Name "Source Type" $currentSrcType "Backup: $($srcRepo.Name)"
        Write-Success "Source changed to backup. Repository: $($srcRepo.Name)"
        Write-Warn "NOTE: Ensure the VMs in this job have valid restore points in the selected repository."
    } catch { Write-Err "Failed to change source type: $_" }
}

# ---- Single Job Editor Menu --------------------------------

function Invoke-EditSingleReplicationJob {
    Write-Header "Edit Single Replication Job"
    $job = Select-SingleReplicationJob -Prompt "Select replication job to edit"
    if ($null -eq $job) { return }

    $before = Get-ReplicationSnapshot -Job $job

    do {
        try { $job = Get-VBRJob -Name $job.Name -WarningAction SilentlyContinue } catch {}

        Clear-Host
        Write-Header "Editing Replication: $($job.Name)"

        $type     = if ($job.JobType -eq "HvReplica") { "Hyper-V Replication" } else { "VMware Replication" }
        $tgtHost  = try { $job.GetTargetHost().Name } catch { "N/A" }
        $suffix   = try { $job.Options.GenerationPolicy.ReplicaNameSuffix } catch { "N/A" }
        $pts      = try {
            $v = $job.Options.GenerationPolicy.RestorePointsToKeep
            if ($null -eq $v -or $v -eq 0) { $job.Options.BackupStorageOptions.RetainCycles } else { $v }
        } catch { "N/A" }
        $compress = try { $job.Options.BackupStorageOptions.CompressionLevel } catch { "N/A" }
        $appAware = try { $job.Options.ViGuestOptions.IsUseGuestAgent } catch { "N/A" }
        $sched    = try { (Get-VBRJobScheduleOptions -Job $job).ScheduleType } catch { "N/A" }
        $email    = try { $job.Options.NotificationOptions.SendEmail } catch { "N/A" }

        Write-Detail "Type         : $type"
        Write-Detail "Target Host  : $tgtHost"
        Write-Detail "Replica Sfx  : $suffix"
        Write-Detail "Restore Pts  : $pts"
        Write-Detail "Compression  : $compress"
        Write-Detail "App-Aware    : $appAware"
        Write-Detail "Schedule     : $sched  (Enabled: $($job.IsScheduleEnabled))"
        Write-Detail "Email Notify : $email"
        Write-Host ""

        $schedState = if ($job.IsScheduleEnabled) { "ENABLED" } else { "DISABLED" }
        $srcType    = try { $job.SourceType } catch { "Unknown" }
        $diskType   = try { $job.ViReplicaTargetOptions.DiskCreationMode } catch { "N/A" }
        Write-Host "  [1]  Retention (Restore Points)"              -ForegroundColor Yellow
        Write-Host "  [2]  Schedule"                                -ForegroundColor Yellow
        Write-Host "  [3]  Advanced (Compression / Storage / App-Aware / Suffix)" -ForegroundColor Yellow
        Write-Host "  [4]  Notifications / Email"                   -ForegroundColor Yellow
        Write-Host "  [5]  Proxies & Target Host"                   -ForegroundColor Yellow
        Write-Host "  [6]  Network Mapping"                         -ForegroundColor Yellow
        Write-Host "  [7]  Show Before / After Comparison"          -ForegroundColor Cyan
        Write-Host "  [8]  Enable / Disable Job  (currently: $schedState)" `
            -ForegroundColor $(if ($job.IsScheduleEnabled) { "Green" } else { "Red" })
        Write-Host "  [9]  Source Type  (currently: $srcType)"      -ForegroundColor Yellow
        Write-Host "  [10] Target Repository"                        -ForegroundColor Yellow
        Write-Host "  [11] Disk Type  (currently: $diskType)"        -ForegroundColor Yellow
        Write-Host "  [12] WAN Accelerator"                          -ForegroundColor Yellow
        Write-Host "  [13] Seeding"                                  -ForegroundColor Yellow
        Write-Host "  [0]  Finish & Return"                          -ForegroundColor DarkGray
        Write-Host ""

        $editChoice = Read-Host "  Select option"

        switch ($editChoice) {
            "1"  { Edit-ReplicationRetention           -Job $job; Pause-Screen }
            "2"  { Edit-ReplicationSchedule            -Job $job; Pause-Screen }
            "3"  { Edit-ReplicationAdvanced            -Job $job; Pause-Screen }
            "4"  { Edit-ReplicationNotifications       -Job $job; Pause-Screen }
            "5"  { Edit-ReplicationProxies             -Job $job; Pause-Screen }
            "6"  { Edit-ReplicationNetworkMap          -Job $job; Pause-Screen }
            "7"  {
                try { $jobRefresh = Get-VBRJob -Name $job.Name -WarningAction SilentlyContinue } catch { $jobRefresh = $job }
                $after = Get-ReplicationSnapshot -Job $jobRefresh
                Show-Comparison -JobName $job.Name -Before $before -After $after
                Pause-Screen
            }
            "8"  {
                $disable = $job.IsScheduleEnabled
                $changes = [ordered]@{ "Job Enabled" = @{ Current = "$($job.IsScheduleEnabled)"; New = "$(-not $job.IsScheduleEnabled)" } }
                if (Show-PendingChangesWindow -JobName $job.Name -Changes $changes) {
                    Invoke-ToggleJobEnabled -Job $job -Disable $disable | Out-Null
                }
                Pause-Screen
            }
            "9"  { Edit-ReplicationSource              -Job $job; Pause-Screen }
            "10" { Edit-ReplicationTargetRepository    -Job $job; Pause-Screen }
            "11" { Edit-ReplicationDiskType            -Job $job; Pause-Screen }
            "12" { Edit-ReplicationWanAccelerator      -Job $job; Pause-Screen }
            "13" { Edit-ReplicationSeeding             -Job $job; Pause-Screen }
            "0"  {
                Write-Host ""
                try { $jobFinal = Get-VBRJob -Name $job.Name -WarningAction SilentlyContinue } catch { $jobFinal = $job }
                $after = Get-ReplicationSnapshot -Job $jobFinal
                Show-Comparison -JobName $job.Name -Before $before -After $after
                Pause-Screen
                return
            }
            default { Write-Err "Invalid option."; Start-Sleep -Seconds 1 }
        }

    } while ($true)
}

# ---- Mass Edit Operations ----------------------------------

function Invoke-MassEditReplicationRetention {
    Write-Header "Mass Edit Replication: Retention (Restore Points)"

    $jobs = @(Select-MassEditReplicationJobs)
    if ($jobs.Count -eq 0) { return }

    Write-Host ""
    do {
        $rawIn = Read-Host "  New restore point count for ALL selected jobs (1-28, 0 to cancel)"
        if ($rawIn -eq "0") { Write-Info "Cancelled."; return }
    } while ($rawIn -notmatch '^\d+$' -or [int]$rawIn -lt 1 -or [int]$rawIn -gt 28)
    $newRetain = [int]$rawIn

    $confirmed = Show-MassEditPreview -Jobs $jobs -SettingName "Restore Points" `
        -GetCurrent {
            param($Job)
            try {
                $v = $Job.Options.GenerationPolicy.RestorePointsToKeep
                if ($null -eq $v -or $v -eq 0) { "$($Job.Options.BackupStorageOptions.RetainCycles)" } else { "$v" }
            } catch { "N/A" }
        } -NewValue "$newRetain"

    if (-not $confirmed) { Write-Info "Aborted  - no changes made."; return }

    Write-Host ""; Write-Info "Phase 1 of 3: Disabling enabled jobs..."
    $disabledJobs = [System.Collections.Generic.List[object]]::new()
    foreach ($job in $jobs) {
        $wasEnabled = $false; try { $wasEnabled = $job.IsScheduleEnabled } catch {}
        if ($wasEnabled) {
            try { Disable-VBRJob -Job $job -ErrorAction Stop; $disabledJobs.Add($job); Write-Detail "  Disabled : $($job.Name)" }
            catch { Write-Warn "  Could not disable '$($job.Name)': $_" }
        }
    }

    Write-Host ""; Write-Info "Phase 2 of 3: Applying retention..."
    $results = [System.Collections.Generic.List[hashtable]]::new()
    foreach ($job in $jobs) {
        $before = try { $v = $job.Options.GenerationPolicy.RestorePointsToKeep; if ($null -eq $v -or $v -eq 0) { "$($job.Options.BackupStorageOptions.RetainCycles)" } else { "$v" } } catch { "N/A" }
        $saved  = $false
        try {
            $opts = Get-VBRJobOptions -Job $job -ErrorAction Stop
            $opts.GenerationPolicy.RestorePointsToKeep = $newRetain
            Set-VBRJobOptions -Job $job -Options $opts -ErrorAction Stop; $saved = $true
        } catch {
            try {
                $opts = Get-VBRJobOptions -Job $job -ErrorAction Stop
                $opts.BackupStorageOptions.RetainCycles = $newRetain
                Set-VBRJobOptions -Job $job -Options $opts -ErrorAction Stop; $saved = $true
            } catch {}
        }
        if ($saved) {
            Log-Change $job.Name "Restore Points (Mass-Replication)" $before "$newRetain"
            $results.Add(@{ JobName = $job.Name; Before = $before; After = "$newRetain"; Status = "SUCCESS"; Error = "" })
            Write-Detail "  Applied  : $($job.Name)  ($before -> $newRetain)"
        } else {
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $before; Status = "FAILED"; Error = "All save methods failed" })
            Write-Detail "  Failed   : $($job.Name)"
        }
    }

    Write-Host ""; Write-Info "Phase 3 of 3: Re-enabling previously enabled jobs..."
    foreach ($job in $disabledJobs) {
        try { Enable-VBRJob -Job $job -ErrorAction Stop; Write-Detail "  Enabled  : $($job.Name)" }
        catch { Write-Warn "  Re-enable failed for '$($job.Name)': $_" }
    }

    Write-Host ""; Write-Header "Mass Edit Replication Retention  - Results"
    Show-MassEditSummary -Results $results -SettingName "Restore Points"
}

function Invoke-MassEditReplicationSchedule {
    Write-Header "Mass Edit Replication: Schedule"

    $jobs = @(Select-MassEditReplicationJobs)
    if ($jobs.Count -eq 0) { return }

    Write-Host ""
    Write-Host "  [1] Daily"        -ForegroundColor Yellow
    Write-Host "  [2] Weekly"       -ForegroundColor Yellow
    Write-Host "  [3] Monthly"      -ForegroundColor Yellow
    Write-Host "  [4] Continuously" -ForegroundColor Yellow
    Write-Host "  [0] Cancel"       -ForegroundColor DarkGray
    Write-Host ""
    $schedChoice = Read-Host "  Select schedule type"
    if ($schedChoice -eq "0") { Write-Info "Cancelled."; return }
    if ($schedChoice -notin @("1","2","3","4")) { Write-Info "Invalid selection."; return }

    function Read-TimeMassRepl {
        $t = ""
        do { $t = Read-Host "  Run at time (HH:mm)" } while ($t -notmatch '^\d{2}:\d{2}$')
        return [datetime]::ParseExact($t, "HH:mm", $null)
    }

    $schedRunAt = $null; $schedDays = @(); $schedOccur = ""; $schedDow = ""; $schedMonths = @(); $schedDesc = ""
    switch ($schedChoice) {
        "1" { $schedRunAt = Read-TimeMassRepl; $schedDesc = "Daily at $($schedRunAt.ToString('HH:mm'))" }
        "2" {
            $schedRunAt = Read-TimeMassRepl
            Write-Host "  Days: Monday Tuesday Wednesday Thursday Friday Saturday Sunday" -ForegroundColor Gray
            $d = Read-Host "  Day(s), comma-separated"
            $schedDays = @($d -split "," | ForEach-Object { $_.Trim() })
            $schedDesc = "Weekly $($schedDays -join ',') @ $($schedRunAt.ToString('HH:mm'))"
        }
        "3" {
            $schedRunAt = Read-TimeMassRepl
            Write-Host "  Occurrence: First Second Third Fourth Last" -ForegroundColor Gray
            $schedOccur = Read-Host "  Occurrence"
            Write-Host "  Day: Monday Tuesday Wednesday Thursday Friday Saturday Sunday" -ForegroundColor Gray
            $schedDow   = Read-Host "  Day of week"
            $mIn        = Read-Host "  Month(s) comma-separated or 'all'"
            $schedMonths = if ($mIn.Trim().ToLower() -eq "all") {
                @("January","February","March","April","May","June","July","August","September","October","November","December")
            } else { @($mIn -split "," | ForEach-Object { $_.Trim() }) }
            $schedDesc = "Monthly $schedOccur $schedDow @ $($schedRunAt.ToString('HH:mm'))"
        }
        "4" { $schedDesc = "Continuously" }
    }

    $confirmed = Show-MassEditPreview -Jobs $jobs -SettingName "Schedule" `
        -GetCurrent { param($Job) try { (Get-VBRJobScheduleOptions -Job $Job).ScheduleType } catch { "N/A" } } `
        -NewValue $schedDesc

    if (-not $confirmed) { Write-Info "Aborted  - no changes made."; return }

    Write-Host ""; Write-Info "Applying schedule to $($jobs.Count) job(s)..."
    $results = [System.Collections.Generic.List[hashtable]]::new()
    foreach ($job in $jobs) {
        $before = try { (Get-VBRJobScheduleOptions -Job $job).ScheduleType } catch { "N/A" }
        try {
            switch ($schedChoice) {
                "1" { Set-VBRJobScheduleOptions -Job $job -Type Daily        -At $schedRunAt -ErrorAction Stop }
                "2" { Set-VBRJobScheduleOptions -Job $job -Type Weekly       -At $schedRunAt -Days $schedDays -ErrorAction Stop }
                "3" { Set-VBRJobScheduleOptions -Job $job -Type Monthly      -At $schedRunAt -Months $schedMonths -DayOfMonth $schedOccur -DayOfWeek $schedDow -ErrorAction Stop }
                "4" { Set-VBRJobScheduleOptions -Job $job -Type Continuously -ErrorAction Stop }
            }
            Log-Change $job.Name "Schedule (Mass-Replication)" $before $schedDesc
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $schedDesc; Status = "SUCCESS"; Error = "" })
            Write-Detail "  Applied : $($job.Name)"
        } catch {
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $before; Status = "FAILED"; Error = "$_" })
            Write-Detail "  Failed  : $($job.Name): $_"
        }
    }

    Write-Host ""; Write-Header "Mass Edit Replication Schedule  - Results"
    Show-MassEditSummary -Results $results -SettingName "Schedule"
}

function Invoke-MassEditReplicationToggle {
    param([bool]$Disable)
    $action = if ($Disable) { "Disable" } else { "Enable" }
    Write-Header "Mass Edit Replication: $action All Selected Jobs"

    $jobs = @(Select-MassEditReplicationJobs)
    if ($jobs.Count -eq 0) { return }

    $confirmed = Show-MassEditPreview -Jobs $jobs -SettingName "Job Enabled" `
        -GetCurrent { param($Job) try { "$($Job.IsScheduleEnabled)" } catch { "N/A" } } `
        -NewValue   "$(if ($Disable) { 'False' } else { 'True' })"

    if (-not $confirmed) { Write-Info "Aborted  - no changes made."; return }

    Write-Host ""; Write-Info "Applying to $($jobs.Count) job(s)..."
    $results = [System.Collections.Generic.List[hashtable]]::new()
    foreach ($job in $jobs) {
        $before = try { "$($job.IsScheduleEnabled)" } catch { "N/A" }
        try {
            if ($Disable) { Disable-VBRJob -Job $job -ErrorAction Stop }
            else          { Enable-VBRJob  -Job $job -ErrorAction Stop }
            $after = if ($Disable) { "False" } else { "True" }
            Log-Change $job.Name "Enabled (Mass-Replication)" $before $after
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $after; Status = "SUCCESS"; Error = "" })
            Write-Detail "  $($action)d : $($job.Name)"
        } catch {
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $before; Status = "FAILED"; Error = "$_" })
            Write-Detail "  Failed  : $($job.Name): $_"
        }
    }

    Write-Host ""; Write-Header "Mass $action Replication Jobs  - Results"
    Show-MassEditSummary -Results $results -SettingName "Job Enabled"
}

function Invoke-MassEditReplicationNotifications {
    Write-Header "Mass Edit Replication: Notifications"

    $jobs = @(Select-MassEditReplicationJobs)
    if ($jobs.Count -eq 0) { return }

    Write-Host ""
    Write-Host "  [1] Enable Email Notifications on all selected"  -ForegroundColor Yellow
    Write-Host "  [2] Disable Email Notifications on all selected" -ForegroundColor Yellow
    Write-Host "  [3] Set Email Address(es) on all selected"       -ForegroundColor Yellow
    Write-Host "  [4] Set Email Subject on all selected"           -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                                      -ForegroundColor DarkGray
    Write-Host ""
    $notifChoice = Read-Host "  Select option"
    if ($notifChoice -eq "0") { Write-Info "Cancelled."; return }
    if ($notifChoice -notin @("1","2","3","4")) { Write-Info "Invalid selection."; return }

    $settingName = ""; $newValStr = ""
    switch ($notifChoice) {
        "1" { $settingName = "Email Notify";    $newValStr = "True"  }
        "2" { $settingName = "Email Notify";    $newValStr = "False" }
        "3" { $newValStr = (Read-Host "  New email address(es)").Trim(); if ($newValStr -eq "") { return }; $settingName = "Email Addresses" }
        "4" { $newValStr = (Read-Host "  New email subject (%JobName%, %JobResult%, %JobDuration%)").Trim(); if ($newValStr -eq "") { return }; $settingName = "Email Subject" }
    }

    $getCurrent = switch ($notifChoice) {
        "1" { { param($Job) try { "$($Job.Options.NotificationOptions.SendEmail)" } catch { "N/A" } } }
        "2" { { param($Job) try { "$($Job.Options.NotificationOptions.SendEmail)" } catch { "N/A" } } }
        "3" { { param($Job) try { $Job.Options.NotificationOptions.EmailNotificationOptions.EmailAddresses } catch { "N/A" } } }
        "4" { { param($Job) try { $e = $Job.Options.NotificationOptions.EmailNotificationOptions; try { $e.NotificationSubject } catch { $e.Subject } } catch { "N/A" } } }
    }

    $confirmed = Show-MassEditPreview -Jobs $jobs -SettingName $settingName -GetCurrent $getCurrent -NewValue $newValStr
    if (-not $confirmed) { Write-Info "Aborted  - no changes made."; return }

    Write-Host ""; Write-Info "Applying '$settingName' to $($jobs.Count) job(s)..."
    $results = [System.Collections.Generic.List[hashtable]]::new()
    foreach ($job in $jobs) {
        $before = try { "$(& $getCurrent $job)" } catch { "N/A" }
        try {
            $notif = $job.Options.NotificationOptions; $e = $notif.EmailNotificationOptions
            switch ($notifChoice) {
                "1" { $notif.SendEmail = $true  }
                "2" { $notif.SendEmail = $false }
                "3" { $e.EmailAddresses = $newValStr }
                "4" { try { $e.NotificationSubject = $newValStr } catch { $e.Subject = $newValStr } }
            }
            Set-VBRJobAdvancedNotificationOptions -Job $job -Options $notif -ErrorAction Stop
            Log-Change $job.Name "$settingName (Mass-Replication)" $before $newValStr
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $newValStr; Status = "SUCCESS"; Error = "" })
            Write-Detail "  Applied : $($job.Name)"
        } catch {
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $before; Status = "FAILED"; Error = "$_" })
            Write-Detail "  Failed  : $($job.Name): $_"
        }
    }

    Write-Host ""; Write-Header "Mass Edit Replication Notifications  - Results"
    Show-MassEditSummary -Results $results -SettingName $settingName
}

function Invoke-MassEditReplicationAdvanced {
    Write-Header "Mass Edit Replication: Compression & Storage"

    $jobs = @(Select-MassEditReplicationJobs)
    if ($jobs.Count -eq 0) { return }

    Write-Host ""
    Write-Host "  [1] Compression Level"    -ForegroundColor Yellow
    Write-Host "  [2] Storage Optimization" -ForegroundColor Yellow
    Write-Host "  [0] Cancel"               -ForegroundColor DarkGray
    Write-Host ""
    $advChoice = Read-Host "  Select option"
    if ($advChoice -eq "0") { Write-Info "Cancelled."; return }

    $settingName = ""; $newValStr = ""
    switch ($advChoice) {
        "1" {
            Write-Host "  Levels: None  DedupeFriendly  Optimal  High  Extreme" -ForegroundColor Gray
            $newValStr = (Read-Host "  New compression level").Trim()
            if ($newValStr -notin @("None","DedupeFriendly","Optimal","High","Extreme")) { Write-Err "Invalid level."; return }
            $settingName = "Compression"
        }
        "2" {
            Write-Host "  Options: Local  Lan  Wan" -ForegroundColor Gray
            $newValStr = (Read-Host "  New storage optimization").Trim()
            if ($newValStr -notin @("Local","Lan","Wan")) { Write-Err "Invalid option."; return }
            $settingName = "Storage Opt"
        }
        default { Write-Info "Invalid selection."; return }
    }

    $getCurrent = if ($advChoice -eq "1") {
        { param($Job) try { "$($Job.Options.BackupStorageOptions.CompressionLevel)" } catch { "N/A" } }
    } else {
        { param($Job) try { "$($Job.Options.BackupStorageOptions.StgBlockSize)" } catch { "N/A" } }
    }

    $confirmed = Show-MassEditPreview -Jobs $jobs -SettingName $settingName -GetCurrent $getCurrent -NewValue $newValStr
    if (-not $confirmed) { Write-Info "Aborted  - no changes made."; return }

    Write-Host ""; Write-Info "Applying '$settingName' to $($jobs.Count) job(s)..."
    $results = [System.Collections.Generic.List[hashtable]]::new()
    foreach ($job in $jobs) {
        $before = try { "$(& $getCurrent $job)" } catch { "N/A" }
        try {
            if ($advChoice -eq "1") { Set-VBRJobAdvancedBackupOptions -Job $job -CompressionLevel $newValStr   -ErrorAction Stop }
            else                    { Set-VBRJobAdvancedBackupOptions -Job $job -StorageOptimization $newValStr -ErrorAction Stop }
            Log-Change $job.Name "$settingName (Mass-Replication)" $before $newValStr
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $newValStr; Status = "SUCCESS"; Error = "" })
            Write-Detail "  Applied : $($job.Name)"
        } catch {
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $before; Status = "FAILED"; Error = "$_" })
            Write-Detail "  Failed  : $($job.Name): $_"
        }
    }

    Write-Host ""; Write-Header "Mass Edit Replication $settingName  - Results"
    Show-MassEditSummary -Results $results -SettingName $settingName
}

# ---- Mass Edit Sub-Menu ------------------------------------

function Invoke-MassEditReplicationJobs {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "  +==============================================================+" -ForegroundColor Cyan
        Write-Host "  |         MASS EDIT  - Replication Jobs                         |" -ForegroundColor Cyan
        Write-Host "  |  Every operation previews changes before touching anything.  |" -ForegroundColor Cyan
        Write-Host "  +==============================================================+" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  [1] Mass Edit: Retention (Restore Points)" -ForegroundColor Yellow
        Write-Host "  [2] Mass Edit: Schedule"                   -ForegroundColor Yellow
        Write-Host "  [3] Enable All Selected Jobs"              -ForegroundColor Green
        Write-Host "  [4] Disable All Selected Jobs"             -ForegroundColor Red
        Write-Host "  [5] Mass Edit: Notifications / Email"      -ForegroundColor Yellow
        Write-Host "  [6] Mass Edit: Compression & Storage"      -ForegroundColor Yellow
        Write-Host "  [0] Return to Main Menu"                   -ForegroundColor DarkGray
        Write-Host ""

        $massChoice = Read-Host "  Select option"
        switch ($massChoice) {
            "1" { Invoke-MassEditReplicationRetention;             Pause-Screen }
            "2" { Invoke-MassEditReplicationSchedule;              Pause-Screen }
            "3" { Invoke-MassEditReplicationToggle -Disable $false; Pause-Screen }
            "4" { Invoke-MassEditReplicationToggle -Disable $true;  Pause-Screen }
            "5" { Invoke-MassEditReplicationNotifications;         Pause-Screen }
            "6" { Invoke-MassEditReplicationAdvanced;              Pause-Screen }
            "0" { return }
            default { Write-Err "Invalid option."; Start-Sleep -Seconds 1 }
        }
    } while ($true)
}
