function Invoke-MassEditGfs {
    Write-Header "Mass Edit: GFS Retention"

    $jobs = @(Select-MassEditTargetJobs)
    if ($jobs.Count -eq 0) { return }

    Write-Host ""
    Write-Host "  [1] Enable GFS on all selected"              -ForegroundColor Yellow
    Write-Host "  [2] Disable GFS on all selected"             -ForegroundColor Yellow
    Write-Host "  [3] Configure GFS settings on all selected"  -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                                  -ForegroundColor DarkGray
    Write-Host ""
    $gfsAction = Read-Host "  Select GFS action"
    if ($gfsAction -eq "0") { Write-Info "Cancelled."; return }
    if ($gfsAction -notin @("1","2","3")) { Write-Info "Invalid selection."; return }

    # --- Build gfsParams hashtable and display values ---
    $gfsParams   = @{}
    $settingName = ""
    $newValStr   = ""

    switch ($gfsAction) {
        "1" {
            $settingName = "GFS Enabled"
            $newValStr   = "True"
            $gfsParams   = @{ EnableGfsOptions = $true }
        }
        "2" {
            if (-not (Confirm-Action "Disable GFS on all $($jobs.Count) selected jobs?")) {
                Write-Info "Aborted."
                return
            }
            $settingName = "GFS Enabled"
            $newValStr   = "False"
            $gfsParams   = @{ EnableGfsOptions = $false }
        }
        "3" {
            Write-SubHeader "GFS Weekly Fulls"
            Write-Host "  Days: Monday Tuesday Wednesday Thursday Friday Saturday Sunday" -ForegroundColor Gray
            $weekDay   = Read-Host "  Day of week for weekly full (e.g. Saturday, or Enter to skip)"
            $weekCount = "0"
            if ($weekDay -ne "") {
                do { $weekCount = Read-Host "  Keep how many weekly fulls? (1-52)" } while ($weekCount -notmatch '^\d+$' -or [int]$weekCount -lt 1 -or [int]$weekCount -gt 52)
            }

            Write-SubHeader "GFS Monthly Fulls"
            $monthCount = "0"
            do { $monthCount = Read-Host "  Keep how many monthly fulls? (1-60, 0 to skip)" } while ($monthCount -notmatch '^\d+$' -or [int]$monthCount -gt 60)

            Write-SubHeader "GFS Yearly Fulls"
            $yearMonth = Read-Host "  Month for yearly full (e.g. January, or Enter to skip)"
            $yearCount = "0"
            if ($yearMonth -ne "") {
                do { $yearCount = Read-Host "  Keep how many yearly fulls? (1-99)" } while ($yearCount -notmatch '^\d+$' -or [int]$yearCount -lt 1 -or [int]$yearCount -gt 99)
            }

            $gfsParams = @{ EnableGfsOptions = $true }
            if ($weekDay -ne "" -and [int]$weekCount -gt 0) {
                $gfsParams['WeeklyBackupDayOfWeek'] = [System.DayOfWeek]$weekDay
                $gfsParams['GfsWeeklyBackups']      = [int]$weekCount
            }
            if ([int]$monthCount -gt 0) { $gfsParams['GfsMonthlyBackups'] = [int]$monthCount }
            if ($yearMonth -ne "" -and [int]$yearCount -gt 0) {
                $gfsParams['YearlyBackupMonthOfYear'] = $yearMonth
                $gfsParams['GfsYearlyBackups']        = [int]$yearCount
            }
            $settingName = "GFS Config"
            $newValStr   = "W:$weekCount M:$monthCount Y:$yearCount"
        }
    }

    $confirmed = Show-MassEditPreview -Jobs $jobs -SettingName $settingName `
        -GetCurrent {
            param($Job)
            try { "$($Job.Options.BackupStorageOptions.EnableGfsOptions)" } catch { "N/A" }
        } `
        -NewValue $newValStr

    if (-not $confirmed) { Write-Info "Aborted  - no changes made."; return }

    # ----- Phase 1: Disable -----
    Write-Host ""
    Write-Info "Phase 1 of 3: Disabling enabled jobs for GFS change..."
    $disabledJobs = [System.Collections.Generic.List[object]]::new()
    foreach ($job in $jobs) {
        $wasEnabled = $false
        try { $wasEnabled = $job.IsScheduleEnabled } catch {}
        if ($wasEnabled) {
            try {
                Disable-VBRJob -Job $job -ErrorAction Stop
                $disabledJobs.Add($job)
                Write-Detail "  Disabled : $($job.Name)"
            } catch {
                Write-Warn "  Could not disable '$($job.Name)': $_"
            }
        }
    }

    # ----- Phase 2: Apply -----
    Write-Host ""
    Write-Info "Phase 2 of 3: Applying GFS settings..."
    $results = [System.Collections.Generic.List[hashtable]]::new()
    foreach ($job in $jobs) {
        $before = try { "$($job.Options.BackupStorageOptions.EnableGfsOptions)" } catch { "N/A" }
        try {
            $cmdParams = @{ Job = $job; ErrorAction = "Stop" }
            foreach ($k in $gfsParams.Keys) { $cmdParams[$k] = $gfsParams[$k] }
            Set-VBRJobAdvancedBackupOptions @cmdParams
            Log-Change $job.Name "$settingName (Mass)" $before $newValStr
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $newValStr; Status = "SUCCESS"; Error = "" })
            Write-Detail "  Applied  : $($job.Name)"
        } catch {
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $before; Status = "FAILED"; Error = "$_" })
            Write-Detail "  Failed   : $($job.Name): $_"
        }
    }

    # ----- Phase 3: Re-enable -----
    Write-Host ""
    Write-Info "Phase 3 of 3: Re-enabling previously enabled jobs..."
    foreach ($job in $disabledJobs) {
        try {
            Enable-VBRJob -Job $job -ErrorAction Stop
            Write-Detail "  Enabled  : $($job.Name)"
        } catch {
            Write-Warn "  Re-enable failed for '$($job.Name)': $_"
        }
    }

    Write-Host ""
    Write-Header "Mass Edit GFS  - Results"
    Show-MassEditSummary -Results $results -SettingName $settingName
}
