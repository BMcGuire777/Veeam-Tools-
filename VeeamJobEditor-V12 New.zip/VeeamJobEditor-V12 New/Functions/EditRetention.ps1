function Edit-JobRetention {
    param($Job)
    Write-Header "Edit Retention: $($Job.Name)"

    $cur = try {
        if ($Job.JobType -eq "BackupSync") { $Job.Options.GenerationPolicy.SimpleRetentionRestorePoints }
        else { $Job.Options.BackupStorageOptions.RetainCycles }
    } catch { "Unknown" }
    Write-Info "Current restore points: $cur  (Job type: $(if ($Job.JobType -eq 'BackupSync') {'Backup Copy'} else {'VMware Backup'}))"
    Write-Host ""

    # Veeam v12 requires the job to be disabled before changing retention
    $wasEnabled = $false
    try { $wasEnabled = $Job.IsScheduleEnabled } catch {}

    if ($wasEnabled) {
        Write-Warn "Job is currently ENABLED. Retention changes require disabling the job first."
        if (-not (Confirm-Action "Disable '$($Job.Name)' now to proceed?")) {
            Write-Info "Cancelled  - no changes made."
            return
        }
        $ok = Invoke-ToggleJobEnabled -Job $Job -Disable $true
        if (-not $ok) { Write-Err "Could not disable job. Aborting retention change."; return }
    }

    do {
        $input = Read-Host "  New restore point count (1-999, 0 to cancel)"
        if ($input -eq "0") {
            if ($wasEnabled) {
                Write-Warn "Cancelled. Job is still DISABLED."
                if (Confirm-Action "Re-enable '$($Job.Name)' now?") {
                    Invoke-ToggleJobEnabled -Job $Job -Disable $false | Out-Null
                }
            }
            return
        }
    } while ($input -notmatch '^\d+$' -or [int]$input -lt 1 -or [int]$input -gt 999)

    $newVal = [int]$input
    $saved  = Set-VBRRetentionValue -Job $Job -RetainCycles $newVal
    if ($saved) {
        Log-Change $Job.Name "Restore Points" "$cur" "$newVal"
        Write-Success "Retention set to $newVal restore points."
    }

    if ($wasEnabled) {
        Write-Host ""
        if (Confirm-Action "Re-enable '$($Job.Name)' now?") {
            Invoke-ToggleJobEnabled -Job $Job -Disable $false | Out-Null
        } else {
            Write-Warn "Job remains DISABLED. Use option [7] in the edit menu to re-enable it when ready."
        }
    }
}
