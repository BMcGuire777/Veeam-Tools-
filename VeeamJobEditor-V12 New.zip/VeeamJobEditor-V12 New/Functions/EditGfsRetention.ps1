function Edit-GfsRetention {
    param($Job)
    Write-Header "Edit GFS Retention: $($Job.Name)"

    $gfsOn = $false
    try { $gfsOn = $Job.Options.BackupStorageOptions.EnableGfsOptions } catch {}

    Write-Info "GFS currently: $(if ($gfsOn) { 'ENABLED' } else { 'DISABLED' })"
    if ($gfsOn) {
        try {
            Write-Detail "  Weekly fulls  : $($Job.Options.BackupStorageOptions.GfsWeeklyBackups) (day: $($Job.Options.BackupStorageOptions.WeeklyBackupDayOfWeek))"
            Write-Detail "  Monthly fulls : $($Job.Options.BackupStorageOptions.GfsMonthlyBackups)"
            Write-Detail "  Yearly fulls  : $($Job.Options.BackupStorageOptions.GfsYearlyBackups) (month: $($Job.Options.BackupStorageOptions.YearlyBackupMonthOfYear))"
        } catch {}
    }
    Write-Host ""

    Write-Host "  [1] Enable GFS" -ForegroundColor Yellow
    Write-Host "  [2] Disable GFS" -ForegroundColor Yellow
    Write-Host "  [3] Edit GFS Settings (Weekly / Monthly / Yearly)" -ForegroundColor Yellow
    Write-Host "  [0] Cancel" -ForegroundColor DarkGray
    Write-Host ""
    $choice = Read-Host "  Select option"

    # GFS changes also require the job to be disabled first
    $wasEnabled = $false
    try { $wasEnabled = $Job.IsScheduleEnabled } catch {}

    if ($choice -in @("1","2","3") -and $wasEnabled) {
        Write-Warn "Job is currently ENABLED. GFS changes require disabling the job first."
        if (-not (Confirm-Action "Disable '$($Job.Name)' now to proceed?")) {
            Write-Info "Cancelled  - no changes made."
            return
        }
        $ok = Invoke-ToggleJobEnabled -Job $Job -Disable $true
        if (-not $ok) { Write-Err "Could not disable job. Aborting."; return }
    }

    switch ($choice) {
        "1" {
            try {
                # Veeam v12: use named parameter -EnableGfsOptions
                Set-VBRJobAdvancedBackupOptions -Job $Job -EnableGfsOptions $true -ErrorAction Stop
                Log-Change $Job.Name "GFS Enabled" "$gfsOn" "True"
                Write-Success "GFS enabled. Use option [3] to configure retention counts."
            } catch { Write-Err "Failed: $_" }
        }
        "2" {
            if (Confirm-Action "Disable GFS for '$($Job.Name)'?") {
                try {
                    Set-VBRJobAdvancedBackupOptions -Job $Job -EnableGfsOptions $false -ErrorAction Stop
                    Log-Change $Job.Name "GFS Enabled" "$gfsOn" "False"
                    Write-Success "GFS disabled."
                } catch { Write-Err "Failed: $_" }
            }
        }
        "3" {
            Write-SubHeader "GFS Weekly Fulls"
            Write-Host "  Days: Monday Tuesday Wednesday Thursday Friday Saturday Sunday" -ForegroundColor Gray
            $weekDay   = Read-Host "  Day of week for weekly full (e.g. Saturday, or Enter to skip)"
            $weekCount = ""
            if ($weekDay -ne "") {
                do {
                    $weekCount = Read-Host "  Keep how many weekly fulls? (1-52)"
                } while ($weekCount -notmatch '^\d+$' -or [int]$weekCount -lt 1 -or [int]$weekCount -gt 52)
            }

            Write-SubHeader "GFS Monthly Fulls"
            do {
                $monthCount = Read-Host "  Keep how many monthly fulls? (1-60, 0 to skip)"
            } while ($monthCount -notmatch '^\d+$' -or [int]$monthCount -gt 60)

            Write-SubHeader "GFS Yearly Fulls"
            $yearMonth = Read-Host "  Month for yearly full (e.g. January, or Enter to skip)"
            $yearCount = "0"
            if ($yearMonth -ne "") {
                do {
                    $yearCount = Read-Host "  Keep how many yearly fulls? (1-99)"
                } while ($yearCount -notmatch '^\d+$' -or [int]$yearCount -lt 1 -or [int]$yearCount -gt 99)
            }

            try {
                # Build parameter hashtable so we only pass what the user configured
                $gfsParams = @{ Job = $Job; EnableGfsOptions = $true; ErrorAction = "Stop" }
                if ($weekDay -ne "" -and $weekCount -ne "") {
                    $gfsParams['WeeklyBackupDayOfWeek'] = [System.DayOfWeek]$weekDay
                    $gfsParams['GfsWeeklyBackups']      = [int]$weekCount
                }
                if ([int]$monthCount -gt 0) { $gfsParams['GfsMonthlyBackups'] = [int]$monthCount }
                if ($yearMonth -ne "" -and $yearCount -ne "0") {
                    $gfsParams['YearlyBackupMonthOfYear'] = $yearMonth
                    $gfsParams['GfsYearlyBackups']        = [int]$yearCount
                }
                Set-VBRJobAdvancedBackupOptions @gfsParams
                Log-Change $Job.Name "GFS Settings" "previous" "W:$weekCount M:$monthCount Y:$yearCount"
                Write-Success "GFS settings updated."
            } catch {
                Write-Err "Failed to apply GFS settings: $_"
            }
        }
        default { Write-Info "Cancelled." }
    }

    if ($choice -in @("1","2","3") -and $wasEnabled) {
        Write-Host ""
        if (Confirm-Action "Re-enable '$($Job.Name)' now?") {
            Invoke-ToggleJobEnabled -Job $Job -Disable $false | Out-Null
        } else {
            Write-Warn "Job remains DISABLED. Use option [7] in the edit menu to re-enable it when ready."
        }
    }
}
