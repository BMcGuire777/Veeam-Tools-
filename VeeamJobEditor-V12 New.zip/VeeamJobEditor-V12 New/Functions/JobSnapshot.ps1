function Get-JobSnapshot {
    <#
    Captures a comprehensive ordered hashtable of a job's current settings.
    All reads are wrapped in try/catch so partial failures don't abort the snapshot.
    #>
    param($Job)

    $s = [ordered]@{}

    # --- Identity ---
    $s['Job Name']      = $Job.Name
    $s['Job Type']      = if ($Job.JobType -eq "BackupSync") { "Backup Copy" } else { "VMware Backup" }
    $s['Job Enabled']   = try { $Job.IsScheduleEnabled } catch { "N/A" }

    # --- Repository ---
    $s['Repository']    = try { $Job.GetTargetRepository().Name } catch { "N/A" }

    # --- Simple Retention ---
    # VMware/HV backup jobs: BackupStorageOptions.RetainCycles
    # Backup Copy jobs:      GenerationPolicy.SimpleRetentionRestorePoints
    $s['Restore Points'] = try {
        if ($Job.JobType -eq "BackupSync") {
            $Job.Options.GenerationPolicy.SimpleRetentionRestorePoints
        } else {
            $Job.Options.BackupStorageOptions.RetainCycles
        }
    } catch { "N/A" }

    # --- GFS Retention ---
    try {
        $gfsOn = $Job.Options.BackupStorageOptions.EnableGfsOptions
        $s['GFS Enabled']         = $gfsOn
        $s['GFS Weekly Fulls']    = if ($gfsOn) { $Job.Options.BackupStorageOptions.GfsWeeklyBackups }  else { "Off" }
        $s['GFS Weekly Day']      = if ($gfsOn) { $Job.Options.BackupStorageOptions.WeeklyBackupDayOfWeek } else { "N/A" }
        $s['GFS Monthly Fulls']   = if ($gfsOn) { $Job.Options.BackupStorageOptions.GfsMonthlyBackups } else { "Off" }
        $s['GFS Yearly Fulls']    = if ($gfsOn) { $Job.Options.BackupStorageOptions.GfsYearlyBackups }  else { "Off" }
        $s['GFS Yearly Month']    = if ($gfsOn) { $Job.Options.BackupStorageOptions.YearlyBackupMonthOfYear } else { "N/A" }
    } catch {
        $s['GFS Enabled']       = "N/A"
        $s['GFS Weekly Fulls']  = "N/A"
        $s['GFS Weekly Day']    = "N/A"
        $s['GFS Monthly Fulls'] = "N/A"
        $s['GFS Yearly Fulls']  = "N/A"
        $s['GFS Yearly Month']  = "N/A"
    }

    # --- Schedule ---
    try {
        $sched = Get-VBRJobScheduleOptions -Job $Job
        $s['Schedule Type'] = $sched.ScheduleType
        $s['Schedule Detail'] = switch ($sched.ScheduleType) {
            "Daily"        { "Daily at $($sched.DailyOptions.Period)" }
            "Weekly"       { "Weekly: $($sched.WeeklyOptions.DaysSrv -join ',') @ $($sched.WeeklyOptions.Period)" }
            "Monthly"      { "Monthly: $($sched.MonthlyOptions.DayNumberInMonth) $($sched.MonthlyOptions.DayOfWeek)" }
            "Continuously" { "Continuously" }
            default        { $sched.ScheduleType }
        }
    } catch {
        $s['Schedule Type']   = "N/A"
        $s['Schedule Detail'] = "N/A"
    }

    # --- Notifications ---
    try {
        $notif = $Job.Options.NotificationOptions
        $email = $notif.EmailNotificationOptions
        $s['Email Notify']      = $notif.SendEmail
        $s['Email Addresses']   = if ($email.EmailAddresses) { $email.EmailAddresses } else { "(none)" }
        $s['Notify On Success'] = $email.NotifyOnSuccess
        $s['Notify On Warning'] = $email.NotifyOnWarning
        $s['Notify On Failure'] = try { $email.NotifyOnError } catch { $email.NotifyOnFailure }
        $s['Email Subject']     = try { $email.NotificationSubject } catch { $email.Subject }
    } catch {
        $s['Email Notify']      = "N/A"
        $s['Email Addresses']   = "N/A"
        $s['Notify On Success'] = "N/A"
        $s['Notify On Warning'] = "N/A"
        $s['Notify On Failure'] = "N/A"
        $s['Email Subject']     = "N/A"
    }

    return $s
}
