function Edit-JobRepository {
    param($Job)
    Write-Header "Edit Repository: $($Job.Name)"

    $repos = @(Get-VBRBackupRepository | Sort-Object Name)
    if ($repos.Count -eq 0) { Write-Err "No repositories found."; return }

    Write-Host ("  {0,-4} {1,-40} {2}" -f "#", "Repository Name", "Type") -ForegroundColor White
    Write-Host ("  {0,-4} {1,-40} {2}" -f "----", "---------------", "----") -ForegroundColor DarkGray
    for ($i = 0; $i -lt $repos.Count; $i++) {
        Write-Host ("  {0,-4} {1,-40} {2}" -f ($i+1), $repos[$i].Name, $repos[$i].Type) -ForegroundColor Yellow
    }
    Write-Host ""

    $cur = try { $Job.GetTargetRepository().Name } catch { "Unknown" }
    Write-Info "Current: $cur"

    do {
        $sel = Read-Host "  Select new repository (1-$($repos.Count), 0 to cancel)"
        if ($sel -eq "0") { return }
    } while ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $repos.Count)

    $newRepo = $repos[[int]$sel - 1]
    try {
        Set-VBRJob -Job $Job -BackupRepository $newRepo -ErrorAction Stop
        Log-Change $Job.Name "Repository" $cur $newRepo.Name
        Write-Success "Repository updated to: $($newRepo.Name)"
    } catch {
        Write-Err "Failed: $_"
    }
}
