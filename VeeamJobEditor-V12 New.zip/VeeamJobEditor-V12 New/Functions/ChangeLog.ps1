function Show-ChangeLog {
    Write-Header "Session Change Log"
    if ($script:ChangeLog.Count -eq 0) {
        Write-Info "No changes recorded this session."
    } else {
        foreach ($entry in $script:ChangeLog) {
            Write-Host "  $entry" -ForegroundColor Green
        }
        Write-Host ""
        Write-Info "Total changes: $($script:ChangeLog.Count)"
        Write-Host ""
        if (Confirm-Action "Export log to file?") {
            $logPath = "VeeamJobEditor_ChangeLog_$(Get-Date -f 'yyyyMMdd_HHmmss').txt"
            $script:ChangeLog | Out-File -FilePath $logPath -Encoding UTF8
            Write-Success "Log saved: $(Resolve-Path $logPath)"
        }
    }
    Pause-Screen
}
