# ---- Edit: Target Repository --------------------------------
# BackupRepository param on Set-VBRViReplicaJob
# This is the repository where the replica job stores its state/metadata.

function Edit-ReplicationTargetRepository {
    param($Job)
    Write-Header "Edit Target Repository: $($Job.Name)"

    $curRepo = try { $Job.GetTargetRepository().Name } catch { "N/A" }
    Write-Info "Current target repository: $curRepo"
    Write-Host ""

    $repos = @(Get-VBRBackupRepository | Sort-Object Name)
    if ($repos.Count -eq 0) { Write-Err "No repositories found."; return }

    Write-Host ("  {0,-4} {1,-40} {2}" -f "#", "Repository Name", "Type") -ForegroundColor White
    Write-Host ("  {0,-4} {1,-40} {2}" -f "----", "---------------", "----") -ForegroundColor DarkGray
    for ($i = 0; $i -lt $repos.Count; $i++) {
        Write-Host ("  {0,-4} {1,-40} {2}" -f ($i+1), $repos[$i].Name, $repos[$i].Type) -ForegroundColor Yellow
    }
    Write-Host ""

    do {
        $sel = Read-Host "  Select repository (1-$($repos.Count), 0 to cancel)"
        if ($sel -eq "0") { Write-Info "Cancelled."; return }
    } while ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $repos.Count)

    $newRepo = $repos[[int]$sel - 1]
    $changes = [ordered]@{ "Target Repository" = @{ Current = $curRepo; New = $newRepo.Name } }
    if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }

    try {
        Set-VBRViReplicaJob -Job $Job -BackupRepository $newRepo -ErrorAction Stop
        Log-Change $Job.Name "Target Repository" $curRepo $newRepo.Name
        Write-Success "Target repository changed to: $($newRepo.Name)"
    } catch { Write-Err "Failed: $_" }
}

# ---- Edit: Disk Type ----------------------------------------
# DiskType param (EDiskCreationMode): controls how replica disks are created.

function Edit-ReplicationDiskType {
    param($Job)
    Write-Header "Edit Disk Type: $($Job.Name)"

    $curDisk = try { $Job.ViReplicaTargetOptions.DiskCreationMode } catch { "N/A" }
    Write-Info "Current disk type: $curDisk"
    Write-Host ""
    Write-Host "  [1] Source  - same format as the original VM disk"     -ForegroundColor Yellow
    Write-Host "  [2] Thin    - thin-provisioned (grows as needed)"       -ForegroundColor Yellow
    Write-Host "  [3] Thick   - thick-provisioned (pre-allocated space)"  -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                                             -ForegroundColor DarkGray
    Write-Host ""

    $choice = Read-Host "  Select"
    $newDisk = switch ($choice) {
        "1" { "Source" }
        "2" { "Thin"   }
        "3" { "Thick"  }
        "0" { Write-Info "Cancelled."; return }
        default { Write-Err "Invalid selection."; return }
    }

    $changes = [ordered]@{ "Disk Type" = @{ Current = $curDisk; New = $newDisk } }
    if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }

    try {
        Set-VBRViReplicaJob -Job $Job -DiskType $newDisk -ErrorAction Stop
        Log-Change $Job.Name "Disk Type" $curDisk $newDisk
        Write-Success "Disk type changed to: $newDisk"
    } catch { Write-Err "Failed: $_" }
}

# ---- Edit: WAN Accelerator ----------------------------------
# UseWANAccelerator, SourceWANAccelerator, TargetWANAccelerator

function Edit-ReplicationWanAccelerator {
    param($Job)
    Write-Header "Edit WAN Accelerator: $($Job.Name)"

    $curWan    = try { $Job.Options.JobOptions.UseWan } catch { "N/A" }
    $curSrcWan = try { $Job.GetSourceWanAccelerator().Name } catch { "(none)" }
    $curTgtWan = try { $Job.GetTargetWanAccelerator().Name } catch { "(none)" }

    Write-Info "WAN acceleration : $curWan"
    Write-Info "Source WAN accel : $curSrcWan"
    Write-Info "Target WAN accel : $curTgtWan"
    Write-Host ""
    Write-Host "  [1] Disable WAN acceleration"     -ForegroundColor Yellow
    Write-Host "  [2] Enable WAN acceleration"      -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                       -ForegroundColor DarkGray
    Write-Host ""

    $choice = Read-Host "  Select"

    if ($choice -eq "0") { Write-Info "Cancelled."; return }

    if ($choice -eq "1") {
        $changes = [ordered]@{ "Use WAN Accel" = @{ Current = "$curWan"; New = "False" } }
        if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
        try {
            Set-VBRViReplicaJob -Job $Job -UseWANAccelerator:$false -ErrorAction Stop
            Log-Change $Job.Name "WAN Accelerator" "$curWan" "Disabled"
            Write-Success "WAN acceleration disabled."
        } catch { Write-Err "Failed: $_" }
        return
    }

    if ($choice -eq "2") {
        $wans = @(Get-VBRWanAccelerator -ErrorAction SilentlyContinue | Sort-Object Name)
        if ($wans.Count -eq 0) { Write-Err "No WAN accelerators found. Configure them in VBR first."; return }

        Write-Host ""
        Write-Host "  Available WAN accelerators:" -ForegroundColor White
        for ($i = 0; $i -lt $wans.Count; $i++) {
            Write-Host ("  [{0}] {1}" -f ($i+1), $wans[$i].Name) -ForegroundColor Gray
        }
        Write-Host ""

        do {
            $srcSel = Read-Host "  Select SOURCE WAN accelerator (1-$($wans.Count))"
        } while ($srcSel -notmatch '^\d+$' -or [int]$srcSel -lt 1 -or [int]$srcSel -gt $wans.Count)

        do {
            $tgtSel = Read-Host "  Select TARGET WAN accelerator (1-$($wans.Count))"
        } while ($tgtSel -notmatch '^\d+$' -or [int]$tgtSel -lt 1 -or [int]$tgtSel -gt $wans.Count)

        $srcWan = $wans[[int]$srcSel - 1]
        $tgtWan = $wans[[int]$tgtSel - 1]

        $changes = [ordered]@{
            "Use WAN Accel"   = @{ Current = "$curWan";    New = "True"          }
            "Source WAN Accel"= @{ Current = $curSrcWan;   New = $srcWan.Name    }
            "Target WAN Accel"= @{ Current = $curTgtWan;   New = $tgtWan.Name    }
        }
        if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }

        try {
            Set-VBRViReplicaJob -Job $Job -UseWANAccelerator `
                -SourceWANAccelerator $srcWan -TargetWANAccelerator $tgtWan -ErrorAction Stop
            Log-Change $Job.Name "WAN Accelerator" "$curWan" "Enabled: $($srcWan.Name) -> $($tgtWan.Name)"
            Write-Success "WAN acceleration enabled. Source: $($srcWan.Name)  Target: $($tgtWan.Name)"
        } catch { Write-Err "Failed: $_" }
        return
    }

    Write-Err "Invalid selection."
}

# ---- Edit: Seeding ------------------------------------------
# EnableSeeding + RepositorySeed: seed initial replica from an existing backup
# to avoid transferring the full VM image over the network.

function Edit-ReplicationSeeding {
    param($Job)
    Write-Header "Edit Seeding: $($Job.Name)"

    $curSeed = try { $Job.ViReplicaTargetOptions.InitialSeeding } catch { "N/A" }
    Write-Info "Seeding currently: $curSeed"
    Write-Host ""
    Write-Host "  Seeding uses a backup in a local repository as the starting point" -ForegroundColor Gray
    Write-Host "  for the initial replication pass, avoiding a full network transfer." -ForegroundColor Gray
    Write-Host ""
    Write-Host "  [1] Enable seeding  (select seed repository)"  -ForegroundColor Yellow
    Write-Host "  [2] Disable seeding"                           -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                                    -ForegroundColor DarkGray
    Write-Host ""

    $choice = Read-Host "  Select"

    if ($choice -eq "0") { Write-Info "Cancelled."; return }

    if ($choice -eq "2") {
        $changes = [ordered]@{ "Seeding" = @{ Current = "$curSeed"; New = "False" } }
        if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }
        try {
            Set-VBRViReplicaJob -Job $Job -EnableSeeding:$false -ErrorAction Stop
            Log-Change $Job.Name "Seeding" "$curSeed" "Disabled"
            Write-Success "Seeding disabled."
        } catch { Write-Err "Failed: $_" }
        return
    }

    if ($choice -eq "1") {
        $repos = @(Get-VBRBackupRepository | Sort-Object Name)
        if ($repos.Count -eq 0) { Write-Err "No repositories found."; return }

        Write-Host ""
        Write-Host ("  {0,-4} {1,-40} {2}" -f "#", "Repository Name", "Type") -ForegroundColor White
        Write-Host ("  {0,-4} {1,-40} {2}" -f "----", "---------------", "----") -ForegroundColor DarkGray
        for ($i = 0; $i -lt $repos.Count; $i++) {
            Write-Host ("  {0,-4} {1,-40} {2}" -f ($i+1), $repos[$i].Name, $repos[$i].Type) -ForegroundColor Yellow
        }
        Write-Host ""

        do {
            $rSel = Read-Host "  Select seed repository (1-$($repos.Count), 0 to cancel)"
            if ($rSel -eq "0") { Write-Info "Cancelled."; return }
        } while ($rSel -notmatch '^\d+$' -or [int]$rSel -lt 1 -or [int]$rSel -gt $repos.Count)

        $seedRepo = $repos[[int]$rSel - 1]
        $changes  = [ordered]@{
            "Seeding"          = @{ Current = "$curSeed"; New = "True"            }
            "Seed Repository"  = @{ Current = "(none)";   New = $seedRepo.Name    }
        }
        if (-not (Show-PendingChangesWindow -JobName $Job.Name -Changes $changes)) { return }

        try {
            Set-VBRViReplicaJob -Job $Job -EnableSeeding -RepositorySeed $seedRepo -ErrorAction Stop
            Log-Change $Job.Name "Seeding" "$curSeed" "Enabled: $($seedRepo.Name)"
            Write-Success "Seeding enabled. Seed repository: $($seedRepo.Name)"
            Write-Warn "NOTE: Run the job once to complete the initial seeded pass."
        } catch { Write-Err "Failed: $_" }
        return
    }

    Write-Err "Invalid selection."
}
