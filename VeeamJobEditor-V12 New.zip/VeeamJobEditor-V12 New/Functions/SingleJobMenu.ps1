function Invoke-EditSingleJob {
    Write-Header "Edit Single Job"
    $job = Select-SingleJob -Prompt "Select job to edit"
    if ($null -eq $job) { return }

    # Capture BEFORE snapshot at the start of the editing session
    $before = Get-JobSnapshot -Job $job

    do {
        # Refresh job object for accurate display
        try { $job = Get-VBRJob -Name $job.Name } catch {}

        Clear-Host
        Write-Header "Editing: $($job.Name)"

        $type  = if ($job.JobType -eq "BackupSync") { "Backup Copy" } else { "VMware Backup" }
        $repo  = try { $job.GetTargetRepository().Name } catch { "N/A" }
        $pts   = try { $job.Options.BackupStorageOptions.RetainCycles } catch { "N/A" }
        $gfsOn = try { $job.Options.BackupStorageOptions.EnableGfsOptions } catch { $false }
        $sched = try { (Get-VBRJobScheduleOptions -Job $job).ScheduleType } catch { "N/A" }
        $email = try { $job.Options.NotificationOptions.SendEmail } catch { "N/A" }

        Write-Detail "Type        : $type"
        Write-Detail "Repository  : $repo"
        Write-Detail "Retention   : $pts restore points"
        Write-Detail "GFS         : $(if ($gfsOn) { 'Enabled' } else { 'Disabled' })"
        Write-Detail "Schedule    : $sched  (Enabled: $($job.IsScheduleEnabled))"
        Write-Detail "Email Notify: $email"
        Write-Host ""

        $schedState = if ($job.IsScheduleEnabled) { "ENABLED" } else { "DISABLED" }
        Write-Host "  [1] Change Repository" -ForegroundColor Yellow
        Write-Host "  [2] Change Retention (Restore Points)" -ForegroundColor Yellow
        Write-Host "  [3] Edit GFS Retention" -ForegroundColor Yellow
        Write-Host "  [4] Edit Schedule" -ForegroundColor Yellow
        Write-Host "  [5] Edit Notifications / Email" -ForegroundColor Yellow
        Write-Host "  [6] Show Before / After Comparison (this session)" -ForegroundColor Cyan
        Write-Host "  [7] Enable / Disable Job  (currently: $schedState)" -ForegroundColor $(if ($job.IsScheduleEnabled) { "Green" } else { "Red" })
        Write-Host "  [0] Finish & Return to Main Menu" -ForegroundColor DarkGray
        Write-Host ""

        $editChoice = Read-Host "  Select option"

        switch ($editChoice) {
            "1" { Edit-JobRepository      -Job $job; Pause-Screen }
            "2" { Edit-JobRetention       -Job $job; Pause-Screen }
            "3" { Edit-GfsRetention       -Job $job; Pause-Screen }
            "4" { Edit-JobSchedule        -Job $job; Pause-Screen }
            "5" { Edit-JobNotifications   -Job $job; Pause-Screen }
            "7" {
                $disable = $job.IsScheduleEnabled
                $action  = if ($disable) { "Disable" } else { "Enable" }
                if (Confirm-Action "$action job '$($job.Name)'?") {
                    Invoke-ToggleJobEnabled -Job $job -Disable $disable | Out-Null
                }
                Pause-Screen
            }
            "6" {
                try { $jobRefresh = Get-VBRJob -Name $job.Name } catch { $jobRefresh = $job }
                $after = Get-JobSnapshot -Job $jobRefresh
                Show-Comparison -JobName $job.Name -Before $before -After $after
                Pause-Screen
            }
            "0" {
                # Always show final comparison on exit
                Write-Host ""
                try { $jobFinal = Get-VBRJob -Name $job.Name } catch { $jobFinal = $job }
                $after = Get-JobSnapshot -Job $jobFinal
                Show-Comparison -JobName $job.Name -Before $before -After $after
                Pause-Screen
                return
            }
            default { Write-Err "Invalid option."; Start-Sleep -Seconds 1 }
        }

    } while ($true)
}
