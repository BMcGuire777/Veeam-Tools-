function Invoke-MassEditNotifications {
    Write-Header "Mass Edit: Notifications / Email"

    $jobs = @(Select-MassEditTargetJobs)
    if ($jobs.Count -eq 0) { return }

    Write-Host ""
    Write-Host "  [1] Enable Email Notifications on all selected"           -ForegroundColor Yellow
    Write-Host "  [2] Disable Email Notifications on all selected"          -ForegroundColor Yellow
    Write-Host "  [3] Set Email Address(es) on all selected"                -ForegroundColor Yellow
    Write-Host "  [4] Set Notify On Success / Warning / Failure on all"     -ForegroundColor Yellow
    Write-Host "  [5] Set Email Subject on all selected"                    -ForegroundColor Yellow
    Write-Host "  [0] Cancel"                                               -ForegroundColor DarkGray
    Write-Host ""
    $notifChoice = Read-Host "  Select notification setting to mass-edit"
    if ($notifChoice -eq "0") { Write-Info "Cancelled."; return }
    if ($notifChoice -notin @("1","2","3","4","5")) { Write-Info "Invalid selection."; return }

    # --- Collect new value for chosen setting ---
    $settingName = ""
    $newValStr   = ""
    # For choice 4  - notify triggers
    $sVal = $false; $wVal = $false; $fVal = $false

    switch ($notifChoice) {
        "1" { $settingName = "Email Notify";    $newValStr = "True"  }
        "2" { $settingName = "Email Notify";    $newValStr = "False" }
        "3" {
            $newValStr = (Read-Host "  New email address(es) (comma-separated)").Trim()
            if ($newValStr -eq "") { Write-Info "Cancelled."; return }
            $settingName = "Email Addresses"
        }
        "4" {
            $sVal        = ((Read-Host "  Notify on Success? (yes/no)").Trim().ToLower() -eq "yes")
            $wVal        = ((Read-Host "  Notify on Warning? (yes/no)").Trim().ToLower() -eq "yes")
            $fVal        = ((Read-Host "  Notify on Failure? (yes/no)").Trim().ToLower() -eq "yes")
            $settingName = "Notify Triggers"
            $newValStr   = "Success:$sVal  Warning:$wVal  Failure:$fVal"
        }
        "5" {
            $newValStr = (Read-Host "  New email subject (%JobName%, %JobResult%, %JobDuration%)").Trim()
            if ($newValStr -eq "") { Write-Info "Cancelled."; return }
            $settingName = "Email Subject"
        }
    }

    # --- GetCurrent scriptblock (used in both preview and results) ---
    if ($notifChoice -eq "1" -or $notifChoice -eq "2") {
        $getCurrent = { param($Job) try { "$($Job.Options.NotificationOptions.SendEmail)" } catch { "N/A" } }
    } elseif ($notifChoice -eq "3") {
        $getCurrent = { param($Job) try { $Job.Options.NotificationOptions.EmailNotificationOptions.EmailAddresses } catch { "N/A" } }
    } elseif ($notifChoice -eq "4") {
        $getCurrent = {
            param($Job)
            try {
                $e = $Job.Options.NotificationOptions.EmailNotificationOptions
                "S:$($e.NotifyOnSuccess) W:$($e.NotifyOnWarning) F:$(try{$e.NotifyOnError}catch{$e.NotifyOnFailure})"
            } catch { "N/A" }
        }
    } else {
        $getCurrent = {
            param($Job)
            try {
                $e = $Job.Options.NotificationOptions.EmailNotificationOptions
                try { $e.NotificationSubject } catch { $e.Subject }
            } catch { "N/A" }
        }
    }

    $confirmed = Show-MassEditPreview -Jobs $jobs -SettingName $settingName `
        -GetCurrent $getCurrent -NewValue $newValStr

    if (-not $confirmed) { Write-Info "Aborted  - no changes made."; return }

    Write-Host ""
    Write-Info "Applying '$settingName' to $($jobs.Count) job(s)..."
    $results = [System.Collections.Generic.List[hashtable]]::new()

    foreach ($job in $jobs) {
        $before = try { "$(& $getCurrent $job)" } catch { "N/A" }
        try {
            $notif = $job.Options.NotificationOptions
            $e     = $notif.EmailNotificationOptions
            switch ($notifChoice) {
                "1" { $notif.SendEmail = $true  }
                "2" { $notif.SendEmail = $false }
                "3" { $e.EmailAddresses = $newValStr }
                "4" {
                    $e.NotifyOnSuccess = $sVal
                    $e.NotifyOnWarning = $wVal
                    try { $e.NotifyOnError   = $fVal } catch { $e.NotifyOnFailure = $fVal }
                }
                "5" {
                    try { $e.NotificationSubject = $newValStr } catch { $e.Subject = $newValStr }
                }
            }
            Set-VBRJobAdvancedNotificationOptions -Job $job -Options $notif -ErrorAction Stop
            Log-Change $job.Name "$settingName (Mass)" $before $newValStr
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $newValStr; Status = "SUCCESS"; Error = "" })
            Write-Detail "  Applied : $($job.Name)"
        } catch {
            $results.Add(@{ JobName = $job.Name; Before = $before; After = $before; Status = "FAILED"; Error = "$_" })
            Write-Detail "  Failed  : $($job.Name): $_"
        }
    }

    Write-Host ""
    Write-Header "Mass Edit Notifications  - Results"
    Show-MassEditSummary -Results $results -SettingName $settingName
}
