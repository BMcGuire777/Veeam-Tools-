function Write-Header {
    param([string]$Title)
    $line = "=" * 66
    Write-Host ""
    Write-Host $line                  -ForegroundColor Cyan
    Write-Host "  $Title"             -ForegroundColor Cyan
    Write-Host $line                  -ForegroundColor Cyan
    Write-Host ""
}

function Write-SubHeader {
    param([string]$Title)
    Write-Host ""
    Write-Host "  -- $Title --" -ForegroundColor DarkCyan
    Write-Host ""
}

function Write-Success { param([string]$Msg) Write-Host "  [OK]  $Msg" -ForegroundColor Green  }
function Write-Info    { param([string]$Msg) Write-Host "  [>>]  $Msg" -ForegroundColor Yellow }
function Write-Warn    { param([string]$Msg) Write-Host "  [!]   $Msg" -ForegroundColor DarkYellow }
function Write-Err     { param([string]$Msg) Write-Host "  [!!]  $Msg" -ForegroundColor Red    }
function Write-Detail  { param([string]$Msg) Write-Host "        $Msg" -ForegroundColor Gray   }

function Pause-Screen {
    Write-Host ""
    $null = Read-Host "  Press Enter to continue"
}

function Confirm-Action {
    param([string]$Prompt)
    $r = Read-Host "  $Prompt (yes/no)"
    return ($r.Trim().ToLower() -eq "yes")
}

function Log-Change {
    param([string]$JobName, [string]$Setting, [string]$OldVal, [string]$NewVal)
    $entry = "[{0}] Job:'{1}' | {2}: '{3}' -> '{4}'" -f (Get-Date -f "yyyy-MM-dd HH:mm:ss"), $JobName, $Setting, $OldVal, $NewVal
    $script:ChangeLog.Add($entry)
}

function Truncate-String {
    param([string]$Str, [int]$MaxLen)
    if ($Str.Length -gt $MaxLen) { return $Str.Substring(0, $MaxLen - 3) + "..." }
    return $Str
}
