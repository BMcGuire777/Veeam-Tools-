function Edit-JobNotifications {
    param($Job)
    Write-Header "Edit Notifications: $($Job.Name)"

    # Display current settings
    try {
        $n = $Job.Options.NotificationOptions
        $e = $n.EmailNotificationOptions
        Write-SubHeader "Current Notification Settings"
        Write-Detail "Email Notify    : $($n.SendEmail)"
        Write-Detail "Email Addresses : $($e.EmailAddresses)"
        Write-Detail "On Success      : $($e.NotifyOnSuccess)"
        Write-Detail "On Warning      : $($e.NotifyOnWarning)"
        $failProp = try { $e.NotifyOnError } catch { $e.NotifyOnFailure }
        Write-Detail "On Failure      : $failProp"
        $subj = try { $e.NotificationSubject } catch { try { $e.Subject } catch { "N/A" } }
        Write-Detail "Subject         : $subj"
    } catch {
        Write-Warn "Could not read current notification settings: $_"
    }
    Write-Host ""

    Write-Host "  [1] Enable / Disable Email Notifications" -ForegroundColor Yellow
    Write-Host "  [2] Set Email Address(es)" -ForegroundColor Yellow
    Write-Host "  [3] Set Notify On Success / Warning / Failure" -ForegroundColor Yellow
    Write-Host "  [4] Set Email Subject" -ForegroundColor Yellow
    Write-Host "  [0] Cancel" -ForegroundColor DarkGray
    Write-Host ""
    $choice = Read-Host "  Select option"

    try {
        $notifOpts = $Job.Options.NotificationOptions
        $emailOpts = $notifOpts.EmailNotificationOptions

        switch ($choice) {
            "1" {
                $cur = $notifOpts.SendEmail
                $new = -not $cur
                if (Confirm-Action "$(if ($new){'Enable'}else{'Disable'}) email notifications for '$($Job.Name)'?") {
                    $notifOpts.SendEmail = $new
                    # Veeam v12: use Set-VBRJobAdvancedNotificationOptions
                    Set-VBRJobAdvancedNotificationOptions -Job $Job -Options $notifOpts -ErrorAction Stop
                    Log-Change $Job.Name "Email Notify" "$cur" "$new"
                    Write-Success "Email notifications set to: $new"
                }
            }
            "2" {
                $cur = $emailOpts.EmailAddresses
                Write-Info "Current: $cur"
                $new = Read-Host "  New email address(es) (comma-separated, or Enter to skip)"
                if ($new.Trim() -ne "") {
                    $emailOpts.EmailAddresses = $new.Trim()
                    Set-VBRJobAdvancedNotificationOptions -Job $Job -Options $notifOpts -ErrorAction Stop
                    Log-Change $Job.Name "Email Addresses" $cur $new.Trim()
                    Write-Success "Email addresses updated."
                }
            }
            "3" {
                foreach ($evt in @("Success","Warning","Failure")) {
                    $propName = if ($evt -eq "Failure") {
                        try { $null = $emailOpts.NotifyOnError; "NotifyOnError" } catch { "NotifyOnFailure" }
                    } else {
                        "NotifyOn$evt"
                    }
                    $cur = try { $emailOpts.$propName } catch { "N/A" }
                    $ans = Read-Host "  Notify on $evt? Current: $cur (yes/no/skip)"
                    if ($ans.Trim().ToLower() -eq "yes")  {
                        $emailOpts.$propName = $true
                        Log-Change $Job.Name "Notify On $evt" "$cur" "True"
                    } elseif ($ans.Trim().ToLower() -eq "no") {
                        $emailOpts.$propName = $false
                        Log-Change $Job.Name "Notify On $evt" "$cur" "False"
                    }
                }
                Set-VBRJobAdvancedNotificationOptions -Job $Job -Options $notifOpts -ErrorAction Stop
                Write-Success "Notification triggers updated."
            }
            "4" {
                $subj     = try { $emailOpts.NotificationSubject } catch { $emailOpts.Subject }
                $subjProp = try { $null = $emailOpts.NotificationSubject; "NotificationSubject" } catch { "Subject" }
                Write-Info "Current subject: $subj"
                $new = Read-Host "  New subject (variables: %JobName%, %JobResult%, %JobDuration%)"
                if ($new.Trim() -ne "") {
                    $emailOpts.$subjProp = $new.Trim()
                    Set-VBRJobAdvancedNotificationOptions -Job $Job -Options $notifOpts -ErrorAction Stop
                    Log-Change $Job.Name "Email Subject" "$subj" $new.Trim()
                    Write-Success "Subject updated."
                }
            }
            default { Write-Info "Cancelled." }
        }
    } catch {
        Write-Err "Failed to apply notification settings: $_"
        Write-Warn "Tip: Ensure VBR global email settings are configured in VBR console first."
    }
}
