# ============================================================
#  AgentSqlProtection.ps1
#  Backup & restore for Veeam Agent workloads protecting SQL.
#
#    Backup side : list agent backup jobs, start / stop them
#                  (Get/Start/Stop-VBRComputerBackupJob).
#    Restore side: Veeam Explorer for Microsoft SQL - restore a
#                  database in place OR to another instance
#                  (Get-VBRApplicationRestorePoint -SQL, VESQL* cmdlets).
#
#  NOTES
#    - Agent jobs do NOT appear in Get-VBRJob; they use their own
#      Get-VBRComputerBackupJob family.
#    - SQL restore points only exist if application-aware processing
#      (VSS) was enabled on the agent job. Get-VBRApplicationRestorePoint
#      -SQL does the SQL filtering for us.
#    - The VESQL* cmdlets ship with Veeam Explorer for Microsoft SQL
#      Server (on the VBR / mount server). Test-VeeamSqlExplorer checks
#      they are available before we try to restore.
# ============================================================

# ------------------------------------------------------------
#  Backup side - agent job retrieval & display
# ------------------------------------------------------------
function Get-AgentBackupJobs {
    # @() keeps .Count safe under Set-StrictMode; -WarningAction hides v12 chatter.
    return @(Get-VBRComputerBackupJob -WarningAction SilentlyContinue | Sort-Object Name)
}

function Show-AgentJobTable {
    param([array]$Jobs)
    Write-Host ""
    Write-Host ("  {0,-4} {1,-40} {2,-16} {3}" -f "#", "Agent Job / Policy", "Mode", "Last Result") -ForegroundColor White
    Write-Host ("  {0,-4} {1,-40} {2,-16} {3}" -f "----", "------------------", "----", "-----------") -ForegroundColor DarkGray

    for ($i = 0; $i -lt $Jobs.Count; $i++) {
        $j    = $Jobs[$i]
        $mode = try { [string]$j.Type }        catch { "N/A" }
        $last = try {
            $s = @(Get-VBRComputerBackupJobSession -Name $j.Name -ErrorAction SilentlyContinue |
                   Sort-Object CreationTime -Descending)
            if ($s.Count -gt 0) { [string]$s[0].Result } else { "None" }
        } catch { "Unknown" }
        Write-Host ("  {0,-4} {1,-40} {2,-16} {3}" -f ($i+1), (Truncate-String $j.Name 39), (Truncate-String $mode 15), $last) -ForegroundColor Cyan
    }
    Write-Host ""
}

function Select-AgentJob {
    param([string]$Prompt = "Select an agent job")
    $jobs = @(Get-AgentBackupJobs)
    if ($jobs.Count -eq 0) { Write-Err "No agent backup jobs found."; return $null }
    Show-AgentJobTable -Jobs $jobs
    do {
        $sel = Read-Host "  $Prompt (1-$($jobs.Count), 0 to cancel)"
        if ($sel -eq "0") { return $null }
    } while ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $jobs.Count)
    return $jobs[[int]$sel - 1]
}

# ------------------------------------------------------------
#  Backup side - run / stop
# ------------------------------------------------------------
function Start-AgentJobNow {
    $job = Select-AgentJob -Prompt "Select agent job to run"
    if ($null -eq $job) { Write-Info "Cancelled."; return }
    if (Confirm-Action "Start agent job '$($job.Name)' now?") {
        try {
            Start-VBRComputerBackupJob -Job $job -ErrorAction Stop | Out-Null
            Log-Change $job.Name "Agent Job Control" "N/A" "Started"
            Write-Success "Agent job '$($job.Name)' started."
        } catch { Write-Err "Failed to start: $_" }
    }
}

function Stop-AgentJobNow {
    $job = Select-AgentJob -Prompt "Select agent job to stop"
    if ($null -eq $job) { Write-Info "Cancelled."; return }
    if (Confirm-Action "Stop running agent job '$($job.Name)'?") {
        try {
            Stop-VBRComputerBackupJob -Job $job -ErrorAction Stop | Out-Null
            Log-Change $job.Name "Agent Job Control" "Running" "Stopped"
            Write-Success "Stop signal sent to '$($job.Name)'."
        } catch { Write-Err "Failed to stop: $_" }
    }
}

# ------------------------------------------------------------
#  Restore side - Veeam Explorer for Microsoft SQL
# ------------------------------------------------------------
function Test-VeeamSqlExplorer {
    # Confirms the VESQL* restore cmdlets are loaded before we rely on them.
    if (Get-Command Start-VESQLRestoreSession -ErrorAction SilentlyContinue) { return $true }
    Write-Err "Veeam Explorer for Microsoft SQL cmdlets (VESQL*) are not available."
    Write-Warn "Ensure Veeam Explorer for Microsoft SQL Server is installed on this"
    Write-Warn "machine (VBR / mount server) and that its PowerShell module is loaded."
    return $false
}

function Select-SqlRestorePoint {
    # Only points from app-aware (VSS) SQL backups are returned - agent or VM alike.
    $points = @(Get-VBRApplicationRestorePoint -SQL -ErrorAction SilentlyContinue |
                Sort-Object CreationTimeUtc -Descending)
    if ($points.Count -eq 0) {
        Write-Err "No SQL restore points found."
        Write-Warn "SQL restore points require application-aware processing (VSS) on the"
        Write-Warn "agent backup job. Enable it in the job's guest processing settings."
        return $null
    }

    Write-Host ""
    Write-Host ("  {0,-4} {1,-34} {2}" -f "#", "Protected Machine", "Restore Point (UTC)") -ForegroundColor White
    Write-Host ("  {0,-4} {1,-34} {2}" -f "----", "-----------------", "-------------------") -ForegroundColor DarkGray
    for ($i = 0; $i -lt $points.Count; $i++) {
        $rp   = $points[$i]
        $name = try { [string]$rp.Name }            catch { "N/A" }
        $when = try { [string]$rp.CreationTimeUtc }  catch { "N/A" }
        Write-Host ("  {0,-4} {1,-34} {2}" -f ($i+1), (Truncate-String $name 33), $when) -ForegroundColor Cyan
    }
    Write-Host ""

    do {
        $sel = Read-Host "  Select restore point (1-$($points.Count), 0 to cancel)"
        if ($sel -eq "0") { return $null }
    } while ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $points.Count)
    return $points[[int]$sel - 1]
}

function Select-SqlDatabase {
    param($Session)
    $dbs = @(Get-VESQLDatabase -Session $Session -ErrorAction Stop)
    if ($dbs.Count -eq 0) { Write-Err "No databases found in this restore point."; return $null }

    Write-Host ""
    Write-Host ("  {0,-4} {1}" -f "#", "Database") -ForegroundColor White
    Write-Host ("  {0,-4} {1}" -f "----", "--------") -ForegroundColor DarkGray
    for ($i = 0; $i -lt $dbs.Count; $i++) {
        $n = try { [string]$dbs[$i].Name } catch { "N/A" }
        Write-Host ("  {0,-4} {1}" -f ($i+1), $n) -ForegroundColor Cyan
    }
    Write-Host ""

    do {
        $sel = Read-Host "  Select database (1-$($dbs.Count), 0 to cancel)"
        if ($sel -eq "0") { return $null }
    } while ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $dbs.Count)
    return $dbs[[int]$sel - 1]
}

function Invoke-AgentSqlRestore {
    Write-Header "Restore SQL Database from Agent Backup"
    if (-not (Test-VeeamSqlExplorer)) { return }

    $rp = Select-SqlRestorePoint
    if ($null -eq $rp) { Write-Info "Cancelled."; return }

    $session = $null
    try {
        Write-Info "Opening restore session..."
        $session = Start-VESQLRestoreSession -RestorePoint $rp -ErrorAction Stop

        $db = Select-SqlDatabase -Session $session
        if ($null -eq $db) { Write-Info "Cancelled."; return }

        # Optional point-in-time (transaction-log) restore. Blank = latest state.
        Write-Host ""
        $pit = Read-Host "  Point-in-time UTC (yyyy-MM-dd HH:mm:ss), or Enter for latest"
        $pitUtc = $null
        if ($pit.Trim() -ne "") {
            try { $pitUtc = [datetime]::Parse($pit.Trim()).ToUniversalTime() }
            catch { Write-Warn "Unrecognised date - restoring to latest state instead." }
        }

        Write-Host ""
        Write-Host "  [1] Restore IN PLACE  (overwrite original database)" -ForegroundColor Red
        Write-Host "  [2] Restore to ANOTHER instance / server"           -ForegroundColor Yellow
        Write-Host "  [0] Cancel"                                         -ForegroundColor DarkGray
        Write-Host ""
        $target = Read-Host "  Select restore target"

        $common = @{ Database = $db; ErrorAction = "Stop" }
        if ($null -ne $pitUtc) { $common["ToPointInTimeUtc"] = $pitUtc }

        switch ($target) {
            "1" {
                Write-Warn "In-place restore OVERWRITES the live database '$($db.Name)'."
                if (Confirm-Action "Are you sure you want to overwrite '$($db.Name)'?") {
                    Restore-VESQLDatabase @common -Force | Out-Null
                    Log-Change $db.Name "SQL Restore" $rp.Name "In-place (overwrite)"
                    Write-Success "Database '$($db.Name)' restored in place."
                } else { Write-Info "Cancelled." }
            }
            "2" {
                $server   = Read-Host "  Target SQL server (DNS / IP)"
                if ($server.Trim() -eq "") { Write-Err "Server name is required."; return }
                $instance = Read-Host "  Target instance (Enter for default)"
                $newName  = Read-Host "  New database name (Enter to keep '$($db.Name)')"
                $folder   = Read-Host "  Target folder for restored files (e.g. C:\SQLRestore)"

                $params = $common.Clone()
                $params["ServerName"] = $server.Trim()
                if ($instance.Trim() -ne "") { $params["InstanceName"] = $instance.Trim() }
                if ($newName.Trim()  -ne "") { $params["DatabaseName"] = $newName.Trim() }
                if ($folder.Trim()   -ne "") { $params["TargetFolder"] = $folder.Trim() }

                if (Confirm-Action "Use SQL authentication for the target? (else current OS account)") {
                    $params["SqlCredentials"]      = Get-Credential -Message "Target SQL credentials"
                    $params["UseSQLAuthentication"] = $true
                }

                $dest = "$($server.Trim())" + $(if ($instance.Trim() -ne "") { "\$($instance.Trim())" } else { "" })
                if (Confirm-Action "Restore '$($db.Name)' to '$dest'?") {
                    Restore-VESQLDatabase @params | Out-Null
                    Log-Change $db.Name "SQL Restore" $rp.Name "To $dest"
                    Write-Success "Database restored to '$dest'."
                } else { Write-Info "Cancelled." }
            }
            default { Write-Info "Cancelled." }
        }
    } catch {
        Write-Err "Restore failed: $_"
    } finally {
        if ($null -ne $session) {
            try { Stop-VESQLRestoreSession -Session $session -ErrorAction SilentlyContinue | Out-Null } catch {}
        }
    }
}

# ------------------------------------------------------------
#  Sub-menu (entry point called from MainMenu)
# ------------------------------------------------------------
function Invoke-AgentSqlProtection {
    do {
        Write-Header "Agent-Based SQL Protection"
        Write-Host "  -- Backup (agent jobs) -------------------------------------" -ForegroundColor DarkGray
        Write-Host "  [1] List Agent Backup Jobs"                    -ForegroundColor Yellow
        Write-Host "  [2] Run an Agent Backup Job Now"               -ForegroundColor Yellow
        Write-Host "  [3] Stop a Running Agent Backup Job"           -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  -- Restore (Veeam Explorer for SQL) ------------------------" -ForegroundColor DarkGray
        Write-Host "  [4] Restore a SQL Database from an Agent Backup" -ForegroundColor Green
        Write-Host ""
        Write-Host "  [0] Back to Main Menu"                          -ForegroundColor DarkGray
        Write-Host ""
        $choice = Read-Host "  Select option"

        switch ($choice) {
            "1" {
                Write-SubHeader "Agent Backup Jobs"
                $jobs = @(Get-AgentBackupJobs)
                if ($jobs.Count -eq 0) { Write-Err "No agent backup jobs found." }
                else { Show-AgentJobTable -Jobs $jobs }
                Pause-Screen
            }
            "2" { Start-AgentJobNow; Pause-Screen }
            "3" { Stop-AgentJobNow;  Pause-Screen }
            "4" { Invoke-AgentSqlRestore; Pause-Screen }
            "0" { return }
            default { Write-Err "Invalid option."; Start-Sleep -Seconds 1 }
        }
    } while ($true)
}
