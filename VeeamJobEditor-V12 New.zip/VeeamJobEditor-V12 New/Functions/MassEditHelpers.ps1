function Select-MassEditTargetJobs {
    <#
    Prompts the user to choose a scope (ALL / VMware / BackupCopy / Hand-pick).
    Returns an array of job objects, or @() if the user cancels or nothing matches.
    #>
    Write-SubHeader "Select Target Jobs for Mass Edit"

    $allJobs    = @(Get-AllEditableJobs)
    if ($allJobs.Count -eq 0) {
        Write-Err "No editable jobs found."
        return @()
    }

    $vmwareJobs = @($allJobs | Where-Object { $_.JobType -eq "Backup"     })
    $bcopyJobs  = @($allJobs | Where-Object { $_.JobType -eq "BackupSync" })

    Write-Host "  Available jobs:" -ForegroundColor White
    Write-Host "    Total        : $($allJobs.Count)"   -ForegroundColor Gray
    Write-Host "    VMware       : $($vmwareJobs.Count)" -ForegroundColor Cyan
    Write-Host "    Backup Copy  : $($bcopyJobs.Count)"  -ForegroundColor Magenta
    Write-Host ""
    Write-Host "  [1] ALL jobs  ($($allJobs.Count))" -ForegroundColor Yellow
    Write-Host "  [2] VMware Backup jobs only  ($($vmwareJobs.Count))" -ForegroundColor Cyan
    Write-Host "  [3] Backup Copy jobs only  ($($bcopyJobs.Count))"   -ForegroundColor Magenta
    Write-Host "  [4] Hand-pick from list" -ForegroundColor Yellow
    Write-Host "  [0] Cancel" -ForegroundColor DarkGray
    Write-Host ""
    $scopeChoice = Read-Host "  Select target scope"

    switch ($scopeChoice) {
        "1" { return $allJobs }
        "2" {
            if ($vmwareJobs.Count -eq 0) { Write-Warn "No VMware Backup jobs found."; return @() }
            return $vmwareJobs
        }
        "3" {
            if ($bcopyJobs.Count -eq 0) { Write-Warn "No Backup Copy jobs found."; return @() }
            return $bcopyJobs
        }
        "4" {
            Show-JobTable -Jobs $allJobs
            Write-Info "Enter job numbers comma-separated (e.g. 1,3,5):"
            $rawIn    = Read-Host "  Selection"
            $selected = @()
            foreach ($idx in ($rawIn -split "," | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' })) {
                $i = [int]$idx - 1
                if ($i -ge 0 -and $i -lt $allJobs.Count) { $selected += $allJobs[$i] }
            }
            if ($selected.Count -eq 0) { Write-Warn "No valid jobs selected."; return @() }
            return $selected
        }
        default {
            Write-Info "Cancelled."
            return @()
        }
    }
}

function Show-MassEditPreview {
    <#
    Displays a per-job preview table before any changes are applied.
    Parameters:
      $Jobs        - array of job objects
      $SettingName - human-readable setting label (e.g. "Restore Points")
      $GetCurrent  - scriptblock { param($Job) return <current-value-as-string> }
      $NewValue    - the new value as a string (for display and comparison)
    Returns $true if the user confirms, $false if they cancel or nothing needs changing.
    #>
    param(
        [array]$Jobs,
        [string]$SettingName,
        [scriptblock]$GetCurrent,
        [string]$NewValue
    )

    $CJ = 38   # col: job name
    $CC = 22   # col: current value
    $CN = 22   # col: new value

    Write-Host ""
    Write-Host ("  {0,-$CJ} {1,-$CC} {2,-$CN} {3}" -f "Job Name", "Current $SettingName", "New $SettingName", "Action") -ForegroundColor White
    Write-Host ("  {0,-$CJ} {1,-$CC} {2,-$CN} {3}" -f ("-"*($CJ-1)), ("-"*($CC-1)), ("-"*($CN-1)), "----------") -ForegroundColor DarkGray

    $willChange = 0
    $alreadySet = 0

    foreach ($j in $Jobs) {
        $cur     = try { "$( & $GetCurrent $j )" } catch { "N/A" }
        $changed = ($cur -ne $NewValue)
        if ($changed) { $willChange++ } else { $alreadySet++ }
        $status  = if ($changed) { "[WILL CHANGE]" } else { "[ALREADY SET]" }
        $color   = if ($changed) { "Yellow" }        else { "DarkGray" }
        Write-Host ("  {0,-$CJ} {1,-$CC} {2,-$CN} {3}" -f `
            (Truncate-String $j.Name ($CJ-1)), `
            (Truncate-String $cur    ($CC-1)), `
            (Truncate-String $NewValue ($CN-1)), `
            $status) -ForegroundColor $color
    }

    Write-Host ""
    Write-Info "Jobs to change : $willChange  |  Already set : $alreadySet  |  Total : $($Jobs.Count)"
    Write-Host ""

    if ($willChange -eq 0) {
        Write-Info "All selected jobs already have '$NewValue' for $SettingName  - nothing to do."
        return $false
    }

    return (Confirm-Action "Apply '$NewValue' to $willChange job(s)?")
}

function Show-MassEditSummary {
    <#
    Displays a results table after a mass-edit pass and offers an export.
    $Results is a List[hashtable] where each entry has:
      JobName, Before, After, Status ("SUCCESS"|"FAILED"|"SKIPPED"), Error
    #>
    param(
        [System.Collections.Generic.List[hashtable]]$Results,
        [string]$SettingName
    )

    $CJ = 36; $CB = 18; $CA = 18

    Write-Host ""
    Write-Host ("  {0,-$CJ} {1,-$CB} {2,-$CA} {3}" -f "Job Name", "Before", "After", "Result") -ForegroundColor White
    Write-Host ("  {0,-$CJ} {1,-$CB} {2,-$CA} {3}" -f ("-"*($CJ-1)), ("-"*($CB-1)), ("-"*($CA-1)), "--------") -ForegroundColor DarkGray

    $success = 0; $failed = 0; $skipped = 0
    foreach ($r in $Results) {
        $color = switch ($r.Status) {
            "SUCCESS" { $success++; "Green"    }
            "FAILED"  { $failed++;  "Red"      }
            "SKIPPED" { $skipped++; "DarkGray" }
            default   { "Gray" }
        }
        Write-Host ("  {0,-$CJ} {1,-$CB} {2,-$CA} {3}" -f `
            (Truncate-String $r.JobName    ($CJ-1)), `
            (Truncate-String "$($r.Before)" ($CB-1)), `
            (Truncate-String "$($r.After)"  ($CA-1)), `
            $r.Status) -ForegroundColor $color
        if ($r.Status -eq "FAILED" -and $r.Error) {
            Write-Host "    +- $($r.Error)" -ForegroundColor DarkRed
        }
    }

    Write-Host ""
    Write-Host "  +- Summary --------------------------------------------------+" -ForegroundColor Cyan
    Write-Host "  |  SUCCESS : $("$success".PadRight(5))  FAILED : $("$failed".PadRight(5))  SKIPPED : $("$skipped".PadRight(5))        |" -ForegroundColor Cyan
    Write-Host "  +------------------------------------------------------------+" -ForegroundColor Cyan
    Write-Host ""

    if (Confirm-Action "Export mass-edit results to file?") {
        $reportPath = "VeeamMassEdit_$(Get-Date -f 'yyyyMMdd_HHmmss').txt"
        $lines  = @()
        $lines += "Veeam Mass Edit Report  |  Setting: $SettingName  |  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')"
        $lines += "=" * 72
        $lines += "{0,-36} {1,-18} {2,-18} {3}" -f "Job Name","Before","After","Result"
        $lines += "{0,-36} {1,-18} {2,-18} {3}" -f ("-"*35),("-"*17),("-"*17),("--------")
        foreach ($r in $Results) {
            $lines += "{0,-36} {1,-18} {2,-18} {3}" -f $r.JobName, "$($r.Before)", "$($r.After)", $r.Status
            if ($r.Status -eq "FAILED" -and $r.Error) { $lines += "    Error: $($r.Error)" }
        }
        $lines += ""
        $lines += "SUCCESS: $success  |  FAILED: $failed  |  SKIPPED: $skipped  |  TOTAL: $($Results.Count)"
        $lines | Out-File -FilePath $reportPath -Encoding UTF8
        Write-Success "Report saved: $(Resolve-Path $reportPath)"
    }
}
