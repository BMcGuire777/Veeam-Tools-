function Invoke-MassEditJobs {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "  +==============================================================+" -ForegroundColor Cyan
        Write-Host "  |              MASS EDIT JOBS  - Apply to Many at Once          |" -ForegroundColor Cyan
        Write-Host "  |  Every operation previews changes before touching anything.  |" -ForegroundColor Cyan
        Write-Host "  +==============================================================+" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  [1] Mass Edit: Retention (Restore Points)"  -ForegroundColor Yellow
        Write-Host "  [2] Mass Edit: Repository"                   -ForegroundColor Yellow
        Write-Host "  [3] Mass Edit: Schedule"                     -ForegroundColor Yellow
        Write-Host "  [4] Mass Edit: Notifications / Email"        -ForegroundColor Yellow
        Write-Host "  [5] Mass Edit: GFS Retention"                -ForegroundColor Yellow
        Write-Host "  [0] Return to Main Menu"                     -ForegroundColor DarkGray
        Write-Host ""

        $massChoice = Read-Host "  Select option"

        switch ($massChoice) {
            "1" { Invoke-MassEditRetention;     Pause-Screen }
            "2" { Invoke-MassEditRepository;    Pause-Screen }
            "3" { Invoke-MassEditSchedule;      Pause-Screen }
            "4" { Invoke-MassEditNotifications; Pause-Screen }
            "5" { Invoke-MassEditGfs;           Pause-Screen }
            "0" { return }
            default { Write-Err "Invalid option."; Start-Sleep -Seconds 1 }
        }

    } while ($true)
}
