function Invoke-MainMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "  +==============================================================+" -ForegroundColor Cyan
        Write-Host "  |        VEEAM VBR v12  |  Interactive Job Editor  v2.2        |" -ForegroundColor Cyan
        Write-Host "  |        Server : $($script:VBRServer.PadRight(46))|" -ForegroundColor Cyan
        Write-Host "  |        Changes: $("$($script:ChangeLog.Count) recorded".PadRight(46))|" -ForegroundColor Cyan
        Write-Host "  +==============================================================+" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  -- Backup & Copy Jobs --------------------------------------" -ForegroundColor DarkGray
        Write-Host "  [1] List All Backup Jobs"                                      -ForegroundColor Yellow
        Write-Host "  [2] Edit a Single Backup Job  (with Before/After comparison)"  -ForegroundColor Yellow
        Write-Host "  [3] Bulk Copy Settings  (Source -> Multiple Backup Jobs)"      -ForegroundColor Yellow
        Write-Host "  [4] Mass Edit Backup Jobs  (one setting -> many jobs)"         -ForegroundColor Cyan
        Write-Host "  [5] Start / Stop a Backup Job"                                 -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  -- Replication Jobs ----------------------------------------" -ForegroundColor DarkGray
        Write-Host "  [6] List All Replication Jobs"                                 -ForegroundColor Yellow
        Write-Host "  [7] Edit a Single Replication Job"                             -ForegroundColor Yellow
        Write-Host "  [8] Mass Edit Replication Jobs"                                -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  -- Agent-Based / SQL ---------------------------------------" -ForegroundColor DarkGray
        Write-Host "  [10] Agent SQL Protection  (run agent jobs / restore SQL DBs)" -ForegroundColor Green
        Write-Host ""
        Write-Host "  -- Session -------------------------------------------------" -ForegroundColor DarkGray
        Write-Host "  [9] View Session Change Log"                                   -ForegroundColor Yellow
        Write-Host "  [0] Exit"                                                      -ForegroundColor DarkGray
        Write-Host ""

        $choice = Read-Host "  Select option"

        switch ($choice) {
            "1" {
                Write-Header "All Backup / Copy Jobs"
                $jobs = @(Get-AllEditableJobs)
                if ($jobs.Count -eq 0) { Write-Err "No jobs found." }
                else { Show-JobTable -Jobs $jobs }
                Pause-Screen
            }
            "2" { Invoke-EditSingleJob }
            "3" { Copy-JobSettings; Pause-Screen }
            "4" { Invoke-MassEditJobs }
            "5" { Invoke-JobControl; Pause-Screen }
            "6" {
                Write-Header "All Replication Jobs"
                $jobs = @(Get-AllReplicationJobs)
                if ($jobs.Count -eq 0) { Write-Err "No replication jobs found." }
                else { Show-ReplicationJobTable -Jobs $jobs }
                Pause-Screen
            }
            "7" { Invoke-EditSingleReplicationJob }
            "8" { Invoke-MassEditReplicationJobs }
            "9"  { Show-ChangeLog }
            "10" { Invoke-AgentSqlProtection }
            "0" {
                Write-Host ""
                Write-Info "Disconnecting..."
                try { Disconnect-VBRServer -ErrorAction SilentlyContinue } catch {}
                Write-Success "Goodbye!"
                Write-Host ""
                return
            }
            default { Write-Err "Invalid option."; Start-Sleep -Seconds 1 }
        }

    } while ($true)
}
