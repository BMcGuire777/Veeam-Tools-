function Show-Comparison {
    param(
        [string]$JobName,
        [System.Collections.Specialized.OrderedDictionary]$Before,
        [System.Collections.Specialized.OrderedDictionary]$After
    )

    Write-Header "Before / After: $JobName"

    $hdr = "  {0,-$COL_SETTING} {1,-$COL_VAL} {2,-$COL_VAL} {3}" -f "Setting", "BEFORE", "AFTER", "Status"
    $div = "  {0,-$COL_SETTING} {1,-$COL_VAL} {2,-$COL_VAL} {3}" -f ("-" * ($COL_SETTING - 1)), ("-" * ($COL_VAL - 1)), ("-" * ($COL_VAL - 1)), ("--" * 4)

    Write-Host $hdr -ForegroundColor White
    Write-Host $div -ForegroundColor DarkGray

    # Collect all unique keys preserving Before order
    $allKeys = [System.Collections.Generic.List[string]]::new()
    foreach ($k in $Before.Keys)  { if (-not $allKeys.Contains($k)) { $allKeys.Add($k) } }
    foreach ($k in $After.Keys)   { if (-not $allKeys.Contains($k)) { $allKeys.Add($k) } }

    $anyChange = $false

    foreach ($key in $allKeys) {
        $bv = if ($Before.Contains($key)) { "$($Before[$key])" } else { "(new)" }
        $av = if ($After.Contains($key))  { "$($After[$key])"  } else { "(removed)" }

        $bvDisplay = Truncate-String -Str $bv -MaxLen ($COL_VAL - 1)
        $avDisplay = Truncate-String -Str $av -MaxLen ($COL_VAL - 1)
        $keyDisp   = Truncate-String -Str $key -MaxLen ($COL_SETTING - 1)

        $changed = ($bv -ne $av)
        if ($changed) { $anyChange = $true }
        $status  = if ($changed) { "[CHANGED]" } else { "" }
        $color   = if ($changed) { "Green" } else { "DarkGray" }

        Write-Host ("  {0,-$COL_SETTING} {1,-$COL_VAL} {2,-$COL_VAL} {3}" -f $keyDisp, $bvDisplay, $avDisplay, $status) -ForegroundColor $color
    }

    Write-Host ""
    if ($anyChange) {
        Write-Success "Changes detected and applied for job: $JobName"
    } else {
        Write-Info "No changes were made for job: $JobName"
    }
    Write-Host ""
}
