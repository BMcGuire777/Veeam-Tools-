function Edit-JobSchedule {
    param($Job)
    Write-Header "Edit Schedule: $($Job.Name)"

    try {
        $cur = Get-VBRJobScheduleOptions -Job $Job
        Write-Info "Current type : $($cur.ScheduleType)"
        Write-Info "Enabled      : $($Job.IsScheduleEnabled)"
    } catch { Write-Warn "Could not read current schedule." }
    Write-Host ""

    Write-Host "  [1] Daily" -ForegroundColor Yellow
    Write-Host "  [2] Weekly" -ForegroundColor Yellow
    Write-Host "  [3] Monthly" -ForegroundColor Yellow
    Write-Host "  [4] Continuously" -ForegroundColor Yellow
    Write-Host "  [5] Enable / Disable schedule" -ForegroundColor Yellow
    Write-Host "  [0] Cancel" -ForegroundColor DarkGray
    Write-Host ""
    $choice = Read-Host "  Select schedule type"

    function Read-ValidTime {
        $t = ""
        do { $t = Read-Host "  Run at time (HH:mm, e.g. 22:00)" } while ($t -notmatch '^\d{2}:\d{2}$')
        return [datetime]::ParseExact($t, "HH:mm", $null)
    }

    switch ($choice) {
        "1" {
            $runAt = Read-ValidTime
            try {
                Set-VBRJobScheduleOptions -Job $Job -Type Daily -At $runAt -ErrorAction Stop
                Log-Change $Job.Name "Schedule" "previous" "Daily at $($runAt.ToString('HH:mm'))"
                Write-Success "Schedule set to Daily at $($runAt.ToString('HH:mm'))"
            } catch { Write-Err "Failed: $_" }
        }
        "2" {
            $runAt   = Read-ValidTime
            Write-Host "  Days: Monday Tuesday Wednesday Thursday Friday Saturday Sunday" -ForegroundColor Gray
            $daysStr = Read-Host "  Day(s), comma-separated (e.g. Monday,Wednesday,Friday)"
            $days    = $daysStr -split "," | ForEach-Object { $_.Trim() }
            try {
                Set-VBRJobScheduleOptions -Job $Job -Type Weekly -At $runAt -Days $days -ErrorAction Stop
                Log-Change $Job.Name "Schedule" "previous" "Weekly $($days -join ',') @ $($runAt.ToString('HH:mm'))"
                Write-Success "Schedule set to Weekly."
            } catch { Write-Err "Failed: $_" }
        }
        "3" {
            $runAt      = Read-ValidTime
            Write-Host "  Occurrence: First Second Third Fourth Last" -ForegroundColor Gray
            $occurrence = Read-Host "  Occurrence"
            Write-Host "  Day: Monday Tuesday Wednesday Thursday Friday Saturday Sunday Day" -ForegroundColor Gray
            $dayOfWeek  = Read-Host "  Day of week"
            Write-Host "  Months (comma-separated or 'all'):" -ForegroundColor Gray
            $mIn = Read-Host "  Month(s)"
            $months = if ($mIn.Trim().ToLower() -eq "all") {
                @("January","February","March","April","May","June","July","August","September","October","November","December")
            } else {
                $mIn -split "," | ForEach-Object { $_.Trim() }
            }
            try {
                Set-VBRJobScheduleOptions -Job $Job -Type Monthly -At $runAt `
                    -Months $months -DayOfMonth $occurrence -DayOfWeek $dayOfWeek -ErrorAction Stop
                Log-Change $Job.Name "Schedule" "previous" "Monthly $occurrence $dayOfWeek @ $($runAt.ToString('HH:mm'))"
                Write-Success "Schedule set to Monthly."
            } catch { Write-Err "Failed: $_" }
        }
        "4" {
            if (Confirm-Action "Set '$($Job.Name)' to run continuously?") {
                try {
                    Set-VBRJobScheduleOptions -Job $Job -Type Continuously -ErrorAction Stop
                    Log-Change $Job.Name "Schedule" "previous" "Continuously"
                    Write-Success "Schedule set to Continuously."
                } catch { Write-Err "Failed: $_" }
            }
        }
        "5" {
            $enabled = $Job.IsScheduleEnabled
            $action  = if ($enabled) { "Disable" } else { "Enable" }
            if (Confirm-Action "$action schedule for '$($Job.Name)'?") {
                try {
                    if ($enabled) { Disable-VBRJob -Job $Job -ErrorAction Stop }
                    else          { Enable-VBRJob  -Job $Job -ErrorAction Stop }
                    Log-Change $Job.Name "Schedule Enabled" "$enabled" "$(-not $enabled)"
                    Write-Success "Schedule $($action)d."
                } catch { Write-Err "Failed: $_" }
            }
        }
        default { Write-Info "Cancelled." }
    }
}
