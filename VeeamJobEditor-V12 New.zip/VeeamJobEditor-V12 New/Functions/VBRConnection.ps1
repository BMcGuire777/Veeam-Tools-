function Initialize-VBRConnection {
    Write-Header "Connecting to Veeam VBR"

    if (-not (Get-Module -Name "Veeam.Backup.PowerShell" -ErrorAction SilentlyContinue)) {
        try {
            Import-Module Veeam.Backup.PowerShell -DisableNameChecking -ErrorAction Stop
            Write-Success "Loaded Veeam.Backup.PowerShell module."
        } catch {
            try {
                Add-PSSnapin VeeamPSSnapin -ErrorAction Stop
                Write-Success "Loaded VeeamPSSnapin snap-in."
            } catch {
                Write-Err "Could not load Veeam PowerShell module or snap-in."
                Write-Err "Ensure VBR v12 console is installed and run as Administrator."
                exit 1
            }
        }
    }

    Write-Host ""
    $inputServer = Read-Host "  VBR Server (Enter for '$script:VBRServer')"
    if ($inputServer.Trim() -ne "") { $script:VBRServer = $inputServer.Trim() }

    try {
        Disconnect-VBRServer -ErrorAction SilentlyContinue | Out-Null
        Connect-VBRServer -Server $script:VBRServer -ErrorAction Stop
        Write-Success "Connected to: $script:VBRServer"
    } catch {
        Write-Err "Connection failed: $_"
        exit 1
    }
}
