function Get-AllEditableJobs {
    # -WarningAction SilentlyContinue suppresses the v12 warning about computer backup jobs
    # @() forces the result to always be an array so .Count is safe under Set-StrictMode
    $raw  = @(Get-VBRJob -WarningAction SilentlyContinue |
              Where-Object { $_.JobType -eq "Backup" -or $_.JobType -eq "BackupSync" })
    return @($raw | Sort-Object Name)
}

function Show-JobTable {
    param([array]$Jobs)
    Write-Host ""
    Write-Host ("  {0,-4} {1,-38} {2,-14} {3,-22} {4,-6} {5}" -f "#", "Job Name", "Type", "Repository", "Points", "Status") -ForegroundColor White
    Write-Host ("  {0,-4} {1,-38} {2,-14} {3,-22} {4,-6} {5}" -f "----", "--------", "----", "----------", "------", "------") -ForegroundColor DarkGray

    for ($i = 0; $i -lt $Jobs.Count; $i++) {
        $j     = $Jobs[$i]
        $type  = if ($j.JobType -eq "BackupSync") { "Backup Copy" } else { "VMware Backup" }
        $repo  = try { $j.GetTargetRepository().Name } catch { "N/A" }
        $pts   = try { $j.Options.BackupStorageOptions.RetainCycles } catch { "N/A" }
        $state = try { $j.GetLastResult() } catch { "Unknown" }
        $color = if ($j.JobType -eq "BackupSync") { "Magenta" } else { "Cyan" }
        Write-Host ("  {0,-4} {1,-38} {2,-14} {3,-22} {4,-6} {5}" -f ($i+1), (Truncate-String $j.Name 37), $type, (Truncate-String $repo 21), $pts, $state) -ForegroundColor $color
    }
    Write-Host ""
}

function Select-SingleJob {
    param([string]$Prompt = "Select a job")
    $jobs = @(Get-AllEditableJobs)
    if ($jobs.Count -eq 0) { Write-Err "No jobs found."; return $null }
    Show-JobTable -Jobs $jobs
    do {
        $sel = Read-Host "  $Prompt (1-$($jobs.Count), 0 to cancel)"
        if ($sel -eq "0") { return $null }
    } while ($sel -notmatch '^\d+$' -or [int]$sel -lt 1 -or [int]$sel -gt $jobs.Count)
    return $jobs[[int]$sel - 1]
}

function Select-MultipleJobs {
    param([string]$ExcludeJobName = "")
    $jobs = @(Get-AllEditableJobs | Where-Object { $_.Name -ne $ExcludeJobName })
    if ($jobs.Count -eq 0) {
        Write-Err "No target jobs available."
        Write-Warn "There are no other jobs to copy settings to."
        Write-Warn "Add more jobs in VBR first, then try bulk copy again."
        Pause-Screen
        return @()
    }
    Show-JobTable -Jobs $jobs
    Write-Info "Enter job numbers comma-separated (e.g. 1,3,5) or 'all':"
    $input = Read-Host "  Selection"
    if ($input.Trim().ToLower() -eq "all") { return $jobs }
    $selected = @()
    foreach ($idx in ($input -split "," | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' })) {
        $i = [int]$idx - 1
        if ($i -ge 0 -and $i -lt $jobs.Count) { $selected += $jobs[$i] }
    }
    return $selected
}
