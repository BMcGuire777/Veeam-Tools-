#!/usr/bin/env pwsh
#Requires -Version 7.0
<#
.SYNOPSIS
    3-Import-VBRConfig.ps1
    Import Veeam job configurations onto a VBR v13 (Rocky Linux VSA) server

.DESCRIPTION
    Run on the TARGET Veeam VBR v13 Linux appliance using pwsh 7 as root/sudo.
    Reads v13-import.json and recreates all jobs.

    Prerequisites on the v13 appliance before running:
      - Repositories already added by name (matching v12 names)
      - Proxies already added by name
      - vCenter / ESXi hosts already added and managed
      - WAN accelerators configured if used
      - This script does NOT migrate credentials

    HTTP 429 handling:
      VBR v13 rate-limits API calls. Every cmdlet call goes through
      Invoke-VBR which retries with exponential backoff on 429/throttle errors.

    Cleanup step (optional, last):
      After all jobs are imported the script offers to remove proxies,
      repositories, and managed servers from the SOURCE v12 server inventory.
      NOTE: The cleanup connection must be run FROM the v12 server itself,
      not remotely from v13. The script will warn you and ask for confirmation.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ---- Global state --------------------------------------------------

$script:Results     = [System.Collections.Generic.List[hashtable]]::new()
$script:RetryMax    = 5
$script:RetryBaseMs = 2000   # 2 s base, doubles each retry

# ---- Console helpers -----------------------------------------------

function Write-Section  { param($T) Write-Host ""; Write-Host ("=" * 70) -ForegroundColor Cyan;  Write-Host "  $T" -ForegroundColor Cyan;  Write-Host ("=" * 70) -ForegroundColor Cyan  }
function Write-OK       { param($T) Write-Host "  [OK]  $T" -ForegroundColor Green  }
function Write-Info     { param($T) Write-Host "  [--]  $T" -ForegroundColor Gray   }
function Write-Warn     { param($T) Write-Host "  [!!]  $T" -ForegroundColor Yellow }
function Write-Fail     { param($T) Write-Host "  [XX]  $T" -ForegroundColor Red    }
function Write-Skip     { param($T) Write-Host "  [..] SKIP  $T" -ForegroundColor DarkGray }

function Confirm-Step {
    param($Prompt)
    $r = Read-Host "  $Prompt [y/N]"
    return ($r -match '^[Yy]')
}

function Add-Result {
    param($JobName, $JobType, $Status, $Error = "")
    $script:Results.Add(@{ JobName = $JobName; JobType = $JobType; Status = $Status; Error = $Error })
}

# ---- Retry wrapper -------------------------------------------------
# Catches HTTP 429 / throttle / rate-limit errors from VBR v13 API.

function Invoke-VBR {
    param([scriptblock]$Block, [string]$Label = "")
    $attempt = 0
    $delayMs = $script:RetryBaseMs
    while ($true) {
        try {
            return (& $Block)
        } catch {
            $msg   = $_.Exception.Message
            $is429 = ($msg -match "429" -or $msg -match "throttl" -or $msg -match "rate.limit" -or $msg -match "TooManyRequests")
            $attempt++
            if ($is429 -and $attempt -lt $script:RetryMax) {
                $waitSec  = [math]::Round($delayMs / 1000, 1)
                $labelStr = if ($Label) { " ($Label)" } else { "" }
                Write-Warn "  Rate limited$labelStr. Waiting ${waitSec}s (attempt $attempt/$($script:RetryMax))..."
                Start-Sleep -Milliseconds $delayMs
                $delayMs = [math]::Min($delayMs * 2, 60000)
            } else {
                throw
            }
        }
    }
}

# ---- VBR Connection ------------------------------------------------

function Connect-VBR13 {
    try {
        Import-Module Veeam.Backup.PowerShell -ErrorAction Stop
        Write-OK "Loaded Veeam.Backup.PowerShell module"
    } catch {
        Write-Fail "Could not load Veeam.Backup.PowerShell: $_"
        Write-Info "Make sure the Veeam PowerShell module is installed on this appliance."
        exit 1
    }

    try {
        $existing = Get-VBRServerSession -ErrorAction SilentlyContinue
        if ($existing) { Write-OK "Already connected to $($existing.Server)"; return }
    } catch {}

    try {
        Invoke-VBR { Connect-VBRServer -Server localhost -ErrorAction Stop } "Connect"
        Write-OK "Connected to VBR on localhost"
    } catch {
        if ($_ -match "already connected") {
            Write-OK "Already connected (reusing session)"
        } else {
            Write-Fail "Could not connect to VBR: $_"
            exit 1
        }
    }
}

# ---- Infrastructure lookup helpers ---------------------------------
# Get-VBRBackupRepository, Get-VBRViProxy, Get-VBRHvProxy have no -Name
# parameter - must enumerate and filter with Where-Object.

function Get-RepoByName {
    param([string]$Name)
    if (-not $Name) { return $null }
    $repo = Invoke-VBR {
        Get-VBRBackupRepository | Where-Object { $_.Name -eq $Name } | Select-Object -First 1
    } "GetRepo:$Name"
    if (-not $repo) {
        try {
            $repo = Invoke-VBR {
                Get-VBRScaleOutBackupRepository |
                    Where-Object { $_.Name -eq $Name } |
                    Select-Object -First 1
            } "GetSOBR:$Name"
        } catch {}
    }
    return $repo
}

function Get-ViProxyByName {
    param([string]$Name)
    if (-not $Name) { return $null }
    Invoke-VBR {
        Get-VBRViProxy | Where-Object { $_.Name -eq $Name } | Select-Object -First 1
    } "GetViProxy:$Name"
}

function Get-HvProxyByName {
    param([string]$Name)
    if (-not $Name) { return $null }
    Invoke-VBR {
        Get-VBRHvProxy | Where-Object { $_.Name -eq $Name } | Select-Object -First 1
    } "GetHvProxy:$Name"
}

function Get-WanByName {
    param([string]$Name)
    if (-not $Name) { return $null }
    Invoke-VBR {
        Get-VBRWanAccelerator | Where-Object { $_.Name -eq $Name } | Select-Object -First 1
    } "GetWan:$Name"
}

function Resolve-ProxyList {
    param($Job)
    if ($Job.IsAutoProxy -eq $true) { return @() }
    $proxies = @()
    foreach ($pName in @($Job.ProxyNames)) {
        $p = Get-ViProxyByName $pName
        if (-not $p) { $p = Get-HvProxyByName $pName }
        if ($p) { $proxies += $p } else { Write-Warn "    Proxy '$pName' not found - skipping" }
    }
    return $proxies
}

# ---- Schedule application ------------------------------------------
# Uses the confirmed Set-VBRJobScheduleOptions -Type pattern from the
# existing VeeamJobEditor (EditSchedule.ps1, MassEditSchedule.ps1).
# -At takes a [datetime] from ParseExact("HH:mm").
# Enable/disable via Enable-VBRJob / Disable-VBRJob (confirmed).

function Apply-Schedule {
    param($Job, $Sched)
    if (-not $Sched -or $Sched.Enabled -eq $false) { return }

    try {
        $runType = "$($Sched.RunType)"

        switch ($runType) {
            "Daily" {
                $timeStr = if ($Sched.DailyTime) { $Sched.DailyTime } else { "22:00" }
                $at      = [datetime]::ParseExact($timeStr, "HH:mm", $null)
                Invoke-VBR {
                    Set-VBRJobScheduleOptions -Job $Job -Type Daily -At $at -ErrorAction Stop
                } "SetSchedDaily"
            }
            "Weekly" {
                $timeStr = if ($Sched.WeeklyTime) { $Sched.WeeklyTime } else { "22:00" }
                $at      = [datetime]::ParseExact($timeStr, "HH:mm", $null)
                $days    = if ($Sched.WeeklyDays -and @($Sched.WeeklyDays).Count -gt 0) {
                    @($Sched.WeeklyDays)
                } else { @("Saturday") }
                Invoke-VBR {
                    Set-VBRJobScheduleOptions -Job $Job -Type Weekly -At $at -Days $days -ErrorAction Stop
                } "SetSchedWeekly"
            }
            "Monthly" {
                $timeStr  = if ($Sched.MonthlyTime) { $Sched.MonthlyTime } else { "22:00" }
                $at       = [datetime]::ParseExact($timeStr, "HH:mm", $null)
                $months   = if ($Sched.MonthlyMonths -and @($Sched.MonthlyMonths).Count -gt 0) {
                    @($Sched.MonthlyMonths)
                } else { @("January","February","March","April","May","June","July","August","September","October","November","December") }
                $dayNum   = if ($Sched.MonthlyDayOfMonth) { $Sched.MonthlyDayOfMonth } else { "First" }
                $dayOfWk  = if ($Sched.MonthlyDayOfWeek)  { $Sched.MonthlyDayOfWeek  } else { "Saturday" }
                Invoke-VBR {
                    Set-VBRJobScheduleOptions -Job $Job -Type Monthly -At $at `
                        -Months $months -DayOfMonth $dayNum -DayOfWeek $dayOfWk -ErrorAction Stop
                } "SetSchedMonthly"
            }
            "Continuously" {
                Invoke-VBR {
                    Set-VBRJobScheduleOptions -Job $Job -Type Continuously -ErrorAction Stop
                } "SetSchedCont"
            }
            default {
                Write-Warn "    Schedule type '$runType' not auto-applied - configure manually in console."
                return
            }
        }

        Invoke-VBR { Enable-VBRJob -Job $Job -ErrorAction Stop } "EnableJob"
        Write-Info "    Schedule applied and enabled ($runType)"
    } catch {
        Write-Warn "    Schedule could not be applied: $($_.Exception.Message)"
    }
}

# ---- GFS application -----------------------------------------------
# GFS settings live flat on BackupStorageOptions, not in a GFSPolicyOptions
# hierarchy. Confirmed from EditGfsRetention.ps1 and MassEditGfs.ps1.

function Apply-GFS {
    param($Job, $GFS)
    if (-not $GFS -or $GFS.IsEnabled -eq $false) { return }
    try {
        $opts = Invoke-VBR { Get-VBRJobOptions -Job $Job -ErrorAction Stop } "GetOptsGFS"
        $bso  = $opts.BackupStorageOptions
        $bso.EnableGfsOptions = $true
        if ($GFS.WeeklyEnabled -eq $true) {
            $bso.GfsWeeklyBackups        = [int]$GFS.WeeklyKeep
            $bso.WeeklyBackupDayOfWeek   = $GFS.WeeklyDayOfWk
        }
        if ($GFS.MonthlyEnabled -eq $true) {
            $bso.GfsMonthlyBackups       = [int]$GFS.MonthlyKeep
        }
        if ($GFS.YearlyEnabled -eq $true) {
            $bso.GfsYearlyBackups        = [int]$GFS.YearlyKeep
            $bso.YearlyBackupMonthOfYear = $GFS.YearlyMonth
        }
        Invoke-VBR { Set-VBRJobOptions -Job $Job -Options $opts -ErrorAction Stop } "SetOptsGFS"
        Write-Info "    GFS applied"
    } catch {
        Write-Warn "    GFS could not be applied: $($_.Exception.Message)"
    }
}

# ---- Retention application -----------------------------------------
# Uses the documented dual-property approach from EditHelpers.ps1.
# BackupCopy (v13 type): GenerationPolicy.SimpleRetentionRestorePoints
# All others:            BackupStorageOptions.RetainCycles

function Apply-Retention {
    param($Job, [int]$RestorePoints, [string]$JobType)
    try {
        $opts = Invoke-VBR { Get-VBRJobOptions -Job $Job -ErrorAction Stop } "GetOptsRet"
        if ($JobType -eq "BackupCopy") {
            $opts.GenerationPolicy.SimpleRetentionRestorePoints = $RestorePoints
        } else {
            $opts.BackupStorageOptions.RetainCycles = $RestorePoints
        }
        Invoke-VBR { Set-VBRJobOptions -Job $Job -Options $opts -ErrorAction Stop } "SetOptsRet"
    } catch {
        Write-Warn "    Retention could not be set: $($_.Exception.Message)"
    }
}

# ---- Storage/compression application -------------------------------
# Set-VBRJobAdvancedBackupOptions is the confirmed cmdlet (not
# Set-VBRJobStorageOptions which does not exist).

function Apply-Storage {
    param($Job, $Storage)
    if (-not $Storage) { return }
    try {
        $level = if ($null -ne $Storage.CompressionLevel) { [int]$Storage.CompressionLevel } else { 5 }
        Invoke-VBR {
            Set-VBRJobAdvancedBackupOptions -Job $Job -CompressionLevel $level -ErrorAction Stop
        } "SetCompression"
    } catch {
        Write-Warn "    Compression could not be applied: $($_.Exception.Message)"
    }
}

# ---- Import: Backup Job --------------------------------------------

function Import-BackupJob {
    param($JobDef)
    $name = $JobDef.Name
    Write-Info "  [Backup] $name"

    try {
        $existing = Invoke-VBR { Get-VBRJob -Name $name -ErrorAction SilentlyContinue } "CheckExisting"
        if ($existing) {
            Write-Skip "$name - already exists"
            Add-Result $name "Backup" "SKIPPED" "Already exists"
            return
        }

        $repo = Get-RepoByName $JobDef.RepositoryName
        if (-not $repo) {
            Write-Fail "    Repository '$($JobDef.RepositoryName)' not found - skipping $name"
            Add-Result $name "Backup" "FAILED" "Repository '$($JobDef.RepositoryName)' not found"
            return
        }

        $rp = if ($JobDef.RestorePoints) { [int]$JobDef.RestorePoints } else { 14 }

        $addParams = @{
            Name             = $name
            BackupRepository = $repo
            Description      = if ($JobDef.Description) { $JobDef.Description } else { "" }
        }

        $job = Invoke-VBR { Add-VBRViBackupJob @addParams -ErrorAction Stop } "AddBackup:$name"
        Write-OK "    Created: $name"

        Apply-Retention $job $rp "Backup"
        Apply-Storage   $job $JobDef.Storage
        Apply-GFS       $job $JobDef.GFS
        Apply-Schedule  $job $JobDef.Schedule

        # Proxy assignment - auto-detect is the default; set specific proxies if configured
        $proxies = Resolve-ProxyList $JobDef
        if ($proxies.Count -gt 0) {
            try {
                Invoke-VBR { Set-VBRViBackupJob -Job $job -Proxy $proxies -ErrorAction Stop } "SetProxy:$name"
            } catch {
                Write-Warn "    Proxies not set: $($_.Exception.Message)"
            }
        }

        Add-Result $name "Backup" "SUCCESS"
    } catch {
        Write-Fail "    Failed: $($_.Exception.Message)"
        Add-Result $name "Backup" "FAILED" $_.Exception.Message
    }
}

# ---- Import: Backup Copy Job ---------------------------------------

function Import-BackupCopyJob {
    param($JobDef)
    $name = $JobDef.Name
    Write-Info "  [BackupCopy] $name"

    try {
        $existing = Invoke-VBR { Get-VBRJob -Name $name -ErrorAction SilentlyContinue } "CheckExisting"
        if ($existing) {
            Write-Skip "$name - already exists"
            Add-Result $name "BackupCopy" "SKIPPED" "Already exists"
            return
        }

        $repo = Get-RepoByName $JobDef.RepositoryName
        if (-not $repo) {
            Write-Fail "    Repository '$($JobDef.RepositoryName)' not found - skipping $name"
            Add-Result $name "BackupCopy" "FAILED" "Repository '$($JobDef.RepositoryName)' not found"
            return
        }

        $rp = if ($JobDef.RestorePoints) { [int]$JobDef.RestorePoints } else { 14 }

        $addParams = @{
            Name             = $name
            BackupRepository = $repo
            Description      = if ($JobDef.Description) { $JobDef.Description } else { "" }
        }

        $job = Invoke-VBR { Add-VBRViBackupCopyJob @addParams -ErrorAction Stop } "AddCopy:$name"
        Write-OK "    Created: $name"
        Write-Warn "    NOTE: backup copy source job must be configured manually in the console."

        Apply-Retention $job $rp "BackupCopy"
        Apply-GFS       $job $JobDef.GFS
        Apply-Schedule  $job $JobDef.Schedule

        Add-Result $name "BackupCopy" "SUCCESS"
    } catch {
        Write-Fail "    Failed: $($_.Exception.Message)"
        Add-Result $name "BackupCopy" "FAILED" $_.Exception.Message
    }
}

# ---- Import: Replication Job ---------------------------------------

function Import-ReplicationJob {
    param($JobDef)
    $name = $JobDef.Name
    Write-Info "  [Replication] $name"

    try {
        $existing = Invoke-VBR { Get-VBRJob -Name $name -ErrorAction SilentlyContinue } "CheckExisting"
        if ($existing) {
            Write-Skip "$name - already exists"
            Add-Result $name "Replication" "SKIPPED" "Already exists"
            return
        }

        # Target host lookup
        $targetHost = $null
        if ($JobDef.TargetHostName) {
            $targetHost = Invoke-VBR {
                Get-VBRServer | Where-Object { $_.Name -eq $JobDef.TargetHostName } | Select-Object -First 1
            } "GetTargetHost"
        }
        if (-not $targetHost) {
            Write-Fail "    Target host '$($JobDef.TargetHostName)' not found - skipping $name"
            Add-Result $name "Replication" "FAILED" "Target host '$($JobDef.TargetHostName)' not found"
            return
        }

        $rp     = if ($JobDef.RestorePoints) { [int]$JobDef.RestorePoints } else { 3 }
        $suffix = if ($JobDef.ReplicaSuffix) { $JobDef.ReplicaSuffix } else { "_replica" }

        $addParams = @{
            Name             = $name
            Server           = $targetHost
            ReplicaNameSuffix = $suffix
            Description      = if ($JobDef.Description) { $JobDef.Description } else { "" }
        }

        if ($JobDef.TargetDatastoreName) { $addParams["Datastore"] = $JobDef.TargetDatastoreName }
        if ($JobDef.TargetFolderName)    { $addParams["Folder"]    = $JobDef.TargetFolderName    }

        $job = Invoke-VBR { Add-VBRViReplicaJob @addParams -ErrorAction Stop } "AddReplica:$name"
        Write-OK "    Created: $name"

        Apply-Retention $job $rp "Replication"

        # Replication-specific settings via Set-VBRViReplicaJob
        $setParams = @{ Job = $job }

        if ($JobDef.ReplicateFromBackup -eq $true -and $JobDef.SourceRepositoryName) {
            $srcRepo = Get-RepoByName $JobDef.SourceRepositoryName
            if ($srcRepo) {
                $setParams["ReplicateFromBackup"] = $true
                $setParams["SourceRepository"]    = @($srcRepo)
            } else {
                Write-Warn "    Source repository '$($JobDef.SourceRepositoryName)' not found - using production source"
            }
        }

        if ($JobDef.TargetRepositoryName) {
            $tgtRepo = Get-RepoByName $JobDef.TargetRepositoryName
            if ($tgtRepo) { $setParams["BackupRepository"] = $tgtRepo }
        }

        if ($JobDef.DiskType) { $setParams["DiskType"] = $JobDef.DiskType }

        if ($JobDef.UseWANAccelerator -eq $true) {
            $srcWan = Get-WanByName $JobDef.SourceWANAccelName
            $tgtWan = Get-WanByName $JobDef.TargetWANAccelName
            if ($srcWan -and $tgtWan) {
                $setParams["UseWANAccelerator"]    = $true
                $setParams["SourceWANAccelerator"] = $srcWan
                $setParams["TargetWANAccelerator"] = $tgtWan
            } else {
                Write-Warn "    WAN accelerators not found - skipping WAN config"
            }
        }

        if ($JobDef.SeedingEnabled -eq $true -and $JobDef.SeedRepositoryName) {
            $seedRepo = Get-RepoByName $JobDef.SeedRepositoryName
            if ($seedRepo) {
                $setParams["EnableSeeding"]  = $true
                $setParams["RepositorySeed"] = $seedRepo
            } else {
                Write-Warn "    Seed repository '$($JobDef.SeedRepositoryName)' not found - skipping seeding"
            }
        }

        if ($setParams.Count -gt 1) {
            try {
                Invoke-VBR { Set-VBRViReplicaJob @setParams -ErrorAction Stop } "SetReplica:$name"
            } catch {
                Write-Warn "    Some replication settings failed: $($_.Exception.Message)"
            }
        }

        # Proxy assignment for replication uses Set-VBRViReplicaJob -AutoSourceProxy / -SourceProxy
        $proxies = Resolve-ProxyList $JobDef
        try {
            if ($proxies.Count -gt 0) {
                Invoke-VBR {
                    Set-VBRViReplicaJob -Job $job -SourceProxy $proxies[0] -ErrorAction Stop
                } "SetSrcProxy:$name"
            } else {
                Invoke-VBR {
                    Set-VBRViReplicaJob -Job $job -AutoSourceProxy -ErrorAction Stop
                } "SetAutoProxy:$name"
            }
        } catch {
            Write-Warn "    Proxy assignment failed: $($_.Exception.Message)"
        }

        Apply-Schedule $job $JobDef.Schedule

        Add-Result $name "Replication" "SUCCESS"
    } catch {
        Write-Fail "    Failed: $($_.Exception.Message)"
        Add-Result $name "Replication" "FAILED" $_.Exception.Message
    }
}

# ---- Import: Agent Job (informational) -----------------------------

function Import-AgentJob {
    param($JobDef)
    $name = $JobDef.Name
    Write-Info "  [Agent] $name"
    Write-Warn "    Agent jobs require manual reconfiguration in the VBR console."
    Write-Warn "    Captured: Name='$name'  Repo='$($JobDef.RepositoryName)'"
    Add-Result $name "Agent" "SKIPPED" "Agent jobs require manual console setup"
}

# ---- Import: NAS Job (informational) -------------------------------

function Import-NASJob {
    param($JobDef)
    $name = $JobDef.Name
    Write-Info "  [NAS] $name"

    try {
        $existing = Invoke-VBR { Get-VBRJob -Name $name -ErrorAction SilentlyContinue } "CheckExisting"
        if ($existing) {
            Write-Skip "$name - already exists"
            Add-Result $name "NAS" "SKIPPED" "Already exists"
            return
        }

        $repo = Get-RepoByName $JobDef.RepositoryName
        if (-not $repo) {
            Write-Warn "    Repository '$($JobDef.RepositoryName)' not found"
            Add-Result $name "NAS" "FAILED" "Repository '$($JobDef.RepositoryName)' not found"
            return
        }

        Write-Warn "    NAS jobs: file server source objects must be re-added manually in the console."
        Write-Warn "    Repository resolved: $($repo.Name)"
        Add-Result $name "NAS" "SKIPPED" "NAS source objects require manual re-add - repository resolved OK"
    } catch {
        Write-Fail "    Failed: $($_.Exception.Message)"
        Add-Result $name "NAS" "FAILED" $_.Exception.Message
    }
}

# ---- Import: Tape Job (informational) ------------------------------

function Import-TapeJob {
    param($JobDef)
    $name = $JobDef.Name
    Write-Info "  [Tape] $name"
    Write-Warn "    Tape jobs require the tape library to be present on v13."
    Write-Warn "    Captured: Name='$name'  MediaPool='$($JobDef.TapeMediaPool)'"
    Add-Result $name "Tape" "SKIPPED" "Tape jobs require tape library presence - configure manually"
}

# ---- Dispatch by type ----------------------------------------------

function Import-JobByType {
    param($JobDef)
    $type = "$($JobDef.JobType)"
    switch ($type) {
        "Backup"        { Import-BackupJob      $JobDef }
        "BackupCopy"    { Import-BackupCopyJob  $JobDef }
        "Replication"   { Import-ReplicationJob $JobDef }
        "Agent"         { Import-AgentJob       $JobDef }
        "NAS"           { Import-NASJob         $JobDef }
        "Tape"          { Import-TapeJob        $JobDef }
        default {
            Write-Warn "  Unknown type '$type': $($JobDef.Name) - skipping"
            Add-Result $JobDef.Name $type "SKIPPED" "Unknown job type '$type'"
        }
    }
}

# ---- Summary -------------------------------------------------------

function Show-ImportSummary {
    $CJ = 36; $CT = 16

    Write-Section "Import Summary"
    Write-Host ("  {0,-$CJ} {1,-$CT} {2}" -f "Job Name", "Type", "Result") -ForegroundColor White
    Write-Host ("  {0,-$CJ} {1,-$CT} {2}" -f ("-"*($CJ-1)), ("-"*($CT-1)), "--------") -ForegroundColor DarkGray

    $success = 0; $failed = 0; $skipped = 0
    foreach ($r in $script:Results) {
        $color = switch ($r.Status) {
            "SUCCESS" { $success++; "Green"    }
            "FAILED"  { $failed++;  "Red"      }
            "SKIPPED" { $skipped++; "DarkGray" }
            default   { "Gray" }
        }
        $jName = if ($r.JobName.Length -gt ($CJ-1)) { $r.JobName.Substring(0,$CJ-2) + "~" } else { $r.JobName }
        Write-Host ("  {0,-$CJ} {1,-$CT} {2}" -f $jName, $r.JobType, $r.Status) -ForegroundColor $color
        if ($r.Status -ne "SUCCESS" -and $r.Error) {
            Write-Host "    +- $($r.Error)" -ForegroundColor DarkRed
        }
    }

    Write-Host ""
    Write-Host "  +----------------------------------------------------------------+" -ForegroundColor Cyan
    Write-Host "  |  SUCCESS : $("$success".PadRight(5))  FAILED : $("$failed".PadRight(5))  SKIPPED : $("$skipped".PadRight(5))              |" -ForegroundColor Cyan
    Write-Host "  +----------------------------------------------------------------+" -ForegroundColor Cyan
    Write-Host ""

    if (Confirm-Step "Export import results to file?") {
        $reportPath = Join-Path $PSScriptRoot "VBRImportReport_$(Get-Date -f 'yyyyMMdd_HHmmss').txt"
        $lines  = @()
        $lines += "Veeam VBR v12->v13 Import Report  |  $(Get-Date -f 'yyyy-MM-dd HH:mm:ss')"
        $lines += "=" * 72
        $lines += "{0,-36} {1,-16} {2}" -f "Job Name","Type","Result"
        $lines += "{0,-36} {1,-16} {2}" -f ("-"*35),("-"*15),"--------"
        foreach ($r in $script:Results) {
            $lines += "{0,-36} {1,-16} {2}" -f $r.JobName, $r.JobType, $r.Status
            if ($r.Error) { $lines += "    Note: $($r.Error)" }
        }
        $lines += ""
        $lines += "SUCCESS: $success  |  FAILED: $failed  |  SKIPPED: $skipped  |  TOTAL: $($script:Results.Count)"
        $lines | Out-File -FilePath $reportPath -Encoding UTF8
        Write-OK "Report saved: $reportPath"
    }
}

# ---- Optional Cleanup: remove v12 infrastructure -------------------
# IMPORTANT: This step requires a VBR connection to the v12 Windows server.
# The Veeam v13 module on Linux is likely unable to connect to a v12 server
# cross-version. Run this script from the v12 server itself, or run the
# cleanup commands manually from the v12 server's PowerShell console.

function Invoke-V12Cleanup {
    Write-Section "OPTIONAL: Remove v12 Infrastructure from Inventory"
    Write-Host ""
    Write-Host "  This step removes from the v12 server inventory:" -ForegroundColor Yellow
    Write-Host "    - VMware proxies"    -ForegroundColor Yellow
    Write-Host "    - Hyper-V proxies"   -ForegroundColor Yellow
    Write-Host "    - WAN accelerators"  -ForegroundColor Yellow
    Write-Host "    - Repositories"      -ForegroundColor Yellow
    Write-Host "    - Managed servers"   -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  WARNING: Cross-version connections (v13 module -> v12 server) are not" -ForegroundColor Red
    Write-Host "  officially supported. If this fails, run cleanup manually on the v12" -ForegroundColor Red
    Write-Host "  server using its own PowerShell console." -ForegroundColor Red
    Write-Host ""
    Write-Host "  IMPORTANT: Only run this AFTER validating all jobs on v13." -ForegroundColor Red
    Write-Host ""

    if (-not (Confirm-Step "Proceed with v12 infrastructure cleanup?")) {
        Write-Info "Cleanup skipped."
        return
    }

    $v12Server = Read-Host "  Enter v12 server hostname or IP"
    if (-not $v12Server) { Write-Info "Cleanup skipped - no server provided."; return }

    Write-Info "Connecting to v12 server: $v12Server"
    try {
        Invoke-VBR { Connect-VBRServer -Server $v12Server -ErrorAction Stop } "ConnectV12"
        Write-OK "Connected to v12: $v12Server"
    } catch {
        Write-Fail "Could not connect to v12: $_"
        Write-Info "Cleanup aborted. Run the following manually on the v12 server:"
        Write-Info "  Get-VBRViProxy | Remove-VBRViProxy -Confirm:$false"
        Write-Info "  Get-VBRBackupRepository | Remove-VBRBackupRepository -Confirm:$false"
        Write-Info "  Get-VBRServer | Where-Object { `$_.Type -in @('ESXi','VC','HvServer','HvCluster') } | Remove-VBRServer -Confirm:$false"
        return
    }

    # VMware proxies
    Write-Host ""
    Write-Info "Removing VMware proxies..."
    try {
        $proxies = @(Get-VBRViProxy)
        foreach ($p in $proxies) {
            try {
                Invoke-VBR { Remove-VBRViProxy -ProxyServer $p -Confirm:$false -ErrorAction Stop } "RemProxy:$($p.Name)"
                Write-OK "  Removed proxy: $($p.Name)"
            } catch { Write-Warn "  Could not remove proxy '$($p.Name)': $($_.Exception.Message)" }
        }
    } catch { Write-Warn "Could not enumerate proxies: $_" }

    # Hyper-V proxies
    try {
        $hvProxies = @(Get-VBRHvProxy -ErrorAction SilentlyContinue)
        foreach ($p in $hvProxies) {
            try {
                Invoke-VBR { Remove-VBRHvProxy -ProxyServer $p -Confirm:$false -ErrorAction Stop } "RemHvProxy:$($p.Name)"
                Write-OK "  Removed HV proxy: $($p.Name)"
            } catch { Write-Warn "  Could not remove HV proxy '$($p.Name)': $($_.Exception.Message)" }
        }
    } catch {}

    # WAN Accelerators
    Write-Info "Removing WAN accelerators..."
    try {
        $wans = @(Get-VBRWanAccelerator)
        foreach ($w in $wans) {
            try {
                Invoke-VBR { Remove-VBRWanAccelerator -WanAccelerator $w -Confirm:$false -ErrorAction Stop } "RemWan:$($w.Name)"
                Write-OK "  Removed WAN accel: $($w.Name)"
            } catch { Write-Warn "  Could not remove WAN accel '$($w.Name)': $($_.Exception.Message)" }
        }
    } catch { Write-Skip "WAN accelerators (none or error)" }

    # Repositories
    Write-Info "Removing repositories..."
    try {
        $repos = @(Get-VBRBackupRepository | Sort-Object Name)
        foreach ($r in $repos) {
            try {
                Invoke-VBR { Remove-VBRBackupRepository -Repository $r -Confirm:$false -ErrorAction Stop } "RemRepo:$($r.Name)"
                Write-OK "  Removed repository: $($r.Name)"
            } catch { Write-Warn "  Could not remove repository '$($r.Name)': $($_.Exception.Message)" }
        }
    } catch { Write-Warn "Could not enumerate repositories: $_" }

    # Managed Servers - ESXi, vCenter, Hyper-V hosts only; exclude the VBR server itself
    Write-Info "Removing managed servers..."
    try {
        $infraTypes = @("ESXi", "VC", "HvServer", "HvCluster", "Linux", "Windows")
        $servers = @(Get-VBRServer |
            Where-Object { $_.Type.ToString() -in $infraTypes } |
            Where-Object { $_.Name -ne "localhost" -and $_.Name -ne $env:COMPUTERNAME } |
            Sort-Object Name)
        foreach ($s in $servers) {
            try {
                Invoke-VBR { Remove-VBRServer -Server $s -Confirm:$false -ErrorAction Stop } "RemServer:$($s.Name)"
                Write-OK "  Removed managed server: $($s.Name)"
            } catch { Write-Warn "  Could not remove server '$($s.Name)': $($_.Exception.Message)" }
        }
    } catch { Write-Warn "Could not enumerate managed servers: $_" }

    Write-Host ""
    Write-OK "v12 cleanup complete."
    try { Disconnect-VBRServer -ErrorAction SilentlyContinue } catch {}
}

# ---- Main ----------------------------------------------------------

Clear-Host
Write-Host ""
Write-Host "  +====================================================================+" -ForegroundColor Cyan
Write-Host "  |    Veeam VBR v12  ->  v13 Migration  |  Step 3: Import Config      |" -ForegroundColor Cyan
Write-Host "  +====================================================================+" -ForegroundColor Cyan
Write-Host ""

$inPath = Join-Path $PSScriptRoot "v13-import.json"

if (-not (Test-Path $inPath)) {
    Write-Fail "v13-import.json not found at: $inPath"
    Write-Info "Run 2-Translate-VBRConfig.ps1 first to produce v13-import.json."
    exit 1
}

Write-Section "Loading v13-import.json"
$raw    = Get-Content $inPath -Raw -Encoding UTF8
$import = $raw | ConvertFrom-Json
Write-OK "Loaded $($import.JobCount) job(s) translated from $($import.SourceServer)"
Write-Info "Originally exported: $($import.OriginalExportedAt)"
Write-Info "Translated at      : $($import.TranslatedAt)"

Connect-VBR13

Write-Section "Importing Jobs"

$typeOrder = @("Backup","BackupCopy","Replication","Agent","NAS","Tape")
$jobs      = @($import.Jobs)

foreach ($type in $typeOrder) {
    $subset = @($jobs | Where-Object { $_.JobType -eq $type })
    foreach ($j in $subset) { Import-JobByType $j }
}

# Anything left with types not in the known list
$knownTypes = [System.Collections.Generic.HashSet[string]]::new()
foreach ($t in $typeOrder) { [void]$knownTypes.Add($t) }
$remaining = @($jobs | Where-Object { -not $knownTypes.Contains("$($_.JobType)") })
foreach ($j in $remaining) { Import-JobByType $j }

Show-ImportSummary

# ---- Optional v12 cleanup ------------------------------------------

Write-Host ""
if (Confirm-Step "Would you like to run the optional v12 infrastructure cleanup step?") {
    Invoke-V12Cleanup
} else {
    Write-Info "Cleanup skipped. You can remove v12 infrastructure manually when ready."
}

Write-Host ""
Write-OK "Migration import complete."
Write-Host ""
Write-Host "  Recommended post-import checklist:" -ForegroundColor White
Write-Host "    1. Open VBR console and add VM source objects to each backup job" -ForegroundColor Gray
Write-Host "    2. Configure backup copy job source jobs in the console" -ForegroundColor Gray
Write-Host "    3. Run each job once manually before relying on the schedule" -ForegroundColor Gray
Write-Host "    4. Verify notification settings and recipients in the console" -ForegroundColor Gray
Write-Host "    5. Re-add agent computers and NAS file servers manually" -ForegroundColor Gray
Write-Host "    6. Validate tape library availability if tape jobs are present" -ForegroundColor Gray
Write-Host "    7. Review proxy assignments for replication jobs in the console" -ForegroundColor Gray
Write-Host ""

try { Disconnect-VBRServer -ErrorAction SilentlyContinue } catch {}
