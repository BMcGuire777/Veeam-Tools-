#Requires -Version 5.1
<#
.SYNOPSIS
    1-Export-VBRConfig.ps1
    Export all Veeam VBR v12 job configurations to v12-export.json

.DESCRIPTION
    Run on the SOURCE Veeam VBR v12 Windows server as Administrator.
    Connects to the local VBR server, enumerates ALL job types present,
    and serializes every job's settings to JSON.

    No credentials are exported. Infrastructure objects (repositories,
    proxies, managed servers, gateways, mount servers) are captured by
    NAME only so the translation layer can validate target readiness.

    Output file: v12-export.json  (written to the folder this script lives in)

.NOTES
    Run from PowerShell 5.1 as Administrator on the VBR v12 Windows server.
    Copy v12-export.json to the VBRMigration folder on the v13 appliance
    before running 2-Translate-VBRConfig.ps1 and 3-Import-VBRConfig.ps1.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ---- Helpers -------------------------------------------------------

function Write-Section  { param($T) Write-Host ""; Write-Host ("=" * 70) -ForegroundColor Cyan;  Write-Host "  $T" -ForegroundColor Cyan;  Write-Host ("=" * 70) -ForegroundColor Cyan  }
function Write-OK       { param($T) Write-Host "  [OK]  $T" -ForegroundColor Green  }
function Write-Info     { param($T) Write-Host "  [--]  $T" -ForegroundColor Gray   }
function Write-Warn     { param($T) Write-Host "  [!!]  $T" -ForegroundColor Yellow }
function Write-Fail     { param($T) Write-Host "  [XX]  $T" -ForegroundColor Red    }
function Write-Skip     { param($T) Write-Host "  [..] SKIP  $T" -ForegroundColor DarkGray }

function Safe-Get {
    param([scriptblock]$Block, $Default = $null)
    try { $v = & $Block; if ($null -eq $v) { $Default } else { $v } }
    catch { $Default }
}

function Names-Of {
    param($Collection)
    @($Collection | ForEach-Object { $_.Name } | Where-Object { $_ })
}

# ---- VBR Connection ------------------------------------------------

function Connect-VBR12 {
    try {
        $snap = Get-PSSnapin -Name VeeamPSSnapin -ErrorAction SilentlyContinue
        if (-not $snap) {
            Add-PSSnapin VeeamPSSnapin -ErrorAction Stop
            Write-OK "Loaded VeeamPSSnapin"
        }
    } catch {
        try {
            Import-Module Veeam.Backup.PowerShell -ErrorAction Stop
            Write-OK "Loaded Veeam.Backup.PowerShell module"
        } catch {
            Write-Fail "Could not load Veeam snap-in or module: $_"
            exit 1
        }
    }

    try {
        $existing = Get-VBRServerSession -ErrorAction SilentlyContinue
        if ($existing) { Write-OK "Already connected to $($existing.Server)"; return }
    } catch {}

    try {
        Connect-VBRServer -Server localhost -ErrorAction Stop
        Write-OK "Connected to VBR on localhost"
    } catch {
        if ($_ -match "already connected") {
            Write-OK "Already connected (reusing session)"
        } else {
            Write-Fail "Could not connect to VBR: $_"
            exit 1
        }
    }
}

# ---- Schedule extraction -------------------------------------------
# Uses Get-VBRJobScheduleOptions (confirmed cmdlet) and reads documented
# properties: .ScheduleType, .DailyOptions.Period, .WeeklyOptions.*,
# .MonthlyOptions.* - matching the BulkCopy.ps1 and EditSchedule.ps1 patterns.

function Get-ScheduleBlock {
    param($Job)
    $sched = try { Get-VBRJobScheduleOptions -Job $Job } catch { $null }
    if (-not $sched) { return $null }

    [ordered]@{
        Enabled           = Safe-Get { $Job.IsScheduleEnabled } $false
        RunType           = Safe-Get { $sched.ScheduleType.ToString() } "Unknown"
        DailyTime         = Safe-Get { $sched.DailyOptions.Period.ToString("HH:mm") } "22:00"
        WeeklyTime        = Safe-Get { $sched.WeeklyOptions.Period.ToString("HH:mm") } "22:00"
        WeeklyDays        = Safe-Get { @($sched.WeeklyOptions.DaysSrv | ForEach-Object { $_.ToString() }) } @()
        MonthlyTime       = Safe-Get { $sched.MonthlyOptions.Period.ToString("HH:mm") } "22:00"
        MonthlyMonths     = Safe-Get { @($sched.MonthlyOptions.Months | ForEach-Object { $_.ToString() }) } @()
        MonthlyDayOfMonth = Safe-Get { $sched.MonthlyOptions.DayNumberInMonth.ToString() } "First"
        MonthlyDayOfWeek  = Safe-Get { $sched.MonthlyOptions.DayOfWeek.ToString() } "Saturday"
        AutoRetryEnabled  = Safe-Get { $sched.RetryOptions.Enabled } $false
        AutoRetryCount    = Safe-Get { $sched.RetryOptions.RetryCount } 3
        AutoRetryWait     = Safe-Get { $sched.RetryOptions.WaitDelay } 10
    }
}

# ---- Notification extraction ---------------------------------------

function Get-NotificationBlock {
    param($Job)
    $opts = Safe-Get { $Job.Options.NotificationOptions }
    if (-not $opts) { return $null }
    [ordered]@{
        SendEmailEnabled   = Safe-Get { $opts.EnableAdditionalNotification } $false
        SendSNMPEnabled    = Safe-Get { $opts.EnableSNMPNotification } $false
        EmailRecipients    = Safe-Get { $opts.AdditionalEmails } ""
        EmailOnSuccess     = Safe-Get { $opts.EmailNotificationSuccess } $false
        EmailOnWarning     = Safe-Get { $opts.EmailNotificationWarnings } $true
        EmailOnFailure     = Safe-Get { $opts.EmailNotificationFailed } $true
        EmailSubject       = Safe-Get { $opts.EmailNotificationSubject } ""
    }
}

# ---- GFS extraction ------------------------------------------------
# Veeam stores GFS settings flat on BackupStorageOptions, not in a
# separate GFSPolicyOptions hierarchy. Confirmed from EditGfsRetention.ps1
# and MassEditGfs.ps1 in the VeeamJobEditor codebase.

function Get-GFSBlock {
    param($Job)
    $bso = Safe-Get { $Job.Options.BackupStorageOptions }
    if (-not $bso) { return $null }
    [ordered]@{
        IsEnabled      = Safe-Get { $bso.EnableGfsOptions } $false
        WeeklyEnabled  = Safe-Get { $bso.GfsWeeklyBackups -gt 0 } $false
        WeeklyKeep     = Safe-Get { $bso.GfsWeeklyBackups } 4
        WeeklyDayOfWk  = Safe-Get { $bso.WeeklyBackupDayOfWeek.ToString() } "Saturday"
        MonthlyEnabled = Safe-Get { $bso.GfsMonthlyBackups -gt 0 } $false
        MonthlyKeep    = Safe-Get { $bso.GfsMonthlyBackups } 3
        YearlyEnabled  = Safe-Get { $bso.GfsYearlyBackups -gt 0 } $false
        YearlyKeep     = Safe-Get { $bso.GfsYearlyBackups } 1
        YearlyMonth    = Safe-Get { $bso.YearlyBackupMonthOfYear.ToString() } "January"
    }
}

# ---- Storage / Advanced extraction ---------------------------------

function Get-StorageBlock {
    param($Job)
    $opts = Safe-Get { $Job.Options.BackupStorageOptions }
    if (-not $opts) { return $null }
    [ordered]@{
        CompressionLevel    = Safe-Get { $opts.CompressionLevel } 5
        StorageOptimization = Safe-Get { $opts.StgBlockSize.ToString() } "Local"
        EnableDedup         = Safe-Get { $opts.EnableDeduplication } $true
        EncryptionEnabled   = Safe-Get { $opts.StorageEncryptionEnabled } $false
        EncryptionKeyName   = Safe-Get { $opts.EncryptionKey.Description } $null
    }
}

function Get-AdvancedVSphereBlock {
    param($Job)
    $opts = Safe-Get { $Job.Options.ViOptions }
    if (-not $opts) { return $null }
    [ordered]@{
        VmCrashConsistent       = Safe-Get { $opts.VMWareSnapshotOptions.IsCrashConsistentEnabled } $false
        EnableDBLogging         = Safe-Get { $opts.VMWareSnapshotOptions.IsDBLoggingEnabled } $false
        VmAttributeSuffix       = Safe-Get { $opts.VMAttributesOptions.NotesSuffix } $null
        UseChangeTracking       = Safe-Get { $opts.UseChangeTracking } $true
        EnableVmAttributeUpdate = Safe-Get { $opts.VMAttributesOptions.IsEnabled } $false
        DirtyBlocksNulling      = Safe-Get { $opts.BackupOptions.DirtyBlocksNullingEnabled } $false
    }
}

# ---- Source objects (VMs) ------------------------------------------

function Get-SourceObjects {
    param($Job)
    try {
        $objs = @($Job.GetObjectsInJob() | Where-Object { $_ })
        $result = @()
        foreach ($o in $objs) {
            $result += [ordered]@{
                Name        = Safe-Get { $o.Name } "Unknown"
                Type        = Safe-Get { $o.Type.ToString() } "Unknown"
                Location    = Safe-Get { $o.Location } $null
                DisplayName = Safe-Get { $o.DisplayName } $null
            }
        }
        return $result
    } catch {
        return @()
    }
}

# ---- Retention helper ----------------------------------------------
# Reads retention using the documented dual-property approach.
# Backup/Replica: BackupStorageOptions.RetainCycles
# Backup Copy:    GenerationPolicy.SimpleRetentionRestorePoints

function Get-RetentionCount {
    param($Job, [int]$Default = 14)
    if ($Job.JobType -eq "BackupSync") {
        $v = Safe-Get { $Job.Options.GenerationPolicy.SimpleRetentionRestorePoints }
        if ($v) { return [int]$v }
    }
    $v = Safe-Get { $Job.Options.BackupStorageOptions.RetainCycles }
    if ($v) { return [int]$v }
    return $Default
}

# ---- Backup Job export ---------------------------------------------

function Export-BackupJob {
    param($Job)
    Write-Info "  Backup: $($Job.Name)"

    [ordered]@{
        JobType             = "Backup"
        Name                = $Job.Name
        Description         = Safe-Get { $Job.Description } ""
        RepositoryName      = Safe-Get { $Job.GetTargetRepository().Name } $null
        RestorePoints       = Get-RetentionCount $Job 14
        Algorithm           = Safe-Get { $Job.BackupType.ToString() } "Increment"
        FullBackupSchedule  = Safe-Get { $Job.Options.BackupStorageOptions.FullBackupSchedule.Type.ToString() } $null
        ProxyNames          = Names-Of (Safe-Get { @($Job.GetProxy()) } @())
        IsAutoProxy         = Safe-Get { $Job.Options.JobOptions.SourceProxyAutoDetect } $true
        Storage             = Get-StorageBlock $Job
        GFS                 = Get-GFSBlock $Job
        Schedule            = Get-ScheduleBlock $Job
        Notifications       = Get-NotificationBlock $Job
        AdvancedVSphere     = Get-AdvancedVSphereBlock $Job
        SourceObjects       = Get-SourceObjects $Job
    }
}

# ---- Backup Copy Job export ----------------------------------------

function Export-BackupCopyJob {
    param($Job)
    Write-Info "  BackupCopy: $($Job.Name)"

    [ordered]@{
        JobType             = "BackupCopy"
        Name                = $Job.Name
        Description         = Safe-Get { $Job.Description } ""
        RepositoryName      = Safe-Get { $Job.GetTargetRepository().Name } $null
        RestorePoints       = Get-RetentionCount $Job 14
        SyncIntervalMinutes = Safe-Get { $Job.Options.ScheduleOptions.BackupSyncInterval } 1440
        ProxyNames          = Names-Of (Safe-Get { @($Job.GetProxy()) } @())
        IsAutoProxy         = Safe-Get { $Job.Options.JobOptions.SourceProxyAutoDetect } $true
        Storage             = Get-StorageBlock $Job
        GFS                 = Get-GFSBlock $Job
        Schedule            = Get-ScheduleBlock $Job
        Notifications       = Get-NotificationBlock $Job
        SourceObjects       = Get-SourceObjects $Job
    }
}

# ---- Replication Job export ----------------------------------------

function Export-ReplicationJob {
    param($Job)
    Write-Info "  Replication: $($Job.Name)"

    $srcRepo = $null
    try {
        $linked = @($Job.GetSourceRepositories())
        if ($linked.Count -gt 0) { $srcRepo = $linked[0].Name }
    } catch {}

    [ordered]@{
        JobType                = "Replication"
        Name                   = $Job.Name
        Description            = Safe-Get { $Job.Description } ""
        ReplicaSuffix          = Safe-Get { $Job.ViReplicaTargetOptions.ReplicaNameSuffix } "_replica"
        RestorePoints          = Get-RetentionCount $Job 3
        TargetHostName         = Safe-Get { $Job.GetTargetHost().Name } $null
        TargetDatastoreName    = Safe-Get { $Job.ViReplicaTargetOptions.DatastoreName } $null
        TargetFolderName       = Safe-Get { $Job.ViReplicaTargetOptions.FolderName } $null
        TargetResourcePool     = Safe-Get { $Job.ViReplicaTargetOptions.ResourcePool } $null
        TargetNetworkMap       = Safe-Get {
            $maps = @(Get-VBRViNetworkMappingRule -Job $Job -ErrorAction SilentlyContinue)
            @($maps | ForEach-Object { [ordered]@{ Source = $_.SourceNetwork; Target = $_.TargetNetwork } })
        } @()
        ReplicateFromBackup    = Safe-Get { $Job.ViReplicaTargetOptions.ReplicateFromBackup } $false
        SourceRepositoryName   = $srcRepo
        TargetRepositoryName   = Safe-Get { $Job.GetTargetRepository().Name } $null
        DiskType               = Safe-Get { $Job.ViReplicaTargetOptions.DiskCreationMode.ToString() } "Source"
        UseWANAccelerator      = Safe-Get { $Job.Options.JobOptions.UseWan } $false
        SourceWANAccelName     = Safe-Get { $Job.GetSourceWanAccelerator().Name } $null
        TargetWANAccelName     = Safe-Get { $Job.GetTargetWanAccelerator().Name } $null
        SeedingEnabled         = Safe-Get { $Job.ViReplicaTargetOptions.InitialSeeding } $false
        SeedRepositoryName     = Safe-Get { ($Job.GetSourceRepositories() | Where-Object { $_ } | Select-Object -Last 1).Name } $null
        ProxyNames             = Names-Of (Safe-Get { @($Job.GetProxy()) } @())
        IsAutoProxy            = Safe-Get { $Job.Options.JobOptions.SourceProxyAutoDetect } $true
        Schedule               = Get-ScheduleBlock $Job
        Notifications          = Get-NotificationBlock $Job
        SourceObjects          = Get-SourceObjects $Job
    }
}

# ---- Tape Job export -----------------------------------------------

function Export-TapeJob {
    param($Job)
    Write-Info "  Tape: $($Job.Name)"

    [ordered]@{
        JobType         = "Tape"
        Name            = $Job.Name
        Description     = Safe-Get { $Job.Description } ""
        TapeMediaPool   = Safe-Get { $Job.Target } $null
        RestorePoints   = Get-RetentionCount $Job 1
        Schedule        = Get-ScheduleBlock $Job
        Notifications   = Get-NotificationBlock $Job
        SourceObjects   = Get-SourceObjects $Job
    }
}

# ---- NAS Backup Job export -----------------------------------------

function Export-NASJob {
    param($Job)
    Write-Info "  NAS: $($Job.Name)"

    [ordered]@{
        JobType             = "NAS"
        Name                = $Job.Name
        Description         = Safe-Get { $Job.Description } ""
        RepositoryName      = Safe-Get { $Job.GetTargetRepository().Name } $null
        RestorePoints       = Get-RetentionCount $Job 14
        Schedule            = Get-ScheduleBlock $Job
        Notifications       = Get-NotificationBlock $Job
        SourceObjects       = Get-SourceObjects $Job
    }
}

# ---- Agent / Endpoint Job export -----------------------------------

function Export-AgentJob {
    param($Job)
    Write-Info "  Agent: $($Job.Name)"

    [ordered]@{
        JobType             = "Agent"
        Name                = $Job.Name
        Description         = Safe-Get { $Job.Description } ""
        RepositoryName      = Safe-Get { $Job.GetTargetRepository().Name } $null
        RestorePoints       = Get-RetentionCount $Job 14
        Schedule            = Get-ScheduleBlock $Job
        Notifications       = Get-NotificationBlock $Job
        SourceObjects       = Get-SourceObjects $Job
    }
}

# ---- Infrastructure inventory --------------------------------------

function Export-Infrastructure {
    Write-Section "Infrastructure Inventory"

    $infra = [ordered]@{
        Repositories    = @()
        Proxies         = @()
        ManagedServers  = @()
        WanAccelerators = @()
        Gateways        = @()
        MountServers    = @()
        SobrNames       = @()
    }

    # Repositories
    try {
        $repos = @(Get-VBRBackupRepository | Sort-Object Name)
        $infra.Repositories = @($repos | ForEach-Object {
            [ordered]@{
                Name = $_.Name
                Type = Safe-Get { $_.Type.ToString() } "Unknown"
                Path = Safe-Get { $_.FriendlyPath } $null
            }
        })
        Write-OK "Repositories     : $($infra.Repositories.Count)"
    } catch { Write-Warn "Could not enumerate repositories: $_" }

    # Scale-out Backup Repositories
    try {
        $sobrs = @(Get-VBRScaleOutBackupRepository | Sort-Object Name)
        $infra.SobrNames = @($sobrs | ForEach-Object { $_.Name })
        Write-OK "SOBR             : $($infra.SobrNames.Count)"
    } catch { Write-Skip "SOBR (not available or none)" }

    # Proxies
    try {
        $proxies = @(Get-VBRViProxy | Sort-Object Name)
        $infra.Proxies = @($proxies | ForEach-Object {
            [ordered]@{
                Name = $_.Name
                Type = "VMware"
                Host = Safe-Get { $_.Host.Name } $null
            }
        })
        $hvProxies = @(Get-VBRHvProxy -ErrorAction SilentlyContinue | Sort-Object Name)
        $infra.Proxies += @($hvProxies | ForEach-Object {
            [ordered]@{
                Name = $_.Name
                Type = "HyperV"
                Host = Safe-Get { $_.Host.Name } $null
            }
        })
        Write-OK "Proxies          : $($infra.Proxies.Count)"
    } catch { Write-Warn "Could not enumerate proxies: $_" }

    # Managed Servers
    try {
        $servers = @(Get-VBRServer | Sort-Object Name)
        $infra.ManagedServers = @($servers | ForEach-Object {
            [ordered]@{
                Name = $_.Name
                Type = Safe-Get { $_.Type.ToString() } "Unknown"
            }
        })
        Write-OK "Managed Servers  : $($infra.ManagedServers.Count)"
    } catch { Write-Warn "Could not enumerate managed servers: $_" }

    # WAN Accelerators
    try {
        $wans = @(Get-VBRWanAccelerator | Sort-Object Name)
        $infra.WanAccelerators = @($wans | ForEach-Object {
            [ordered]@{ Name = $_.Name; Host = Safe-Get { $_.GetHost().Name } $null }
        })
        Write-OK "WAN Accelerators : $($infra.WanAccelerators.Count)"
    } catch { Write-Skip "WAN Accelerators (none or not available)" }

    # Gateways - derive from repository gateway server properties
    try {
        $repos = @(Get-VBRBackupRepository)
        $gatewayNames = @($repos | ForEach-Object {
            Safe-Get { $_.GatewayServer.Name } $null
        } | Where-Object { $_ } | Sort-Object -Unique)
        $infra.Gateways = @($gatewayNames | ForEach-Object { [ordered]@{ Name = $_ } })
        Write-OK "Gateways (from repos) : $($infra.Gateways.Count)"
    } catch { Write-Skip "Gateways" }

    return $infra
}

# ---- Dispatch by job type ------------------------------------------

function Export-JobByType {
    param($Job)
    $type = $Job.JobType.ToString()
    switch ($type) {
        "Backup"        { return Export-BackupJob $Job }
        "BackupSync"    { return Export-BackupCopyJob $Job }
        "Replica"       { return Export-ReplicationJob $Job }
        "HvReplica"     { return Export-ReplicationJob $Job }
        "EpAgentBackup" { return Export-AgentJob $Job }
        "EpAgentPolicy" { return Export-AgentJob $Job }
        "NasBackup"     { return Export-NASJob $Job }
        "FileTapeBackup"{ return Export-TapeJob $Job }
        "VmTapeBackup"  { return Export-TapeJob $Job }
        default {
            Write-Warn "  Unknown type '$type': $($Job.Name) - capturing raw"
            return [ordered]@{
                JobType     = $type
                Name        = $Job.Name
                Description = Safe-Get { $Job.Description } ""
                _RawType    = $type
            }
        }
    }
}

# ---- Main ----------------------------------------------------------

Clear-Host
Write-Host ""
Write-Host "  +====================================================================+" -ForegroundColor Cyan
Write-Host "  |    Veeam VBR v12  ->  v13 Migration  |  Step 1: Export Config      |" -ForegroundColor Cyan
Write-Host "  +====================================================================+" -ForegroundColor Cyan
Write-Host ""

Connect-VBR12

Write-Section "Discovering Jobs"

$allJobs = @(Get-VBRJob -WarningAction SilentlyContinue | Sort-Object JobType, Name)

# Supplement with NAS jobs if available via a dedicated cmdlet
try {
    $nasJobs = @(Get-VBRNASBackupJob -ErrorAction SilentlyContinue | Where-Object { $_ })
    if ($nasJobs.Count -gt 0) {
        Write-Info "Found $($nasJobs.Count) NAS job(s) via Get-VBRNASBackupJob"
        $allJobs = @($allJobs) + @($nasJobs | Where-Object { $allJobs.Name -notcontains $_.Name })
    }
} catch {}

if ($allJobs.Count -eq 0) {
    Write-Fail "No VBR jobs found on this server."
    exit 1
}

$typeSummary = $allJobs | Group-Object { $_.JobType.ToString() } | Sort-Object Name
Write-Host "  Job types found on this server:" -ForegroundColor White
foreach ($g in $typeSummary) {
    Write-Host ("  {0,-22} {1} job(s)" -f $g.Name, $g.Count) -ForegroundColor Yellow
}
Write-Host ""
Write-OK "Total jobs: $($allJobs.Count)"

Write-Section "Exporting Jobs"

$exportedJobs = [System.Collections.Generic.List[object]]::new()
$skipCount    = 0
$failCount    = 0

foreach ($job in $allJobs) {
    try {
        $exported = Export-JobByType $job
        if ($exported) { $exportedJobs.Add($exported) }
        else { $skipCount++ }
    } catch {
        Write-Warn "Failed to export '$($job.Name)': $_"
        $failCount++
    }
}

Write-Host ""
Write-OK "Exported  : $($exportedJobs.Count)"
if ($skipCount -gt 0) { Write-Warn "Skipped   : $skipCount" }
if ($failCount -gt 0) { Write-Warn "Failed    : $failCount" }

$infra = Export-Infrastructure

Write-Section "Writing v12-export.json"

$exportRoot = [ordered]@{
    ExportVersion   = "1.0"
    ExportedAt      = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    SourceServer    = $env:COMPUTERNAME
    VBRVersion      = "12"
    JobCount        = $exportedJobs.Count
    Infrastructure  = $infra
    Jobs            = @($exportedJobs)
}

$outPath = Join-Path $PSScriptRoot "v12-export.json"
$exportRoot | ConvertTo-Json -Depth 20 | Out-File -FilePath $outPath -Encoding UTF8
Write-OK "Saved: $outPath"
Write-Host ""

$sizeMB = [math]::Round((Get-Item $outPath).Length / 1MB, 2)
Write-Info "File size: $sizeMB MB  |  Jobs: $($exportedJobs.Count)  |  Types: $($typeSummary.Count)"
Write-Host ""
Write-Host "  Next step: copy v12-export.json to the v13 appliance and run" -ForegroundColor White
Write-Host "  2-Translate-VBRConfig.ps1 to produce v13-import.json." -ForegroundColor Gray
Write-Host ""

try { Disconnect-VBRServer -ErrorAction SilentlyContinue } catch {}
