# VBR Migration Tool - Code Review Notes
Generated: 2026-05-14  
Scope: Static analysis + Veeam cmdlet documentation backcheck  
Files reviewed: 1-Export-VBRConfig.ps1, 2-Translate-VBRConfig.ps1, 3-Import-VBRConfig.ps1

---

## CRITICAL - Will fail at runtime

### C1 | `Get-VBRViProxy -Name` does not accept -Name parameter
**File:** 3-Import-VBRConfig.ps1, line 132  
**Code:** `Get-VBRViProxy -Name $Name -ErrorAction SilentlyContinue`  
**Problem:** `Get-VBRViProxy` has no -Name parameter. Passing it causes a runtime error.  
**Fix:** `Get-VBRViProxy | Where-Object { $_.Name -eq $Name } | Select-Object -First 1`

### C2 | `Get-VBRHvProxy -Name` does not accept -Name parameter
**File:** 3-Import-VBRConfig.ps1, line 138  
**Code:** `Get-VBRHvProxy -Name $Name -ErrorAction SilentlyContinue`  
**Problem:** Same as C1 - no -Name parameter.  
**Fix:** `Get-VBRHvProxy | Where-Object { $_.Name -eq $Name } | Select-Object -First 1`

### C3 | `Get-VBRBackupRepository -Name` does not accept -Name parameter
**File:** 3-Import-VBRConfig.ps1, line 120  
**Code:** `Get-VBRBackupRepository -Name $Name -ErrorAction SilentlyContinue`  
**Problem:** `Get-VBRBackupRepository` has no -Name parameter.  
**Fix:** `Get-VBRBackupRepository | Where-Object { $_.Name -eq $Name } | Select-Object -First 1`

### C4 | `Set-VBRViBackupJobProxy` cmdlet does not exist
**File:** 3-Import-VBRConfig.ps1, lines 300, 462  
**Code:** `Set-VBRViBackupJobProxy -Job $job -Proxy $proxies`  
**Problem:** This cmdlet does not exist in the Veeam PowerShell module. Proxy assignment  
is done via `Set-VBRViBackupJob -Job $job -Proxy $proxies` (the proxy list is a parameter  
on the main job set cmdlet, not a separate cmdlet).  
**Fix:** Replace both calls with `Set-VBRViBackupJob -Job $job -Proxy $proxies -ErrorAction Stop`

### C5 | `Set-VBRJobStorageOptions` likely does not exist / -CompressionLevel param uncertain
**File:** 3-Import-VBRConfig.ps1, line 257  
**Code:** `Set-VBRJobStorageOptions -Job $Job -CompressionLevel $level`  
**Problem:** The storage/compression settings for VMware backup jobs are managed through  
`Get-VBRJobOptions` / `Set-VBRJobOptions`, not a separate `Set-VBRJobStorageOptions` cmdlet.  
The documented pattern is:  
  `$opts = Get-VBRJobOptions -Job $job`  
  `$opts.BackupStorageOptions.CompressionLevel = $level`  
  `Set-VBRJobOptions -Job $job -Options $opts`  
**Fix:** Rewrite Apply-Storage to use Get-VBRJobOptions / Set-VBRJobOptions pattern.

### C6 | `Get-VBRJobScheduleOptions` / `Set-VBRJobScheduleOptions` uncertain - pattern may be wrong
**File:** 3-Import-VBRConfig.ps1, lines 172, 179, 208, 212, 228, 242  
**Problem:** `Get-VBRJobScheduleOptions` does not appear in the documented cmdlet list.  
Schedule options in Veeam are accessed through `Get-VBRJobOptions` which returns a  
`CJobOptions` object containing a `ScheduleOptions` property.  
`Set-VBRJobScheduleOptions` IS a documented cmdlet but its parameter set is not  
`-Options $schedOpts -DailyOptions (...)` -- it takes switch parameters directly  
(e.g. `-Daily -At $time -DaysOfWeek Mon,Tue`).  
**Fix:** Rewrite Apply-Schedule to use the documented parameter set for Set-VBRJobScheduleOptions,  
or use the Get/Set-VBRJobOptions pattern for schedule mutation.

### C7 | `New-VBRDailyJobScheduleOptions`, `New-VBRPeriodicallyJobScheduleOptions`, `New-VBRMonthlyJobScheduleOptions` - cmdlets do not exist
**File:** 3-Import-VBRConfig.ps1, lines 180, 188, 196  
**Problem:** These New-VBR*ScheduleOptions cmdlets are not in the Veeam PowerShell reference.  
Schedule options are set directly on `Set-VBRJobScheduleOptions` via switch parameters,  
not via separate constructor cmdlets.  
**Fix:** Use `Set-VBRJobScheduleOptions` directly with its documented switches:  
  Daily: `-Daily -At $time -DaysOfWeek @("Everyday")`  
  Periodically: `-Periodically -FullPeriod $minutes`  
  Monthly: `-Monthly -At $time -Months @(...) -DayOfMonth First`

### C8 | `Enable-VBRJobSchedule` cmdlet does not exist
**File:** 3-Import-VBRConfig.ps1, line 215  
**Code:** `Enable-VBRJobSchedule -Job $Job`  
**Problem:** Not a documented cmdlet. The schedule is enabled as part of  
`Set-VBRJobScheduleOptions -Job $Job -EnableSchedule`.  
**Fix:** Remove `Enable-VBRJobSchedule` call. Pass `-EnableSchedule` switch to  
`Set-VBRJobScheduleOptions` when setting the schedule type.

### C9 | String interpolation syntax error in Invoke-VBR
**File:** 3-Import-VBRConfig.ps1, line 74  
**Code:** `"  Rate limited${$(if ($Label) { " ($Label)" } else { '' })}. Waiting..."`  
**Problem:** `${...}` is for variable names, not subexpressions. `$(...)` is for expressions.  
Nesting `$(...)` inside `${}` is a parse error. Also the inner double quotes conflict with  
the outer string delimiter.  
**Fix:**  
```powershell
$labelStr = if ($Label) { " ($Label)" } else { "" }
Write-Warn "  Rate limited$labelStr. Waiting ${waitSec}s (attempt $attempt/$($script:RetryMax))..."
```

### C10 | `Add-VBRViBackupJob -RestorePointsToKeep` - parameter name unconfirmed
**File:** 3-Import-VBRConfig.ps1, line 292  
**Problem:** The documented parameter on `Add-VBRViBackupJob` for restore points is  
`-RestorePointsToKeep` in some versions but documented examples show it may vary.  
Cross-check: Veeam docs show `-BackupRepository` and `-Entity` as primary params.  
The restore points count may need to be set post-creation via job options.  
**Risk:** Mild - if the param is wrong the job creates with default retention and apply  
sets it correctly anyway via job options. Mark for verification.

### C11 | `Add-VBRViReplicaJob` parameter names uncertain (-Server, -ReplicaName)
**File:** 3-Import-VBRConfig.ps1, lines 392-394  
**Code:** `-Server $targetHost`, `-ReplicaName $suffix`  
**Problem:** The documented parameter for the target server may be `-TargetServer` not `-Server`.  
The replica name suffix parameter may be `-ReplicaNameSuffix` not `-ReplicaName`.  
**Fix (pending doc confirm):** Change to `-TargetServer` and `-ReplicaNameSuffix`.

### C12 | `Add-VBRViBackupCopyJob -TargetRepository` parameter name uncertain
**File:** 3-Import-VBRConfig.ps1, line 341  
**Code:** `-TargetRepository = $repo`  
**Problem:** The documented parameter on backup copy job creation is likely `-BackupRepository`,  
consistent with backup jobs. `-TargetRepository` may not exist.  
**Fix (pending doc confirm):** Change to `-BackupRepository`.

---

## MEDIUM - Logic errors or data mapping issues

### M1 | Dead variable `$replicateFromBackup` in Export-ReplicationJob
**File:** 1-Export-VBRConfig.ps1, line 261  
**Code:** `$replicateFromBackup = Safe-Get { $Job.ViReplicaTargetOptions.InitialSeeding } $false`  
**Problem:** This variable is assigned but never referenced. The actual export key on  
line 282 correctly reads `$Job.ViReplicaTargetOptions.ReplicateFromBackup`. The variable  
on line 261 is leftover scaffolding.  
**Fix:** Delete line 261 entirely.

### M2 | `$Job.GetSeedRepository()` - method existence unverified
**File:** 1-Export-VBRConfig.ps1, line 290  
**Code:** `SeedRepositoryName = Safe-Get { $Job.GetSeedRepository().Name } $null`  
**Problem:** `GetSeedRepository()` is not in the known confirmed method list from the  
probe script runs. Wrapped in Safe-Get so it silently returns null if wrong, but  
seeding config would not be exported.  
**Fix:** Verify method name. Fallback: read from `$Job.ViReplicaTargetOptions` directly  
if the method doesn't exist (the seed repo may be stored as a property on that object).

### M3 | `$Job.GetSourceRepositories()` - method name unverified
**File:** 1-Export-VBRConfig.ps1, line 264  
**Code:** `$linked = @($Job.GetSourceRepositories())`  
**Problem:** Method name unconfirmed. The probe script showed `LinkedJobs`, `LinkedJobIds`,  
`LinkedBackups`, `LinkedBackupIds` as properties but not `GetSourceRepositories()`.  
For "replicate from backup" jobs the source backup may be accessed differently.  
**Fix:** Wrap in try/catch (already done) but also add fallback to check  
`$Job.GetLinkedJobs()` or `$Job.LinkedBackups` as alternatives.

### M4 | `$Job.GetTargetHost()` - method name unverified for replication
**File:** 1-Export-VBRConfig.ps1, line 274  
**Code:** `TargetHostName = Safe-Get { $Job.GetTargetHost().Name } $null`  
**Problem:** `GetTargetHost()` is not in the confirmed method list. May be `GetTarget()`  
or the target server object may be accessed via `$Job.ViReplicaTargetOptions.TargetServer`.  
Wrapped in Safe-Get so silently returns null, but target host is required for import.  
**Fix:** Test both `$Job.GetTargetHost()` and `$Job.GetTarget()`.  
Note: a null TargetHostName will cause every replication job import to fail.

### M5 | `$Job.NetworkMappings` - property name unverified
**File:** 1-Export-VBRConfig.ps1, line 279  
**Problem:** Property path unconfirmed. Network mappings may be accessed via  
`$Job.NetworkMapping` (singular) or via `$Job.ViReplicaTargetOptions.NetworkMappings`.  
Safe-Get protects against null so no crash, but network map data would be silently lost.

### M6 | NAS jobs may not be returned by `Get-VBRJob`
**File:** 1-Export-VBRConfig.ps1, line 483  
**Problem:** NAS backup jobs in Veeam v12 use a separate cmdlet family (`Get-VBRNASBackupJob`  
if it exists, or `Get-VBRJob` with type filter). The `JobType` of "NasBackup" may or may  
not appear in `Get-VBRJob` results depending on VBR version. If NAS jobs are stored  
separately they will be silently missed.  
**Fix:** Add a supplementary enumeration attempt:  
  `try { @(Get-VBRNASBackupJob -ErrorAction SilentlyContinue) } catch { @() }`  
  and merge results before exporting.

### M7 | Notification block: SendSNMPEnabled and SendEmailEnabled map to same source property
**File:** 1-Export-VBRConfig.ps1, lines 119-120  
**Code:** Both `SendSNMPEnabled` and `SendEmailEnabled` read from `$opts.EnableAdditionalNotification`  
**Problem:** Copy-paste error. These should read from different source properties.  
SNMP notifications have their own property (likely `EnableSNMPNotification`).  
**Fix:** Correct the SNMP source property. If unknown, remove SendSNMPEnabled from export  
rather than capturing a wrong value.

### M8 | GFS accessed via `Get-VBRJobScheduleOptions` - may not have GFSPolicyOptions
**File:** 3-Import-VBRConfig.ps1, lines 228-242  
**Problem:** If `Get-VBRJobScheduleOptions` does not exist (see C6), `Apply-GFS` will fail  
silently (wrapped in try/catch). The GFS options are most reliably accessed via  
`Get-VBRJobOptions -Job $job` which returns a `CJobOptions` containing GFS settings.

### M9 | Cleanup step: connecting v13 module to v12 server may fail cross-version
**File:** 3-Import-VBRConfig.ps1, lines 635-642  
**Problem:** The cleanup step connects from the v13 Linux appliance's Veeam PS module  
to the remote v12 Windows server. The v13 module may refuse to connect to a  
lower-version VBR server. This should be called out as unsupported and the cleanup  
step documented as "run from the v12 server itself" rather than remotely.  
**Fix:** Add a prominent warning. Alternative: provide a separate standalone cleanup  
script designed to run on the v12 server.

### M10 | `$_.Type -ne "Local"` for managed server filter in cleanup - type string unverified
**File:** 3-Import-VBRConfig.ps1, line 694  
**Code:** `Get-VBRServer | Where-Object { $_.Type -ne "Local" }`  
**Problem:** The VBR server type string for the local server may not be "Local".  
It may be "Windows" or the server may be identified by comparing `$_.Name` to  
`$env:COMPUTERNAME`. Filtering wrong here could delete the VBR server itself.  
**Fix:** Filter by `$_.Name -ne $env:COMPUTERNAME` AND `$_.Name -ne "localhost"` as  
a safer double-check, in addition to the type filter.

### M11 | `$Job.Options.BackupStorageOptions.RetainCycles` - property name uncertain
**File:** 1-Export-VBRConfig.ps1, lines 218, 243, 273, 328, 346  
**Problem:** The retention count property on `BackupStorageOptions` may be `RetainCycles`,  
`RetainCount`, `RestorePointsToKeep`, or read via `$Job.Options.BackupStorageOptions.RetainDaysToKeep`.  
Wrapped in Safe-Get so silently defaults to 14, but migration would use the wrong retention.

---

## MINOR - Code quality and edge cases

### N1 | `Add-VBRViBackupCopyJob` - backup copy jobs require a source job to be meaningful
**File:** 3-Import-VBRConfig.ps1, lines 339-344  
**Note:** Backup copy jobs in Veeam must have source jobs/repositories specified at  
creation or shortly after. The current import creates the shell but does not wire up  
the source backup job. Jobs will be created but will be non-functional until the  
source is configured manually. This should be called out in the post-import checklist.

### N2 | `Add-VBRViBackupJob` and `Add-VBRViReplicaJob` require source objects (VMs)
**File:** 3-Import-VBRConfig.ps1  
**Note:** The export captures source VM names and types, but the import does not attempt  
to re-add VM objects to jobs. Jobs will be created as empty (no protected VMs). This is  
intentional given infrastructure remapping complexity, but it is not called out explicitly  
in the console output or post-import checklist. Add to checklist.

### N3 | `ConvertTo-Json -Depth 20` on large environments
**File:** 1-Export-VBRConfig.ps1, line 536  
**Note:** Depth 20 is generous but some Veeam job option objects have circular references  
that cause infinite loops or terminating errors with ConvertTo-Json. The Safe-Get pattern  
extracts primitives before serialization which largely mitigates this, but the outer  
`$exportRoot | ConvertTo-Json -Depth 20` still serializes the full structured data.  
**Mitigation already in place:** Safe-Get extracts only named fields. Risk is low but  
worth noting.

### N4 | `$PSScriptRoot` is empty when script is dot-sourced or run from ISE without save
**File:** All three files  
**Note:** If a user runs the script by pasting into an ISE window without saving,  
`$PSScriptRoot` is empty and `Join-Path $PSScriptRoot "v12-export.json"` writes to  
the current working directory. This is standard PowerShell behavior and acceptable,  
but worth noting in the header comment.

### N5 | `Remove-VBRViProxy` / `Remove-VBRHvProxy` parameter names need verification
**File:** 3-Import-VBRConfig.ps1, lines 651, 661  
**Code:** `Remove-VBRViProxy -Proxy $p`, `Remove-VBRHvProxy -Proxy $p`  
**Problem:** The parameter name on Remove-VBRViProxy is likely `-ProxyServer` not `-Proxy`.  
**Fix (pending doc confirm):** Change `-Proxy` to `-ProxyServer`.

### N6 | `Remove-VBRWanAccelerator -WanAccelerator` parameter name needs verification
**File:** 3-Import-VBRConfig.ps1, line 672  
**Code:** `Remove-VBRWanAccelerator -WanAccelerator $w`  
**Problem:** Parameter name may be `-Accelerator` or positional.

### N7 | `Remove-VBRBackupRepository -Repository` parameter name needs verification
**File:** 3-Import-VBRConfig.ps1, line 685  
**Code:** `Remove-VBRBackupRepository -Repository $r`  
**Problem:** Parameter name may be `-BackupRepository`.

### N8 | `Remove-VBRServer -Server` parameter name needs verification
**File:** 3-Import-VBRConfig.ps1, line 697  
**Code:** `Remove-VBRServer -Server $s`  
**Problem:** Standard convention in Veeam is to use the object type as the param name.  
May need to be `-Server $s` (which looks correct) but the -Confirm:$false behavior  
should be verified - some Remove cmdlets use -Confirm, others don't support it.

### N9 | `$schedOpts` is fetched but possibly not needed as -Options param
**File:** 3-Import-VBRConfig.ps1, line 172  
**Note:** If `Set-VBRJobScheduleOptions` uses direct switch parameters (not -Options),  
then the `$schedOpts = Invoke-VBR { Get-VBRJobScheduleOptions... }` call is unnecessary  
boilerplate and should be removed once C6 is resolved.

### N10 | `Get-VBRViHostByName` function defined but never called
**File:** 3-Import-VBRConfig.ps1, lines 147-151  
**Code:** `function Get-ViHostByName` exists but the replication import uses inline  
`Get-VBRServer | Where-Object { ... }` instead of calling this helper.  
**Fix:** Either remove the function or use it in Import-ReplicationJob.

---

## ITEMS PENDING DOCUMENTATION CONFIRMATION
(Research agent cross-check in progress)

- Correct param name for restore points on Add-VBRViBackupJob (C10)
- Correct params for Add-VBRViReplicaJob: -TargetServer vs -Server, -ReplicaNameSuffix vs -ReplicaName (C11)
- Correct param for Add-VBRViBackupCopyJob: -BackupRepository vs -TargetRepository (C12)
- Confirmed set of Set-VBRJobScheduleOptions switch parameters (C6, C7, C8)
- Confirmed existence of Get-VBRJobScheduleOptions (C6)
- Remove-VBRViProxy param: -ProxyServer vs -Proxy (N5)
- Remove-VBRWanAccelerator param name (N6)
- Remove-VBRBackupRepository param name (N7)
- GetSeedRepository() method (M2)
- GetSourceRepositories() method (M3)
- GetTargetHost() vs GetTarget() method (M4)
- NetworkMappings property path (M5)
- RetainCycles vs RetainCount property (M11)

---

## CHANGE IMPACT SUMMARY

| Priority | Count | Description |
|----------|-------|-------------|
| Critical | 12    | Runtime failures - must fix before use |
| Medium   | 11    | Logic/data issues - silent failures or wrong data |
| Minor    | 10    | Quality issues - non-breaking but worth fixing |
| Pending  | 14    | Awaiting documentation confirmation |

**Highest risk areas:**
1. Apply-Schedule function (C6, C7, C8) - entirely wrong cmdlet pattern, needs full rewrite
2. Proxy cmdlets (C1, C2, C4) - -Name param and wrong cmdlet name, affects all jobs
3. Repository lookup (C3) - affects every single job import
4. Replication target host export (M4) - null host = all replication imports fail

---
*This is a review log only. No code has been changed.*
