#Requires -Version 5.1
<#
.SYNOPSIS
    2-Translate-VBRConfig.ps1
    Translate v12-export.json into v13-import.json

.DESCRIPTION
    NO VBR connection required. Run this anywhere with PowerShell 5.1+.
    Reads v12-export.json, remaps field names/values for any v12->v13 API
    differences, validates that all referenced infrastructure names are
    declared in the infrastructure inventory, and writes v13-import.json.

    Current known v12->v13 field differences handled here:
      - JobType "BackupSync"   -> "BackupCopy"
      - JobType "EpAgentBackup"/"EpAgentPolicy" -> "Agent"
      - JobType "HvReplica"   -> "Replication"
      - Algorithm enum names normalised
      - DiskType enum "Source" -> "SameAsSource" (v13 rename)
      - Schedule RunType enum normalised

    All other fields are passed through verbatim; the import script reads
    v13-import.json directly.

    Output file: v13-import.json  (same folder as this script)
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ---- Helpers -------------------------------------------------------

function Write-Section  { param($T) Write-Host ""; Write-Host ("=" * 70) -ForegroundColor Cyan;  Write-Host "  $T" -ForegroundColor Cyan;  Write-Host ("=" * 70) -ForegroundColor Cyan  }
function Write-OK       { param($T) Write-Host "  [OK]  $T" -ForegroundColor Green  }
function Write-Info     { param($T) Write-Host "  [--]  $T" -ForegroundColor Gray   }
function Write-Warn     { param($T) Write-Host "  [!!]  $T" -ForegroundColor Yellow }
function Write-Fail     { param($T) Write-Host "  [XX]  $T" -ForegroundColor Red    }

# ---- JobType normalisation -----------------------------------------
# Maps v12 JobType strings to canonical names used by the import script

$JobTypeMap = @{
    "Backup"         = "Backup"
    "BackupSync"     = "BackupCopy"
    "Replica"        = "Replication"
    "HvReplica"      = "Replication"
    "EpAgentBackup"  = "Agent"
    "EpAgentPolicy"  = "Agent"
    "NasBackup"      = "NAS"
    "FileTapeBackup" = "Tape"
    "VmTapeBackup"   = "Tape"
}

# ---- DiskType normalisation ----------------------------------------
# v13 renamed "Source" -> "SameAsSource"

function Translate-DiskType {
    param($v)
    if (-not $v) { return $v }
    if ($v -eq "Source") { return "SameAsSource" }
    return $v
}

# ---- Algorithm normalisation ---------------------------------------

function Translate-Algorithm {
    param($v)
    if (-not $v) { return $v }
    switch ($v) {
        "Increment"         { return "Incremental" }
        "ReverseIncrement"  { return "ReverseIncremental" }
        default             { return $v }
    }
}

# ---- Schedule RunType normalisation --------------------------------

function Translate-RunType {
    param($v)
    if (-not $v) { return $v }
    switch ($v) {
        "Daily"          { return "Daily" }
        "Monthly"        { return "Monthly" }
        "Periodically"   { return "Periodically" }
        "Continuously"   { return "Continuously" }
        "AfterJob"       { return "AfterJob" }
        "ManuallyOnly"   { return "ManuallyOnly" }
        default          { return $v }
    }
}

# ---- Translate a single job ----------------------------------------

function Translate-Job {
    param($Job)

    $v12Type  = "$($Job.JobType)"
    $v13Type  = if ($JobTypeMap.ContainsKey($v12Type)) { $JobTypeMap[$v12Type] } else { $v12Type }

    $out = [ordered]@{}
    foreach ($key in $Job.PSObject.Properties.Name) {
        $out[$key] = $Job.$key
    }

    $out["JobType"] = $v13Type

    if ($out.ContainsKey("Algorithm"))  { $out["Algorithm"] = Translate-Algorithm $out["Algorithm"] }
    if ($out.ContainsKey("DiskType"))   { $out["DiskType"]  = Translate-DiskType  $out["DiskType"]  }

    if ($out.ContainsKey("Schedule") -and $out["Schedule"]) {
        $sched = $out["Schedule"]
        if ($sched.PSObject.Properties["RunType"]) {
            $sched.RunType = Translate-RunType $sched.RunType
        }
        $out["Schedule"] = $sched
    }

    return $out
}

# ---- Validation ----------------------------------------------------

function Validate-InfraRefs {
    param($Jobs, $Infra)

    $repoNames  = @($Infra.Repositories | ForEach-Object { $_.Name } | Where-Object { $_ })
    $proxyNames = @($Infra.Proxies      | ForEach-Object { $_.Name } | Where-Object { $_ })
    $wanNames   = @($Infra.WanAccelerators | ForEach-Object { $_.Name } | Where-Object { $_ })

    $warnings = [System.Collections.Generic.List[string]]::new()

    foreach ($job in $Jobs) {
        $jName = $job.Name

        # Repository
        foreach ($prop in @("RepositoryName","TargetRepositoryName","SourceRepositoryName","SeedRepositoryName")) {
            if ($job.$prop -and $job.$prop -ne "" -and $repoNames -notcontains $job.$prop) {
                $warnings.Add("  Job '$jName': $prop '$($job.$prop)' not found in infrastructure inventory")
            }
        }

        # Proxies (auto-proxy jobs don't need explicit proxies)
        if (-not $job.IsAutoProxy -and $job.ProxyNames) {
            foreach ($p in @($job.ProxyNames)) {
                if ($p -and $proxyNames -notcontains $p) {
                    $warnings.Add("  Job '$jName': proxy '$p' not found in infrastructure inventory")
                }
            }
        }

        # WAN accelerators
        foreach ($prop in @("SourceWANAccelName","TargetWANAccelName")) {
            if ($job.$prop -and $job.$prop -ne "" -and $wanNames -notcontains $job.$prop) {
                $warnings.Add("  Job '$jName': $prop '$($job.$prop)' not in infrastructure inventory")
            }
        }
    }

    return $warnings
}

# ---- Main ----------------------------------------------------------

Clear-Host
Write-Host ""
Write-Host "  +====================================================================+" -ForegroundColor Cyan
Write-Host "  |    Veeam VBR v12  ->  v13 Migration  |  Step 2: Translate Config   |" -ForegroundColor Cyan
Write-Host "  +====================================================================+" -ForegroundColor Cyan
Write-Host ""

$inPath  = Join-Path $PSScriptRoot "v12-export.json"
$outPath = Join-Path $PSScriptRoot "v13-import.json"

if (-not (Test-Path $inPath)) {
    Write-Fail "v12-export.json not found at: $inPath"
    Write-Info "Run 1-Export-VBRConfig.ps1 on the v12 server first."
    exit 1
}

Write-Section "Loading v12-export.json"
$raw    = Get-Content $inPath -Raw -Encoding UTF8
$export = $raw | ConvertFrom-Json
Write-OK "Loaded $($export.Jobs.Count) job(s) exported from $($export.SourceServer) on $($export.ExportedAt)"

Write-Section "Translating Jobs"

$translated = [System.Collections.Generic.List[object]]::new()
$typeChanges = [System.Collections.Generic.List[string]]::new()

foreach ($job in $export.Jobs) {
    $v12Type = "$($job.JobType)"
    $tJob    = Translate-Job $job
    $v13Type = $tJob.JobType

    if ($v12Type -ne $v13Type) {
        $typeChanges.Add("  $($job.Name): $v12Type -> $v13Type")
    }

    $translated.Add($tJob)
    Write-Info "  [$v13Type] $($job.Name)"
}

if ($typeChanges.Count -gt 0) {
    Write-Host ""
    Write-Warn "JobType translations applied:"
    foreach ($tc in $typeChanges) { Write-Host $tc -ForegroundColor Yellow }
}

Write-Section "Validating Infrastructure References"

$valWarnings = Validate-InfraRefs $translated $export.Infrastructure

if ($valWarnings.Count -eq 0) {
    Write-OK "All infrastructure references resolved within the inventory snapshot."
    Write-Warn "NOTE: The inventory snapshot reflects the v12 server state."
    Write-Warn "Verify that these same names exist on the v13 target before importing."
} else {
    Write-Warn "$($valWarnings.Count) infrastructure reference warning(s):"
    foreach ($w in $valWarnings) { Write-Host $w -ForegroundColor Yellow }
    Write-Host ""
    Write-Warn "These jobs may fail at import if the named resources do not exist on v13."
    Write-Warn "Add the missing resources to the v13 appliance, or edit v13-import.json manually."
}

Write-Section "Writing v13-import.json"

$v13Root = [ordered]@{
    TranslateVersion    = "1.0"
    TranslatedAt        = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    OriginalExportedAt  = $export.ExportedAt
    SourceServer        = $export.SourceServer
    JobCount            = $translated.Count
    Infrastructure      = $export.Infrastructure
    Jobs                = @($translated)
}

$v13Root | ConvertTo-Json -Depth 20 | Out-File -FilePath $outPath -Encoding UTF8
Write-OK "Saved: $outPath"
Write-Host ""
Write-Host "  Next step: copy v13-import.json to the v13 appliance and run" -ForegroundColor White
Write-Host "  3-Import-VBRConfig.ps1 using pwsh (PowerShell 7) as Administrator." -ForegroundColor Gray
Write-Host ""
