# veeam-portcheck.sh

Linux-side port checker for a Veeam Software Appliance (VSA) or any Linux Veeam component. Enumerates listening sockets, classifies the owning process, and flags conflicts against the documented Veeam port table.

Designed to be **pasted into a console** on a locked-down appliance, or driven remotely by `portest3.ps1 -SshServer`.

## Running it

```bash
# Human-readable, on the appliance
sudo bash veeam-portcheck.sh

# Machine-readable, for portest3.ps1 to parse
sudo bash veeam-portcheck.sh --report

# CSV
sudo bash veeam-portcheck.sh --csv

sudo bash veeam-portcheck.sh --help
```

Driven from Windows:

```powershell
.\portest3.ps1 -SshServer vsa01 -SshUser root -OutFile estate.csv
```

## Run it as root

Without root, `ss` cannot show process owners and **everything reads UNKNOWN**. The script says so, but the output is close to useless.

## Requirements

- bash 4.2+ (uses associative arrays), `ss` from iproute2
- GNU coreutils — `stat -c`, `readlink -f`, GNU `sed`. Fine on RHEL, SLES and Ubuntu; not BSD-safe.
- Writes **no temp files**. Everything accumulates in shell variables, which is what makes it safe to stream into `bash -s` on an appliance with a read-only or locked-down filesystem.

## Port data

The `veeam_ports` table near the top of the script is the source of truth. Only **6160** (`veeamdeployment`) and **6162** (`veeamtransport`) are confirmed by service name in Veeam KB4519 — the rest come from the v13 Ports documentation.

Check them against the Ports page for your build and **edit the table, not the logic**.

vPower NFS (TCP/UDP 111, 1058, 2049) is a Windows service and is deliberately not checked here. Use `portest3.ps1` for Windows backup and mount servers.

## Exit codes

| Code | Meaning |
|---|---|
| 0 | No conflicts |
| 1 | Conflicts **or unknown owners** found |
| 2 | Could not run (no `ss`, etc.) |

Note that 1 covers unknowns as well as conflicts, despite the header text. If you're consuming this in CI, treat 1 as "look at the output".

## Output formats

- **default** — coloured, human-readable, with a Veeam services section
- **`--report`** — pipe-delimited records (`#META`, `#SVC`, `#ROW`, `#END`) that `portest3.ps1` parses into the same shape as the Windows collector
- **`--csv`** — flat CSV

A truncated `--report` (no `#END` marker) is detected by the PowerShell side and reported as an incomplete collection rather than a clean result.

## Known limitations

- The `--report` format carries no "verified" field, so the Windows side derives it from a hardcoded list of KB4519-confirmed ports. If you add confirmed ports to the table here, update `$script:LinuxVerifiedPorts` in `functions\SshTransport.ps1` too.
- No PID cache: `classify` and `describe_owner` each shell out to `systemctl` per process. On a host with many listeners this is slow. (`veeam-blueprint.sh` solves this with `declare -A` caches; it hasn't been back-ported.)
- Per-field sanitisation forks two processes per field. On a 150-listener host that's ~2,400 forks.
- `set -uo pipefail` **without** `-e`, deliberately: this is a probe-everything collector where half the commands are expected to fail.

## Changed in this revision

- **Failed systemd units are parsed correctly.** `systemctl list-units` prefixes failed units with a `●` glyph, which shifted every field — so the one case an operator cares about most reported the glyph as the unit name and `loaded` as its state:

  ```
  before:  #SVC|●|loaded
  after:   #SVC|veeamtransport.service|failed
  ```

  `veeam-blueprint.sh` already had the bullet-aware `awk`; it was never back-ported. Both sites in this script are fixed, and `--plain` is now passed as well.

- **`--help` no longer prints source code.** The `sed` range overshot the header comment and leaked `set -uo pipefail`, `CSV=0`, `REPORT=0`.
