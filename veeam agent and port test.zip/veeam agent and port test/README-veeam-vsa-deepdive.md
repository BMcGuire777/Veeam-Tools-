# veeam-vsa-deepdive.sh

Deep diagnostic collector for a Veeam Software Appliance. Produces a single bundle containing an OS and hardware profile, PostgreSQL analysis, Veeam service and log inventory, security posture, and optionally a timed database capture.

Run this when a VSA is slow, unstable, or you need to hand evidence to support.

## Usage

```bash
# Full collection
sudo bash veeam-vsa-deepdive.sh

# Add a 30-minute database capture, sampling every 30s
sudo bash veeam-vsa-deepdive.sh --watch

sudo bash veeam-vsa-deepdive.sh --watch 60 --interval 15

# Database only - skip the OS profile and file collection
sudo bash veeam-vsa-deepdive.sh --db-only --watch 30

# Add the full-filesystem Veeam file inventory (slow - see below)
sudo bash veeam-vsa-deepdive.sh --inventory

sudo bash veeam-vsa-deepdive.sh --help
```

**Root is required.** PostgreSQL analysis runs via `runuser -u postgres`, and `/var/log/veeam` plus the journal are root-only. The script refuses to start without it rather than producing a half-empty bundle.

## Options

| Option | Notes |
|---|---|
| `--watch [minutes]` | Timed database capture. Default 30 minutes. Ctrl+C stops the capture and still writes the summary. |
| `--interval <seconds>` | Sample interval for `--watch`. Default 30. |
| `--db-only` | Skip the OS profile and file collection. |
| `--no-collect` | Report only; don't gather log/config files. |
| `--collect-days <n>` | How far back to collect logs. |
| `--max-file-mb <n>` | Per-file size cap on collected files. |
| `--outdir <path>` | Override the output directory. |
| `--inventory` | **Opt-in.** Walk the entire root filesystem for Veeam-named paths. |
| `--no-color` | Plain output. |

## Where the bundle goes

By default `/tmp/vsa-deepdive_<hostname>_<timestamp>/`, created with **mode 700 under `umask 077`**.

That matters: the bundle contains `pg_hba.conf`, `sysctl -a`, the full journal and the Veeam logs. Previously it was created at the inherited umask (typically 0755) under a guessable name in a world-writable directory — readable by any local account on the appliance.

```
<outdir>/
├── deepdive-report.txt     the main report
├── db-watch.csv            one row per sample (--watch only)
├── collected/              logs, configs, package inventory
└── packages-full.txt
```

## `--inventory` is opt-in for a reason

It runs `find /` across the whole root filesystem. This script is usually run **because the appliance is slow** — left on by default, the collector becomes the dominant I/O load during the incident it's meant to diagnose. Turn it on only when you specifically need to locate Veeam files.

## Exit codes

| Code | Meaning |
|---|---|
| 0 | Report produced |
| 2 | Could not run (not root, cannot create the output directory) |

## Known limitations

- There is no `EXIT` trap. If you interrupt during the collection phase (as opposed to during `--watch`, which handles `INT` properly), a partial bundle is left behind. It's mode 700, so it isn't exposed — just clean it up.
- `rpm -qa` writes to `"$full.tmp"` then moves it; a failure between those leaves the temp file.
- `grep -rnIiE` across all collected logs and two `du -sm` passes are additional I/O on an already-struggling box.
- GNU-only tools throughout (`stat -c`, `readlink -f`, `sed 's/\x1b.../'`, `find -print0`). Fine on the appliance; not portable to BSD.
- Requires bash 4+.

## Changed in this revision

- **Output directory is now `umask 077` + `mkdir -m 700`**, with a check that the path isn't an existing non-directory (a pre-created symlink was a plausible attack given the guessable name).
- **The full-filesystem `find /` is behind `--inventory`** instead of running every time.
- **`--help` no longer prints source code** — the `sed` range overshot the header and leaked `set -uo pipefail`, `WATCH_MIN=0`, `INTERVAL=30`.
- Moved into `veeam-portcheck/` alongside the rest of the toolkit. The newest copy had been sitting at the scripts-folder root, separate from the toolkit it belongs to.
