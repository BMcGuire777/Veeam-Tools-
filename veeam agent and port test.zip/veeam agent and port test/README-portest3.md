# portest3.ps1

Windows entry point for the Veeam port / TLS / CRL diagnostics toolkit. Checks which Veeam component ports are listening, who owns them, whether a remote host can reach them, whether TLS handshakes complete, and whether certificate revocation endpoints are reachable.

Dot-sources everything in `functions\`.

## Quick start

```powershell
# Interactive menu
.\portest3.ps1

# Local scan: what is listening, and who owns it
.\portest3.ps1

# Can this machine reach a backup server's ports?
.\portest3.ps1 -Target vbr01

# TLS handshake probe, plus revocation checks
.\portest3.ps1 -Target vbr01 -TlsProbe -CrlCheck

# Scan a Linux VSA over SSH (see README-veeam-portcheck-sh.md)
.\portest3.ps1 -SshServer vsa01 -OutFile results.csv

# Outbound CRL/OCSP reachability from this machine
.\portest3.ps1 -CrlCheck

# Conflict check with an HTML report alongside the CSV
.\portest3.ps1 -ComputerName vbr01 -OutFile vbr01.csv -HtmlOut vbr01.html
```

## HTML reports

`-HtmlOut <path>` writes a single self-contained `.html` document — inline SVG, inline CSS, **zero JavaScript**, nothing to install or sign. It opens in any browser, prints to PDF, and attaches to a ticket. Same engine and same stylesheet as the blueprint report (`functions\HtmlReport.ps1`).

The port report carries a KPI row, a plain-language verdict, a chart of ports needing attention by owner type, a **Resolve these first** list, then tables for the named ports, the data-transfer range and the Veeam services on that host.

**A failed collection does not render as a report.** When `Meta.CollectError` is set, every port would read as free — which looks exactly like an all-clear. The HTML keeps the header and the diagnosis and drops the tables entirely, on the reasoning that someone looking at a page of green rows will not read the banner above them. `Save-Results` already withholds those rows from the CSV for the same reason.

Interactively, menu entry `[7]` offers:

| Key | Output |
|---|---|
| `[Enter]` / `[A]` | CSV — last check, or every host this session |
| `[P]` | HTML — last port check (one host, with services and banners) |
| `[E]` | HTML — whole estate, mixed Windows + Linux, with a per-host rollup |
| `[G]` / `[L]` | CSV — guest findings / log triage signatures |
| `[H]` / `[T]` | HTML — last guest check / log triage |

Note the asymmetry: CSV `[A]` and HTML `[E]` span the session, while `[P]` and `[H]` cover one run — those reports carry a host header, an elevation banner and that collection's notes, which belong to a single collection.

## Parameters

| Parameter | Notes |
|---|---|
| `-Target <host>` | Probe a remote host's Veeam ports instead of scanning locally. |
| `-TlsProbe` / `-TlsPorts` | Attempt a TLS handshake and capture the certificate. |
| `-CrlCheck` / `-CrlUrls` | Check revocation endpoints. Works standalone, with `-TlsProbe`, **and now with `-Target` alone**. |
| `-Probe` | HTTP/service probes against a target. |
| `-ScanRange` / `-RangeStart` / `-RangeEnd` | Sweep the data-transfer range (default 2500–3300). |
| `-IncludeEnterpriseManager` | Add the Enterprise Manager port set. |
| `-SshServer` / `-SshUser` / `-KeyFile` / `-Mode` | Run the Linux collector on a VSA over SSH. |
| `-RemotePath` | Where the Linux script lands. **Validated** — must be an absolute path of `[A-Za-z0-9._/-]`. |
| `-OutFile` | Export the last run to CSV. |
| `-HtmlOut <path>` | Write the run as a self-contained HTML report. Works with `-LocalCheck`, `-ComputerName`, `-VbrServer`, `-SshServer`, and with the app-aware modes. Reachability, TLS and CRL probes stay console-only. |

## Reading the output

- **`~` next to a port** means the port number is documented but not confirmed by service name in Veeam KB4519. Treat it as indicative. Only 6160 and 6162 are confirmed by name on Linux.
- **OwnerType** is now one vocabulary across Windows and Linux: `Veeam`, `Database`, `OS`, `ThirdParty`, `Unknown`. The `Platform` column tells you which OS the row came from.
- **Ports inside 2500–3300** that aren't Veeam are flagged — that range is used for data transfer and a squatter there causes intermittent job failures that look like network problems.

## Exit codes

| Code | Meaning |
|---|---|
| 0 | No conflicts |
| 1 | Conflicts or unknown owners found |
| 2 | Could not run (missing functions folder, load error) |
| 3 | A remote collection failed |

## Known limitations

- Both entry points dot-source **every** file in `functions\`, including ~108 KB this script never calls. Harmless, just slow to load.
- The connect timeout is a hardcoded 500 ms. Any WAN-latency target will report every port blocked.
- First-connect SSH host keys are accepted automatically (`StrictHostKeyChecking=accept-new`). SSH to the appliance once by hand first to pin the key — otherwise the very first connection can be intercepted and the password captured.
- Everything goes to the console via `Write-Host`. There is no transcript or log file.
- `netstat` fallback parsing is English-only. On a localised host it returns no rows, which is reported as an error rather than a false all-clear.

## Changed in this revision

- **`-Target <host> -CrlCheck` now works.** The standalone `-CrlCheck` branch was unreachable once `-Target` was set, so that combination silently did nothing — one character away from the documented `-Target x -TlsProbe -CrlCheck`.
- **Linux rows no longer all claim `Verified = true`.** Every Linux row was silently promoted to "confirmed", making the `~` legend wrong on exactly the platform where the port data is weakest.
- **One `OwnerType` vocabulary.** Windows emitted `Veeam|Windows|Database|ThirdParty|Unknown`, Linux emitted `veeam|os|db|thirdparty|unknown`, and both went into the same mixed-estate CSV — so filtering `OwnerType -eq 'Database'` silently missed every Linux PostgreSQL row.
- **A failed collection no longer exports.** `$script:LastResults` was populated *before* the invalid-run guard, so a failed SSH run wrote a CSV full of known-bad rows (every port `FREE`) while the console said "RESULTS BELOW ARE NOT VALID".
- **Port 9080 added to the HTML report's annotation table.** It was in `PortTables.ps1` but not there, so any listener on it rendered with a blank Component column.
- **`$RemotePath` is validated on all four SSH transport functions and on the interactive prompt** — see the SshTransport note in the toolkit README.
- `Ensure-Target` → `Resolve-Target`, `Sorted-Map` → `ConvertTo-SortedMap` (approved verbs).
