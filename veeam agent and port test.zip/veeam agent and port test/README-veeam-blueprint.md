# veeam-blueprint.sh / veeam-blueprint.ps1 / functions\Blueprint.ps1

Captures a structured "blueprint" of a Veeam environment — listeners, service inventory, trunk map, database settings, installed products, certificates, firewall state, config file hashes and runtime metrics — then compares it against a saved baseline to show what drifted.

Three pieces, one job:

| File | Role |
|---|---|
| `veeam-blueprint.sh` | Linux capture. Emits pipe-delimited records. Pasteable into a console. |
| `functions\BlueprintCollector.ps1` | Windows capture. Same data, native. |
| `functions\Blueprint.ps1` | The **adapter** — normalises either into one JSON schema. Not a third implementation. |
| `veeam-blueprint.ps1` | Windows entry point: capture, compare, promote, report. |

## Usage

```powershell
# Capture this Windows host
.\veeam-blueprint.ps1

# Capture a Linux VSA over SSH
.\veeam-blueprint.ps1 -SshServer vsa01 -SshUser root

# Capture and compare against the saved baseline
.\veeam-blueprint.ps1 -Baseline .\blueprints\vbr01\baseline.json

# HTML report
.\veeam-blueprint.ps1 -HtmlReport -ReportOut .\report.html

# Drift as CSV
.\veeam-blueprint.ps1 -Baseline ... -DriftCsv .\drift.csv
```

```bash
# Direct, on the appliance
sudo bash veeam-blueprint.sh
```

## The workflow this is built for

1. Capture a blueprint when the environment is known good.
2. **Promote it to baseline explicitly.**
3. After an upgrade or an incident, capture again and compare.
4. Review the drift, *then* promote the new capture.

Promotion is deliberately manual. Auto-promoting makes drift the new normal and the tool stops telling you anything.

## Capture tiers matter

A capture taken as root sees process owners; one taken without root doesn't. The drift engine **refuses to compare across tiers** and says so in the report, rather than reporting every unidentifiable listener as a change. This is the single most important behaviour in the tool — if you see "capture tier differs", re-capture with the same privilege level rather than reading the diff.

## Identity vs metrics

The schema separates **identity** (things that should be stable: ports, services, certificates, config hashes) from **metrics** (things that always change: connection counts, sizes, uptime). Drift is reported on identity. Metrics are shown for context but never flagged.

Matching is keyed, not positional, so reordered output doesn't read as drift, and duplicates are suffixed rather than silently dropped.

## Known limitations

- `openssl s_client` is called without `-servername`, so an SNI-dependent endpoint returns the default vhost certificate and the blueprint records the wrong one. Drift then reports phantom certificate changes.
- The trunk map keys loopback listeners by port alone, so a dual-stack service on both `0.0.0.0:443` and `[::]:443` collapses to one entry (last writer wins).
- Windows certificate `NotAfter` was being stamped with a `Z` suffix while holding local time — up to ±14 h out. Harmless at the 90-day threshold, wrong at the boundary. The Linux path was already correct.
- A blueprint where certificate collection failed records zero certificates, which the drift engine reads as "all certificates REMOVED → Warning". Check the capture notes before believing that.
- **Config files are hashed, never read.** No secret ever lands in a blueprint. The Windows registry walk has both a deny-list (`password|pwd|secret|salt|key$|login|credential`) and an allow-list. That's deliberate — don't relax it.

## The Python renderer

`veeam-blueprint-report.py` is **not** carried forward into this tree. It was a line-by-line transliteration of `HtmlReport.ps1` into a second language: the port knowledge table (30 entries), service roles (22 keys) and database setting impacts (9 keys) were verified byte-identical, and they had **already drifted** — port 9080 was missing from both annotation tables, so any listener on it rendered with a blank Component column.

It also required `openpyxl` on a customer machine, which `Export-BlueprintCsv` in `HtmlReport.ps1` already makes unnecessary.

The original is preserved in `_archive/veeam-portcheck/`. If you genuinely need `.xlsx` output, bring it back — but have it *read* the knowledge tables from a shared export rather than restating them, or they will drift again.

## Changed in this revision

- Port 9080 added to `HtmlReport.ps1`'s annotation table.
- `$RemotePath` is pattern-validated on `Invoke-RemoteBlueprintCapture`.
- `Sorted-Map` renamed to `ConvertTo-SortedMap` (approved verb).
- `--help` no longer overshoots into source code.
