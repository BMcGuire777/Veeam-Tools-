# =============================================================================
#  GuestReport.ps1 - running the guest collector and rendering its findings.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables, the guest knowledge base and all
#  $script: state directly.
#
#  The collector itself ($guestCollector, GuestCollector.ps1) is standalone so
#  it can cross a WinRM boundary. Everything that needs the knowledge base -
#  writer ownership hints, error code lookups, clock skew against the caller -
#  is applied here, on this side.
# =============================================================================

$guestGroupsAll = @('Network','Credentials','VSS','Application','Agent')

# =============================================================================
#  ENRICHMENT
#  Applied to the payload after collection. Adds what the scriptblock could
#  not know: which service owns a failed writer, and how far the guest clock
#  has drifted from the machine running this script.
# =============================================================================
function Add-GuestEnrichment($payload) {
    if (-not $payload -or -not $payload.Findings) { return $payload }

    $enriched = @()
    foreach ($f in @($payload.Findings)) {
        if ($f.Category -eq 'VSS' -and $f.Check -match '^Writer:\s*(?<w>.+)$') {
            $writer = $Matches['w'].Trim()
            if ($guestVssWriters.ContainsKey($writer)) {
                $f.Action = ('Owner: {0}  |  {1}' -f $guestVssWriters[$writer], $f.Action).Trim()
            }
        }
        $enriched += $f
    }

    # Clock skew: the collector reports its own local time; only this side
    # knows what the caller's clock says. Over 5 minutes kills Kerberos.
    if ($payload.Meta -and $payload.Meta.LocalTime) {
        try {
            $skew = [math]::Abs(((Get-Date) - [datetime]$payload.Meta.LocalTime).TotalMinutes)
            $status = 'PASS'; $impact = ''; $action = ''
            if ($skew -gt 5) {
                $status = 'FAIL'
                $impact = 'Kerberos rejects tickets beyond a five-minute skew. The job reports a logon failure that looks exactly like a wrong password.'
                $action = 'Fix time sync on the guest before changing any credential.'
            } elseif ($skew -gt 2) {
                $status = 'WARN'
                $impact = 'Drifting. It will cross the Kerberos threshold on its own.'
                $action = 'Check the time hierarchy on this guest.'
            }
            $enriched += [pscustomobject]@{
                Category='Credentials'; Check='Clock skew vs this machine'; Status=$status
                Detail=('{0:N1} minute(s) difference.' -f $skew); Impact=$impact; Action=$action
            }
        } catch { }
    }

    # Return a fresh hashtable rather than writing back into $payload. What
    # comes off the wire from Invoke-Command is a rehydrated copy, and mutating
    # it in place is the kind of thing that works on every host you test and
    # fails on the one that matters.
    return @{ Findings = $enriched; Meta = $payload.Meta }
}

# =============================================================================
#  RUNNING THE COLLECTOR
# =============================================================================

function Invoke-LocalGuestCheck {
    param(
        [string[]]$Groups = $guestGroupsAll,
        [int]$EventLogDays = 7,
        [switch]$NoSql
    )
    return (Add-GuestEnrichment (& $guestCollector $Groups $EventLogDays (-not $NoSql)))
}

function Invoke-RemoteGuestCheck {
    param(
        [Parameter(Mandatory)][string]$Computer,
        [System.Management.Automation.PSCredential]$Credential,
        [string[]]$Groups = $guestGroupsAll,
        [int]$EventLogDays = 7,
        [switch]$NoSql
    )

    Write-Host ''
    Write-Host ('  Opening a PowerShell remoting session to {0}...' -f $Computer) -ForegroundColor DarkCyan

    $icmArgs = @{
        ComputerName = $Computer
        ScriptBlock  = $guestCollector
        ArgumentList = @($Groups, $EventLogDays, (-not $NoSql))
        ErrorAction  = 'Stop'
    }
    if ($Credential) { $icmArgs['Credential'] = $Credential }

    try {
        return (Add-GuestEnrichment (Invoke-Command @icmArgs))
    } catch {
        Write-Host ''
        Write-Host ('  Remoting to {0} failed: {1}' -f $Computer, $_.Exception.Message) -ForegroundColor Red
        Write-Host ''
        Write-Host '  NOTE: this failure is itself a finding. WinRM and the guest' -ForegroundColor Yellow
        Write-Host '  interaction path are different transports, but they share DNS,' -ForegroundColor Yellow
        Write-Host '  firewall profile and credential ground. If WinRM cannot reach the' -ForegroundColor Yellow
        Write-Host '  guest, start there before blaming VSS.' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '  Things to check on the target:' -ForegroundColor Yellow
        Write-Host '    Enable-PSRemoting -Force            (run on the guest)' -ForegroundColor DarkCyan
        Write-Host '    Test-WSMan -ComputerName <guest>    (run from here)' -ForegroundColor DarkCyan
        Write-Host '    TCP 5985/5986 open, and the account is a local admin on the target.' -ForegroundColor DarkCyan
        Write-Host '    For a non-domain target, add it to TrustedHosts:' -ForegroundColor DarkCyan
        Write-Host '      Set-Item WSMan:\localhost\Client\TrustedHosts -Value <guest> -Concatenate' -ForegroundColor DarkCyan
        Write-Host ''
        Write-Host '  To run the check without WinRM, copy this toolkit to the guest and' -ForegroundColor DarkCyan
        Write-Host '  run:  .\portest3.ps1 -GuestCheck   (elevated)' -ForegroundColor DarkCyan
        return $null
    }
}

# =============================================================================
#  RENDERING
# =============================================================================

function Get-GuestStatusColor($status) {
    switch ($status) {
        'FAIL'    { return 'Red' }
        'WARN'    { return 'Yellow' }
        'PASS'    { return 'Green' }
        'UNKNOWN' { return 'Magenta' }
        default   { return 'DarkGray' }
    }
}

function Show-GuestReport {
    param($payload, [switch]$FailuresOnly)

    if (-not $payload) { Write-Host '  No data returned.' -ForegroundColor Red; return }

    $findings = @($payload.Findings)
    $meta     = $payload.Meta

    Write-Host ''
    Write-Host ('  Host        : {0}' -f $meta.Host) -ForegroundColor White
    if ($meta.OS)     { Write-Host ('  OS          : {0}' -f $meta.OS) -ForegroundColor DarkCyan }
    Write-Host ('  Ran as      : {0}   (elevated: {1})' -f $meta.RanAs, $meta.Elevated) -ForegroundColor DarkCyan
    Write-Host ('  Domain      : {0}' -f $(if ($meta.DomainJoined) { $meta.Domain } else { 'WORKGROUP - not domain joined' })) -ForegroundColor DarkCyan
    Write-Host ('  PowerShell  : {0}' -f $meta.PSVersion) -ForegroundColor DarkCyan
    Write-Host ('  Groups      : {0}' -f (@($meta.Groups) -join ', ')) -ForegroundColor DarkCyan

    if (-not $meta.Elevated) {
        Write-Host ''
        Write-Host '  ! The collector was NOT elevated. vssadmin, winmgmt and parts of the' -ForegroundColor Yellow
        Write-Host '    event log were skipped, so the VSS section is incomplete. Re-run' -ForegroundColor Yellow
        Write-Host '    elevated before concluding that VSS is healthy.' -ForegroundColor Yellow
    }
    foreach ($n in @($meta.CollectorNotes)) {
        if ($n) { Write-Host ('  ! {0}' -f $n) -ForegroundColor DarkYellow }
    }

    foreach ($cat in $guestGroupsAll) {
        $rows = @($findings | Where-Object { $_.Category -eq $cat })
        if ($rows.Count -eq 0) { continue }
        if ($FailuresOnly) {
            $rows = @($rows | Where-Object { $_.Status -in @('FAIL','WARN','UNKNOWN') })
            if ($rows.Count -eq 0) { continue }
        }

        Write-Host ''
        Write-Rule $cat
        Write-Host ''
        foreach ($r in ($rows | Sort-Object @{e={ switch ($_.Status) { 'FAIL' {0} 'UNKNOWN' {1} 'WARN' {2} 'INFO' {3} default {4} } }}, Check)) {
            Write-Host ('  [{0,-7}] {1}' -f $r.Status, $r.Check) -ForegroundColor (Get-GuestStatusColor $r.Status)
            if ($r.Detail) { Write-Host ('            {0}' -f $r.Detail) -ForegroundColor Gray }
            if ($r.Impact) { Write-Host ('            -> {0}' -f $r.Impact) -ForegroundColor DarkCyan }
            if ($r.Action) { Write-Host ('            FIX: {0}' -f $r.Action) -ForegroundColor DarkYellow }
        }
    }

    # -- verdict ---------------------------------------------------------------
    $fails    = @($findings | Where-Object { $_.Status -eq 'FAIL' })
    $warns    = @($findings | Where-Object { $_.Status -eq 'WARN' })
    $unknowns = @($findings | Where-Object { $_.Status -eq 'UNKNOWN' })

    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    if ($fails.Count -eq 0 -and $warns.Count -eq 0 -and $unknowns.Count -eq 0) {
        Write-Host '  RESULT: no app-aware blockers found on this guest.' -ForegroundColor Green
        Write-Host '  If the job still fails, the problem is between the backup server' -ForegroundColor DarkCyan
        Write-Host '  and this guest, not on it. Run the port reachability check next.' -ForegroundColor DarkCyan
    } else {
        Write-Host ('  RESULT: {0} FAIL, {1} WARN, {2} UNKNOWN.' -f $fails.Count, $warns.Count, $unknowns.Count) `
            -ForegroundColor $(if ($fails.Count -gt 0) { 'Red' } else { 'Yellow' })
        if ($fails.Count -gt 0) {
            Write-Host ''
            Write-Host '  Deal with these first:' -ForegroundColor Red
            foreach ($f in $fails) {
                Write-Host ('   * [{0}] {1}' -f $f.Category, $f.Check) -ForegroundColor Red
                if ($f.Action) { Write-Host ('     {0}' -f $f.Action) -ForegroundColor DarkGray }
            }
        }
        if ($unknowns.Count -gt 0) {
            Write-Host ''
            Write-Host ('  {0} check(s) could not be completed - those are not passes.' -f $unknowns.Count) -ForegroundColor Magenta
        }
    }
    Write-Host '=======================================================' -ForegroundColor Cyan
}

# =============================================================================
#  SESSION STATE + EXPORT
#  Deliberately kept separate from $script:LastResults / $script:AllResults:
#  a guest finding and a port row have nothing in common beyond a host name,
#  and merging them would produce a CSV with half its columns empty on every
#  row. Guest findings get their own accumulator and their own export.
# =============================================================================

function Save-GuestFindings($payload) {
    if (-not $payload -or -not $payload.Findings) {
        $script:LastGuestFindings = @()
        $script:LastGuestHost     = ''
        $script:LastGuestPayload  = $null
        return
    }
    $script:LastGuestFindings = @($payload.Findings)
    $script:LastGuestHost     = [string]$payload.Meta.Host
    # The HTML renderer needs Meta (host, OS, elevation, the collector notes),
    # not just the flattened rows the CSV export uses.
    $script:LastGuestPayload  = $payload

    $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    foreach ($f in @($payload.Findings)) {
        $script:AllGuestFindings += [pscustomobject]@{
            Host     = [string]$payload.Meta.Host
            Checked  = $stamp
            Category = $f.Category
            Check    = $f.Check
            Status   = $f.Status
            Detail   = $f.Detail
            Impact   = $f.Impact
            Action   = $f.Action
        }
    }
}

function Export-GuestFindings($path, [switch]$All) {
    $rows = if ($All) { $script:AllGuestFindings } else {
        @($script:LastGuestFindings | ForEach-Object {
            [pscustomobject]@{
                Host=$script:LastGuestHost; Checked=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
                Category=$_.Category; Check=$_.Check; Status=$_.Status
                Detail=$_.Detail; Impact=$_.Impact; Action=$_.Action
            }
        })
    }
    if (-not $rows -or $rows.Count -eq 0) {
        Write-Host '  Nothing to export - run a guest check first.' -ForegroundColor Red
        return
    }
    try {
        $rows | Sort-Object Host, @{e={ switch ($_.Status) { 'FAIL' {0} 'UNKNOWN' {1} 'WARN' {2} default {3} } }}, Category, Check |
            Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
        $hostCount = @($rows | Select-Object -ExpandProperty Host -Unique).Count
        Write-Host ('  Exported {0} finding(s) across {1} host(s) to {2}' -f $rows.Count, $hostCount, $path) -ForegroundColor Green
    } catch {
        Write-Host ('  Export failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
    }
}

# Exit code for pipeline use, same convention as the SSH path:
#   0 clean, 1 blockers found, 2 the check could not be completed.
function Get-GuestExitCode($payload) {
    if (-not $payload) { return 2 }
    $findings = @($payload.Findings)
    if (@($findings | Where-Object { $_.Status -eq 'FAIL' }).Count -gt 0) { return 1 }
    if (@($findings | Where-Object { $_.Status -eq 'UNKNOWN' }).Count -gt 0) { return 2 }
    return 0
}

# =============================================================================
#  GUEST PORT REACHABILITY
#  Run this FROM the backup server or the guest interaction proxy, aimed at
#  the guest. It answers the question the job log cannot: is this an RPC
#  problem on the wire, or a VSS problem inside the guest?
# =============================================================================
function Invoke-GuestPortScan {
    param(
        [Parameter(Mandatory)][string]$TargetHost,
        [switch]$SkipRpcRange
    )

    Write-Host ''
    Write-Rule 'Guest Processing Ports'
    $criticalFail = @()

    foreach ($e in $guestProcessingPorts) {
        $open   = Test-PortOpen $TargetHost $e.Port
        $status = if ($open) { '  OPEN  ' } else { ' CLOSED ' }
        $color  = if ($open) { 'Green' } elseif ($e.Critical) { 'Red' } else { 'DarkGray' }
        Write-Host ('[{0}] {1,-6} {2}' -f $status, $e.Port, $e.Description) -ForegroundColor $color
        if (-not $open -and $e.Critical) { $criticalFail += $e.Port }
    }

    if (-not $SkipRpcRange) {
        Write-Host ''
        Write-Rule 'Dynamic RPC Range (sampled)'
        Write-Host '  Sampling the default 49152-65535 range. A firewall opens or closes' -ForegroundColor DarkCyan
        Write-Host '  this wholesale, so samples are as informative as a full scan.' -ForegroundColor DarkCyan
        Write-Host ''

        $openSamples = @(); $closedSamples = @()
        foreach ($p in $guestRpcDynamicSamples) {
            if (Test-PortOpen $TargetHost $p) { $openSamples += $p } else { $closedSamples += $p }
        }

        # A closed sample is NOT proof of a blocked range: RPC allocates these
        # on demand, so an idle guest has most of them genuinely unbound. The
        # distinction that matters is refused-by-firewall vs nothing-listening,
        # and a TCP connect cannot tell those apart from here. Say so rather
        # than reporting a false blockage.
        Write-Host ('  Responding : {0}' -f $(if ($openSamples.Count)   { $openSamples -join ', ' }   else { 'none' })) -ForegroundColor DarkCyan
        Write-Host ('  Silent     : {0}' -f $(if ($closedSamples.Count) { $closedSamples -join ', ' } else { 'none' })) -ForegroundColor DarkCyan
        Write-Host ''
        Write-Host '  A silent sampled port is normal - RPC binds these on demand, so most' -ForegroundColor DarkGray
        Write-Host '  are genuinely unbound on an idle guest. This sample CANNOT distinguish' -ForegroundColor DarkGray
        Write-Host '  "firewall dropped it" from "nothing was listening". Treat it as context,' -ForegroundColor DarkGray
        Write-Host '  not as a verdict - the firewall rule itself is the thing to read, and the' -ForegroundColor DarkGray
        Write-Host '  guest check reports the range the guest actually uses.' -ForegroundColor DarkGray
    }

    Write-Host ''
    if ($criticalFail.Count -eq 0) {
        Write-Host '  Both critical ports (135, 445) are reachable.' -ForegroundColor Green
        Write-Host '  If guest processing still fails, it is authentication, the dynamic' -ForegroundColor DarkCyan
        Write-Host '  RPC range, or something inside the guest. Run -GuestTarget next.' -ForegroundColor DarkCyan
    } else {
        Write-Host ('  CRITICAL: port(s) {0} unreachable.' -f ($criticalFail -join ', ')) -ForegroundColor Red
        Write-Host '  App-aware processing cannot start. Fix this before looking at VSS.' -ForegroundColor Red
        if ($criticalFail -contains 135) {
            Write-Host '    135 closed -> RPC error 1722 on every run.' -ForegroundColor DarkGray
        }
        if ($criticalFail -contains 445) {
            Write-Host '    445 closed -> the guest runtime cannot be deployed through ADMIN$.' -ForegroundColor DarkGray
        }
    }
}
