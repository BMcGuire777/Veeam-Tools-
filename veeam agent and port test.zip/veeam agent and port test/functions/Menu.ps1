# =============================================================================
#  Menu.ps1 - the interactive menu.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

# Group selection for the guest check. Kept here rather than inline so menu
# entries 17 and 18 cannot drift apart.
function Read-GuestGroups {
    Write-Host ''
    Write-Host '  Groups: [Enter] all, or any combination of' -ForegroundColor DarkCyan
    Write-Host '          N=Network  C=Credentials  V=VSS  A=Application  G=Agent' -ForegroundColor DarkCyan
    $raw = (Read-Host '  Groups').Trim().ToUpper()
    if (-not $raw) { return $guestGroupsAll }
    $sel = @()
    if ($raw -match 'N') { $sel += 'Network' }
    if ($raw -match 'C') { $sel += 'Credentials' }
    if ($raw -match 'V') { $sel += 'VSS' }
    if ($raw -match 'A') { $sel += 'Application' }
    if ($raw -match 'G') { $sel += 'Agent' }
    if ($sel.Count -eq 0) {
        Write-Host '  Nothing recognised - running all groups.' -ForegroundColor Yellow
        return $guestGroupsAll
    }
    return $sel
}

function Invoke-InteractiveMenu {

$menuTarget = ''
$optEM = $false; $optCC = $false; $optWan = $false
$quit  = $false

while (-not $quit) {

    $vbrDisplay = if ($script:VbrConnected) {
        '{0}  [{1}]' -f $script:VbrServerName, $script:VbrPlatform
    } else { '(not connected)' }
    $targetDisplay = if ($menuTarget) { $menuTarget } else { '(not set)' }
    $extras = @()
    if ($optEM)  { $extras += 'EM' }
    if ($optCC)  { $extras += 'CloudConnect' }
    if ($optWan) { $extras += 'WAN' }
    $extrasDisplay = if ($extras.Count -gt 0) { $extras -join ', ' } else { 'none' }

    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host '  Veeam Port Diagnostic' -ForegroundColor Cyan
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ('  This host      : {0}' -f $env:COMPUTERNAME)  -ForegroundColor White
    Write-Host ('  VBR connection : {0}' -f $vbrDisplay)        -ForegroundColor White
    Write-Host ('  Scan target    : {0}' -f $targetDisplay)     -ForegroundColor White
    Write-Host ('  Extra profiles : {0}' -f $extrasDisplay)     -ForegroundColor White
    Write-Host ''
    Write-Host '  VBR SERVER' -ForegroundColor Magenta
    Write-Host '  [1] Connect to VBR server and run the conflict check' -ForegroundColor Green
    Write-Host '       Connect-VBRServer, detect Windows vs VSA, then check that host'
    Write-Host '  [2] Show managed servers (Get-VBRServer)' -ForegroundColor Green
    Write-Host '  [3] Check a named Windows host directly (no VBR API)' -ForegroundColor Green
    Write-Host '  [4] Linux / VSA - push over SSH, or emit the script' -ForegroundColor Green
    Write-Host '  [5] Disconnect from VBR' -ForegroundColor Yellow
    Write-Host '  -----------------------------------------------'
    Write-Host '  THIS MACHINE' -ForegroundColor Magenta
    Write-Host '  [6] Port conflict check on this machine' -ForegroundColor Green
    Write-Host '  [7] Export results to CSV (last check, or the whole session)' -ForegroundColor Green
    Write-Host '  [8] Toggle extra profiles (EM / Cloud Connect / WAN)' -ForegroundColor Yellow
    Write-Host '  -----------------------------------------------'
    Write-Host '  REACHABILITY' -ForegroundColor Magenta
    Write-Host '  [9] Set / change scan target' -ForegroundColor Yellow
    Write-Host '  [10] Core ports only (adds EM ports when the EM profile is on)' -ForegroundColor Green
    Write-Host '  [11] Core ports + full dynamic range (2500-3300)' -ForegroundColor Green
    Write-Host '  [12] Core ports + custom range' -ForegroundColor Green
    Write-Host '  [13] Remote server probe - DNS check + ports + HTTP, no login' -ForegroundColor Green
    Write-Host '  -----------------------------------------------'
    Write-Host '  TLS / CERTIFICATE' -ForegroundColor Magenta
    Write-Host '  [14] TLS handshake probe - catches broken certs TCP tests miss' -ForegroundColor Green
    Write-Host '  [15] Certificate audit on this machine (store / key / ACL)' -ForegroundColor Green
    Write-Host '  [16] Outbound CRL / revocation check (port 80 from this machine)' -ForegroundColor Green
    Write-Host '  -----------------------------------------------'
    Write-Host '  APP-AWARE / GUEST PROCESSING' -ForegroundColor Magenta
    Write-Host '  [17] Guest check on THIS machine - RPC, VSS, credentials, app, agent' -ForegroundColor Green
    Write-Host '  [18] Guest check on a remote guest (over WinRM)' -ForegroundColor Green
    Write-Host '  [19] Guest processing port reachability (135 / 445 / dynamic RPC)' -ForegroundColor Green
    Write-Host '  [20] Veeam log triage - find and decode the failure signatures' -ForegroundColor Green
    Write-Host '  [21] Look up an RPC or VSS error code' -ForegroundColor Green
    Write-Host '  -----------------------------------------------'
    Write-Host '  [Q] Quit' -ForegroundColor Red
    Write-Host ''

    $choice = (Read-Host '  Select').Trim().ToUpper()

    switch ($choice) {

        '1' {
            $srv = (Read-Host '  VBR server hostname or IP').Trim()
            if (-not $srv) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $pRaw = (Read-Host '  Port [Enter=443, use 9392 for v12 and older]').Trim()
            $prt  = if ($pRaw -match '^\d+$') { [int]$pRaw } else { 443 }
            $ac   = (Read-Host '  Accept the server TLS certificate? [Y/n]').Trim().ToUpper()
            Invoke-VbrConnectAndCheck -Server $srv -Port $prt -AcceptCert:($ac -ne 'N') `
                -WithEM:$optEM -WithCC:$optCC -WithWan:$optWan
            Write-Footer
        }

        '2' { Show-VbrInfrastructure; Write-Footer }

        '3' {
            $cn = (Read-Host '  Windows host to check').Trim()
            if (-not $cn) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $prompt = if ($script:VbrCred) {
                '  Credentials: [Enter] reuse the VBR credential, [C] current Windows user, [N] prompt me'
            } else {
                '  Credentials: [Enter] current Windows user, [N] prompt me'
            }
            Write-Host $prompt -ForegroundColor DarkCyan
            $ans = (Read-Host '  Choice').Trim().ToUpper()
            $cred = switch ($ans) {
                'N'     { Get-Credential -Message "Admin on $cn" }
                'C'     { $null }
                default { if ($script:VbrCred) { $script:VbrCred } else { $null } }
            }
            Write-Banner 'Veeam Port Conflict Check' $cn
            $payload = Invoke-RemoteCollector -Computer $cn -Credential $cred `
                -WithEM:$optEM -WithCC:$optCC -WithWan:$optWan
            if ($payload) { Save-Results $payload; Show-ConflictReport $payload }
            Write-Footer
        }

        '4' { Invoke-VsaWorkflow -ServerName $script:VbrServerName; Write-Footer }

        '5' { Disconnect-Vbr }

        '6' {
            Write-Banner 'Veeam Port Conflict Check' $env:COMPUTERNAME
            $payload = Invoke-LocalCollector -WithEM:$optEM -WithCC:$optCC -WithWan:$optWan
            Save-Results $payload
            Show-ConflictReport $payload
            Write-Footer
        }

        '7' {
            Write-Host ''
            Write-Host ('  [Enter] last check only ({0})' -f
                $(if ($script:LastResultHost) { $script:LastResultHost } else { 'nothing yet' })) -ForegroundColor Gray
            Write-Host ('  [A]     every check this session ({0} rows, mixed Windows + Linux)' -f
                $script:AllResults.Count) -ForegroundColor Gray
            Write-Host ('  [G]     guest / app-aware findings ({0} rows this session)' -f
                $script:AllGuestFindings.Count) -ForegroundColor Gray
            Write-Host ('  [L]     log triage signatures ({0} rows)' -f
                $script:LastLogHits.Count) -ForegroundColor Gray
            Write-Host '  [P]     last port check as an HTML report' -ForegroundColor Gray
            Write-Host '  [E]     whole estate as an HTML report (every host this session)' -ForegroundColor Gray
            Write-Host '  [H]     last guest check as an HTML report' -ForegroundColor Gray
            Write-Host '  [T]     log triage as an HTML report' -ForegroundColor Gray
            $which = (Read-Host '  Choice').Trim().ToUpper()

            if ($which -eq 'G' -or $which -eq 'L') {
                $gTag = if ($which -eq 'G') { 'GuestFindings' } else { 'LogTriage' }
                $gDefault = Join-Path $env:TEMP ('Veeam{0}_{1}.csv' -f $gTag, (Get-Date -Format 'yyyyMMdd_HHmmss'))
                $gPath = (Read-Host "  CSV path [Enter=$gDefault]").Trim()
                if (-not $gPath) { $gPath = $gDefault }
                if ($which -eq 'G') { Export-GuestFindings $gPath -All } else { Export-LogTriage $gPath }
                continue
            }

            if ($which -eq 'P' -or $which -eq 'E') {
                $pTag = if ($which -eq 'P') { 'PortCheck' } else { 'PortEstate' }
                $pHost = if ($which -eq 'P' -and $script:LastResultHost) { '_' + $script:LastResultHost } else { '' }
                $pDefault = Join-Path $env:TEMP ('Veeam{0}{1}_{2}.html' -f
                    $pTag, $pHost, (Get-Date -Format 'yyyyMMdd_HHmmss'))
                $pPath = (Read-Host "  HTML path [Enter=$pDefault]").Trim()
                if (-not $pPath) { $pPath = $pDefault }
                $written = if ($which -eq 'P') {
                    Export-PortCheckHtml -OutPath $pPath
                } else {
                    Export-PortEstateHtml -OutPath $pPath
                }
                if ($written) { Write-Host '  Open it in any browser, or print it to PDF for the ticket.' -ForegroundColor DarkCyan }
                continue
            }

            if ($which -eq 'H' -or $which -eq 'T') {
                # The HTML report covers ONE run, not the session: it carries
                # the host header, elevation banner and collector notes, and
                # those belong to a single collection. The CSV is the
                # cross-host artefact; this is the one you attach to a ticket.
                $hTag = if ($which -eq 'H') { 'GuestCheck' } else { 'LogTriage' }
                $hHost = if ($which -eq 'H' -and $script:LastGuestHost) { '_' + $script:LastGuestHost } else { '' }
                $hDefault = Join-Path $env:TEMP ('Veeam{0}{1}_{2}.html' -f
                    $hTag, $hHost, (Get-Date -Format 'yyyyMMdd_HHmmss'))
                $hPath = (Read-Host "  HTML path [Enter=$hDefault]").Trim()
                if (-not $hPath) { $hPath = $hDefault }
                if ($which -eq 'H') {
                    if (-not $script:LastGuestPayload) {
                        Write-Host '  No guest check has been run this session.' -ForegroundColor Red
                    } else {
                        $written = Export-GuestHtml -Payload $script:LastGuestPayload -OutPath $hPath
                        if ($written) { Write-Host '  Open it in any browser, or print it to PDF for the ticket.' -ForegroundColor DarkCyan }
                    }
                } else {
                    $written = Export-LogTriageHtml -OutPath $hPath -Hits @($script:LastLogHits)
                    if ($written) { Write-Host '  Open it in any browser, or print it to PDF for the ticket.' -ForegroundColor DarkCyan }
                }
                continue
            }

            $tag = if ($which -eq 'A') { 'AllHosts' }
                   elseif ($script:LastResultHost) { $script:LastResultHost }
                   else { $env:COMPUTERNAME }
            $default = Join-Path $env:TEMP ('VeeamPortCheck_{0}_{1}.csv' -f
                        $tag, (Get-Date -Format 'yyyyMMdd_HHmmss'))
            $path = (Read-Host "  CSV path [Enter=$default]").Trim()
            if (-not $path) { $path = $default }
            if ($which -eq 'A') { Export-AllResults $path } else { Export-Results $path }
        }

        '8' {
            Write-Host ''
            Write-Host '  [A] Enterprise Manager  [B] Cloud Connect  [C] WAN Accelerator' -ForegroundColor DarkCyan
            $t = (Read-Host '  Toggle which').Trim().ToUpper()
            switch ($t) {
                'A' { $optEM  = -not $optEM;  Write-Host "  Enterprise Manager: $optEM" -ForegroundColor DarkCyan }
                'B' { $optCC  = -not $optCC;  Write-Host "  Cloud Connect: $optCC"      -ForegroundColor DarkCyan }
                'C' { $optWan = -not $optWan; Write-Host "  WAN Accelerator: $optWan"   -ForegroundColor DarkCyan }
                default { Write-Host '  No change.' -ForegroundColor Red }
            }
        }

        '9' {
            $val = (Read-Host '  Enter hostname or IP').Trim()
            if ($val) { $menuTarget = $val; Write-Host "  Target set to: $menuTarget" -ForegroundColor DarkCyan }
        }

        '10' {
            $t = Resolve-Target $menuTarget
            if ($t) { $menuTarget = $t; Write-Banner 'Veeam Port Reachability' $t; Invoke-CoreScan $t -IncludeEM:$optEM; Write-Footer }
        }

        '11' {
            $t = Resolve-Target $menuTarget
            if ($t) {
                $menuTarget = $t; Write-Banner 'Veeam Port Reachability' $t
                Invoke-CoreScan $t -IncludeEM:$optEM; Invoke-RangeScan $t 2500 3300; Write-Footer
            }
        }

        '12' {
            Write-Host ''
            Write-Host '  Enter the sub-range to scan (within 2500-3300):' -ForegroundColor DarkCyan
            $s = Read-PortNumber 'Start port' 2500 3300 2500
            $e = Read-PortNumber 'End port  ' $s   3300 3300
            $t = Resolve-Target $menuTarget
            if ($t) {
                $menuTarget = $t
                Write-Host ''
                Write-Host ('  About to scan {0} ports ({1}-{2}) on {3}.' -f ($e-$s+1), $s, $e, $t) -ForegroundColor DarkCyan
                $confirm = (Read-Host '  Press Enter to start, or [B] to go back').Trim().ToUpper()
                if ($confirm -ne 'B') {
                    Write-Banner 'Veeam Port Reachability' $t
                    Invoke-CoreScan $t -IncludeEM:$optEM; Invoke-RangeScan $t $s $e; Write-Footer
                }
            }
        }

        '13' {
            Write-Host ''
            Write-Host '  Probes the server from here with no login: DNS lookup (forward +' -ForegroundColor DarkCyan
            Write-Host '  reverse), TCP port tests, and an HTTP(S) check on the web ports.' -ForegroundColor DarkCyan
            $default = if ($menuTarget) { " [Enter=$menuTarget]" } else { '' }
            $val = (Read-Host "  Hostname or IP address$default").Trim()
            if (-not $val -and $menuTarget) { $val = $menuTarget }
            if (-not $val) { Write-Host '  No target entered.' -ForegroundColor Red; continue }
            $menuTarget = $val
            Invoke-RemoteProbe $val -IncludeEM:$optEM
            Write-Footer
        }

        '14' {
            Write-Host ''
            Write-Host '  Negotiates real TLS handshakes on the Veeam TLS ports. A RESET here' -ForegroundColor DarkCyan
            Write-Host '  with TCP open is the signature of a badly installed certificate.' -ForegroundColor DarkCyan
            $t = Resolve-Target $menuTarget
            if ($t) {
                $menuTarget = $t
                $extraRaw = (Read-Host '  Extra port(s) to probe, comma-separated [Enter=none]').Trim()
                $extra = @()
                foreach ($tok in ($extraRaw -split ',')) {
                    if ($tok.Trim() -match '^\d+$') { $extra += [int]$tok.Trim() }
                }
                Write-Banner 'Veeam TLS Handshake Probe' $t
                Invoke-TlsScan $t -IncludeEM:$optEM -ExtraPorts $extra
                Write-Footer
            }
        }

        '15' {
            Write-Host ''
            Write-Host '  Audits LocalMachine\My for the Veeam certificate: private key present,' -ForegroundColor DarkCyan
            Write-Host '  key ACL readable by the Veeam service accounts, expiry, wrong-store' -ForegroundColor DarkCyan
            Write-Host '  installs. Run this ON the backup server, elevated.' -ForegroundColor DarkCyan
            $tp = (Read-Host '  Specific thumbprint to audit [Enter=auto-detect]').Trim()
            Invoke-LocalCertAudit -Thumbprint $tp
            Write-Footer
        }

        '16' {
            Write-Host ''
            Write-Host '  Tests OUTBOUND revocation traffic from this machine: DNS -> TCP ->' -ForegroundColor DarkCyan
            Write-Host '  HTTP GET against the CDP/OCSP URLs in local Veeam certs plus the' -ForegroundColor DarkCyan
            Write-Host '  well-known Windows CTL endpoints. Blocked port 80 = slow handshakes.' -ForegroundColor DarkCyan
            $extraRaw = (Read-Host '  Extra CRL URL(s) to probe, comma-separated [Enter=none]').Trim()
            $extraUrls = @()
            foreach ($tok in ($extraRaw -split ',')) {
                if ($tok.Trim()) { $extraUrls += $tok.Trim() }
            }
            Write-Banner 'Outbound CRL / Revocation Check' $env:COMPUTERNAME
            Invoke-CrlCheck -FromLocalStore -ExtraUrls $extraUrls
            Write-Footer
        }

        '17' {
            Write-Host ''
            Write-Host '  Walks the five domains an app-aware backup has to clear on THIS' -ForegroundColor DarkCyan
            Write-Host '  machine: RPC/network, credentials and policy, VSS, applications,' -ForegroundColor DarkCyan
            Write-Host '  and the Veeam agent. Read-only. Run it elevated or the VSS section' -ForegroundColor DarkCyan
            Write-Host '  comes back UNKNOWN rather than PASS.' -ForegroundColor DarkCyan
            $g = Read-GuestGroups
            $fo = (Read-Host '  Hide PASS/INFO rows? [y/N]').Trim().ToUpper()
            Write-Banner 'Veeam App-Aware Guest Check' $env:COMPUTERNAME
            $payload = Invoke-LocalGuestCheck -Groups $g
            Save-GuestFindings $payload
            Show-GuestReport $payload -FailuresOnly:($fo -eq 'Y')
            Write-Footer
        }

        '18' {
            $gt = (Read-Host '  Guest hostname or IP').Trim()
            if (-not $gt) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $prompt = if ($script:VbrCred) {
                '  Credentials: [Enter] reuse the VBR credential, [C] current Windows user, [N] prompt me'
            } else {
                '  Credentials: [Enter] current Windows user, [N] prompt me'
            }
            Write-Host $prompt -ForegroundColor DarkCyan
            $ans = (Read-Host '  Choice').Trim().ToUpper()
            $cred = switch ($ans) {
                'N'     { Get-Credential -Message "Local admin on $gt" }
                'C'     { $null }
                default { if ($script:VbrCred) { $script:VbrCred } else { $null } }
            }
            $g = Read-GuestGroups
            $fo = (Read-Host '  Hide PASS/INFO rows? [y/N]').Trim().ToUpper()
            Write-Banner 'Veeam App-Aware Guest Check' $gt
            $payload = Invoke-RemoteGuestCheck -Computer $gt -Credential $cred -Groups $g
            if ($payload) {
                Save-GuestFindings $payload
                Show-GuestReport $payload -FailuresOnly:($fo -eq 'Y')
            }
            Write-Footer
        }

        '19' {
            Write-Host ''
            Write-Host '  Run this FROM the backup server or guest interaction proxy. It' -ForegroundColor DarkCyan
            Write-Host '  separates "RPC cannot reach the guest" from "VSS failed inside it".' -ForegroundColor DarkCyan
            $default = if ($menuTarget) { " [Enter=$menuTarget]" } else { '' }
            $gt = (Read-Host "  Guest hostname or IP$default").Trim()
            if (-not $gt -and $menuTarget) { $gt = $menuTarget }
            if (-not $gt) { Write-Host '  No target entered.' -ForegroundColor Red; continue }
            $menuTarget = $gt
            Write-Banner 'Guest Processing Reachability' $gt
            Invoke-GuestPortScan -TargetHost $gt
            Write-Footer
        }

        '20' {
            Write-Host ''
            Write-Host '  Reads Veeam job, agent and guest helper logs, matches known failure' -ForegroundColor DarkCyan
            Write-Host '  signatures, resolves the RPC/VSS codes, and ranks them by what' -ForegroundColor DarkCyan
            Write-Host '  actually blocks the job. Read-only.' -ForegroundColor DarkCyan
            $lp = (Read-Host '  Log file or folder [Enter=default Veeam locations]').Trim()
            $sdRaw = (Read-Host '  Only files modified in the last N days [Enter=14]').Trim()
            $sd = if ($sdRaw -match '^\d+$') { [int]$sdRaw } else { 14 }
            $sa = (Read-Host '  Include informational signatures too? [y/N]').Trim().ToUpper()
            Write-Banner 'Veeam Log Triage' $(if ($lp) { $lp } else { 'default log locations' })
            Invoke-VeeamLogTriage -Path $lp -SinceDays $sd -ShowAll:($sa -eq 'Y') | Out-Null
            Write-Footer
        }

        '21' {
            Write-Host ''
            Write-Host '  Accepts a decimal RPC code (1722), a hex Win32 code (0x800706BA)' -ForegroundColor DarkCyan
            Write-Host '  or a VSS HRESULT (0x800423F4).' -ForegroundColor DarkCyan
            $ec = (Read-Host '  Error code').Trim()
            if (-not $ec) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            Show-GuestErrorCode -Code $ec
            Write-Footer
        }

        'Q' { $quit = $true }

        default { Write-Host '  Invalid choice.' -ForegroundColor Red }
    }
}
}
