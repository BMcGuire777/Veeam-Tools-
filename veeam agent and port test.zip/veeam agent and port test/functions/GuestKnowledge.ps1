# =============================================================================
#  GuestKnowledge.ps1 - the knowledge base for app-aware / guest processing
#  failures: RPC and VSS error codes, log signatures, and what each one means.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
#
#  THIS FILE IS DATA, NOT LOGIC. If a code or a signature is wrong, fix it
#  here - do not special-case it in the collector or the parser.
#
#  Verified = $true  : confirmed against Microsoft or Veeam documentation
#  Verified = $false : general field knowledge - rendered with a ~ marker
# =============================================================================

# =============================================================================
#  WIN32 / RPC ERROR CODES
#  Keyed by the decimal code Veeam prints as "RPC error: ... Code: NNNN".
#  Hex aliases are resolved to these by Resolve-GuestErrorCode.
# =============================================================================
$guestWin32Errors = @{
    5 = @{
        Name='ERROR_ACCESS_DENIED'; Verified=$true; Category='Credentials'
        Meaning='Access denied. The account reached the guest but was refused.'
        Causes=@(
            'The guest processing account is not in the local Administrators group on this guest.'
            'UAC remote restriction: a LOCAL (non-domain) admin gets a filtered token over the network unless LocalAccountTokenFilterPolicy=1.'
            'DCOM or WMI namespace ACLs have been hardened by GPO.'
            'The account is admin on the domain but a GPO removes it from local Administrators on this tier.'
        )
    }
    53 = @{
        Name='ERROR_BAD_NETPATH'; Verified=$true; Category='Network'
        Meaning='The network path was not found. SMB could not be reached or the share does not exist.'
        Causes=@(
            'The ADMIN$ administrative share is disabled (AutoShareServer=0) - Veeam deploys its runtime there.'
            'The Server (LanmanServer) service is stopped.'
            'TCP 445 is blocked between the backup server / guest interaction proxy and the guest.'
            'Name resolution returns a host that is not the guest.'
        )
    }
    64 = @{
        Name='ERROR_NETNAME_DELETED'; Verified=$true; Category='Network'
        Meaning='The specified network name is no longer available - the session was torn down mid-call.'
        Causes=@(
            'A firewall or IPS is resetting the SMB/RPC session rather than dropping it.'
            'NIC teaming, VPN or asymmetric routing breaking an established session.'
            'The guest rebooted or the Server service restarted during the job.'
        )
    }
    1203 = @{
        Name='ERROR_NO_NET_OR_BAD_PATH'; Verified=$true; Category='Network'
        Meaning='No network provider accepted the given path.'
        Causes=@('Malformed target name, or the SMB client is disabled on the source host.')
    }
    1225 = @{
        Name='ERROR_CONNECTION_REFUSED'; Verified=$true; Category='Network'
        Meaning='The remote computer actively refused the connection.'
        Causes=@(
            'The service is not listening on that port (RPC Endpoint Mapper stopped).'
            'A firewall configured to reject rather than drop.'
        )
    }
    1326 = @{
        Name='ERROR_LOGON_FAILURE'; Verified=$true; Category='Credentials'
        Meaning='Unknown user name or bad password. This is the literal "wrong password" case.'
        Causes=@(
            'The stored Veeam credential is stale after a password change or a LAPS rotation.'
            'Wrong UPN/NetBIOS form - DOMAIN\user vs user@domain vs a local account on a workgroup guest.'
            'A second, forgotten Veeam credential record is also hitting this account and locking it out.'
        )
    }
    1327 = @{
        Name='ERROR_ACCOUNT_RESTRICTION'; Verified=$true; Category='Credentials'
        Meaning='Account restrictions are preventing this user from signing in.'
        Causes=@('Blank password not allowed, logon hours, or workstation restrictions on the account.')
    }
    1330 = @{
        Name='ERROR_PASSWORD_EXPIRED'; Verified=$true; Category='Credentials'
        Meaning='The password for this account has expired.'
        Causes=@('Service account subject to the domain password policy with no exemption.')
    }
    1331 = @{
        Name='ERROR_ACCOUNT_DISABLED'; Verified=$true; Category='Credentials'
        Meaning='The account is currently disabled.'
        Causes=@('Account disabled by a leaver process or a stale-account cleanup job.')
    }
    1722 = @{
        Name='RPC_S_SERVER_UNAVAILABLE'; Verified=$true; Category='Network'
        Meaning='The RPC server is unavailable. By far the most common app-aware failure.'
        Causes=@(
            'TCP 135 blocked, or the high dynamic RPC range (default 49152-65535) blocked. Opening 135 alone is NOT enough.'
            'The RPC Endpoint Mapper (RpcEptMapper) or RPC (RpcSs) service is not running.'
            'Windows Firewall flipped to the Public profile after a NIC change, so Domain-scoped rules stopped applying.'
            'DNS resolves the guest to a stale or duplicate A record.'
            'IPv6 is preferred for the connection but only IPv4 is permitted through the firewall.'
            'EDR/AV blocking the inbound RPC call or the VeeamGuestHelper deployment.'
        )
    }
    1723 = @{
        Name='RPC_S_SERVER_TOO_BUSY'; Verified=$true; Category='Network'
        Meaning='The RPC server is too busy to complete this operation.'
        Causes=@('Resource exhaustion on the guest, or too many concurrent jobs touching the same guest.')
    }
    1726 = @{
        Name='RPC_S_CALL_FAILED'; Verified=$true; Category='Network'
        Meaning='The remote procedure call failed after it was accepted.'
        Causes=@('The service handling the call crashed or was restarted mid-operation.')
    }
    1727 = @{
        Name='RPC_S_CALL_FAILED_DNE'; Verified=$true; Category='Network'
        Meaning='The remote procedure call failed and did not execute.'
        Causes=@('The endpoint mapper answered but the dynamic port it handed back was unreachable - classic partially-open firewall.')
    }
    1753 = @{
        Name='EPT_S_NOT_REGISTERED'; Verified=$true; Category='Network'
        Meaning='There are no more endpoints available from the endpoint mapper.'
        Causes=@(
            'The target service never registered an endpoint - it is stopped or failed to start.'
            'Ephemeral port exhaustion on the guest (check with netstat for TIME_WAIT volume).'
            'The dynamic RPC range has been narrowed by policy to fewer ports than the host needs.'
        )
    }
    1907 = @{
        Name='ERROR_PASSWORD_MUST_CHANGE'; Verified=$true; Category='Credentials'
        Meaning='The user password must be changed before signing in.'
        Causes=@('"User must change password at next logon" is set on the service account.')
    }
    1908 = @{
        Name='ERROR_NO_SUCH_DOMAIN'; Verified=$true; Category='Credentials'
        Meaning='Could not find the domain controller for this domain.'
        Causes=@('DNS on the guest does not point at a DC, or the site has no reachable DC.')
    }
    1909 = @{
        Name='ERROR_ACCOUNT_LOCKED_OUT'; Verified=$true; Category='Credentials'
        Meaning='The referenced account is currently locked out.'
        Causes=@(
            'A stale credential elsewhere (another Veeam job, a scheduled task, a mapped drive) is burning the lockout counter.'
            'Chase this with the DC lockout events, not with the backup job - the job is the victim, not the cause.'
        )
    }
    2147942405 = @{
        Name='E_ACCESSDENIED (0x80070005)'; Verified=$true; Category='Credentials'
        Meaning='Access denied, surfaced as an HRESULT rather than a Win32 code.'
        Causes=@(
            'DCOM launch/activation permissions on the guest.'
            'The same root causes as code 5 - treat the two together.'
        )
    }
}

# Hex spellings Veeam and Windows both emit, mapped to the decimal codes above.
$guestHexAliases = @{
    '0x80070005' = 2147942405
    '0x800706BA' = 1722
    '0x800706BB' = 1723
    '0x800706BF' = 1727
    '0x800706D9' = 1753
    '0x8007052E' = 1326
    '0x80070035' = 53
}

# =============================================================================
#  VSS ERROR CODES
#  Keyed by the uppercase hex HRESULT. Veeam prints these as
#  "Cannot create a shadow copy ... Error code: 0x800423f4".
# =============================================================================
$guestVssErrors = @{
    '0X80042301' = @{
        Name='VSS_E_BAD_STATE'; Verified=$true
        Meaning='A VSS object is in an inconsistent state - the snapshot sequence was called out of order.'
        Causes=@(
            'A previous failed backup left the writers wedged. Restart the owning services, or reboot.'
            'Two backup products snapshotting the same volume at once.'
        )
    }
    '0X80042306' = @{
        Name='VSS_E_PROVIDER_VETO'; Verified=$true
        Meaning='The shadow copy provider had an error and vetoed the snapshot.'
        Causes=@(
            'A third-party hardware or software VSS provider was selected instead of the Microsoft one.'
            'Look in the System event log for VolSnap and the provider vendor source at the same timestamp.'
        )
    }
    '0X80042308' = @{
        Name='VSS_E_OBJECT_NOT_FOUND'; Verified=$true
        Meaning='The specified shadow copy object was not found.'
        Causes=@('A shadow copy was deleted underneath the job, often by another backup product or a cleanup script.')
    }
    '0X8004230C' = @{
        Name='VSS_E_VOLUME_NOT_SUPPORTED'; Verified=$true
        Meaning='Shadow copying this volume is not supported by the selected provider.'
        Causes=@(
            'Dynamic disks, spanned or striped volumes.'
            'A non-NTFS/ReFS volume, a raw volume, or a volume presented by an unsupported driver.'
            'A volume too small to hold its own diff area.'
        )
    }
    '0X8004230F' = @{
        Name='VSS_E_UNEXPECTED_PROVIDER_ERROR'; Verified=$true
        Meaning='The shadow copy provider had an unexpected error.'
        Causes=@('Usually the same ground as PROVIDER_VETO - identify which provider is being chosen first.')
    }
    '0X80042312' = @{
        Name='VSS_E_MAXIMUM_NUMBER_OF_VOLUMES_REACHED'; Verified=$false
        Meaning='Too many volumes in the snapshot set.'
        Causes=@('Split the job, or exclude volumes that do not need application consistency.')
    }
    '0X80042313' = @{
        Name='VSS_E_MAXIMUM_NUMBER_OF_SNAPSHOTS_REACHED'; Verified=$false
        Meaning='The volume already holds the maximum number of shadow copies.'
        Causes=@('Orphaned shadow copies from failed runs. List them with vssadmin list shadows before deciding anything.')
    }
    '0X80042314' = @{
        Name='VSS_E_WRITER_INFRASTRUCTURE'; Verified=$false
        Meaning='The VSS writer infrastructure is not operating properly.'
        Causes=@('COM+ / DCOM, the Event System service, or a corrupt VSS registration. Check the Application log for VSS source errors.')
    }
    '0X80042316' = @{
        Name='VSS_E_SNAPSHOT_SET_IN_PROGRESS'; Verified=$true
        Meaning='Another shadow copy operation is already in progress.'
        Causes=@(
            'Overlapping backup windows - a second Veeam job, Windows Server Backup, or a third-party product.'
            'A previous snapshot that never completed and still holds the set.'
        )
    }
    '0X80042317' = @{
        Name='VSS_E_MAXIMUM_DIFFAREA_ASSOCIATIONS_REACHED'; Verified=$false
        Meaning='The maximum number of diff area associations has been reached.'
        Causes=@('Too many shadow storage associations configured - review vssadmin list shadowstorage.')
    }
    '0X8004231F' = @{
        Name='VSS_E_INSUFFICIENT_STORAGE'; Verified=$true
        Meaning='Insufficient storage to create the shadow copy or the diff area.'
        Causes=@(
            'Not enough free space on the protected volume.'
            'MaxSize on the shadow storage association is set too low.'
            'The diff area is associated with a DIFFERENT volume and that volume is full.'
        )
    }
    '0X80042321' = @{
        Name='VSS_E_WRITERERROR_PARTIAL_FAILURE'; Verified=$false
        Meaning='A writer partially failed the snapshot.'
        Causes=@('One component of one writer failed - identify the writer from the job log before touching anything.')
    }
    '0X800423F0' = @{
        Name='VSS_E_WRITERERROR_INCONSISTENTSNAPSHOT'; Verified=$true
        Meaning='The shadow copy contains only a subset of the volumes the writer needs.'
        Causes=@(
            'An application has data spread across volumes that are not all in the backup scope.'
            'Classic with SQL data on one drive and logs on another where only one is included.'
        )
    }
    '0X800423F1' = @{
        Name='VSS_E_WRITERERROR_OUTOFRESOURCES'; Verified=$true
        Meaning='The writer ran out of memory or other system resources.'
        Causes=@('Memory pressure on the guest during the freeze, or a very large writer (SQL with many databases).')
    }
    '0X800423F2' = @{
        Name='VSS_E_WRITERERROR_TIMEOUT'; Verified=$true
        Meaning='The writer operation failed because of a timeout between the freeze and thaw.'
        Causes=@(
            'The 10-second VSS freeze window was exceeded - heavy I/O or slow storage under the guest.'
            'Databases large enough that the writer cannot quiesce in time.'
            'This is a performance problem wearing a VSS costume. Move the job window before changing VSS settings.'
        )
    }
    '0X800423F3' = @{
        Name='VSS_E_WRITERERROR_RETRYABLE'; Verified=$true
        Meaning='The writer experienced a transient error - retrying the snapshot may succeed.'
        Causes=@('Transient load. If it is not transient, treat it as the timeout case above.')
    }
    '0X800423F4' = @{
        Name='VSS_E_WRITERERROR_NONRETRYABLE'; Verified=$true
        Meaning='The writer experienced a non-transient error; retrying will not succeed.'
        Causes=@(
            'The writer itself is in a failed state - vssadmin list writers will show it.'
            'The owning application service needs restarting, or the guest needs a reboot.'
        )
    }
    '0X80070005' = @{
        Name='E_ACCESSDENIED'; Verified=$true
        Meaning='Access denied during the snapshot call.'
        Causes=@('The guest processing account lacks local admin, or VSS COM permissions have been hardened.')
    }
    '0X80070422' = @{
        Name='ERROR_SERVICE_DISABLED'; Verified=$true
        Meaning='The service cannot be started because it is disabled.'
        Causes=@('The Volume Shadow Copy (VSS) or Microsoft Software Shadow Copy Provider (swprv) service start type is Disabled.')
    }
}

# =============================================================================
#  VSS WRITERS THAT MATTER FOR APP-AWARE PROCESSING
#  Name -> what owns it, so a failed writer points at a service rather than
#  a generic "restart VSS" instruction.
# =============================================================================
$guestVssWriters = @{
    'SqlServerWriter'            = 'SQL Server VSS Writer service (SQLWriter). Stopped or Disabled on many installs by default.'
    'Microsoft Exchange Writer'  = 'Microsoft Exchange Information Store service.'
    'NTDS'                       = 'Active Directory Domain Services (ntds). Domain controller only.'
    'IIS Metabase Writer'        = 'IIS Admin Service.'
    'IIS Config Writer'          = 'Application Host Helper Service.'
    'FRS Writer'                 = 'File Replication Service (legacy SYSVOL replication).'
    'DFS Replication service writer' = 'DFS Replication service.'
    'Registry Writer'            = 'Core Windows writer - a failure here usually means the whole VSS stack is unhealthy.'
    'System Writer'              = 'Cryptographic Services (CryptSvc). Fails when the %windir%\\winsxs ACLs drift.'
    'COM+ REGDB Writer'          = 'COM+ System Application service.'
    'WMI Writer'                 = 'Windows Management Instrumentation service. A failure here often means a corrupt WMI repository.'
    'ASR Writer'                 = 'Core Windows writer - commonly fails when a disk has no valid signature.'
    'Shadow Copy Optimization Writer' = 'Core Windows writer.'
    'MSSearch Service Writer'    = 'Windows Search service.'
    'SPSearch4 VSS Writer'       = 'SharePoint Foundation Search.'
    'Oracle VSS Writer'          = 'Oracle VSS Writer service (per Oracle instance).'
}

# =============================================================================
#  LOG SIGNATURES
#  Regex -> cause + action. Used by Invoke-VeeamLogTriage. Ordered: the first
#  pattern that matches a line wins, so put the specific ones above the broad
#  ones.
#
#  Severity: FAIL (job-stopping) | WARN (degraded / will bite later) | INFO
# =============================================================================
$guestLogPatterns = @(
    # -- RPC / transport ------------------------------------------------------
    @{ Pattern='RPC function call failed.*Function name:\s*\[(?<fn>[^\]]+)\]'
       Category='Network'; Severity='FAIL'
       Cause='A guest interaction RPC call failed. The function name says how far it got: InvokerTestConnection = the very first reachability test; anything else = the session opened and a later call failed.'
       Action='Read the Code: value on the same line and look it up in the RPC table. Then run the guest check against that host.' }

    @{ Pattern='RPC error:?\s*(?<msg>.+?)\s*Code:\s*(?<code>\d+)'
       Category='Network'; Severity='FAIL'
       Cause='Explicit RPC error code from the guest interaction layer.'
       Action='Resolve the code against the RPC table. 1722 is nearly always the dynamic RPC range, not port 135.' }

    @{ Pattern='(?i)cannot connect to the host.?s? administrative share'
       Category='Network'; Severity='FAIL'
       Cause='Veeam could not reach ADMIN$ to deploy its guest runtime.'
       Action='Confirm ADMIN$ exists, LanmanServer is running, AutoShareServer is not 0, and TCP 445 is open.' }

    @{ Pattern='(?i)(failed to connect to (the )?guest (agent|helper)|unable to connect to the guest)'
       Category='Network'; Severity='FAIL'
       Cause='The guest helper was deployed but never called back, or was never deployed.'
       Action='Check EDR/AV quarantine on the guest for VeeamGuestHelper.exe and VeeamVssSupport.exe, then the dynamic RPC range.' }

    @{ Pattern='(?i)the network path was not found'
       Category='Network'; Severity='FAIL'
       Cause='SMB path unreachable - error 53.'
       Action='Admin shares, LanmanServer, TCP 445, and name resolution, in that order.' }

    # -- Credentials ----------------------------------------------------------
    @{ Pattern='(?i)(logon failure|the user name or password is incorrect|unknown user name or bad password)'
       Category='Credentials'; Severity='FAIL'
       Cause='Authentication was rejected outright.'
       Action='Check the credential record for staleness, then check the DC for lockout events on that account - a lockout caused elsewhere surfaces here.' }

    @{ Pattern='(?i)(account is locked out|referenced account is currently locked out)'
       Category='Credentials'; Severity='FAIL'
       Cause='The guest processing account is locked.'
       Action='Find the lockout SOURCE on the DC (event 4740). Another stale credential is almost always to blame; unlocking alone will not hold.' }

    @{ Pattern='(?i)access is denied'
       Category='Credentials'; Severity='FAIL'
       Cause='Authenticated but not authorised - error 5 / 0x80070005.'
       Action='Confirm local Administrators membership ON THAT GUEST, then LocalAccountTokenFilterPolicy for local accounts.' }

    @{ Pattern='(?i)(restrict ?ntlm|ntlm authentication.*(blocked|denied))'
       Category='Credentials'; Severity='FAIL'
       Cause='NTLM is blocked by policy, forcing Kerberos.'
       Action='Check for duplicate SPNs and time skew on the guest - Kerberos fails quietly where NTLM used to work.' }

    # -- VSS ------------------------------------------------------------------
    @{ Pattern='(?i)error code:?\s*(?<vss>0x8004[0-9a-f]{4})'
       Category='VSS'; Severity='FAIL'
       Cause='A VSS HRESULT was returned by the snapshot call.'
       Action='Resolve the code against the VSS table.' }

    @{ Pattern='(?i)cannot create a shadow copy of the volumes containing writer.?s data'
       Category='VSS'; Severity='FAIL'
       Cause='A writer needs data on a volume that is not in the snapshot set.'
       Action='Compare the writer component paths against the volumes in the job scope - typically SQL logs on an excluded drive.' }

    @{ Pattern='(?i)(writer.*(failed|timed? ?out|retryable|non-?retryable)|vss writer.*error)'
       Category='VSS'; Severity='FAIL'
       Cause='A named VSS writer failed during freeze.'
       Action='Run vssadmin list writers on the guest and map the writer to its owning service.' }

    @{ Pattern='(?i)(shadow copy creation.*(timed? ?out|timeout)|freeze.*timeout)'
       Category='VSS'; Severity='FAIL'
       Cause='The VSS freeze window was exceeded.'
       Action='This is an I/O performance problem. Move the job window or address storage latency before changing VSS settings.' }

    @{ Pattern='(?i)(insufficient (disk )?space|not enough (disk )?space|shadow (copy )?storage)'
       Category='VSS'; Severity='FAIL'
       Cause='No room for the shadow copy diff area.'
       Action='vssadmin list shadowstorage - check both free space AND the MaxSize cap, and which volume the diff area lives on.' }

    @{ Pattern='(?i)another shadow copy (operation|creation) is (already )?in progress'
       Category='VSS'; Severity='FAIL'
       Cause='Overlapping snapshot operations.'
       Action='Find the other backup product or the other Veeam job sharing this window.' }

    # -- Application ----------------------------------------------------------
    @{ Pattern='(?i)(failed to (log ?in|login|connect) to .*sql|cannot (open|connect to) (the )?sql|login failed for user)'
       Category='Application'; Severity='FAIL'
       Cause='SQL authentication or connectivity failed inside the guest.'
       Action='Confirm the account has sysadmin on the instance, that TCP/Named Pipes are enabled, and SQL Browser is running for named instances.' }

    @{ Pattern='(?i)(unable to truncate|failed to truncate|transaction log.*(not )?truncat)'
       Category='Application'; Severity='WARN'
       Cause='Log truncation did not happen. The backup may still have succeeded.'
       Action='Check the recovery model, whether another product also backs up these logs (broken LSN chain), and sysadmin rights.' }

    @{ Pattern='(?i)circular logging'
       Category='Application'; Severity='WARN'
       Cause='Exchange circular logging is enabled - log truncation is impossible by design.'
       Action='Either accept it or disable circular logging on the database. Not a Veeam fault.' }

    @{ Pattern='(?i)(database .* is (offline|in (restoring|recovery|suspect|single.user) )|is not accessible)'
       Category='Application'; Severity='WARN'
       Cause='A database was not in a backupable state.'
       Action='Expected for a log-shipping target or a restoring replica. Exclude it from app-aware processing if it is permanent.' }

    @{ Pattern='(?i)always ?on|availability (group|replica)'
       Category='Application'; Severity='INFO'
       Cause='AlwaysOn Availability Group involvement.'
       Action='Check the preferred-replica setting and whether the job is hitting a secondary that cannot do a non-copy-only backup.' }

    # -- Agent / deployment ---------------------------------------------------
    @{ Pattern='(?i)(failed to (deploy|upload|install) .*(agent|runtime|component)|deployment of .* failed)'
       Category='Agent'; Severity='FAIL'
       Cause='The Veeam runtime could not be pushed into the guest.'
       Action='ADMIN$ access, free space on the system drive, and EDR/AV blocking the write or the process creation.' }

    @{ Pattern='(?i)(version mismatch|incompatible version|agent version .* is not supported)'
       Category='Agent'; Severity='FAIL'
       Cause='The agent or transport component is a different version to the backup server.'
       Action='Upgrade the agent on this guest. Common after a VBR upgrade where one protection group was missed.' }

    @{ Pattern='(?i)guest (processing|os) (was )?skipped'
       Category='Agent'; Severity='WARN'
       Cause='The job fell back to a crash-consistent backup.'
       Action='The real error is on an earlier line. This is the symptom, not the cause - keep reading upwards.' }

    @{ Pattern='(?i)(wmi|winmgmt).*(failed|error|0x8004100)'
       Category='Agent'; Severity='FAIL'
       Cause='WMI query failure inside the guest.'
       Action='Run winmgmt /verifyrepository on the guest. A corrupt repository fails app-aware long before it fails anything visible.' }

    @{ Pattern='(?i)(pending reboot|reboot is required)'
       Category='Agent'; Severity='WARN'
       Cause='The guest has a pending reboot.'
       Action='Pending servicing operations leave writers in a half-state. Reboot before chasing anything else.' }
)

# =============================================================================
#  RESOLVERS
# =============================================================================

# Accepts 1722, '1722', '0x800706BA' or '0x800423F4' and returns the knowledge
# entry plus a normalised label, or $null when the code is not in the tables.
function Resolve-GuestErrorCode {
    param([Parameter(Mandatory)][string]$Code)

    $raw = $Code.Trim()
    if (-not $raw) { return $null }

    # VSS HRESULTs first - they are always hex and always 0x8004xxxx.
    $upper = $raw.ToUpper()
    if ($upper -match '^0X8004[0-9A-F]{4}$' -and $guestVssErrors.ContainsKey($upper)) {
        $e = $guestVssErrors[$upper]
        return [pscustomobject]@{
            Code=$upper; Kind='VSS'; Category='VSS'
            Name=$e.Name; Verified=$e.Verified; Meaning=$e.Meaning; Causes=@($e.Causes)
        }
    }

    # Hex aliases of Win32 codes.
    if ($guestHexAliases.ContainsKey($upper)) { $raw = [string]$guestHexAliases[$upper] }
    elseif ($upper -match '^0X[0-9A-F]+$') {
        try { $raw = [string][Convert]::ToInt64($upper.Substring(2), 16) } catch { }
    }

    if ($raw -match '^\d+$' -and $guestWin32Errors.ContainsKey([int]$raw)) {
        $e = $guestWin32Errors[[int]$raw]
        return [pscustomobject]@{
            Code=[int]$raw; Kind='Win32'; Category=$e.Category
            Name=$e.Name; Verified=$e.Verified; Meaning=$e.Meaning; Causes=@($e.Causes)
        }
    }

    return $null
}

function Show-GuestErrorCode {
    param([Parameter(Mandatory)][string]$Code)

    $e = Resolve-GuestErrorCode -Code $Code
    Write-Host ''
    if (-not $e) {
        Write-Host ('  {0} is not in the error tables.' -f $Code) -ForegroundColor Yellow
        Write-Host '  Add it to functions\GuestKnowledge.ps1 rather than working around it.' -ForegroundColor DarkGray
        return
    }
    $flag = if ($e.Verified) { '' } else { '  ~ (not confirmed against vendor docs)' }
    Write-Rule ('{0}  {1}{2}' -f $e.Code, $e.Name, $flag) 'Magenta'
    Write-Host ('  {0}' -f $e.Meaning) -ForegroundColor White
    Write-Host ''
    Write-Host '  Usual causes, most likely first:' -ForegroundColor DarkCyan
    foreach ($c in $e.Causes) { Write-Host ('    - {0}' -f $c) -ForegroundColor DarkCyan }
}
