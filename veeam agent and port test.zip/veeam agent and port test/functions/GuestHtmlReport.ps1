# =============================================================================
#  GuestHtmlReport.ps1 - HTML output for the app-aware / guest processing
#  diagnostics.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables, the guest knowledge base and all
#  $script: state directly.
#
#  Reuses the engine in HtmlReport.ps1 rather than reimplementing it:
#  ConvertTo-HtmlText, New-BlueprintHtmlTable, New-BlueprintSvgBar, the
#  palette, and Get-VeeamHtmlCss. The same promise applies - a single
#  self-contained .html document, inline SVG, inline CSS, zero JavaScript.
#  It opens in any browser, prints to PDF, and attaches to a ticket, on a
#  box with nothing installed but PowerShell.
#
#  Export-GuestHtml      : a guest check payload -> .html
#  Export-LogTriageHtml  : log triage signatures -> .html
# =============================================================================

# Report rules live in HtmlReport.ps1 ($script:VeeamReportExtraCss) so the port,
# guest and blueprint reports cannot drift apart. Severity colouring reuses the
# existing row classes (tr.crit / tr.warn); UNKNOWN has one of its own because
# "could not be checked" is not a warning and must not read as one.

# Why each group sits where it does. Rendered under the section heading so the
# report carries the reasoning, not just the rows - the person reading the HTML
# is usually not the person who ran the check.
$script:GuestCategoryNotes = @{
    'Network'     = 'Checked first because nothing below it can be trusted until the guest is reachable. An RPC failure here means the VSS answers further down were never actually collected.'
    'Credentials' = 'Authentication and policy. A failure here looks identical to a wrong password in the job log, and usually is not one.'
    'VSS'         = 'The snapshot path. Only meaningful once Network and Credentials are clean.'
    'Application' = 'SQL, Exchange, Active Directory, Oracle. These fail the application part of the backup while the image itself still succeeds.'
    'Agent'       = 'Deployment and runtime. Pending reboots and a corrupt WMI repository belong here and routinely masquerade as VSS faults.'
}

function Get-GuestRowClass {
    param([string]$Status)
    switch ($Status) {
        'FAIL'    { return 'crit' }
        'WARN'    { return 'warn' }
        'UNKNOWN' { return 'sevUnknown' }
        default   { return '' }
    }
}

# =============================================================================
#  GUEST CHECK -> HTML
# =============================================================================
function ConvertTo-GuestHtml {
    param(
        [Parameter(Mandatory)]$Payload,
        [string]$SourceName = ''
    )

    $findings = @($Payload.Findings)
    $meta     = $Payload.Meta
    $now      = Get-Date

    $counts = @{}
    foreach ($s in @('FAIL','WARN','UNKNOWN','INFO','PASS')) {
        $counts[$s] = @($findings | Where-Object { $_.Status -eq $s }).Count
    }

    $h = New-Object System.Text.StringBuilder
    function AL([string]$s) { [void]$h.AppendLine($s) }

    AL '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
    AL '<meta name="viewport" content="width=device-width, initial-scale=1">'
    AL ('<title>Veeam App-Aware Check - {0}</title>' -f (ConvertTo-HtmlText $meta.Host))
    AL '<style>'
    AL (Get-VeeamHtmlCss)
    AL $script:VeeamReportExtraCss
    AL '</style></head><body><div class="page">'

    # ---- header -------------------------------------------------------------
    AL ('<h1>Veeam App-Aware Guest Check &mdash; {0}</h1>' -f (ConvertTo-HtmlText $meta.Host))
    $domainTxt = 'WORKGROUP - not domain joined'
    if ($meta.DomainJoined) { $domainTxt = [string]$meta.Domain }
    AL ('<div class="sub">Checked {0} &nbsp;|&nbsp; {1} &nbsp;|&nbsp; {2} &nbsp;|&nbsp; ran as {3} &nbsp;|&nbsp; PowerShell {4}</div>' -f `
        (ConvertTo-HtmlText ($now.ToString('yyyy-MM-dd HH:mm:ss'))),
        (ConvertTo-HtmlText $meta.OS), (ConvertTo-HtmlText $domainTxt),
        (ConvertTo-HtmlText $meta.RanAs), (ConvertTo-HtmlText $meta.PSVersion))

    if (-not $meta.Elevated) {
        AL '<div class="banner bannerbad"><strong>The collector was not elevated.</strong> vssadmin, winmgmt and parts of the event log were skipped, so the VSS section is incomplete. Nothing below should be read as evidence that VSS is healthy &mdash; re-run elevated.</div>'
    }
    foreach ($n in @($meta.CollectorNotes)) {
        if ($n) { AL ('<div class="banner">{0}</div>' -f (ConvertTo-HtmlText $n)) }
    }

    $navItems = @('overview')
    foreach ($cat in $guestGroupsAll) {
        if (@($findings | Where-Object { $_.Category -eq $cat }).Count -gt 0) { $navItems += $cat.ToLower() }
    }
    AL '<nav>'
    foreach ($n in $navItems) { AL ('<a href="#{0}">{1}</a>' -f $n, $n) }
    AL '</nav>'

    # ---- overview ------------------------------------------------------------
    AL '<div class="card" id="overview">'
    AL '<h2>Overview</h2>'
    AL '<div class="kpis">'
    foreach ($pair in @(
        @('FAIL','blocking'), @('WARN','degraded'), @('UNKNOWN','not checked'),
        @('PASS','healthy'), @('INFO','context')
    )) {
        AL ('<div class="kpi"><div class="v">{0}</div><div class="l">{1}</div></div>' -f `
            $counts[$pair[0]], (ConvertTo-HtmlText $pair[1]))
    }
    AL '</div>'

    # Verdict, stated in words rather than left for the reader to add up.
    if ($counts['FAIL'] -eq 0 -and $counts['WARN'] -eq 0 -and $counts['UNKNOWN'] -eq 0) {
        AL '<p class="ok">No app-aware blockers found on this guest. If the job still fails, the problem is between the backup server and this guest rather than on it &mdash; run the guest processing port reachability check next.</p>'
    } elseif ($counts['FAIL'] -gt 0) {
        AL ('<p class="bad">{0} blocking issue(s). App-aware processing will not complete on this guest until these are resolved.</p>' -f $counts['FAIL'])
    } else {
        AL '<p>No hard blockers, but there are findings worth reading before the next failed run.</p>'
    }

    # Findings by category, FAIL+WARN only - a bar of PASS counts would say
    # nothing except that most checks pass, which they always do.
    $pairs = @()
    foreach ($cat in $guestGroupsAll) {
        $bad = @($findings | Where-Object { $_.Category -eq $cat -and $_.Status -in @('FAIL','WARN','UNKNOWN') }).Count
        if ($bad -gt 0) {
            $hasFail = @($findings | Where-Object { $_.Category -eq $cat -and $_.Status -eq 'FAIL' }).Count -gt 0
            $color = $script:HtmlStatus.Warning
            if ($hasFail) { $color = $script:HtmlStatus.Critical }
            $pairs += @{ Label = $cat; Value = $bad; Color = $color }
        }
    }
    if ($pairs.Count -gt 0) {
        AL (New-BlueprintSvgBar -Title 'Findings needing attention, by category' -Pairs $pairs)
    }

    # ---- fix these first ------------------------------------------------------
    $fails = @()
    foreach ($cat in $guestGroupsAll) {
        $fails += @($findings | Where-Object { $_.Category -eq $cat -and $_.Status -eq 'FAIL' })
    }
    if ($fails.Count -gt 0) {
        AL '<h2>Fix these first</h2>'
        AL '<p class="catnote">In dependency order. A network failure makes every VSS answer below it meaningless, so work top-down rather than by apparent severity.</p>'
        AL '<ul class="fixlist">'
        foreach ($f in $fails) {
            AL ('<li><span class="what">[{0}] {1}</span><br><span class="how">{2}</span>{3}</li>' -f `
                (ConvertTo-HtmlText $f.Category), (ConvertTo-HtmlText $f.Check),
                (ConvertTo-HtmlText $f.Detail),
                $(if ($f.Action) { '<br><span class="how"><strong>Fix:</strong> ' + (ConvertTo-HtmlText $f.Action) + '</span>' } else { '' }))
        }
        AL '</ul>'
    }

    $unknowns = @($findings | Where-Object { $_.Status -eq 'UNKNOWN' })
    if ($unknowns.Count -gt 0) {
        AL ('<p class="muted small">{0} check(s) could not be completed. Those are not passes &mdash; they are gaps in this report.</p>' -f $unknowns.Count)
    }
    AL '</div>'

    # ---- per-category tables ---------------------------------------------------
    $columns = @(
        @{ Head = 'Status';  Get = { $_.Status } }
        @{ Head = 'Check';   Get = { $_.Check } }
        @{ Head = 'Detail';  Get = { $_.Detail } }
        @{ Head = 'Impact';  Get = { $_.Impact } }
        @{ Head = 'Fix';     Get = { $_.Action } }
    )
    $rank = @{ 'FAIL' = 0; 'UNKNOWN' = 1; 'WARN' = 2; 'INFO' = 3; 'PASS' = 4 }

    foreach ($cat in $guestGroupsAll) {
        $rows = @($findings | Where-Object { $_.Category -eq $cat })
        if ($rows.Count -eq 0) { continue }
        $rows = @($rows | Sort-Object @{e={ $rank[[string]$_.Status] }}, Check)

        AL ('<div class="card" id="{0}">' -f $cat.ToLower())
        AL ('<h2>{0}</h2>' -f (ConvertTo-HtmlText $cat))
        if ($script:GuestCategoryNotes.ContainsKey($cat)) {
            AL ('<p class="catnote">{0}</p>' -f (ConvertTo-HtmlText $script:GuestCategoryNotes[$cat]))
        }
        AL (New-BlueprintHtmlTable -Columns $columns -Rows $rows `
                -RowClass { Get-GuestRowClass -Status ([string]$_.Status) } `
                -EmptyText 'nothing checked in this group')
        AL '</div>'
    }

    AL ('<p class="muted small">Generated {0} by portest3.ps1 (GuestHtmlReport.ps1){1}. Error code and remediation annotations come from functions\GuestKnowledge.ps1 &mdash; entries marked there as unverified are field knowledge, not vendor documentation. This check is read-only; nothing on this host was changed.</p>' -f `
        (ConvertTo-HtmlText ($now.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'))),
        $(if ($SourceName) { ' from ' + (ConvertTo-HtmlText $SourceName) } else { '' }))
    AL '</div></body></html>'
    return $h.ToString()
}

function Export-GuestHtml {
    param(
        [Parameter(Mandatory)]$Payload,
        [Parameter(Mandatory)][string]$OutPath
    )
    if (-not $Payload -or -not $Payload.Findings) {
        Write-Host '  Nothing to render - run a guest check first.' -ForegroundColor Red
        return $null
    }
    try {
        $html = ConvertTo-GuestHtml -Payload $Payload
        [IO.File]::WriteAllText($OutPath, $html, (New-Object Text.UTF8Encoding($false)))
        Write-Host ('  HTML report written: {0}' -f $OutPath) -ForegroundColor Green
        return $OutPath
    } catch {
        Write-Host ('  HTML report failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}

# =============================================================================
#  LOG TRIAGE -> HTML
# =============================================================================
function ConvertTo-LogTriageHtml {
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][array]$Hits,
        [string]$SourceName = '',
        [switch]$IncludeInfo
    )

    $now = Get-Date
    $all = @($Hits)
    $shown = $all
    if (-not $IncludeInfo) { $shown = @($all | Where-Object { $_.Severity -ne 'INFO' }) }

    $fails = @($all | Where-Object { $_.Severity -eq 'FAIL' })
    $warns = @($all | Where-Object { $_.Severity -eq 'WARN' })
    $totalHits = 0
    foreach ($x in $all) { $totalHits += [int]$x.Hits }

    $h = New-Object System.Text.StringBuilder
    function AL([string]$s) { [void]$h.AppendLine($s) }

    AL '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
    AL '<meta name="viewport" content="width=device-width, initial-scale=1">'
    AL '<title>Veeam Log Triage</title>'
    AL '<style>'
    AL (Get-VeeamHtmlCss)
    AL $script:VeeamReportExtraCss
    AL '</style></head><body><div class="page">'

    AL '<h1>Veeam Log Triage</h1>'
    AL ('<div class="sub">Parsed {0}{1} &nbsp;|&nbsp; {2} distinct signature(s) across {3} matching line(s)</div>' -f `
        (ConvertTo-HtmlText ($now.ToString('yyyy-MM-dd HH:mm:ss'))),
        $(if ($SourceName) { ' &nbsp;|&nbsp; ' + (ConvertTo-HtmlText $SourceName) } else { '' }),
        $all.Count, $totalHits)

    if ($all.Count -eq 0) {
        AL '<div class="banner">No known failure signatures matched. That is not the same as &quot;no problem&quot; &mdash; it means nothing matched the patterns in functions\GuestKnowledge.ps1. If you have the failing line in front of you and it is not here, add it to $guestLogPatterns.</div>'
        AL '</div></body></html>'
        return $h.ToString()
    }

    AL '<nav>'
    AL '<a href="#overview">overview</a>'
    foreach ($cat in @('Network','Credentials','VSS','Application','Agent')) {
        if (@($shown | Where-Object { $_.Category -eq $cat }).Count -gt 0) {
            AL ('<a href="#log{0}">{1}</a>' -f $cat.ToLower(), $cat.ToLower())
        }
    }
    AL '</nav>'

    # ---- overview -------------------------------------------------------------
    AL '<div class="card" id="overview">'
    AL '<h2>Overview</h2>'
    AL '<div class="kpis">'
    AL ('<div class="kpi"><div class="v">{0}</div><div class="l">blocking</div></div>' -f $fails.Count)
    AL ('<div class="kpi"><div class="v">{0}</div><div class="l">degraded</div></div>' -f $warns.Count)
    AL ('<div class="kpi"><div class="v">{0}</div><div class="l">distinct signatures</div></div>' -f $all.Count)
    AL ('<div class="kpi"><div class="v">{0}</div><div class="l">matching lines</div></div>' -f $totalHits)
    AL '</div>'

    if ($fails.Count -gt 0) {
        $top = @($fails | Sort-Object @{e={ -[int]$_.Hits }} | Select-Object -First 1)[0]
        AL ('<p class="bad">Most frequent blocking signature ({0} occurrences): {1}</p>' -f `
            [int]$top.Hits, (ConvertTo-HtmlText $top.Cause))
        AL ('<p class="how">{0}</p>' -f (ConvertTo-HtmlText $top.Action))
        AL '<p class="catnote">Next step: run the guest check against the affected host &mdash; <code>.\portest3.ps1 -GuestTarget &lt;guest&gt;</code></p>'
    } else {
        AL '<p>No blocking signatures. The findings below degrade the backup rather than stopping it.</p>'
    }

    # Frequency chart. Occurrence counts matter here in a way they do not in the
    # guest check: one signature repeated 400 times across every task log is a
    # systemic fault, the same signature seen twice is one bad night.
    $pairs = @()
    foreach ($x in @($shown | Sort-Object @{e={ -[int]$_.Hits }} | Select-Object -First 10)) {
        $label = [string]$x.Cause
        if ($x.Code) { $label = ('{0}  {1}' -f $x.Code, $label) }
        if ($label.Length -gt 58) { $label = $label.Substring(0, 55) + '...' }
        $color = $script:HtmlStatus.Warning
        if ($x.Severity -eq 'FAIL') { $color = $script:HtmlStatus.Critical }
        $pairs += @{ Label = $label; Value = [int]$x.Hits; Color = $color }
    }
    if ($pairs.Count -gt 0) {
        AL (New-BlueprintSvgBar -Title 'Occurrences by signature (top 10)' -Pairs $pairs)
    }
    AL '</div>'

    # ---- per-category tables ----------------------------------------------------
    $columns = @(
        @{ Head = 'Sev';        Get = { $_.Severity } }
        @{ Head = 'Hits';       Get = { $_.Hits } }
        @{ Head = 'Code';       Get = { if ($_.Code) { if ($_.Verified) { '{0} {1}' -f $_.Code, $_.CodeName } else { '{0} {1} ~' -f $_.Code, $_.CodeName } } else { '' } } }
        @{ Head = 'Means';      Get = { $_.CodeMeaning } }
        @{ Head = 'Cause';      Get = { $_.Cause } }
        @{ Head = 'Fix';        Get = { $_.Action } }
        @{ Head = 'Seen';       Get = { if ($_.FirstSeen) { '{0} .. {1}' -f $_.FirstSeen, $_.LastSeen } else { '' } } }
        @{ Head = 'Files';      Get = { (@($_.Files) -join ', ') } }
    )
    $sevRank = @{ 'FAIL' = 0; 'WARN' = 1; 'INFO' = 2 }

    foreach ($cat in @('Network','Credentials','VSS','Application','Agent')) {
        $rows = @($shown | Where-Object { $_.Category -eq $cat })
        if ($rows.Count -eq 0) { continue }
        $rows = @($rows | Sort-Object @{e={ $sevRank[[string]$_.Severity] }}, @{e={ -[int]$_.Hits }})

        AL ('<div class="card" id="log{0}">' -f $cat.ToLower())
        AL ('<h2>{0}</h2>' -f (ConvertTo-HtmlText $cat))
        if ($script:GuestCategoryNotes.ContainsKey($cat)) {
            AL ('<p class="catnote">{0}</p>' -f (ConvertTo-HtmlText $script:GuestCategoryNotes[$cat]))
        }
        AL (New-BlueprintHtmlTable -Columns $columns -Rows $rows `
                -RowClass { if ([string]$_.Severity -eq 'FAIL') { 'crit' } elseif ([string]$_.Severity -eq 'WARN') { 'warn' } else { '' } } `
                -EmptyText 'no signatures in this group')

        # Sample lines are long and are evidence rather than summary, so they go
        # behind a disclosure rather than stretching every table row.
        AL '<details><summary>Sample log lines</summary>'
        foreach ($r in $rows) {
            AL ('<p class="small"><code>{0}</code></p>' -f (ConvertTo-HtmlText $r.Sample))
        }
        AL '</details>'
        AL '</div>'
    }

    $infoCount = @($all | Where-Object { $_.Severity -eq 'INFO' }).Count
    if (-not $IncludeInfo -and $infoCount -gt 0) {
        AL ('<p class="muted small">{0} informational signature(s) hidden. Re-run with -ShowAllLogHits to include them.</p>' -f $infoCount)
    }
    AL ('<p class="muted small">Generated {0} by portest3.ps1 (GuestHtmlReport.ps1). Signatures and code annotations come from functions\GuestKnowledge.ps1; <code>~</code> marks an error code that is field knowledge rather than vendor documentation. Logs were opened read-only.</p>' -f `
        (ConvertTo-HtmlText ($now.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'))))
    AL '</div></body></html>'
    return $h.ToString()
}

function Export-LogTriageHtml {
    param(
        [Parameter(Mandatory)][string]$OutPath,
        [array]$Hits,
        [string]$SourceName = '',
        [switch]$IncludeInfo
    )
    if (-not $PSBoundParameters.ContainsKey('Hits')) { $Hits = $script:LastLogHits }
    if (-not $Hits -or @($Hits).Count -eq 0) {
        Write-Host '  Nothing to render - run the log triage first.' -ForegroundColor Red
        return $null
    }
    try {
        $html = ConvertTo-LogTriageHtml -Hits @($Hits) -SourceName $SourceName -IncludeInfo:$IncludeInfo
        [IO.File]::WriteAllText($OutPath, $html, (New-Object Text.UTF8Encoding($false)))
        Write-Host ('  HTML report written: {0}' -f $OutPath) -ForegroundColor Green
        return $OutPath
    } catch {
        Write-Host ('  HTML report failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}
