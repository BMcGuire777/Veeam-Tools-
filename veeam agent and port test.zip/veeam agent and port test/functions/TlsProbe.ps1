# =============================================================================
#  TlsProbe.ps1 - TLS handshake probe + local certificate store audit.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
#
#  WHY THIS EXISTS
#  A plain TCP connect test (Reachability.ps1) reports a port OPEN even when
#  the service behind it kills every TLS handshake. That is exactly what a
#  badly installed certificate looks like in the VBR logs:
#
#      Grpc.Core.RpcException: RPC service VeeamRestoreService is unavailable.
#      HttpRequestException: The SSL connection could not be established
#      SocketException (10054): An existing connection was forcibly closed
#
#  TCP is fine, TLS dies. The usual causes for a self-signed cert:
#    1. Imported without its private key (.cer instead of .pfx).
#    2. Imported into CurrentUser\My instead of LocalMachine\My.
#    3. Private key ACL does not grant the Veeam service account read access.
#    4. The thumbprint Veeam has registered no longer matches any cert in
#       the store (cert was replaced or deleted after selection).
#    5. Key generated with an algorithm/KeySpec Schannel cannot use for TLS.
#
#  Test-TlsHandshake sees causes 1-5 from the OUTSIDE (handshake reset).
#  Invoke-LocalCertAudit distinguishes them from the INSIDE (run it ON the
#  backup server, elevated).
# =============================================================================

# =============================================================================
#  TLS PORT TABLE
#  Ports where a Veeam component terminates TLS itself. Same conventions as
#  PortTables.ps1: edit the table, not the logic. Verified = confirmed against
#  v13 docs; ~ rows are best-effort.
#  (Named $tlsPortTable, NOT $tlsPorts - this file is dot-sourced into the main
#  script scope and $TlsPorts is a portest3.ps1 parameter.)
# =============================================================================

$tlsPortTable = @(
    @{Port=443;   Profile='Core'; Verified=$true
      Description='v13 backup server connection / gRPC services (Connect-VBRServer)'}
    @{Port=9419;  Profile='Core'; Verified=$true
      Description='Veeam RESTful API Service (HTTPS)'}
    @{Port=9405;  Profile='Core'; Verified=$true
      Description='Certificate port (EM collecting from v12 backup servers)'}
    @{Port=10443; Profile='Core'; Verified=$true
      Description='Veeam Host Management'}
    @{Port=9443;  Profile='EnterpriseManager'; Verified=$true
      Description='Enterprise Manager web UI (HTTPS, Windows)'}
    @{Port=9398;  Profile='EnterpriseManager'; Verified=$true
      Description='Enterprise Manager RESTful API (HTTPS)'}
)

# =============================================================================
#  HANDSHAKE PROBE
# =============================================================================

# Attempts a real TLS handshake and classifies the outcome:
#   TlsStatus = OK      handshake completed; certificate captured
#               RESET   TCP connected but the peer closed/reset mid-handshake
#                       (10054) - the badly-installed-certificate signature
#               FAILED  handshake failed for another reason (protocol/cipher
#                       mismatch, non-TLS listener answered, timeout)
#               NOTCP   the port did not accept a TCP connection at all
function Test-TlsHandshake($server, $port, $timeoutMs = 5000) {
    $out = [pscustomobject]@{
        Port       = $port
        TlsStatus  = 'NOTCP'
        Protocol   = ''
        Subject    = ''
        Issuer     = ''
        Thumbprint = ''
        NotBefore  = $null
        NotAfter   = $null
        SelfSigned = $false
        SanMatch   = $null      # $true/$false/$null (null = no cert to test)
        San        = ''
        SigAlg     = ''
        Detail     = ''
        Cert       = $null
    }

    $tcp = New-Object System.Net.Sockets.TcpClient
    $tcp.ReceiveTimeout = $timeoutMs
    $tcp.SendTimeout    = $timeoutMs
    $ssl = $null
    try {
        $ar = $tcp.BeginConnect($server, $port, $null, $null)
        if (-not $ar.AsyncWaitHandle.WaitOne($timeoutMs, $false)) {
            $out.Detail = 'TCP connect timed out.'
            return $out
        }
        try { $tcp.EndConnect($ar) } catch {
            $out.Detail = $_.Exception.Message
            return $out
        }

        # Accept every certificate - the point is to CAPTURE it, not trust it.
        # The callback runs synchronously on this thread, so a hashtable in
        # this scope is a reliable capture channel under both 5.1 and 7.
        $capture = @{ Cert = $null }
        $cb = {
            param($s, $cert, $chain, $errors)
            if ($cert) {
                $capture.Cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 $cert
            }
            return $true
        }
        $ssl = New-Object System.Net.Security.SslStream($tcp.GetStream(), $false, $cb)
        try {
            # No SslProtocols argument = OS/framework defaults, same as the
            # Veeam components themselves.
            $ssl.AuthenticateAsClient($server)
            $out.TlsStatus = 'OK'
            $out.Protocol  = $ssl.SslProtocol.ToString()
        } catch {
            $inner = $_.Exception
            while ($inner.InnerException) { $inner = $inner.InnerException }
            if ($inner -is [System.Net.Sockets.SocketException] -and $inner.ErrorCode -eq 10054) {
                $out.TlsStatus = 'RESET'
                $out.Detail    = 'Connection forcibly closed DURING the TLS handshake (10054).'
            } else {
                $out.TlsStatus = 'FAILED'
                $out.Detail    = $inner.Message
            }
        }

        if ($capture.Cert) {
            $capturedCert   = $capture.Cert
            $out.Cert       = $capturedCert
            $out.Subject    = $capturedCert.Subject
            $out.Issuer     = $capturedCert.Issuer
            $out.Thumbprint = $capturedCert.Thumbprint
            $out.NotBefore  = $capturedCert.NotBefore
            $out.NotAfter   = $capturedCert.NotAfter
            $out.SelfSigned = ($capturedCert.Subject -eq $capturedCert.Issuer)
            $out.SigAlg     = $capturedCert.SignatureAlgorithm.FriendlyName
            $san = $capturedCert.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.17' }
            if ($san) {
                $out.San = ($san.Format($false) -replace '\s+', ' ').Trim()
                # crude but 5.1-safe: does the SAN text mention the name we dialled?
                $out.SanMatch = ($out.San -match [regex]::Escape($server))
            }
        }
        return $out
    } catch {
        $out.Detail = $_.Exception.Message
        return $out
    } finally {
        if ($ssl) { try { $ssl.Dispose() } catch { } }
        try { $tcp.Close() } catch { }
    }
}

function Invoke-TlsScan($testTarget, [switch]$IncludeEM, [int[]]$ExtraPorts,
                        [switch]$CheckCrl, [string[]]$CrlExtraUrls) {
    Write-Host ''
    Write-Rule 'TLS Handshake Probe'
    Write-Host '  A port can pass a TCP test and still kill every TLS handshake - the' -ForegroundColor DarkCyan
    Write-Host '  signature of a badly installed certificate. This negotiates for real.' -ForegroundColor DarkCyan
    Write-Host ''

    $rows = @($tlsPortTable | Where-Object { $_.Profile -eq 'Core' -or ($IncludeEM -and $_.Profile -eq 'EnterpriseManager') })
    foreach ($p in @($ExtraPorts)) {
        if ($p -and -not ($rows | Where-Object { $_.Port -eq $p })) {
            $rows += @{Port=$p; Profile='Custom'; Verified=$false; Description='custom port'}
        }
    }

    $results = @()
    $resets  = @()
    foreach ($e in ($rows | Sort-Object { $_.Port })) {
        $r = Test-TlsHandshake $testTarget $e.Port
        $results += $r
        $flag = if (-not $e.Verified) { '~' } else { ' ' }
        switch ($r.TlsStatus) {
            'OK' {
                $days = [int]($r.NotAfter - (Get-Date)).TotalDays
                $expiry = if ($days -lt 0) { 'EXPIRED' } elseif ($days -lt 30) { "expires in $days d" } else { '' }
                $tag  = @()
                if ($r.SelfSigned)          { $tag += 'self-signed' }
                if ($expiry)                { $tag += $expiry }
                if ($r.SanMatch -eq $false) { $tag += 'SAN mismatch' }
                $tagText = if ($tag.Count -gt 0) { ' [' + ($tag -join ', ') + ']' } else { '' }
                $color = if ($expiry -eq 'EXPIRED') { 'Red' } elseif ($tag.Count -gt 0) { 'Yellow' } else { 'Green' }
                Write-Host ('[ TLS OK ] {0,-6}{1}{2} {3}{4}' -f $e.Port, $flag, $r.Protocol, $e.Description, $tagText) -ForegroundColor $color
            }
            'RESET' {
                Write-Host ('[ RESET  ] {0,-6}{1}TCP ok, TLS handshake killed - {2}' -f $e.Port, $flag, $e.Description) -ForegroundColor Red
                $resets += $r
            }
            'FAILED' {
                Write-Host ('[ TLSFAIL] {0,-6}{1}{2}' -f $e.Port, $flag, $e.Description) -ForegroundColor Yellow
                Write-Host ('           -> {0}' -f $r.Detail) -ForegroundColor DarkGray
            }
            default {
                Write-Host ('[ NO TCP ] {0,-6}{1}{2}' -f $e.Port, $flag, $e.Description) -ForegroundColor DarkGray
            }
        }
    }

    # -- certificate detail: show each DISTINCT cert once -----------------------
    $seen = @{}
    foreach ($r in ($results | Where-Object { $_.Cert })) {
        if ($seen.ContainsKey($r.Thumbprint)) { continue }
        $seen[$r.Thumbprint] = $true
        Write-Host ''
        Write-Rule ('Certificate presented on port {0}' -f $r.Port) 'DarkCyan'
        Write-Host ('  Subject     : {0}' -f $r.Subject)
        Write-Host ('  Issuer      : {0}' -f $r.Issuer)
        Write-Host ('  Thumbprint  : {0}' -f $r.Thumbprint)
        Write-Host ('  Valid       : {0:yyyy-MM-dd} -> {1:yyyy-MM-dd}' -f $r.NotBefore, $r.NotAfter)
        Write-Host ('  Signature   : {0}' -f $r.SigAlg)
        Write-Host ('  Self-signed : {0}' -f $r.SelfSigned)
        if ($r.San) { Write-Host ('  SAN         : {0}' -f $r.San) }
        if ($r.SanMatch -eq $false) {
            Write-Host ('  ! SAN does not contain "{0}" - clients validating the name will fail.' -f $testTarget) -ForegroundColor Yellow
        }
    }

    # -- verdict -----------------------------------------------------------------
    Write-Host ''
    if ($resets.Count -gt 0) {
        Write-Host ('  {0} port(s) RESET the TLS handshake while accepting TCP. That is the' -f $resets.Count) -ForegroundColor Red
        Write-Host '  classic broken-certificate signature. On the backup server, run:' -ForegroundColor Red
        Write-Host ''
        Write-Host '      .\portest3.ps1 -CertAudit          (elevated)' -ForegroundColor White
        Write-Host ''
        Write-Host '  to check the store the cert is in, its private key, and the key ACL.' -ForegroundColor Red
    } elseif (($results | Where-Object { $_.TlsStatus -eq 'OK' }).Count -gt 0) {
        Write-Host '  TLS negotiated on every port that answered.' -ForegroundColor Green
    } else {
        Write-Host '  No port completed a TLS handshake - check reachability first (option 10).' -ForegroundColor Yellow
    }

    # -- optional: probe the revocation URLs carried by the wire certs -----------
    if ($CheckCrl) {
        $wireCerts = @($results | Where-Object { $_.Cert } | ForEach-Object { $_.Cert })
        Invoke-CrlCheck -Certs $wireCerts -ExtraUrls $CrlExtraUrls
    }
}

# =============================================================================
#  LOCAL CERTIFICATE STORE AUDIT (run ON the backup server, elevated)
# =============================================================================

# Locates the private key file behind a cert so its ACL can be inspected.
# Tries CNG first (Crypto\Keys), then legacy CSP (Crypto\RSA\MachineKeys).
function Get-PrivateKeyFilePath($cert) {
    try {
        $rsa = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert)
        if ($rsa -and $rsa.Key -and $rsa.Key.UniqueName) {
            foreach ($base in @(
                (Join-Path $env:ProgramData 'Microsoft\Crypto\Keys'),
                (Join-Path $env:ProgramData 'Microsoft\Crypto\RSA\MachineKeys'))) {
                $p = Join-Path $base $rsa.Key.UniqueName
                if (Test-Path $p) { return $p }
            }
        }
    } catch { }
    try {
        $name = $cert.PrivateKey.CspKeyContainerInfo.UniqueKeyContainerName
        if ($name) {
            $p = Join-Path $env:ProgramData ('Microsoft\Crypto\RSA\MachineKeys\' + $name)
            if (Test-Path $p) { return $p }
        }
    } catch { }
    return $null
}

function Invoke-LocalCertAudit([string]$Thumbprint) {
    if ($env:OS -ne 'Windows_NT') {
        Write-Host ''
        Write-Host '  -CertAudit inspects the Windows certificate store - run it ON the' -ForegroundColor Red
        Write-Host '  Windows backup server, not from this machine.' -ForegroundColor Red
        return
    }

    Write-Banner 'Veeam Certificate Audit' $env:COMPUTERNAME

    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
               ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) {
        Write-Host ''
        Write-Host '  ! Not elevated - private key files and ACLs will not be readable.' -ForegroundColor Yellow
    }

    # -- which account do the Veeam services run as? ---------------------------
    $svcAccounts = @('NT AUTHORITY\SYSTEM')
    try {
        $veeamSvcs = @(Get-CimInstance Win32_Service -ErrorAction Stop |
                       Where-Object { $_.Name -like 'Veeam*' })
        $svcAccounts = @($veeamSvcs | ForEach-Object { $_.StartName } |
                         Where-Object { $_ } | Sort-Object -Unique)
        if ($svcAccounts.Count -eq 0) { $svcAccounts = @('NT AUTHORITY\SYSTEM') }
        Write-Host ''
        Write-Host ('  Veeam services found : {0}' -f $veeamSvcs.Count) -ForegroundColor DarkCyan
        Write-Host ('  Service account(s)   : {0}' -f ($svcAccounts -join ', ')) -ForegroundColor DarkCyan
    } catch {
        Write-Host ''
        Write-Host '  Could not enumerate services - assuming LocalSystem.' -ForegroundColor DarkGray
    }

    # -- candidate certificates -------------------------------------------------
    $machineCerts = @(Get-ChildItem Cert:\LocalMachine\My -ErrorAction SilentlyContinue)
    $candidates = if ($Thumbprint) {
        $t = ($Thumbprint -replace '\s', '').ToUpper()
        @($machineCerts | Where-Object { $_.Thumbprint -eq $t })
    } else {
        @($machineCerts | Where-Object {
            $_.FriendlyName -like '*Veeam*' -or $_.Subject -like '*Veeam*' -or
            $_.Subject -like ('*' + $env:COMPUTERNAME + '*')
        })
    }

    if ($Thumbprint -and $candidates.Count -eq 0) {
        Write-Host ''
        Write-Host ('  ** Thumbprint {0} is NOT in LocalMachine\My. **' -f $Thumbprint) -ForegroundColor Red
        Write-Host '  If Veeam still has this thumbprint registered, every TLS handshake' -ForegroundColor Red
        Write-Host '  will be reset. Re-select the certificate in the VBR console' -ForegroundColor Red
        Write-Host '  (Menu > General Options > Security) or re-import the .pfx.' -ForegroundColor Red
        # fall through - still list what IS in the store below
    }

    Write-Host ''
    Write-Rule ('LocalMachine\My - {0} candidate cert(s)' -f $candidates.Count)
    if ($candidates.Count -eq 0) {
        Write-Host '  No Veeam-looking certificate found in LocalMachine\My.' -ForegroundColor Yellow
        Write-Host '  (Matched on FriendlyName/Subject containing "Veeam" or the hostname.' -ForegroundColor DarkGray
        Write-Host '   Use -Thumbprint XX.. to audit a specific certificate instead.)' -ForegroundColor DarkGray
    }

    $problems = 0
    foreach ($cert in $candidates) {
        Write-Host ''
        Write-Host ('  Subject     : {0}' -f $cert.Subject) -ForegroundColor White
        if ($cert.FriendlyName) { Write-Host ('  Friendly    : {0}' -f $cert.FriendlyName) }
        Write-Host ('  Thumbprint  : {0}' -f $cert.Thumbprint)
        Write-Host ('  Valid       : {0:yyyy-MM-dd} -> {1:yyyy-MM-dd}' -f $cert.NotBefore, $cert.NotAfter)
        Write-Host ('  Self-signed : {0}' -f ($cert.Subject -eq $cert.Issuer))

        # 1. expiry
        if ($cert.NotAfter -lt (Get-Date)) {
            Write-Host '  [FAIL] Certificate is EXPIRED.' -ForegroundColor Red; $problems++
        } elseif ($cert.NotBefore -gt (Get-Date)) {
            Write-Host '  [FAIL] Certificate is not valid YET (NotBefore in the future - clock skew?).' -ForegroundColor Red; $problems++
        }

        # 2. private key present
        if (-not $cert.HasPrivateKey) {
            Write-Host '  [FAIL] NO PRIVATE KEY. The cert was imported from a .cer/.crt (public' -ForegroundColor Red
            Write-Host '         part only). TLS cannot work - Schannel resets the handshake,' -ForegroundColor Red
            Write-Host '         which surfaces as SocketException 10054 on clients.' -ForegroundColor Red
            Write-Host '         Fix: re-import the .pfx (with the key) into LocalMachine\My,' -ForegroundColor Red
            Write-Host '         then re-select it in the VBR console.' -ForegroundColor Red
            $problems++
        } else {
            # 3. private key ACL
            $keyPath = Get-PrivateKeyFilePath $cert
            if (-not $keyPath) {
                Write-Host '  [WARN] HasPrivateKey is true but the key FILE could not be located' -ForegroundColor Yellow
                Write-Host '         (or read - run elevated). A dangling key reference behaves' -ForegroundColor Yellow
                Write-Host '         exactly like a missing key: handshake resets.' -ForegroundColor Yellow
                $problems++
            } else {
                Write-Host ('  Key file    : {0}' -f $keyPath) -ForegroundColor DarkGray
                try {
                    $acl = Get-Acl $keyPath -ErrorAction Stop
                    $grants = @($acl.Access | ForEach-Object { $_.IdentityReference.Value })
                    foreach ($account in $svcAccounts) {
                        # match "DOMAIN\name", bare "name", and localised
                        # SYSTEM ("NT AUTHORITY\SYSTEM" vs "LocalSystem")
                        $short = ($account -split '\\')[-1]
                        if ($short -eq 'LocalSystem') { $short = 'SYSTEM' }
                        $ok = $grants | Where-Object {
                            $_ -eq $account -or $_ -like ('*\' + $short) -or $_ -eq $short
                        }
                        if ($ok) {
                            Write-Host ('  [ OK ] Private key ACL grants access to {0}.' -f $account) -ForegroundColor Green
                        } else {
                            Write-Host ('  [FAIL] Private key ACL has NO entry for {0}.' -f $account) -ForegroundColor Red
                            Write-Host '         The service cannot use the key -> handshake resets (10054).' -ForegroundColor Red
                            Write-Host '         Fix: certlm.msc > cert > All Tasks > Manage Private Keys >' -ForegroundColor Red
                            Write-Host ('         grant Read to {0}, then restart the Veeam services.' -f $account) -ForegroundColor Red
                            $problems++
                        }
                    }
                } catch {
                    Write-Host ('  [WARN] Could not read the key file ACL: {0}' -f $_.Exception.Message) -ForegroundColor Yellow
                }
            }

            # 4. signature algorithm sanity
            if ($cert.SignatureAlgorithm.FriendlyName -match 'sha1|md5') {
                Write-Host ('  [WARN] Weak signature algorithm ({0}) - modern TLS stacks may refuse it.' -f
                    $cert.SignatureAlgorithm.FriendlyName) -ForegroundColor Yellow
            }
        }
    }

    # 5. the wrong-store classic: same-looking cert sitting in CurrentUser\My
    $userCerts = @(Get-ChildItem Cert:\CurrentUser\My -ErrorAction SilentlyContinue |
                   Where-Object { $_.FriendlyName -like '*Veeam*' -or $_.Subject -like '*Veeam*' })
    if ($userCerts.Count -gt 0) {
        Write-Host ''
        Write-Rule 'CurrentUser\My' 'Red'
        foreach ($c in $userCerts) {
            $also = $machineCerts | Where-Object { $_.Thumbprint -eq $c.Thumbprint }
            if (-not $also) {
                Write-Host ('  [FAIL] {0} ({1}) exists ONLY in CurrentUser\My.' -f $c.Subject, $c.Thumbprint) -ForegroundColor Red
                Write-Host '         Services run as SYSTEM/service accounts and cannot see the' -ForegroundColor Red
                Write-Host '         current user store. Re-import the .pfx into LocalMachine\My' -ForegroundColor Red
                Write-Host '         ("Local Computer" in the import wizard / certlm.msc).' -ForegroundColor Red
                $problems++
            }
        }
    }

    # -- verdict -----------------------------------------------------------------
    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    if ($candidates.Count -eq 0 -and $userCerts.Count -eq 0) {
        Write-Host '  RESULT: INCONCLUSIVE - no candidate certificate found to audit.' -ForegroundColor Yellow
    } elseif ($problems -eq 0) {
        Write-Host '  RESULT: No certificate installation problems detected.' -ForegroundColor Green
        Write-Host '  If handshakes still reset, confirm the thumbprint REGISTERED in the' -ForegroundColor DarkCyan
        Write-Host '  VBR console (General Options > Security) matches a cert shown above,' -ForegroundColor DarkCyan
        Write-Host '  and restart the Veeam services after any change.' -ForegroundColor DarkCyan
    } else {
        Write-Host ('  RESULT: {0} PROBLEM(S) FOUND - fix and restart the Veeam services.' -f $problems) -ForegroundColor Red
    }
    Write-Host '=======================================================' -ForegroundColor Cyan
}
