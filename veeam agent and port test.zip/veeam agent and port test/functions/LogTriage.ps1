# =============================================================================
#  LogTriage.ps1 - parse Veeam job / agent / guest helper logs and map what
#  they say onto the knowledge base in GuestKnowledge.ps1.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables, the guest knowledge base and all
#  $script: state directly.
#
#  WHY THIS EXISTS: the error a job surfaces in the console ("guest processing
#  skipped") is the symptom. The cause is several hundred lines further up, in
#  a per-task log nobody reads. This finds the signature lines, resolves the
#  numeric codes, counts the repeats, and orders them by what actually blocks
#  the job.
#
#  READ-ONLY. It opens files for reading and nothing else.
# =============================================================================

# Default search roots, in the order they are worth reading. Anything missing
# is skipped silently - a backup server has the first, a protected guest has
# the last two, and nothing has all of them.
$guestLogRoots = @(
    @{ Path = 'C:\ProgramData\Veeam\Backup'
       What = 'VBR job and task logs (one folder per job)' }
    @{ Path = 'C:\ProgramData\Veeam\Endpoint'
       What = 'Veeam Agent for Microsoft Windows' }
    @{ Path = 'C:\Windows\VeeamVssSupport'
       What = 'Guest helper / VSS support runtime, written inside the guest' }
    @{ Path = 'C:\ProgramData\Veeam\Setup\Temp'
       What = 'Component deployment and upgrade logs' }
)

# A leading bracketed timestamp, whatever the locale wrote into it. Kept as
# text on purpose: Veeam writes dd.MM.yyyy on some builds and yyyy-MM-dd on
# others, and guessing wrong is worse than showing the raw string.
$guestLogStampPattern = '^\s*\[(?<stamp>[^\]]{8,40})\]'

function Get-GuestLogFiles {
    param(
        [string]$Path,
        [int]$SinceDays = 14,
        [int]$MaxFiles  = 400
    )

    $cutoff = (Get-Date).AddDays(-$SinceDays)
    $files  = @()

    if ($Path) {
        if (-not (Test-Path $Path)) {
            Write-Host ('  Path not found: {0}' -f $Path) -ForegroundColor Red
            return @()
        }
        if (Test-Path $Path -PathType Leaf) { return @(Get-Item $Path) }
        $files = @(Get-ChildItem -Path $Path -Filter '*.log' -File -Recurse -ErrorAction SilentlyContinue)
    } else {
        foreach ($root in $guestLogRoots) {
            if (Test-Path $root.Path) {
                Write-Host ('  Searching {0}' -f $root.Path) -ForegroundColor DarkCyan
                Write-Host ('            {0}' -f $root.What) -ForegroundColor DarkGray
                $files += @(Get-ChildItem -Path $root.Path -Filter '*.log' -File -Recurse -ErrorAction SilentlyContinue)
            }
        }
        if ($files.Count -eq 0) {
            Write-Host ''
            Write-Host '  No Veeam log folders found in the default locations.' -ForegroundColor Yellow
            Write-Host '  Point -LogPath at the logs instead. On the backup server they are' -ForegroundColor DarkCyan
            Write-Host '  under C:\ProgramData\Veeam\Backup\<job name>\; inside a guest they' -ForegroundColor DarkCyan
            Write-Host '  are under C:\Windows\VeeamVssSupport\.' -ForegroundColor DarkCyan
            return @()
        }
    }

    $recent = @($files | Where-Object { $_.LastWriteTime -ge $cutoff } | Sort-Object LastWriteTime -Descending)
    if ($recent.Count -eq 0 -and $files.Count -gt 0) {
        Write-Host ('  {0} log file(s) found but none modified in the last {1} days.' -f $files.Count, $SinceDays) -ForegroundColor Yellow
        Write-Host '  Widen the window with -SinceDays if the failure is older than that.' -ForegroundColor DarkCyan
        return @()
    }
    if ($recent.Count -gt $MaxFiles) {
        Write-Host ('  {0} log files in window; reading the {1} most recent.' -f $recent.Count, $MaxFiles) -ForegroundColor DarkYellow
        $recent = @($recent | Select-Object -First $MaxFiles)
    }
    return $recent
}

function Invoke-VeeamLogTriage {
    param(
        [string]$Path,
        [int]$SinceDays = 14,
        [int]$MaxFiles  = 400,
        [switch]$ShowAll          # include INFO-severity signatures
    )

    Write-Host ''
    $files = Get-GuestLogFiles -Path $Path -SinceDays $SinceDays -MaxFiles $MaxFiles
    if ($files.Count -eq 0) { $script:LastLogHits = @(); return @() }

    Write-Host ''
    Write-Host ('  Reading {0} log file(s)...' -f $files.Count) -ForegroundColor DarkCyan

    # Key -> aggregate. One row per distinct signature+code, not per line:
    # a failing job writes the same error on every retry and a per-line list
    # would bury the two signatures that matter under four hundred repeats.
    $hits = @{}
    $i = 0

    foreach ($file in $files) {
        $i++
        if ($files.Count -gt 20) {
            Write-Progress -Id 2 -Activity 'Scanning Veeam logs' `
                -Status ("{0} ({1} of {2})" -f $file.Name, $i, $files.Count) `
                -PercentComplete (($i / $files.Count) * 100)
        }

        $lines = @()
        try { $lines = Get-Content -Path $file.FullName -ErrorAction Stop } catch { continue }

        foreach ($line in $lines) {
            if ([string]::IsNullOrWhiteSpace($line)) { continue }

            foreach ($pat in $guestLogPatterns) {
                $m = [regex]::Match($line, $pat.Pattern)
                if (-not $m.Success) { continue }

                # Pull a code out of this line if there is one, so the hit can
                # carry the resolved meaning rather than just the raw text.
                $code = ''
                foreach ($g in @('code','vss')) {
                    if ($m.Groups[$g].Success) { $code = $m.Groups[$g].Value; break }
                }
                if (-not $code -and $line -match '(?i)\bcode:\s*(?<c>0x[0-9a-f]+|\d+)') { $code = $Matches['c'] }

                $resolved = $null
                if ($code) { $resolved = Resolve-GuestErrorCode -Code $code }

                $stamp = ''
                if ($line -match $guestLogStampPattern) { $stamp = $Matches['stamp'].Trim() }

                $key = '{0}|{1}' -f $pat.Pattern, $code
                if (-not $hits.ContainsKey($key)) {
                    $hits[$key] = [pscustomobject]@{
                        Category   = $pat.Category
                        Severity   = $pat.Severity
                        Code       = $code
                        CodeName   = $(if ($resolved) { $resolved.Name }     else { '' })
                        CodeMeaning= $(if ($resolved) { $resolved.Meaning }  else { '' })
                        CodeCauses = @(if ($resolved) { $resolved.Causes }   else { @() })
                        Verified   = $(if ($resolved) { $resolved.Verified } else { $true })
                        Cause      = $pat.Cause
                        Action     = $pat.Action
                        Hits       = 0
                        FirstSeen  = $stamp
                        LastSeen   = $stamp
                        Sample     = $line.Trim()
                        Files      = @()
                    }
                }
                $h = $hits[$key]
                $h.Hits++
                if ($stamp) { $h.LastSeen = $stamp; if (-not $h.FirstSeen) { $h.FirstSeen = $stamp } }
                if ($h.Files -notcontains $file.Name) {
                    # Cap the file list - a signature present in 300 task logs
                    # tells you it is systemic, and the names stop adding value
                    # after the first handful.
                    if ($h.Files.Count -lt 5) { $h.Files += $file.Name }
                }

                break   # first matching pattern wins; they are ordered specific-first
            }
        }
    }
    if ($files.Count -gt 20) { Write-Progress -Id 2 -Activity 'Scanning Veeam logs' -Completed }

    $all = @($hits.Values)
    $script:LastLogHits = $all

    $sevRank = @{ 'FAIL' = 0; 'WARN' = 1; 'INFO' = 2 }
    $shown = if ($ShowAll) { $all } else { @($all | Where-Object { $_.Severity -ne 'INFO' }) }
    $shown = @($shown | Sort-Object @{e={ $sevRank[$_.Severity] }}, @{e={ -$_.Hits }})

    if ($all.Count -eq 0) {
        Write-Host ''
        Write-Host '  No known failure signatures found in those logs.' -ForegroundColor Green
        Write-Host '  That is not the same as "no problem" - it means nothing matched the' -ForegroundColor DarkCyan
        Write-Host '  patterns in functions\GuestKnowledge.ps1. If you have the failing' -ForegroundColor DarkCyan
        Write-Host '  line in front of you and it is not here, add it to $guestLogPatterns.' -ForegroundColor DarkCyan
        return $all
    }

    foreach ($cat in @('Network','Credentials','VSS','Application','Agent')) {
        $rows = @($shown | Where-Object { $_.Category -eq $cat })
        if ($rows.Count -eq 0) { continue }

        Write-Host ''
        Write-Rule $cat
        foreach ($h in $rows) {
            $color = switch ($h.Severity) { 'FAIL' { 'Red' } 'WARN' { 'Yellow' } default { 'DarkGray' } }
            $codeLabel = ''
            if ($h.Code) {
                $codeLabel = '  ' + $h.Code
                if ($h.CodeName) { $codeLabel += ' ' + $h.CodeName }
                if (-not $h.Verified) { $codeLabel += ' ~' }
            }

            Write-Host ''
            Write-Host ('  [{0}] x{1}{2}' -f $h.Severity, $h.Hits, $codeLabel) -ForegroundColor $color
            if ($h.FirstSeen) {
                Write-Host ('        seen: {0}  ..  {1}' -f $h.FirstSeen, $h.LastSeen) -ForegroundColor DarkGray
            }
            Write-Host ('        in  : {0}' -f (($h.Files -join ', '))) -ForegroundColor DarkGray

            $sample = $h.Sample
            if ($sample.Length -gt 150) { $sample = $sample.Substring(0, 150) + '...' }
            Write-Host ('        log : {0}' -f $sample) -ForegroundColor Gray

            if ($h.CodeMeaning) {
                Write-Host ('        means: {0}' -f $h.CodeMeaning) -ForegroundColor White
            }
            Write-Host ('        cause: {0}' -f $h.Cause) -ForegroundColor DarkCyan
            foreach ($c in @($h.CodeCauses)) {
                Write-Host ('               - {0}' -f $c) -ForegroundColor DarkCyan
            }
            Write-Host ('        FIX  : {0}' -f $h.Action) -ForegroundColor DarkYellow
        }
    }

    $fails = @($all | Where-Object { $_.Severity -eq 'FAIL' })
    $warns = @($all | Where-Object { $_.Severity -eq 'WARN' })

    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host ('  {0} distinct signature(s): {1} blocking, {2} degraded.' -f $all.Count, $fails.Count, $warns.Count) `
        -ForegroundColor $(if ($fails.Count -gt 0) { 'Red' } else { 'Yellow' })
    if ($fails.Count -gt 0) {
        $top = @($fails | Sort-Object @{e={ -$_.Hits }} | Select-Object -First 1)[0]
        Write-Host ''
        Write-Host '  Most frequent blocking signature:' -ForegroundColor Red
        Write-Host ('   {0}  ({1} occurrences)' -f $top.Cause, $top.Hits) -ForegroundColor Red
        Write-Host ('   {0}' -f $top.Action) -ForegroundColor DarkGray
        Write-Host ''
        Write-Host '  Next step: run the guest check against the affected host.' -ForegroundColor DarkCyan
        Write-Host '    .\portest3.ps1 -GuestTarget <guest>' -ForegroundColor DarkCyan
    }
    if (-not $ShowAll -and @($all | Where-Object { $_.Severity -eq 'INFO' }).Count -gt 0) {
        Write-Host ''
        Write-Host ('  {0} informational signature(s) hidden - add -ShowAllLogHits to see them.' -f
            @($all | Where-Object { $_.Severity -eq 'INFO' }).Count) -ForegroundColor DarkGray
    }
    Write-Host '  ~ = error code not confirmed against vendor documentation' -ForegroundColor DarkGray
    Write-Host '=======================================================' -ForegroundColor Cyan

    return $all
}

function Export-LogTriage($path) {
    if (-not $script:LastLogHits -or $script:LastLogHits.Count -eq 0) {
        Write-Host '  Nothing to export - run the log triage first.' -ForegroundColor Red
        return
    }
    try {
        $script:LastLogHits |
            Select-Object Category, Severity, Hits, Code, CodeName, CodeMeaning, Cause, Action,
                          FirstSeen, LastSeen, Sample, @{n='Files';e={ ($_.Files -join '; ') }} |
            Sort-Object Severity, @{e={ -$_.Hits }} |
            Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
        Write-Host ('  Exported {0} signature(s) to {1}' -f $script:LastLogHits.Count, $path) -ForegroundColor Green
    } catch {
        Write-Host ('  Export failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
    }
}
