# =============================================================================
#  OwnerType vocabulary
#
#  The Windows collector emitted  Veeam | Windows | Database | ThirdParty | Unknown
#  the Linux collector emitted    veeam | os      | db       | thirdparty | unknown
#
#  Export-AllResults merges both into one mixed-estate CSV - the very thing the
#  SSH transport exists for - so the key column arrived in two incompatible
#  vocabularies. Filtering OwnerType -eq 'Database' silently missed every Linux
#  PostgreSQL row.
#
#  Both sides now normalise through here. 'Windows' becomes the platform-neutral
#  'OS' so the same filter works across a mixed estate; the Platform column
#  already records which OS a row came from.
# =============================================================================
function ConvertTo-CanonicalOwnerType {
    param([string]$Raw)
    if ([string]::IsNullOrWhiteSpace($Raw)) { return '' }
    switch -Regex ($Raw.Trim()) {
        '^(?i)veeam$'                  { return 'Veeam' }
        '^(?i)(db|database)$'          { return 'Database' }
        '^(?i)(os|windows|linux)$'     { return 'OS' }
        '^(?i)thirdparty$'             { return 'ThirdParty' }
        '^(?i)unknown$'                { return 'Unknown' }
        default                        { return $Raw }
    }
}

# =============================================================================
#  Results.ps1 - session result state and CSV export.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
# =============================================================================

function Export-Results($path) {
    if (-not $script:LastResults -or $script:LastResults.Count -eq 0) {
        Write-Host '  Nothing to export - run a conflict check first.' -ForegroundColor Red
        return
    }
    try {
        $script:LastResults |
            Select-Object @{n='Host';e={$script:LastResultHost}}, Port, Protocol, Status,
                          OwnerType, Owner, Component, Verified, Notes |
            Sort-Object Status, Port |
            Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
        Write-Host ('  Exported {0} rows to {1}' -f $script:LastResults.Count, $path) -ForegroundColor Green
    } catch {
        Write-Host ('  Export failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
    }
}

function Save-Results($payload) {
    # Always overwrite, so a failed run cannot leave a previous host's rows
    # sitting there waiting to be exported as if they were current.
    #
    # Every mode - local, remote, VBR-connected and Linux over SSH - funnels
    # through here, so this is also where the HTML renderer picks the payload
    # up. It is kept even for a FAILED collection, unlike $script:LastResults:
    # the HTML report needs Meta.CollectError to render the "this is not a
    # result" page, and withholding the rows is its job, not this function's.
    $script:LastPortPayload = $payload
    if ($payload) {
        # The invalid-run guard comes FIRST. It used to sit below these two
        # assignments, so a failed collection still populated $script:LastResults
        # - and Export-Results reads that variable. The effect was that
        # `-SshServer x -OutFile y.csv` wrote a CSV full of known-bad rows (every
        # port reported FREE) while the console said "RESULTS BELOW ARE NOT VALID".
        # A pipeline reading the CSV saw an all-clear.
        if ($payload.Meta.CollectError) {
            $script:LastResults    = @()
            $script:LastResultHost = [string]$payload.Meta.Host
            Write-Host '  (Not adding this run to the session CSV - the collection failed.)' -ForegroundColor DarkYellow
            Write-Host '  (Nothing will be exported either - these rows are not valid.)'     -ForegroundColor DarkYellow
            return
        }

        $script:LastResults    = @($payload.Results)
        $script:LastResultHost = [string]$payload.Meta.Host

        $hostName = [string]$payload.Meta.Host
        $platform = if ($payload.Meta.Platform) { [string]$payload.Meta.Platform } else { 'Windows' }
        $stamp    = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        foreach ($r in @($payload.Results)) {
            $script:AllResults += [pscustomobject]@{
                Host=$hostName; Platform=$platform; Checked=$stamp
                Port=$r.Port; Protocol=$r.Protocol; Status=$r.Status
                OwnerType=(ConvertTo-CanonicalOwnerType $r.OwnerType); Owner=$r.Owner; Component=$r.Component
                Verified=$r.Verified; Notes=$r.Notes
            }
        }
    } else {
        $script:LastResults    = @()
        $script:LastResultHost = ''
    }
}

function Export-AllResults($path) {
    if (-not $script:AllResults -or $script:AllResults.Count -eq 0) {
        Write-Host '  Nothing accumulated yet - run at least one conflict check.' -ForegroundColor Red
        return
    }
    try {
        $script:AllResults |
            Sort-Object Host, Status, Port |
            Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
        $hosts = @($script:AllResults | Select-Object -ExpandProperty Host -Unique).Count
        Write-Host ('  Exported {0} rows across {1} host(s) to {2}' -f
            $script:AllResults.Count, $hosts, $path) -ForegroundColor Green
    } catch {
        Write-Host ('  Export failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
    }
}
