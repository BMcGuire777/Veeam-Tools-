# =============================================================================
#  PortHtmlReport.ps1 - HTML output for the port conflict check.
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
#
#  Reuses the engine in HtmlReport.ps1 - ConvertTo-HtmlText,
#  New-BlueprintHtmlTable, New-BlueprintSvgBar, the palette and
#  Get-VeeamHtmlCss - so the port report, the guest report and the blueprint
#  all render in the same visual language. One self-contained .html, inline
#  SVG, inline CSS, zero JavaScript.
#
#  Export-PortCheckHtml   : the last single-host conflict check -> .html
#  Export-PortEstateHtml  : every check this session, mixed Windows + Linux
# =============================================================================

# Report rules live in HtmlReport.ps1 ($script:VeeamReportExtraCss) so the
# port, guest and blueprint reports cannot drift apart.

function Get-PortRowClass {
    param([string]$Status)
    switch ($Status) {
        'CONFLICT' { return 'crit' }
        'UNKNOWN'  { return 'sevUnknown' }
        default    { return '' }
    }
}

# The console report marks an unconfirmed port number with '~'. The HTML tables
# encode every cell, so the marker has to be part of the text rather than
# markup - same convention, same meaning.
function Get-PortVerifiedText {
    param($Verified)
    if ($Verified -eq $false) { return '~ not confirmed' }
    return 'documented'
}

# Falls back to the blueprint's own port knowledge when a row carries no
# component - the two tables are meant to mirror each other, so a gap in one
# is worth filling from the other rather than rendering blank.
function Get-PortComponentText {
    param($Row)
    $c = [string]$Row.Component
    if ($c) { return $c }
    $info = Get-BlueprintPortInfo -Port ([int]$Row.Port)
    return [string]$info.Component
}

# =============================================================================
#  SINGLE HOST
# =============================================================================
function ConvertTo-PortCheckHtml {
    param(
        [Parameter(Mandatory)]$Payload,
        [string]$SourceName = ''
    )

    $results = @($Payload.Results)
    $meta    = $Payload.Meta
    $now     = Get-Date
    $platform = 'Windows'
    if ($meta.Platform) { $platform = [string]$meta.Platform }

    $named     = @($results | Where-Object { -not $_.InRange })
    $rangeRows = @($results | Where-Object { $_.InRange })
    $conflicts = @($results | Where-Object { $_.Status -eq 'CONFLICT' })
    $unknowns  = @($results | Where-Object { $_.Status -eq 'UNKNOWN' })
    $oks       = @($results | Where-Object { $_.Status -eq 'OK' })
    $svcs      = @($meta.Services)
    $stoppedSvcs = @($svcs | Where-Object { $_.Status -ne 'Running' })

    $h = New-Object System.Text.StringBuilder
    function AL([string]$s) { [void]$h.AppendLine($s) }

    AL '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
    AL '<meta name="viewport" content="width=device-width, initial-scale=1">'
    AL ('<title>Veeam Port Check - {0}</title>' -f (ConvertTo-HtmlText $meta.Host))
    AL '<style>'
    AL (Get-VeeamHtmlCss)
    AL $script:VeeamReportExtraCss
    AL '</style></head><body><div class="page">'

    AL ('<h1>Veeam Port Conflict Check &mdash; {0}</h1>' -f (ConvertTo-HtmlText $meta.Host))
    AL ('<div class="sub">Checked {0} &nbsp;|&nbsp; {1}{2}</div>' -f `
        (ConvertTo-HtmlText ($now.ToString('yyyy-MM-dd HH:mm:ss'))),
        (ConvertTo-HtmlText $platform),
        $(if ($meta.OS) { ' &nbsp;|&nbsp; ' + (ConvertTo-HtmlText $meta.OS) } else { '' }))

    # ---- the collection-failed case -----------------------------------------
    # This is the one state that must never render as a report. Every port
    # reads FREE when enumeration fails, which looks exactly like an all-clear.
    # Save-Results already refuses to put these rows in the CSV; the HTML keeps
    # the header and the diagnosis and drops the tables entirely, because a
    # human reading a page of green rows will not read the banner above them.
    if ($meta.CollectError) {
        AL '<div class="banner bannerbad">'
        AL '<strong>Listener enumeration failed &mdash; this is not a result.</strong><br>'
        AL ('{0}<br>' -f (ConvertTo-HtmlText $meta.CollectError))
        AL 'Every port would read as free, so the findings have been withheld rather than shown. Re-run the check with an account that has administrative rights on this host.'
        AL '</div>'
        AL ('<p class="muted small">Generated {0} by portest3.ps1 (PortHtmlReport.ps1).</p>' -f `
            (ConvertTo-HtmlText ($now.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'))))
        AL '</div></body></html>'
        return $h.ToString()
    }

    if (-not $meta.Elevated) {
        AL '<div class="banner"><strong>The collector was not elevated.</strong> Process owners that could not be resolved are reported as UNKNOWN rather than as conflicts. Re-run elevated, or with an account holding administrative rights on the target, before concluding a port is free.</div>'
    }
    if ($meta.Fallback) {
        AL '<div class="banner">NetTCPIP was unavailable or returned nothing on this host, so the collector fell back to <code>netstat</code>. The results are usable but less precise about owning processes.</div>'
    }
    if (-not $meta.RangeChecked) {
        AL '<div class="banner">The data transfer range 2500&ndash;3300 was <strong>not</strong> checked on this run.</div>'
    }

    AL '<nav><a href="#overview">overview</a><a href="#ports">ports</a><a href="#range">range</a><a href="#services">services</a></nav>'

    # ---- overview -------------------------------------------------------------
    AL '<div class="card" id="overview">'
    AL '<h2>Overview</h2>'
    AL '<div class="kpis">'
    foreach ($pair in @(
        @($conflicts.Count,   'conflicts'),
        @($unknowns.Count,    'unresolved owner'),
        @($oks.Count,         'as expected'),
        @($rangeRows.Count,   'in data range'),
        @($stoppedSvcs.Count, 'Veeam svc stopped')
    )) {
        AL ('<div class="kpi"><div class="v">{0}</div><div class="l">{1}</div></div>' -f `
            $pair[0], (ConvertTo-HtmlText $pair[1]))
    }
    AL '</div>'

    if ($conflicts.Count -eq 0 -and $unknowns.Count -eq 0) {
        if ($meta.RangeChecked) {
            AL '<p class="ok">No port conflicts detected.</p>'
        } else {
            AL '<p>No conflicts on the named ports. The data transfer range was not checked, so this is not a full all-clear.</p>'
        }
    } else {
        if ($conflicts.Count -gt 0) {
            AL ('<p class="bad">{0} conflict(s). Resolve these before upgrading VBR &mdash; a port held by another process at install time fails the component, not the installer.</p>' -f $conflicts.Count)
        }
        if ($unknowns.Count -gt 0) {
            AL ('<p>{0} port(s) have a listener whose owner could not be resolved. That is not a pass &mdash; re-run with administrative rights on the target.</p>' -f $unknowns.Count)
        }
    }

    # Only chart what needs attention. A bar of OK counts would say nothing
    # except that most ports are fine, which they almost always are.
    $byOwner = @{}
    foreach ($r in @($conflicts + $unknowns)) {
        $k = [string]$r.OwnerType
        if (-not $k) { $k = 'Unknown' }
        if (-not $byOwner.ContainsKey($k)) { $byOwner[$k] = 0 }
        $byOwner[$k]++
    }
    $pairs = @()
    foreach ($k in ($byOwner.Keys | Sort-Object)) {
        $pairs += @{ Label = $k; Value = $byOwner[$k]; Color = $script:HtmlStatus.Critical }
    }
    if ($pairs.Count -gt 0) {
        AL (New-BlueprintSvgBar -Title 'Ports needing attention, by owner type' -Pairs $pairs)
    }

    if ($conflicts.Count -gt 0) {
        AL '<h2>Resolve these first</h2>'
        AL '<ul class="fixlist">'
        foreach ($c in ($conflicts | Sort-Object Port)) {
            AL ('<li><span class="what">{0}/{1} held by {2}</span><br><span class="how">Needed by: {3}</span>{4}</li>' -f `
                (ConvertTo-HtmlText $c.Port), (ConvertTo-HtmlText $c.Protocol),
                (ConvertTo-HtmlText $c.Owner), (ConvertTo-HtmlText (Get-PortComponentText $c)),
                $(if ($c.Notes) { '<br><span class="how">' + (ConvertTo-HtmlText $c.Notes) + '</span>' } else { '' }))
        }
        AL '</ul>'
    }
    AL '</div>'

    # ---- named ports -----------------------------------------------------------
    $portCols = @(
        @{ Head = 'Port';      Get = { $_.Port } }
        @{ Head = 'Proto';     Get = { $_.Protocol } }
        @{ Head = 'Status';    Get = { $_.Status } }
        @{ Head = 'Owner';     Get = { $_.Owner } }
        @{ Head = 'Type';      Get = { $_.OwnerType } }
        @{ Head = 'Component'; Get = { Get-PortComponentText $_ } }
        @{ Head = 'Source';    Get = { Get-PortVerifiedText $_.Verified } }
        @{ Head = 'Notes';     Get = { $_.Notes } }
    )
    $rank = @{ 'CONFLICT' = 0; 'UNKNOWN' = 1; 'OK' = 2 }

    AL '<div class="card" id="ports">'
    AL '<h2>Veeam port ownership</h2>'
    AL '<p class="catnote">A port marked <code>~ not confirmed</code> in the Source column has a number taken from general knowledge rather than the v13 documentation. Treat it as indicative and check it against the Ports page for your build &mdash; the table in <code>functions\PortTables.ps1</code> is the place to correct it.</p>'
    AL (New-BlueprintHtmlTable -Columns $portCols `
            -Rows @($named | Sort-Object @{e={ $rank[[string]$_.Status] }}, Port) `
            -RowClass { Get-PortRowClass -Status ([string]$_.Status) } `
            -EmptyText 'no named ports evaluated')
    AL '</div>'

    # ---- data transfer range ----------------------------------------------------
    AL '<div class="card" id="range">'
    AL '<h2>Data transfer range 2500&ndash;3300</h2>'
    if (-not $meta.RangeChecked) {
        AL '<p class="banner">Not checked on this run.</p>'
    } elseif ($rangeRows.Count -eq 0) {
        AL '<p class="ok">No non-Veeam process is listening in the range.</p>'
    } else {
        AL '<p class="catnote">Veeam takes one port from this range per job TCP connection. A few occupied ports are tolerable; large contiguous blocks are not.</p>'
        AL (New-BlueprintHtmlTable -Columns @(
                @{ Head = 'Port';  Get = { $_.Port } }
                @{ Head = 'Owner'; Get = { $_.Owner } }
                @{ Head = 'Type';  Get = { $_.OwnerType } }
                @{ Head = 'Known as'; Get = { $_.Notes } }
            ) -Rows @($rangeRows | Sort-Object Port) `
              -RowClass { Get-PortRowClass -Status ([string]$_.Status) })
    }
    AL '</div>'

    # ---- services ----------------------------------------------------------------
    AL '<div class="card" id="services">'
    AL '<h2>Veeam services on this host</h2>'
    if ($svcs.Count -eq 0) {
        AL '<p class="muted">No Veeam services found &mdash; treating this as a pre-install host.</p>'
    } else {
        if ($stoppedSvcs.Count -gt 0) {
            AL ('<p class="catnote">{0} Veeam service(s) are not running. A port they own reads as free right now, but it must still be free when the upgrade restarts them.</p>' -f $stoppedSvcs.Count)
        }
        AL (New-BlueprintHtmlTable -Columns @(
                @{ Head = 'Status';  Get = { $_.Status } }
                @{ Head = 'Service'; Get = { $_.DisplayName } }
                @{ Head = 'Name';    Get = { $_.Name } }
            ) -Rows @($svcs | Sort-Object @{e={ if ([string]$_.Status -eq 'Running') { 1 } else { 0 } }}, DisplayName) `
              -RowClass { if ([string]$_.Status -ne 'Running') { 'warn' } else { '' } })
    }
    AL '</div>'

    AL ('<p class="muted small">Generated {0} by portest3.ps1 (PortHtmlReport.ps1){1}. Port annotations mirror functions\PortTables.ps1 &mdash; verify against the Veeam docs for your build. This check is read-only; nothing on this host was changed.</p>' -f `
        (ConvertTo-HtmlText ($now.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'))),
        $(if ($SourceName) { ' from ' + (ConvertTo-HtmlText $SourceName) } else { '' }))
    AL '</div></body></html>'
    return $h.ToString()
}

function Export-PortCheckHtml {
    param(
        [Parameter(Mandatory)][string]$OutPath,
        $Payload
    )
    if (-not $PSBoundParameters.ContainsKey('Payload')) { $Payload = $script:LastPortPayload }
    if (-not $Payload) {
        Write-Host '  Nothing to render - run a port conflict check first.' -ForegroundColor Red
        return $null
    }
    try {
        $html = ConvertTo-PortCheckHtml -Payload $Payload
        [IO.File]::WriteAllText($OutPath, $html, (New-Object Text.UTF8Encoding($false)))
        Write-Host ('  HTML report written: {0}' -f $OutPath) -ForegroundColor Green
        return $OutPath
    } catch {
        Write-Host ('  HTML report failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}

# =============================================================================
#  WHOLE ESTATE
#  $script:AllResults accumulates every check this session, Windows and Linux
#  alike - that mixed-estate roll-up is the reason the SSH transport exists,
#  so it gets a report rather than only a CSV.
# =============================================================================
function ConvertTo-PortEstateHtml {
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][array]$Rows
    )

    $now   = Get-Date
    $all   = @($Rows)
    $hosts = @($all | Select-Object -ExpandProperty Host -Unique | Sort-Object)

    $h = New-Object System.Text.StringBuilder
    function AL([string]$s) { [void]$h.AppendLine($s) }

    AL '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
    AL '<meta name="viewport" content="width=device-width, initial-scale=1">'
    AL '<title>Veeam Port Estate</title>'
    AL '<style>'
    AL (Get-VeeamHtmlCss)
    AL $script:VeeamReportExtraCss
    AL '</style></head><body><div class="page">'

    AL '<h1>Veeam Port Estate</h1>'
    AL ('<div class="sub">Compiled {0} &nbsp;|&nbsp; {1} host(s) &nbsp;|&nbsp; {2} row(s)</div>' -f `
        (ConvertTo-HtmlText ($now.ToString('yyyy-MM-dd HH:mm:ss'))), $hosts.Count, $all.Count)

    if ($all.Count -eq 0) {
        AL '<div class="banner">Nothing accumulated yet &mdash; run at least one conflict check.</div>'
        AL '</div></body></html>'
        return $h.ToString()
    }

    $conflicts = @($all | Where-Object { $_.Status -eq 'CONFLICT' })
    $unknowns  = @($all | Where-Object { $_.Status -eq 'UNKNOWN' })

    AL '<nav><a href="#overview">overview</a><a href="#hosts">by host</a><a href="#rows">all findings</a></nav>'

    AL '<div class="card" id="overview">'
    AL '<h2>Overview</h2>'
    AL '<div class="kpis">'
    AL ('<div class="kpi"><div class="v">{0}</div><div class="l">hosts</div></div>' -f $hosts.Count)
    AL ('<div class="kpi"><div class="v">{0}</div><div class="l">conflicts</div></div>' -f $conflicts.Count)
    AL ('<div class="kpi"><div class="v">{0}</div><div class="l">unresolved owner</div></div>' -f $unknowns.Count)
    AL '</div>'
    if ($conflicts.Count -eq 0 -and $unknowns.Count -eq 0) {
        AL '<p class="ok">No conflicts across the estate.</p>'
    }

    $pairs = @()
    foreach ($hn in $hosts) {
        $n = @($all | Where-Object { $_.Host -eq $hn -and ($_.Status -eq 'CONFLICT' -or $_.Status -eq 'UNKNOWN') }).Count
        if ($n -gt 0) { $pairs += @{ Label = $hn; Value = $n; Color = $script:HtmlStatus.Critical } }
    }
    if ($pairs.Count -gt 0) {
        AL (New-BlueprintSvgBar -Title 'Ports needing attention, by host' -Pairs $pairs)
    }
    AL '</div>'

    # ---- per host ---------------------------------------------------------------
    $summary = @()
    foreach ($hn in $hosts) {
        $hr = @($all | Where-Object { $_.Host -eq $hn })
        $summary += [pscustomobject]@{
            Host      = $hn
            Platform  = [string]($hr[0].Platform)
            Checked   = [string]($hr[0].Checked)
            Conflicts = @($hr | Where-Object { $_.Status -eq 'CONFLICT' }).Count
            Unknown   = @($hr | Where-Object { $_.Status -eq 'UNKNOWN' }).Count
            OK        = @($hr | Where-Object { $_.Status -eq 'OK' }).Count
        }
    }
    AL '<div class="card" id="hosts">'
    AL '<h2>By host</h2>'
    AL '<p class="catnote">Owner types are normalised across platforms &mdash; Windows <code>Windows</code> and Linux <code>os</code> both read as <code>OS</code> &mdash; so the same filter works over a mixed estate. The Platform column records which side a row came from.</p>'
    AL (New-BlueprintHtmlTable -Columns @(
            @{ Head = 'Host';      Get = { $_.Host } }
            @{ Head = 'Platform';  Get = { $_.Platform } }
            @{ Head = 'Checked';   Get = { $_.Checked } }
            @{ Head = 'Conflicts'; Get = { $_.Conflicts } }
            @{ Head = 'Unknown';   Get = { $_.Unknown } }
            @{ Head = 'OK';        Get = { $_.OK } }
        ) -Rows @($summary | Sort-Object @{e={ -$_.Conflicts }}, Host) `
          -RowClass { if ($_.Conflicts -gt 0) { 'crit' } elseif ($_.Unknown -gt 0) { 'sevUnknown' } else { '' } })
    AL '</div>'

    # ---- all rows -----------------------------------------------------------------
    $rank = @{ 'CONFLICT' = 0; 'UNKNOWN' = 1; 'OK' = 2 }
    AL '<div class="card" id="rows">'
    AL '<h2>All findings</h2>'
    AL (New-BlueprintHtmlTable -Columns @(
            @{ Head = 'Host';      Get = { $_.Host } }
            @{ Head = 'Port';      Get = { $_.Port } }
            @{ Head = 'Proto';     Get = { $_.Protocol } }
            @{ Head = 'Status';    Get = { $_.Status } }
            @{ Head = 'Owner';     Get = { $_.Owner } }
            @{ Head = 'Type';      Get = { $_.OwnerType } }
            @{ Head = 'Component'; Get = { Get-PortComponentText $_ } }
            @{ Head = 'Source';    Get = { Get-PortVerifiedText $_.Verified } }
        ) -Rows @($all | Sort-Object @{e={ $rank[[string]$_.Status] }}, Host, Port) `
          -RowClass { Get-PortRowClass -Status ([string]$_.Status) })
    AL '</div>'

    AL ('<p class="muted small">Generated {0} by portest3.ps1 (PortHtmlReport.ps1). Port annotations mirror functions\PortTables.ps1 &mdash; verify against the Veeam docs for your build. Runs whose collection failed are not represented here; they were withheld at capture time rather than carried forward as rows reading free.</p>' -f `
        (ConvertTo-HtmlText ($now.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'))))
    AL '</div></body></html>'
    return $h.ToString()
}

function Export-PortEstateHtml {
    param(
        [Parameter(Mandatory)][string]$OutPath,
        [array]$Rows
    )
    if (-not $PSBoundParameters.ContainsKey('Rows')) { $Rows = $script:AllResults }
    if (-not $Rows -or @($Rows).Count -eq 0) {
        Write-Host '  Nothing accumulated yet - run at least one conflict check.' -ForegroundColor Red
        return $null
    }
    try {
        $html = ConvertTo-PortEstateHtml -Rows @($Rows)
        [IO.File]::WriteAllText($OutPath, $html, (New-Object Text.UTF8Encoding($false)))
        Write-Host ('  HTML report written: {0}' -f $OutPath) -ForegroundColor Green
        return $OutPath
    } catch {
        Write-Host ('  HTML report failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}
