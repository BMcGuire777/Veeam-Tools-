# =============================================================================
#  CrlCheck.ps1 - outbound CRL / OCSP / CTL reachability (port 80 and friends).
#
#  Dot-sourced by portest3.ps1. Runs in the main script scope, so functions
#  defined here see the shared port tables and $script: state directly.
#
#  WHY THIS EXISTS
#  Certificate revocation checking is an OUTBOUND dependency that no inbound
#  port test will ever surface:
#
#    * CA-issued certs carry CRL Distribution Point (CDP, OID 2.5.29.31) and
#      OCSP (AIA, OID 1.3.6.1.5.5.7.1.1) URLs - almost always plain HTTP on
#      port 80. If the backup server cannot reach them, .NET/Schannel stalls
#      the handshake for its revocation timeout (typically ~15s per URL)
#      before giving up - jobs get slow or intermittently fail rather than
#      erroring cleanly.
#
#    * Even with a SELF-SIGNED cert (no CDP at all), Windows still fetches
#      Certificate Trust List updates from ctldl.windowsupdate.com over
#      port 80. A silently blocked outbound 80 shows up as odd first-connect
#      delays on otherwise healthy TLS.
#
#  So: parse the REAL revocation URLs out of the certificate(s) and probe
#  them - DNS, then TCP, then an actual HTTP GET - plus a small set of
#  well-known Windows endpoints as an outbound-80 canary.
#
#  PROXY CAVEAT: this probe uses the current user's proxy (WinINET). The
#  Veeam services resolve CRLs through the WinHTTP/machine proxy, which can
#  differ - if this passes but handshakes still stall, compare with:
#      netsh winhttp show proxy
# =============================================================================

# =============================================================================
#  WELL-KNOWN ENDPOINT TABLE
#  Same conventions as PortTables.ps1: edit the table, not the logic.
#  Verified = URL confirmed current; ~ rows are best-effort canaries.
# =============================================================================

$crlWellKnownEndpoints = @(
    @{Url='http://ctldl.windowsupdate.com/msdownload/update/v3/static/trustedr/en/disallowedcertstl.cab'
      Verified=$true
      Description='Windows CTL auto-update (Schannel trusted/disallowed roots)'}
    @{Url='http://crl.microsoft.com/pki/crl/products/microsoftrootcert.crl'
      Verified=$false
      Description='Microsoft root CRL'}
    @{Url='http://crl3.digicert.com/DigiCertGlobalRootCA.crl'
      Verified=$false
      Description='DigiCert root CRL (generic outbound-80 canary)'}
)

# =============================================================================
#  URL EXTRACTION + PROBE
# =============================================================================

# Pulls CDP (CRL) and AIA (OCSP / CA issuer) URLs out of a certificate.
function Get-CertRevocationUrls($cert) {
    $found = @()
    foreach ($ext in $cert.Extensions) {
        $kind = switch ($ext.Oid.Value) {
            '2.5.29.31'           { 'CRL (CDP)' }
            '1.3.6.1.5.5.7.1.1'   { 'OCSP/AIA' }
            default               { $null }
        }
        if (-not $kind) { continue }
        try {
            $text = $ext.Format($true)
            foreach ($m in [regex]::Matches($text, '(?i)\b(https?|ldap)://[^\s,"\)\]>]+')) {
                $found += [pscustomobject]@{ Kind = $kind; Url = $m.Value.TrimEnd('.') }
            }
        } catch { }
    }
    # de-duplicate, keep first Kind seen
    $seen = @{}; @($found | Where-Object { -not $seen.ContainsKey($_.Url) -and ($seen[$_.Url] = $true) })
}

# DNS -> TCP -> HTTP GET against one URL. Any HTTP status (even 404) proves
# outbound HTTP works; the download only has to succeed for a clean OK.
function Test-CrlUrl($url, $timeoutMs = 5000) {
    $out = [pscustomobject]@{
        Url = $url; Status = 'SKIP'; Detail = ''
    }
    $uri = $null
    try { $uri = [uri]$url } catch { }
    if (-not $uri -or $uri.Scheme -notmatch '^https?$') {
        $out.Detail = 'not HTTP(S) - LDAP CDP entries need AD connectivity, not port 80'
        return $out
    }

    # 1. DNS
    try { $null = [System.Net.Dns]::GetHostAddresses($uri.Host) }
    catch { $out.Status = 'NO DNS'; $out.Detail = $_.Exception.Message; return $out }

    # 2. TCP (Reachability.ps1's Test-PortOpen uses a 500ms LAN timeout -
    #    internet endpoints deserve longer, so connect inline)
    $tcp = New-Object System.Net.Sockets.TcpClient
    try {
        $ar = $tcp.BeginConnect($uri.Host, $uri.Port, $null, $null)
        if (-not ($ar.AsyncWaitHandle.WaitOne($timeoutMs, $false))) {
            $out.Status = 'NO TCP'; $out.Detail = ('TCP {0} connect timed out' -f $uri.Port); return $out
        }
        $tcp.EndConnect($ar)
    } catch {
        $out.Status = 'NO TCP'; $out.Detail = $_.Exception.Message; return $out
    } finally { $tcp.Close() }

    # 3. HTTP GET
    try {
        $resp = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop
        $len = if ($resp.RawContentLength -ge 0) { $resp.RawContentLength } else { ($resp.Content | Measure-Object -Property Length -Sum).Sum }
        $out.Status = 'OK'
        $out.Detail = ('HTTP {0}, {1:n0} bytes' -f [int]$resp.StatusCode, $len)
    } catch {
        $resp = $null
        try { $resp = $_.Exception.Response } catch { }
        if ($resp -and $resp.StatusCode) {
            # got an HTTP answer - outbound 80 itself works
            $out.Status = 'HTTP ERR'
            $out.Detail = ('HTTP {0} - port is open, URL/content problem' -f [int]$resp.StatusCode)
        } else {
            $out.Status = 'NO HTTP'
            $out.Detail = $_.Exception.Message
        }
    }
    return $out
}

# =============================================================================
#  DRIVER
# =============================================================================

function Invoke-CrlCheck {
    param(
        # certs whose CDP/OCSP URLs should be probed (e.g. captured off the
        # wire by Invoke-TlsScan, or picked out of the local store)
        [System.Security.Cryptography.X509Certificates.X509Certificate2[]]$Certs,
        [switch]$FromLocalStore,    # pull Veeam-ish certs from LocalMachine\My
        [string]$Thumbprint,        # narrow -FromLocalStore to one cert
        [string[]]$ExtraUrls,       # anything else worth probing
        [switch]$SkipWellKnown
    )

    Write-Host ''
    Write-Rule 'Outbound CRL / Revocation Reachability'
    Write-Host '  Revocation is an OUTBOUND dependency: CDP/OCSP URLs ride plain HTTP' -ForegroundColor DarkCyan
    Write-Host '  (port 80). Blocked = slow handshakes (~15s revocation timeouts), not' -ForegroundColor DarkCyan
    Write-Host '  clean errors. Windows also pulls CTL updates over 80 regardless of' -ForegroundColor DarkCyan
    Write-Host '  the cert - that part applies even to self-signed certificates.' -ForegroundColor DarkCyan

    $certList = @($Certs | Where-Object { $_ })

    if ($FromLocalStore) {
        if ($env:OS -ne 'Windows_NT') {
            Write-Host ''
            Write-Host '  (Local store scan skipped - not a Windows machine.)' -ForegroundColor DarkGray
        } else {
            $machineCerts = @(Get-ChildItem Cert:\LocalMachine\My -ErrorAction SilentlyContinue)
            $picked = if ($Thumbprint) {
                $t = ($Thumbprint -replace '\s', '').ToUpper()
                @($machineCerts | Where-Object { $_.Thumbprint -eq $t })
            } else {
                @($machineCerts | Where-Object {
                    $_.FriendlyName -like '*Veeam*' -or $_.Subject -like '*Veeam*' -or
                    $_.Subject -like ('*' + $env:COMPUTERNAME + '*')
                })
            }
            $certList += $picked
            Write-Host ''
            Write-Host ('  Local store: {0} candidate cert(s) to mine for CDP/OCSP URLs.' -f $picked.Count) -ForegroundColor DarkCyan
        }
    }

    # -- URLs from the certificates ---------------------------------------------
    $probes = @()
    $seenThumb = @{}
    foreach ($cert in $certList) {
        if ($seenThumb.ContainsKey($cert.Thumbprint)) { continue }
        $seenThumb[$cert.Thumbprint] = $true
        $urls = @(Get-CertRevocationUrls $cert)
        $subject = if ($cert.Subject.Length -gt 50) { $cert.Subject.Substring(0,47) + '...' } else { $cert.Subject }
        if ($urls.Count -eq 0) {
            Write-Host ''
            if ($cert.Subject -eq $cert.Issuer) {
                Write-Host ('  {0}: self-signed, no CDP/OCSP URLs (normal) - only the' -f $subject) -ForegroundColor DarkGray
                Write-Host '  well-known Windows endpoints below apply to this cert.' -ForegroundColor DarkGray
            } else {
                Write-Host ('  {0}: CA-issued but NO CDP/OCSP extension found.' -f $subject) -ForegroundColor Yellow
            }
        } else {
            foreach ($u in $urls) {
                $probes += [pscustomobject]@{ Url = $u.Url; Label = ('{0} <- {1}' -f $u.Kind, $subject) }
            }
        }
    }
    foreach ($u in @($ExtraUrls | Where-Object { $_ })) {
        $probes += [pscustomobject]@{ Url = $u; Label = 'custom URL' }
    }

    # -- well-known canaries ------------------------------------------------------
    if (-not $SkipWellKnown) {
        foreach ($e in $crlWellKnownEndpoints) {
            $flag = if (-not $e.Verified) { '~' } else { '' }
            $probes += [pscustomobject]@{ Url = $e.Url; Label = $e.Description + $flag }
        }
    }

    if ($probes.Count -eq 0) {
        Write-Host ''
        Write-Host '  Nothing to probe.' -ForegroundColor Yellow
        return
    }

    # -- probe --------------------------------------------------------------------
    Write-Host ''
    $noTcp = 0; $ok = 0
    foreach ($p in $probes) {
        $r = Test-CrlUrl $p.Url
        $color = switch ($r.Status) {
            'OK'       { $ok++;    'Green' }
            'HTTP ERR' { $ok++;    'Yellow' }   # port works, URL stale - still outbound-OK
            'NO TCP'   { $noTcp++; 'Red' }
            'NO HTTP'  {           'Red' }
            'NO DNS'   {           'Red' }
            default    {           'DarkGray' }
        }
        Write-Host ('  [{0,-8}] {1}' -f $r.Status, $p.Url) -ForegroundColor $color
        Write-Host ('             {0}{1}' -f $p.Label, $(if ($r.Detail) { ' - ' + $r.Detail } else { '' })) -ForegroundColor DarkGray
    }

    # -- verdict --------------------------------------------------------------------
    Write-Host ''
    if ($noTcp -gt 0 -and $ok -eq 0) {
        Write-Host '  Outbound port 80 looks BLOCKED from this machine. Expect ~15s TLS' -ForegroundColor Red
        Write-Host '  handshake stalls while revocation checks time out. Either open 80' -ForegroundColor Red
        Write-Host '  outbound (or the proxy), or accept the stall behaviour knowingly.' -ForegroundColor Red
    } elseif ($noTcp -gt 0) {
        Write-Host '  Some endpoints unreachable - check whether the failing ones are the' -ForegroundColor Yellow
        Write-Host '  URLs YOUR certificate actually carries (labelled "<- subject" above).' -ForegroundColor Yellow
    } else {
        Write-Host '  Outbound HTTP revocation traffic looks healthy from this machine.' -ForegroundColor Green
    }
    Write-Host '  Note: probes used the user/WinINET proxy; Veeam services use WinHTTP.' -ForegroundColor DarkGray
    Write-Host '  If results differ from live behaviour: netsh winhttp show proxy' -ForegroundColor DarkGray
}
