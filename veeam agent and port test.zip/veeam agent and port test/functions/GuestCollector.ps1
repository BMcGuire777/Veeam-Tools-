# =============================================================================
#  GuestCollector.ps1 - the $guestCollector scriptblock.
#
#  Self-contained, like $collector in Collector.ps1: it is shipped verbatim
#  over WinRM, so it CANNOT call anything defined outside itself. Everything
#  the guest check needs is inside this scriptblock.
#
#  Windows PowerShell 5.1 compatible - no ternaries, no null-coalescing, no
#  PS7-only cmdlets. Invoke-Command's default WinRM endpoint is 5.1 on most
#  targets, and the guests being diagnosed are frequently older than the
#  backup server.
#
#  READ-ONLY. It starts nothing, stops nothing, and writes nothing. Several
#  checks shell out to vssadmin / netsh / w32tm / winmgmt - all query verbs.
#  This is deliberate: an app-aware failure is usually a change someone else
#  already made, and a diagnostic that "helpfully" restarts VSS destroys the
#  evidence before you have read it.
#
#  Returns @{ Findings=<pscustomobject[]>; Meta=@{} }.
#  Finding: Category, Check, Status, Detail, Impact, Action
#  Status : PASS | WARN | FAIL | INFO | UNKNOWN
# =============================================================================

$guestCollector = {
    param(
        [string[]]$Groups    = @('Network','Credentials','VSS','Application','Agent'),
        [int]$EventLogDays   = 7,
        [bool]$QuerySql      = $true
    )

    $findings = @()
    $notes    = @()

    function Add-Finding {
        param($Category, $Check, $Status, $Detail, $Impact = '', $Action = '')
        [pscustomobject]@{
            Category = $Category
            Check    = $Check
            Status   = $Status
            Detail   = [string]$Detail
            Impact   = [string]$Impact
            Action   = [string]$Action
        }
    }

    function Get-SvcState {
        param([string]$Name)
        $out = [pscustomobject]@{ Present=$false; Status='';  StartMode='' }
        try {
            $s = Get-Service -Name $Name -ErrorAction Stop
            $out.Present = $true
            $out.Status  = [string]$s.Status
        } catch { return $out }
        try {
            $w = Get-CimInstance -ClassName Win32_Service -Filter ("Name='{0}'" -f $Name) -ErrorAction Stop
            if ($w) { $out.StartMode = [string]$w.StartMode }
        } catch { }
        return $out
    }

    function Get-RegValue {
        param([string]$Path, [string]$Name)
        try {
            $i = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
            return $i.$Name
        } catch { return $null }
    }

    $isElevated = $false
    try {
        $isElevated = ([Security.Principal.WindowsPrincipal] `
            [Security.Principal.WindowsIdentity]::GetCurrent()
            ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { }

    $cs = $null; $os = $null
    try { $cs = Get-CimInstance Win32_ComputerSystem   -ErrorAction Stop } catch { }
    try { $os = Get-CimInstance Win32_OperatingSystem  -ErrorAction Stop } catch { }

    $isDomainJoined = $false
    $domainRole     = -1
    if ($cs) {
        $isDomainJoined = [bool]$cs.PartOfDomain
        $domainRole     = [int]$cs.DomainRole     # 4/5 = domain controller
    }

    # =========================================================================
    #  NETWORK / RPC
    # =========================================================================
    if ($Groups -contains 'Network') {

        # -- RPC services -----------------------------------------------------
        foreach ($pair in @(
            @('RpcSs',       'Remote Procedure Call (RPC)'),
            @('RpcEptMapper','RPC Endpoint Mapper'),
            @('LanmanServer','Server (SMB / admin shares)'),
            @('DcomLaunch',  'DCOM Server Process Launcher'),
            @('EventSystem', 'COM+ Event System')
        )) {
            $svc = Get-SvcState $pair[0]
            if (-not $svc.Present) {
                $findings += Add-Finding 'Network' $pair[1] 'FAIL' 'Service not present on this host.' `
                    'Guest interaction cannot work without it.' 'Investigate why a core Windows service is missing.'
            } elseif ($svc.Status -ne 'Running') {
                $findings += Add-Finding 'Network' $pair[1] 'FAIL' ("Status {0}, start type {1}." -f $svc.Status, $svc.StartMode) `
                    'RPC error 1722 / 1753 on every app-aware run.' 'Start the service and set it back to Automatic.'
            } else {
                $findings += Add-Finding 'Network' $pair[1] 'PASS' ("Running ({0})." -f $svc.StartMode)
            }
        }

        # -- Dynamic RPC port range -------------------------------------------
        # netsh output is localised, so parse the numbers rather than the
        # labels and say so plainly when that fails.
        $dynStart = $null; $dynCount = $null
        try {
            $netshOut = & netsh int ipv4 show dynamicport tcp 2>$null
            foreach ($line in @($netshOut)) {
                if ($line -match '(?i)start.*?:\s*(\d+)')  { $dynStart = [int]$Matches[1] }
                if ($line -match '(?i)number.*?:\s*(\d+)') { $dynCount = [int]$Matches[1] }
            }
            if ($null -eq $dynStart -or $null -eq $dynCount) {
                $nums = @()
                foreach ($line in @($netshOut)) {
                    if ($line -match ':\s*(\d+)\s*$') { $nums += [int]$Matches[1] }
                }
                if ($nums.Count -ge 2) { $dynStart = $nums[0]; $dynCount = $nums[1] }
            }
        } catch { }

        if ($null -ne $dynStart -and $null -ne $dynCount) {
            $dynEnd = $dynStart + $dynCount - 1
            $detail = 'TCP {0}-{1} ({2} ports).' -f $dynStart, $dynEnd, $dynCount
            if ($dynCount -lt 255) {
                $findings += Add-Finding 'Network' 'Dynamic RPC port range' 'WARN' $detail `
                    'A narrowed range exhausts under concurrent jobs and returns RPC 1753.' `
                    'Confirm the firewall permits exactly this range, and that the narrowing was intentional.'
            } else {
                $findings += Add-Finding 'Network' 'Dynamic RPC port range' 'INFO' $detail `
                    '' ('THIS is the range the firewall must permit inbound, not just TCP 135. Verify {0}-{1} end to end from the backup server / guest interaction proxy.' -f $dynStart, $dynEnd)
            }
        } else {
            $findings += Add-Finding 'Network' 'Dynamic RPC port range' 'UNKNOWN' 'Could not parse netsh output (localised or netsh unavailable).' `
                '' 'Run: netsh int ipv4 show dynamicport tcp - and open that range inbound.'
        }

        # -- Local listeners on 135 / 445 -------------------------------------
        if (Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue) {
            foreach ($p in @(135, 445)) {
                $listening = $false
                try { $listening = [bool](Get-NetTCPConnection -State Listen -LocalPort $p -ErrorAction Stop) } catch { }
                if ($listening) {
                    $findings += Add-Finding 'Network' ("TCP {0} listener" -f $p) 'PASS' 'Listening.'
                } else {
                    $findings += Add-Finding 'Network' ("TCP {0} listener" -f $p) 'FAIL' 'Nothing listening on this port.' `
                        'The guest cannot accept RPC (135) or SMB (445) at all.' 'Check the owning service above.'
                }
            }
        }

        # -- Administrative shares --------------------------------------------
        $adminShareOk = $null
        if (Get-Command Get-SmbShare -ErrorAction SilentlyContinue) {
            try { $adminShareOk = [bool](Get-SmbShare -Name 'ADMIN$' -ErrorAction Stop) } catch { $adminShareOk = $false }
        } else {
            try { $adminShareOk = [bool](@(& net share 2>$null) -match 'ADMIN\$') } catch { }
        }
        if ($adminShareOk -eq $true) {
            $findings += Add-Finding 'Network' 'ADMIN$ administrative share' 'PASS' 'Present.'
        } elseif ($adminShareOk -eq $false) {
            $findings += Add-Finding 'Network' 'ADMIN$ administrative share' 'FAIL' 'Not present.' `
                'Veeam deploys its guest runtime through ADMIN$. Without it: RPC error 53 / "cannot connect to the administrative share".' `
                'Check AutoShareServer below, and any hardening baseline that removes admin shares.'
        }

        $autoShare = Get-RegValue 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' 'AutoShareServer'
        if ($null -ne $autoShare -and [int]$autoShare -eq 0) {
            $findings += Add-Finding 'Network' 'AutoShareServer' 'FAIL' 'Set to 0 - automatic admin shares are disabled.' `
                'ADMIN$ will not be recreated at boot. Guest runtime deployment fails every run.' `
                'This is almost always a CIS/STIG hardening item. It must be excepted for the backup estate.'
        } else {
            $findings += Add-Finding 'Network' 'AutoShareServer' 'PASS' 'Not disabled.'
        }

        # -- Firewall ----------------------------------------------------------
        if (Get-Command Get-NetFirewallProfile -ErrorAction SilentlyContinue) {
            try {
                foreach ($fp in @(Get-NetFirewallProfile -ErrorAction Stop)) {
                    $st = 'INFO'
                    if ($fp.Enabled -and $fp.DefaultInboundAction -eq 'Block') { $st = 'INFO' }
                    $findings += Add-Finding 'Network' ("Firewall profile: {0}" -f $fp.Name) $st `
                        ("Enabled={0}, DefaultInbound={1}." -f $fp.Enabled, $fp.DefaultInboundAction)
                }
            } catch { }

            # Rule NAMES (not DisplayNames) are stable across locales.
            foreach ($rule in @(
                @('FPS-SMB-In-TCP',     'File and Printer Sharing (SMB-In), TCP 445'),
                @('WMI-RPCSS-In-TCP',   'WMI / RPCSS inbound (endpoint mapper)'),
                @('WMI-WINMGMT-In-TCP', 'WMI winmgmt inbound')
            )) {
                try {
                    $r = Get-NetFirewallRule -Name $rule[0] -ErrorAction Stop
                    if ($r.Enabled -eq 'True' -or $r.Enabled -eq $true) {
                        $findings += Add-Finding 'Network' ("Firewall rule: {0}" -f $rule[1]) 'PASS' `
                            ("Enabled, profile(s): {0}, action {1}." -f $r.Profile, $r.Action)
                    } else {
                        $findings += Add-Finding 'Network' ("Firewall rule: {0}" -f $rule[1]) 'WARN' 'Rule exists but is disabled.' `
                            'Guest interaction and VSS deployment traffic will be dropped.' 'Enable it for the profile this machine is actually on.'
                    }
                } catch {
                    $findings += Add-Finding 'Network' ("Firewall rule: {0}" -f $rule[1]) 'WARN' 'Built-in rule not found.' `
                        'Either removed by policy, or replaced by a custom rule set.' 'Confirm an equivalent custom rule exists before assuming this is broken.'
                }
            }

            # Which profile is live matters more than which rules exist: rules
            # scoped to Domain stop applying the moment a NIC lands on Public.
            try {
                $live = @(Get-NetConnectionProfile -ErrorAction Stop)
                foreach ($p in $live) {
                    $st = 'PASS'
                    if ($p.NetworkCategory -eq 'Public') { $st = 'WARN' }
                    $findings += Add-Finding 'Network' ("Active network category: {0}" -f $p.InterfaceAlias) $st `
                        ("{0} (network: {1})." -f $p.NetworkCategory, $p.Name) `
                        $(if ($p.NetworkCategory -eq 'Public') { 'Domain-scoped firewall rules do not apply on a Public interface - this is a classic silent cause of RPC 1722 after a NIC or VLAN change.' } else { '' }) `
                        $(if ($p.NetworkCategory -eq 'Public') { 'Find out why domain detection failed (DC reachability, NLA service start order).' } else { '' })
                }
            } catch { }
        } else {
            $findings += Add-Finding 'Network' 'Windows Firewall' 'UNKNOWN' 'NetSecurity module unavailable on this host.' `
                '' 'Check manually: netsh advfirewall show allprofiles'
        }

        # -- Name resolution ---------------------------------------------------
        try {
            $fqdn = [System.Net.Dns]::GetHostEntry($env:COMPUTERNAME)
            $ips  = @($fqdn.AddressList | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | ForEach-Object { $_.IPAddressToString })
            $v6   = @($fqdn.AddressList | Where-Object { $_.AddressFamily -eq 'InterNetworkV6' })
            $findings += Add-Finding 'Network' 'Forward name resolution' 'INFO' `
                ("{0} -> {1}" -f $fqdn.HostName, ($ips -join ', '))
            if ($ips.Count -gt 1) {
                $findings += Add-Finding 'Network' 'Duplicate A records' 'WARN' ("{0} IPv4 addresses registered." -f $ips.Count) `
                    'The backup server may be dialling a stale address and timing out as RPC 1722.' `
                    'Scavenge stale DNS records, or pin the correct address in the Veeam infrastructure entry.'
            }
            if ($v6.Count -gt 0) {
                $findings += Add-Finding 'Network' 'IPv6 registered' 'INFO' ("{0} IPv6 address(es) registered in DNS." -f $v6.Count) `
                    'Windows prefers IPv6. If only IPv4 is permitted through the firewall, the first connection attempt fails.' `
                    'Either permit the RPC range over IPv6 too, or stop registering IPv6 in DNS for this host.'
            }
            # Reverse lookup on the first address - a mismatch breaks Kerberos.
            if ($ips.Count -gt 0) {
                try {
                    $rev = [System.Net.Dns]::GetHostEntry($ips[0])
                    if ($rev.HostName -notlike ($env:COMPUTERNAME + '*')) {
                        $findings += Add-Finding 'Network' 'Reverse name resolution' 'WARN' `
                            ("{0} reverses to {1}." -f $ips[0], $rev.HostName) `
                            'Kerberos SPN lookups and some Veeam reachability checks use the reverse name.' `
                            'Fix the PTR record.'
                    } else {
                        $findings += Add-Finding 'Network' 'Reverse name resolution' 'PASS' ("{0} -> {1}" -f $ips[0], $rev.HostName)
                    }
                } catch {
                    $findings += Add-Finding 'Network' 'Reverse name resolution' 'WARN' ("No PTR record for {0}." -f $ips[0]) `
                        'Kerberos and some reachability checks fall back or fail.' 'Create the PTR record.'
                }
            }
        } catch {
            $findings += Add-Finding 'Network' 'Name resolution' 'FAIL' $_.Exception.Message `
                'If the guest cannot resolve itself, the backup server almost certainly cannot resolve it either.' 'Fix DNS first - nothing below matters until this works.'
        }
    }

    # =========================================================================
    #  CREDENTIALS / AUTHENTICATION
    # =========================================================================
    if ($Groups -contains 'Credentials') {

        # -- UAC remote token filtering ---------------------------------------
        $latfp = Get-RegValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'LocalAccountTokenFilterPolicy'
        if ($isDomainJoined) {
            if ($null -eq $latfp -or [int]$latfp -eq 0) {
                $findings += Add-Finding 'Credentials' 'LocalAccountTokenFilterPolicy' 'INFO' 'Not set (default).' `
                    'Only matters if Veeam connects with a LOCAL account. Domain accounts are unaffected.' `
                    'If the Veeam credential is a local account on this guest, set this to 1 or expect error 5 / access denied.'
            } else {
                $findings += Add-Finding 'Credentials' 'LocalAccountTokenFilterPolicy' 'PASS' 'Set to 1 - local admin accounts get a full token remotely.'
            }
        } else {
            if ($null -eq $latfp -or [int]$latfp -eq 0) {
                $findings += Add-Finding 'Credentials' 'LocalAccountTokenFilterPolicy' 'FAIL' 'Not set, and this host is NOT domain-joined.' `
                    'A workgroup guest can only be reached with a local account, and UAC filters that token over the network. Result: error 5 / access denied, with correct credentials.' `
                    'Set HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\LocalAccountTokenFilterPolicy (DWORD) to 1.'
            } else {
                $findings += Add-Finding 'Credentials' 'LocalAccountTokenFilterPolicy' 'PASS' 'Set to 1.'
            }
        }

        # -- NTLM restriction policy ------------------------------------------
        $ntlmSend = Get-RegValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0' 'RestrictSendingNTLMTraffic'
        $ntlmRecv = Get-RegValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0' 'RestrictReceivingNTLMTraffic'
        if (($null -ne $ntlmRecv -and [int]$ntlmRecv -gt 0) -or ($null -ne $ntlmSend -and [int]$ntlmSend -gt 0)) {
            $findings += Add-Finding 'Credentials' 'Restrict NTLM policy' 'WARN' `
                ("RestrictSending={0}, RestrictReceiving={1}." -f $ntlmSend, $ntlmRecv) `
                'NTLM is blocked or audited. Guest interaction must then succeed with Kerberos, which fails on duplicate SPNs, time skew, or an IP-addressed target.' `
                'Make sure the Veeam infrastructure entry uses the FQDN, not an IP, and check for SPN duplicates.'
        } else {
            $findings += Add-Finding 'Credentials' 'Restrict NTLM policy' 'PASS' 'Not restricted.'
        }

        # -- Secure channel ----------------------------------------------------
        if ($isDomainJoined) {
            try {
                $sc = Test-ComputerSecureChannel -ErrorAction Stop
                if ($sc) {
                    $findings += Add-Finding 'Credentials' 'Domain secure channel' 'PASS' 'Healthy.'
                } else {
                    $findings += Add-Finding 'Credentials' 'Domain secure channel' 'FAIL' 'Broken.' `
                        'Every domain credential presented to this guest will be rejected. Looks exactly like a wrong password.' `
                        'Repair the secure channel (Test-ComputerSecureChannel -Repair) or rejoin the domain.'
                }
            } catch {
                $findings += Add-Finding 'Credentials' 'Domain secure channel' 'UNKNOWN' $_.Exception.Message `
                    '' 'Run Test-ComputerSecureChannel manually on the guest.'
            }
        }

        # -- Time service / skew ------------------------------------------------
        $w32 = Get-SvcState 'W32Time'
        if ($w32.Present -and $w32.Status -ne 'Running') {
            $findings += Add-Finding 'Credentials' 'Windows Time service' 'WARN' ("Status {0}." -f $w32.Status) `
                'Clock drift beyond 5 minutes breaks Kerberos outright.' 'Start W32Time and confirm it syncs to the domain hierarchy.'
        } else {
            $src = ''
            try { $src = (& w32tm /query /source 2>$null) -join '' } catch { }
            $findings += Add-Finding 'Credentials' 'Time source' 'INFO' ("Service {0}; source: {1}" -f $w32.Status, $src) `
                '' 'Compare the guest clock to the backup server - a skew over 5 minutes fails Kerberos.'
        }

        # -- Logon-right denials -------------------------------------------------
        # secedit is the only read path that does not need RSAT. Export to a
        # temp file, read it, delete it.
        try {
            $tmp = Join-Path $env:TEMP ('vgc_{0}.inf' -f [guid]::NewGuid().ToString('N'))
            $null = & secedit /export /areas USER_RIGHTS /cfg $tmp 2>$null
            if (Test-Path $tmp) {
                $inf = Get-Content $tmp -ErrorAction SilentlyContinue
                Remove-Item $tmp -Force -ErrorAction SilentlyContinue
                foreach ($right in @(
                    @('SeDenyNetworkLogonRight',     'Deny access to this computer from the network'),
                    @('SeDenyBatchLogonRight',       'Deny log on as a batch job'),
                    @('SeDenyServiceLogonRight',     'Deny log on as a service'),
                    @('SeDenyInteractiveLogonRight', 'Deny log on locally')
                )) {
                    $line = @($inf | Where-Object { $_ -match ('^\s*' + $right[0] + '\s*=') })
                    if ($line.Count -gt 0) {
                        $val = ($line[0] -split '=', 2)[1].Trim()
                        if ($val) {
                            $findings += Add-Finding 'Credentials' ("User right: {0}" -f $right[1]) 'WARN' `
                                ("Populated: {0}" -f $val) `
                                'If the Veeam guest processing account resolves into one of these SIDs, authentication fails with a logon-failure error that looks like a bad password.' `
                                'Resolve the SIDs and confirm the backup account is not covered, directly or through a group.'
                        }
                    }
                }
            }
        } catch { }
    }

    # =========================================================================
    #  VSS
    # =========================================================================
    if ($Groups -contains 'VSS') {

        foreach ($pair in @(
            @('VSS',   'Volume Shadow Copy service'),
            @('swprv', 'Microsoft Software Shadow Copy Provider')
        )) {
            $svc = Get-SvcState $pair[0]
            if (-not $svc.Present) {
                $findings += Add-Finding 'VSS' $pair[1] 'FAIL' 'Service not present.' 'No VSS, no application-consistent backup.' 'Investigate - this should never be absent.'
            } elseif ($svc.StartMode -eq 'Disabled') {
                $findings += Add-Finding 'VSS' $pair[1] 'FAIL' 'Start type is Disabled.' `
                    'Snapshot creation fails with 0x80070422 (service disabled).' 'Set the start type back to Manual. Both services are demand-started by design.'
            } else {
                $findings += Add-Finding 'VSS' $pair[1] 'PASS' ("{0} / {1}." -f $svc.Status, $svc.StartMode)
            }
        }

        if (-not $isElevated) {
            $findings += Add-Finding 'VSS' 'vssadmin queries' 'UNKNOWN' 'Not elevated - vssadmin will refuse.' `
                'Writers, providers and shadow storage cannot be read.' 'Re-run elevated, or remotely with an account that is a local admin here.'
            $notes += 'vssadmin checks skipped: the collector was not elevated.'
        } else {

            # -- Writers --------------------------------------------------------
            $writerLines = @()
            try { $writerLines = @(& vssadmin list writers 2>$null) } catch { }
            $wName = ''; $wState = ''; $wErr = ''; $writerCount = 0; $badWriters = 0
            foreach ($line in $writerLines) {
                if ($line -match "Writer name:\s*'(?<n>[^']+)'") {
                    $wName = $Matches['n']; $wState = ''; $wErr = ''
                } elseif ($line -match 'State:\s*\[\d+\]\s*(?<s>.+?)\s*$') {
                    $wState = $Matches['s'].Trim()
                } elseif ($line -match 'Last error:\s*(?<e>.+?)\s*$') {
                    $wErr = $Matches['e'].Trim()
                    if ($wName) {
                        $writerCount++
                        $healthy = ($wState -match '(?i)stable') -and ($wErr -match '(?i)no error')
                        if (-not $healthy) {
                            $badWriters++
                            $findings += Add-Finding 'VSS' ("Writer: {0}" -f $wName) 'FAIL' `
                                ("State '{0}', last error '{1}'." -f $wState, $wErr) `
                                'A writer in this state fails the snapshot for every application that depends on it.' `
                                'Restart the service that owns this writer. If it returns to failed on the next run, reboot the guest - repeated failures leave writers unrecoverable in place.'
                        }
                        $wName = ''
                    }
                }
            }
            if ($writerCount -eq 0) {
                $findings += Add-Finding 'VSS' 'VSS writers' 'UNKNOWN' 'vssadmin returned no parseable writers (localised output, or the VSS service failed to enumerate).' `
                    '' 'Run vssadmin list writers on the guest by hand.'
                $notes += 'Writer output could not be parsed - vssadmin is localised on non-English hosts.'
            } elseif ($badWriters -eq 0) {
                $findings += Add-Finding 'VSS' 'VSS writers' 'PASS' ("All {0} writers Stable / No error." -f $writerCount)
            } else {
                $findings += Add-Finding 'VSS' 'VSS writers' 'FAIL' ("{0} of {1} writers unhealthy." -f $badWriters, $writerCount) `
                    'Listed individually above.' ''
            }

            # -- Providers -------------------------------------------------------
            $provLines = @()
            try { $provLines = @(& vssadmin list providers 2>$null) } catch { }
            $msProviderId = 'B5946137-7B9F-4925-AF80-51ABD60B20D5'
            $pName = ''; $provCount = 0; $thirdParty = @()
            foreach ($line in $provLines) {
                if ($line -match "Provider name:\s*'(?<n>[^']+)'") { $pName = $Matches['n'] }
                elseif ($line -match 'Provider Id:\s*\{(?<g>[0-9A-Fa-f-]+)\}') {
                    $provCount++
                    if ($Matches['g'].ToUpper() -ne $msProviderId -and $pName) { $thirdParty += $pName }
                    $pName = ''
                }
            }
            if ($provCount -eq 0) {
                $findings += Add-Finding 'VSS' 'VSS providers' 'UNKNOWN' 'Could not parse vssadmin list providers.' '' 'Check by hand.'
            } elseif ($thirdParty.Count -eq 0) {
                $findings += Add-Finding 'VSS' 'VSS providers' 'PASS' 'Only the Microsoft software provider is registered.'
            } else {
                $findings += Add-Finding 'VSS' 'VSS providers' 'WARN' ("Third-party provider(s) registered: {0}" -f ($thirdParty -join '; ')) `
                    'Windows may select a hardware or third-party provider instead of the Microsoft one. That provider then vetoes the snapshot - error 0x80042306 / 0x8004230F.' `
                    'Identify which provider owns each volume. Leftover providers from a decommissioned array or a removed backup product are the usual culprits.'
            }

            # -- Shadow storage ---------------------------------------------------
            $ssLines = @()
            try { $ssLines = @(& vssadmin list shadowstorage 2>$null) } catch { }
            $ssVol = ''; $ssCount = 0
            foreach ($line in $ssLines) {
                if     ($line -match '(?i)for volume:\s*\((?<v>[^)]+)\)') { $ssVol = $Matches['v']; $ssCount++ }
                elseif ($line -match '(?i)maximum.*?:\s*(?<m>.+?)\s*$' -and $ssVol) {
                    $maxTxt = $Matches['m'].Trim()
                    $st = 'INFO'; $impact = ''; $action = ''
                    if ($maxTxt -match '(?i)^\s*0\b') {
                        $st = 'FAIL'
                        $impact = 'A zero cap means no shadow copy can be created on this volume at all.'
                        $action = 'Raise the MaxSize on the shadow storage association.'
                    } elseif ($maxTxt -match '\((?<p>\d+)%\)' -and [int]$Matches['p'] -lt 10) {
                        $st = 'WARN'
                        $impact = 'A cap under 10% commonly runs out mid-backup: VSS_E_INSUFFICIENT_STORAGE (0x8004231F).'
                        $action = 'Raise the cap, or confirm the change rate genuinely fits inside it.'
                    }
                    $findings += Add-Finding 'VSS' ("Shadow storage cap: {0}" -f $ssVol) $st ("Maximum {0}." -f $maxTxt) $impact $action
                    $ssVol = ''
                }
            }
            if ($ssCount -eq 0) {
                $findings += Add-Finding 'VSS' 'Shadow storage' 'INFO' 'No shadow storage associations reported.' `
                    'Windows will create one on demand, sized by default.' 'Not a fault in itself.'
            }

            # -- Existing shadow copies ---------------------------------------------
            try {
                $shadows = @(& vssadmin list shadows 2>$null)
                $shadowCount = @($shadows | Where-Object { $_ -match '(?i)shadow copy id' }).Count
                if ($shadowCount -gt 64) {
                    $findings += Add-Finding 'VSS' 'Existing shadow copies' 'WARN' ("{0} shadow copies present." -f $shadowCount) `
                        'Approaching the per-volume limits. Orphans from failed runs consume both the limit and the diff area.' `
                        'Identify who owns them before removing anything - some are legitimate (Previous Versions, other products).'
                } else {
                    $findings += Add-Finding 'VSS' 'Existing shadow copies' 'INFO' ("{0} present." -f $shadowCount)
                }
            } catch { }
        }

        # -- Volume health (no elevation needed) -----------------------------------
        try {
            foreach ($v in @(Get-CimInstance Win32_Volume -ErrorAction Stop |
                             Where-Object { $_.DriveType -eq 3 -and $_.Capacity -gt 0 })) {
                $label  = if ($v.DriveLetter) { $v.DriveLetter } else { $v.Name }
                $freeGb = [math]::Round($v.FreeSpace / 1GB, 1)
                $capGb  = [math]::Round($v.Capacity  / 1GB, 1)
                $pct    = [math]::Round(($v.FreeSpace / $v.Capacity) * 100, 1)

                $st = 'PASS'; $impact = ''; $action = ''
                if ($pct -lt 10) {
                    $st = 'FAIL'
                    $impact = 'VSS needs room for the diff area on the volume it is snapshotting. Under 10% free is the single most common cause of 0x8004231F.'
                    $action = 'Free space, or relocate the diff area to a volume that has room.'
                } elseif ($pct -lt 15) {
                    $st = 'WARN'
                    $impact = 'Tight for a volume with a meaningful change rate during the backup window.'
                    $action = 'Watch it, or raise headroom before the next growth step.'
                }
                $findings += Add-Finding 'VSS' ("Free space: {0}" -f $label) $st `
                    ("{0} GB free of {1} GB ({2}%), {3}." -f $freeGb, $capGb, $pct, $v.FileSystem) $impact $action

                if ($v.FileSystem -and $v.FileSystem -notin @('NTFS','ReFS')) {
                    $findings += Add-Finding 'VSS' ("Filesystem: {0}" -f $label) 'FAIL' ("{0} is not snapshottable by the Microsoft provider." -f $v.FileSystem) `
                        'VSS_E_VOLUME_NOT_SUPPORTED (0x8004230C).' 'Exclude this volume from the job, or convert it.'
                }
            }
        } catch { }

        # -- Dynamic disks ----------------------------------------------------------
        if (Get-Command Get-Disk -ErrorAction SilentlyContinue) {
            try {
                $dyn = @(Get-Disk -ErrorAction Stop | Where-Object { $_.PartitionStyle -eq 'RAW' -or $_.IsClustered })
                foreach ($d in $dyn) {
                    $findings += Add-Finding 'VSS' ("Disk {0}" -f $d.Number) 'WARN' `
                        ("PartitionStyle {0}, Clustered {1}." -f $d.PartitionStyle, $d.IsClustered) `
                        'Clustered and raw disks have their own snapshot rules; dynamic/spanned volumes are not supported by the software provider.' `
                        'Confirm the job scope matches what this guest can actually snapshot.'
                }
            } catch { }
        }

        # -- Event log --------------------------------------------------------------
        try {
            $since = (Get-Date).AddDays(-$EventLogDays)
            $vssEvents = @(Get-WinEvent -FilterHashtable @{
                                LogName      = 'Application','System'
                                ProviderName = 'VSS','volsnap'
                                Level        = 1,2
                                StartTime    = $since
                            } -ErrorAction Stop)
            if ($vssEvents.Count -gt 0) {
                $grouped = $vssEvents | Group-Object Id | Sort-Object Count -Descending | Select-Object -First 5
                foreach ($g in $grouped) {
                    $sample = ($g.Group[0].Message -split "`n")[0]
                    $findings += Add-Finding 'VSS' ("Event {0} ({1})" -f $g.Name, $g.Group[0].ProviderName) 'WARN' `
                        ("{0} occurrence(s) in the last {1} days. First line: {2}" -f $g.Count, $EventLogDays, $sample.Trim()) `
                        'VSS and volsnap errors here are the ground truth behind a Veeam snapshot failure.' `
                        'Correlate the timestamps against the failed job runs.'
                }
            } else {
                $findings += Add-Finding 'VSS' 'VSS event log' 'PASS' ("No VSS/volsnap errors in the last {0} days." -f $EventLogDays)
            }
        } catch {
            $findings += Add-Finding 'VSS' 'VSS event log' 'UNKNOWN' 'Could not read the event logs (permissions, or no matching provider).' '' ''
        }
    }

    # =========================================================================
    #  APPLICATIONS
    # =========================================================================
    if ($Groups -contains 'Application') {

        # -- SQL Server ---------------------------------------------------------
        $sqlInstances = @()
        try {
            $k = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL' -ErrorAction Stop
            foreach ($p in $k.PSObject.Properties) {
                if ($p.Name -notlike 'PS*') { $sqlInstances += $p.Name }
            }
        } catch { }

        if ($sqlInstances.Count -gt 0) {
            $findings += Add-Finding 'Application' 'SQL Server detected' 'INFO' ("Instance(s): {0}" -f ($sqlInstances -join ', '))

            $sqlWriter = Get-SvcState 'SQLWriter'
            if (-not $sqlWriter.Present) {
                $findings += Add-Finding 'Application' 'SQL Server VSS Writer service' 'FAIL' 'Not installed.' `
                    'Without SQLWriter there is no SqlServerWriter, so SQL is backed up crash-consistent and logs are never truncated.' `
                    'Install the SQL Server VSS Writer feature from the SQL media.'
            } elseif ($sqlWriter.Status -ne 'Running') {
                $findings += Add-Finding 'Application' 'SQL Server VSS Writer service' 'FAIL' ("Status {0}, start type {1}." -f $sqlWriter.Status, $sqlWriter.StartMode) `
                    'The SqlServerWriter will not appear in the writer list and app-aware processing silently degrades.' `
                    'Start SQLWriter and set it to Automatic. It is NOT Automatic by default on every SQL install - this is a very common miss.'
            } else {
                $findings += Add-Finding 'Application' 'SQL Server VSS Writer service' 'PASS' ("Running ({0})." -f $sqlWriter.StartMode)
            }

            $browser = Get-SvcState 'SQLBrowser'
            $named = @($sqlInstances | Where-Object { $_ -ne 'MSSQLSERVER' })
            if ($named.Count -gt 0) {
                if ($browser.Status -ne 'Running') {
                    $findings += Add-Finding 'Application' 'SQL Browser service' 'WARN' ("Status {0}; named instance(s) present: {1}." -f $browser.Status, ($named -join ', ')) `
                        'Named instances cannot be resolved by name without the Browser service unless a static port is configured.' `
                        'Start SQLBrowser, or configure and use a static port.'
                } else {
                    $findings += Add-Finding 'Application' 'SQL Browser service' 'PASS' 'Running.'
                }
            }

            # TCP protocol enabled, per instance
            foreach ($inst in $sqlInstances) {
                try {
                    $instId = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL' -ErrorAction Stop).$inst
                    $tcpKey = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instId\MSSQLServer\SuperSocketNetLib\Tcp"
                    $enabled = Get-RegValue $tcpKey 'Enabled'
                    if ($null -ne $enabled) {
                        if ([int]$enabled -eq 1) {
                            $findings += Add-Finding 'Application' ("SQL TCP/IP: {0}" -f $inst) 'PASS' 'Enabled.'
                        } else {
                            $findings += Add-Finding 'Application' ("SQL TCP/IP: {0}" -f $inst) 'WARN' 'Disabled.' `
                                'Veeam connects over the local protocols, but log backup and any remote verification will fail.' `
                                'Enable TCP/IP in SQL Server Configuration Manager if remote access is expected.'
                        }
                    }
                } catch { }
            }

            # Database states - read-only query, integrated auth.
            if ($QuerySql) {
                foreach ($inst in $sqlInstances) {
                    $serverName = if ($inst -eq 'MSSQLSERVER') { '.' } else { ('.\{0}' -f $inst) }
                    $conn = $null
                    try {
                        $conn = New-Object System.Data.SqlClient.SqlConnection
                        $conn.ConnectionString = ("Server={0};Database=master;Integrated Security=True;Connect Timeout=10;Application Name=VeeamGuestCheck" -f $serverName)
                        $conn.Open()

                        $cmd = $conn.CreateCommand()
                        $cmd.CommandText = "SELECT name, state_desc, recovery_model_desc, is_read_only FROM sys.databases"
                        $rd = $cmd.ExecuteReader()
                        $odd = @(); $simple = @(); $total = 0
                        while ($rd.Read()) {
                            $total++
                            $dbName = [string]$rd['name']
                            $state  = [string]$rd['state_desc']
                            $model  = [string]$rd['recovery_model_desc']
                            if ($state -ne 'ONLINE') { $odd += ("{0} ({1})" -f $dbName, $state) }
                            if ($model -eq 'SIMPLE' -and $dbName -notin @('master','tempdb','model','msdb')) { $simple += $dbName }
                        }
                        $rd.Close()

                        $findings += Add-Finding 'Application' ("SQL connectivity: {0}" -f $inst) 'PASS' ("Connected; {0} databases." -f $total)

                        if ($odd.Count -gt 0) {
                            $findings += Add-Finding 'Application' ("SQL database state: {0}" -f $inst) 'WARN' ("Not ONLINE: {0}" -f ($odd -join ', ')) `
                                'Offline, restoring, suspect or recovering databases cannot be processed and will fail or warn the job every run.' `
                                'Exclude them from app-aware processing if the state is permanent (log-shipping targets, archived databases).'
                        }
                        if ($simple.Count -gt 0) {
                            $findings += Add-Finding 'Application' ("SQL recovery model: {0}" -f $inst) 'INFO' ("SIMPLE: {0}" -f ($simple -join ', ')) `
                                'Log truncation is not applicable - these produce "unable to truncate" style noise in the job log.' `
                                'Expected, not a fault. Set the job to ignore log processing for these if the warnings are hiding real ones.'
                        }

                        # sysadmin check for the account running this collector
                        $cmd2 = $conn.CreateCommand()
                        $cmd2.CommandText = "SELECT IS_SRVROLEMEMBER('sysadmin') AS sa, SUSER_SNAME() AS who"
                        $rd2 = $cmd2.ExecuteReader()
                        if ($rd2.Read()) {
                            $sa  = $rd2['sa']
                            $who = [string]$rd2['who']
                            if ($sa -eq 1) {
                                $findings += Add-Finding 'Application' ("SQL sysadmin: {0}" -f $inst) 'PASS' ("{0} has sysadmin." -f $who)
                            } else {
                                $findings += Add-Finding 'Application' ("SQL sysadmin: {0}" -f $inst) 'WARN' ("{0} does NOT have sysadmin." -f $who) `
                                    'Log truncation and transaction log backup need sysadmin. db_backupoperator is not enough for everything Veeam does.' `
                                    'Grant sysadmin to the guest processing account, or supply a separate SQL credential in the job.'
                            }
                        }
                        $rd2.Close()
                    } catch {
                        $findings += Add-Finding 'Application' ("SQL connectivity: {0}" -f $inst) 'WARN' $_.Exception.Message `
                            'The collector could not reach this instance. Veeam may still succeed with different credentials, but a login failure here is worth chasing.' `
                            'This is the account the collector ran as - compare it with the account configured in the job.'
                    } finally {
                        if ($conn -and $conn.State -eq 'Open') { $conn.Close() }
                    }
                }
            }
        }

        # -- Exchange ------------------------------------------------------------
        $exch = Get-SvcState 'MSExchangeIS'
        if ($exch.Present) {
            $findings += Add-Finding 'Application' 'Exchange detected' 'INFO' ("Information Store: {0}." -f $exch.Status) `
                '' 'Check circular logging per database: it makes log truncation impossible by design and is reported as a Veeam failure.'
        }

        # -- Domain controller -----------------------------------------------------
        if ($domainRole -eq 4 -or $domainRole -eq 5) {
            $ntds = Get-SvcState 'NTDS'
            $findings += Add-Finding 'Application' 'Domain controller' 'INFO' ("This host is a DC (NTDS: {0})." -f $ntds.Status) `
                '' 'The NTDS writer must be healthy, and the guest processing account needs rights appropriate to a DC.'
        }

        # -- Oracle -----------------------------------------------------------------
        try {
            $ora = @(Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'OracleVss*' -or $_.Name -like 'OracleService*' })
            if ($ora.Count -gt 0) {
                $stopped = @($ora | Where-Object { $_.Status -ne 'Running' })
                $st = 'INFO'
                if ($stopped.Count -gt 0) { $st = 'WARN' }
                $findings += Add-Finding 'Application' 'Oracle detected' $st ("{0} Oracle service(s), {1} not running." -f $ora.Count, $stopped.Count) `
                    '' 'Oracle app-aware needs ARCHIVELOG mode and an account with sysdba.'
            }
        } catch { }
    }

    # =========================================================================
    #  AGENT / DEPLOYMENT
    # =========================================================================
    if ($Groups -contains 'Agent') {

        # -- Veeam services --------------------------------------------------------
        try {
            $vsvc = @(Get-Service -ErrorAction SilentlyContinue |
                      Where-Object { $_.Name -like 'Veeam*' -or $_.DisplayName -like 'Veeam*' })
            if ($vsvc.Count -eq 0) {
                $findings += Add-Finding 'Agent' 'Veeam services' 'INFO' 'No Veeam services on this host.' `
                    'Normal for a guest processed over the network with no persistent agent.' ''
            } else {
                foreach ($s in $vsvc) {
                    $st = 'PASS'
                    if ($s.Status -ne 'Running') { $st = 'WARN' }
                    $findings += Add-Finding 'Agent' ("Service: {0}" -f $s.DisplayName) $st ([string]$s.Status) `
                        $(if ($s.Status -ne 'Running') { 'A stopped Veeam service on the guest blocks deployment and transport.' } else { '' }) ''
                }
            }
        } catch { }

        # -- Agent version ----------------------------------------------------------
        try {
            $keys = @(
                'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
                'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
            )
            $vProducts = @(Get-ItemProperty $keys -ErrorAction SilentlyContinue |
                           Where-Object { $_.DisplayName -like 'Veeam*' } |
                           Select-Object DisplayName, DisplayVersion)
            foreach ($p in $vProducts) {
                $findings += Add-Finding 'Agent' 'Installed Veeam product' 'INFO' ("{0}  {1}" -f $p.DisplayName, $p.DisplayVersion) `
                    '' 'Compare against the backup server build. A version mismatch after a VBR upgrade fails guest processing outright.'
            }
        } catch { }

        # -- CBT driver --------------------------------------------------------------
        try {
            $drv = @(Get-CimInstance Win32_SystemDriver -ErrorAction Stop | Where-Object { $_.Name -like 'veeam*' })
            foreach ($d in $drv) {
                $st = 'PASS'
                if ($d.State -ne 'Running') { $st = 'WARN' }
                $findings += Add-Finding 'Agent' ("Driver: {0}" -f $d.Name) $st ("State {0}, start mode {1}." -f $d.State, $d.StartMode) `
                    $(if ($d.State -ne 'Running') { 'The changed block tracking driver is not active - backups fall back to full volume reads.' } else { '' }) ''
            }
        } catch { }

        # -- System drive space ------------------------------------------------------
        try {
            $sysDrive = $env:SystemDrive
            $ld = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='{0}'" -f $sysDrive) -ErrorAction Stop
            $freeGb = [math]::Round($ld.FreeSpace / 1GB, 1)
            $st = 'PASS'; $impact = ''; $action = ''
            if ($freeGb -lt 1) {
                $st = 'FAIL'
                $impact = 'Veeam deploys its guest runtime into the system drive through ADMIN$. Under 1 GB free, deployment fails.'
                $action = 'Free space on the system drive before anything else.'
            } elseif ($freeGb -lt 5) {
                $st = 'WARN'
                $impact = 'Tight for runtime deployment plus logging.'
                $action = 'Aim for several GB free.'
            }
            $findings += Add-Finding 'Agent' 'System drive free space' $st ("{0} GB free on {1}." -f $freeGb, $sysDrive) $impact $action
        } catch { }

        # -- Pending reboot -----------------------------------------------------------
        $rebootReasons = @()
        if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $rebootReasons += 'Component Based Servicing' }
        if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $rebootReasons += 'Windows Update' }
        $pfro = Get-RegValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' 'PendingFileRenameOperations'
        if ($pfro) { $rebootReasons += 'PendingFileRenameOperations' }
        if ($rebootReasons.Count -gt 0) {
            $findings += Add-Finding 'Agent' 'Pending reboot' 'WARN' ($rebootReasons -join ', ') `
                'Pending servicing operations leave VSS writers and drivers in a half-applied state. This produces VSS failures that no amount of VSS troubleshooting will fix.' `
                'Reboot the guest and re-test before investigating anything else on this report.'
        } else {
            $findings += Add-Finding 'Agent' 'Pending reboot' 'PASS' 'None.'
        }

        # -- WMI repository -------------------------------------------------------------
        try {
            $wmi = (& winmgmt /verifyrepository 2>&1) -join ' '
            if ($wmi -match '(?i)consistent') {
                $findings += Add-Finding 'Agent' 'WMI repository' 'PASS' $wmi.Trim()
            } else {
                $findings += Add-Finding 'Agent' 'WMI repository' 'FAIL' $wmi.Trim() `
                    'Veeam queries WMI throughout guest processing. A corrupt repository fails app-aware long before anything else on the guest looks wrong.' `
                    'Salvage or rebuild the repository during a maintenance window.'
            }
        } catch {
            $findings += Add-Finding 'Agent' 'WMI repository' 'UNKNOWN' 'winmgmt could not be run (needs elevation).' '' 'Run winmgmt /verifyrepository elevated.'
        }

        # -- PowerShell constraints -------------------------------------------------------
        $lm = [string]$ExecutionContext.SessionState.LanguageMode
        if ($lm -ne 'FullLanguage') {
            $findings += Add-Finding 'Agent' 'PowerShell language mode' 'WARN' $lm `
                'WDAC or AppLocker is constraining PowerShell. Veeam guest helpers that shell out can be blocked by the same policy.' `
                'Confirm the Veeam runtime paths are allowed by the application control policy.'
        } else {
            $findings += Add-Finding 'Agent' 'PowerShell language mode' 'PASS' $lm
        }

        # -- Security software ---------------------------------------------------------------
        $edrServices = @(
            'CSFalconService','SentinelAgent','CylanceSvc','CbDefense','cbsensor','TaniumClient',
            'McAfeeFramework','SAVService','SepMasterService','ekrn','WinDefend','TmCCSF','xagt','ds_agent'
        )
        $found = @()
        foreach ($name in $edrServices) {
            $s = Get-SvcState $name
            if ($s.Present -and $s.Status -eq 'Running') { $found += $name }
        }
        if ($found.Count -gt 0) {
            $findings += Add-Finding 'Agent' 'Endpoint security present' 'INFO' ($found -join ', ') `
                'EDR and AV block VeeamGuestHelper.exe / VeeamVssSupport.exe deployment often enough to be a first-line suspect. Defender ASR rule "Block process creations originating from PSExec and WMI commands" is a frequent silent cause.' `
                'Check the product console for blocks on the Veeam runtime paths at the time of the failed job, and confirm exclusions exist.'
        }

        # -- Leftover guest runtime -----------------------------------------------------------
        foreach ($p in @("$env:SystemRoot\VeeamVssSupport", "$env:ProgramData\Veeam\Backup")) {
            if (Test-Path $p) {
                $findings += Add-Finding 'Agent' 'Veeam runtime path' 'INFO' ("Present: {0}" -f $p) `
                    '' 'Guest helper logs here are the most direct evidence of what failed inside the guest.'
            }
        }
    }

    # =========================================================================
    return @{
        Findings = $findings
        Meta     = @{
            Host           = $env:COMPUTERNAME
            OS             = $(if ($os) { [string]$os.Caption } else { '' })
            Elevated       = $isElevated
            DomainJoined   = $isDomainJoined
            DomainRole     = $domainRole
            Domain         = $(if ($cs) { [string]$cs.Domain } else { '' })
            RanAs          = ("{0}\{1}" -f $env:USERDOMAIN, $env:USERNAME)
            LocalTime      = (Get-Date)
            PSVersion      = [string]$PSVersionTable.PSVersion
            Groups         = $Groups
            EventLogDays   = $EventLogDays
            CollectorNotes = $notes
            Collected      = (Get-Date)
        }
    }
}
