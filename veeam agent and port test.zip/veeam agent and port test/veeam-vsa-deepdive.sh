#!/usr/bin/env bash
# =============================================================================
#  veeam-vsa-deepdive.sh
#  Deep inspection of a Linux-based Veeam backup server (incl. the v13 VSA):
#  everything going on under the covers, with a tunable-database focus.
#
#  WHAT IT DOES
#    One-shot report (default):
#      - OS: distro, kernel, virtualisation, time sync, SELinux, tuned profile
#      - CPU & memory: topology, load vs cores, swap, top processes by RSS
#      - Storage: block devices, filesystems, mount options, I/O schedulers
#      - Kernel: curated sysctl values that matter for a DB-carrying host
#      - Packages: veeam packages, totals, recent installs (full list -> file)
#      - Ports: listener summary + anything that is NOT veeam/os/db
#      - Recent kernel/journal errors
#      - DATABASE deep analysis (PostgreSQL - the VBR config DB):
#          version, data dir, every NON-DEFAULT setting (the tuning surface),
#          connection breakdown by state/application, longest query/txn,
#          cache hit ratio, temp file spill, deadlocks, checkpoint pressure,
#          top tables by size with dead-tuple/autovacuum health, unused
#          indexes, blocked locks, pg_stat_statements top queries (if present)
#      - OVERLOAD VERDICT: data-driven flags, each with a tuning suggestion
#
#    Timed capture (--watch [minutes], default 30):
#      samples the database every --interval seconds (default 30) and writes
#      a CSV time series (connections, cache hit, WAL bytes, temp spill,
#      checkpoints, longest query, postgres CPU/RSS, data-dir device I/O,
#      host load/memory) plus a post-run summary with the same verdict
#      engine - the raw material for tuning shared_buffers / work_mem /
#      max_wal_size later.
#
#    Support file collection (default ON):
#      gathers what Veeam support needs for a performance case into
#      <outdir>/collected/ and packs everything into <outdir>.tar.gz:
#      - Veeam logs   (/var/log/veeam*, /opt/veeam/logs, ...; last N days)
#      - PostgreSQL   postgresql.conf/auto.conf/pg_hba/pg_ident + recent DB logs
#      - System state ps/top/free/vmstat/iostat/mpstat/ss/sysctl/dmesg/journal,
#                     sysstat (sar) history, mounts, block devices
#      - Configs      /etc/veeam, sysctl.d, limits, tuned, fstab, veeam units,
#                     firewall ruleset
#      - Inventory    every veeam-named path on the appliance
#      - SIGNAL SCAN  grep of the collected veeam+db logs for error/timeout/
#                     latency/deadlock/OOM patterns, with a per-file hit count
#
#  USAGE (must be run as root)
#    sudo bash veeam-vsa-deepdive.sh                   # report + collection
#    sudo bash veeam-vsa-deepdive.sh --watch           # + 30-minute DB capture
#    sudo bash veeam-vsa-deepdive.sh --watch 60 --interval 15
#    sudo bash veeam-vsa-deepdive.sh --db-only --watch 30   # skip OS + collection
#    sudo bash veeam-vsa-deepdive.sh --inventory            # + full-filesystem Veeam file walk
#    sudo bash veeam-vsa-deepdive.sh --collect-days 7  # collect a wider window
#    sudo bash veeam-vsa-deepdive.sh --no-collect      # report only, no files
#    sudo bash veeam-vsa-deepdive.sh --max-file-mb 500 # per-file copy cap
#    sudo bash veeam-vsa-deepdive.sh --outdir /tmp/dd --no-color
#
#  OUTPUT FILES (printed at the end)
#    <outdir>/deepdive-report.txt      everything shown on screen
#    <outdir>/packages-full.txt        complete package inventory
#    <outdir>/db-settings-nondefault.txt
#    <outdir>/db-top-queries.txt       (when pg_stat_statements exists)
#    <outdir>/db-watch.csv             (--watch) one row per sample
#    <outdir>/collected/               support files (see above)
#    <outdir>.tar.gz                   the bundle to attach to the case
#
#  Same rules as the other collectors: ONE file, bash + coreutils + iproute2;
#  everything else (lscpu, lsblk, timedatectl, journalctl, psql...) is probed
#  and skipped gracefully. ROOT IS REQUIRED: the database section runs
#  runuser -> postgres and the collection reads /var/log/veeam - the script
#  refuses to start without it. Ctrl+C during --watch stops the capture
#  cleanly and still writes the summary.
#
#  Exit code: 0 = report produced, 2 = could not run.
# =============================================================================

set -uo pipefail

WATCH_MIN=0
INTERVAL=30
DB_ONLY=0
FULL_INVENTORY=0
USE_COLOR=1
OUTDIR=""
COLLECT=1
COLLECT_DAYS=3
MAX_MB=200

while [ $# -gt 0 ]; do
  case "$1" in
    --watch)
      WATCH_MIN=30
      if [ $# -gt 1 ] && printf '%s' "$2" | grep -qE '^[0-9]+$'; then WATCH_MIN=$2; shift; fi ;;
    --interval)
      if [ $# -gt 1 ] && printf '%s' "$2" | grep -qE '^[0-9]+$'; then INTERVAL=$2; shift
      else echo "--interval needs a number of seconds" >&2; exit 2; fi ;;
    --outdir)
      if [ $# -gt 1 ]; then OUTDIR=$2; shift
      else echo "--outdir needs a path" >&2; exit 2; fi ;;
    --collect-days)
      if [ $# -gt 1 ] && printf '%s' "$2" | grep -qE '^[1-9][0-9]*$'; then COLLECT_DAYS=$2; shift
      else echo "--collect-days needs a whole number of days (>=1)" >&2; exit 2; fi ;;
    --max-file-mb)
      if [ $# -gt 1 ] && printf '%s' "$2" | grep -qE '^[1-9][0-9]*$'; then MAX_MB=$2; shift
      else echo "--max-file-mb needs a whole number of MB (>=1)" >&2; exit 2; fi ;;
    --no-collect) COLLECT=0 ;;
    --inventory)  FULL_INVENTORY=1 ;;
    --db-only)  DB_ONLY=1 ;;
    --no-color) USE_COLOR=0 ;;
    -h|--help)  sed -n '2,72p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *)          echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

# ROOT IS REQUIRED: DB analysis (runuser -> postgres), /var/log/veeam and the
# journal are all root-only on the appliance. Refuse early rather than produce
# a hollow report that wastes a support round-trip.
if [ "$(id -u)" -ne 0 ]; then
  echo "veeam-vsa-deepdive.sh must be run as root." >&2
  echo "  try:  sudo bash $0 $*" >&2
  exit 2
fi

[ -t 1 ] || USE_COLOR=0
if [ "$USE_COLOR" -eq 1 ]; then
  C_RED=$'\033[31m'; C_GRN=$'\033[32m'; C_YEL=$'\033[33m'
  C_CYN=$'\033[36m'; C_DIM=$'\033[2m';  C_RST=$'\033[0m'
else
  C_RED=''; C_GRN=''; C_YEL=''; C_CYN=''; C_DIM=''; C_RST=''
fi

AM_ROOT=1   # enforced above
have() { command -v "$1" >/dev/null 2>&1; }

# This bundle ends up holding pg_hba.conf, sysctl -a, the full journal and the
# Veeam logs. Created by root at the inherited umask it would land 0755 under a
# guessable name in a world-writable directory - readable by any local account,
# and pre-creatable as a symlink. Lock it down before anything is written.
umask 077
[ -n "$OUTDIR" ] || OUTDIR="/tmp/vsa-deepdive_$(hostname)_$(date +%Y%m%d_%H%M%S)"
if [ -e "$OUTDIR" ] && [ ! -d "$OUTDIR" ]; then
  echo "Refusing to use $OUTDIR - it exists and is not a directory." >&2; exit 2
fi
mkdir -m 700 -p "$OUTDIR" 2>/dev/null || { echo "Cannot create $OUTDIR" >&2; exit 2; }
chmod 700 "$OUTDIR" 2>/dev/null || true
REPORT="$OUTDIR/deepdive-report.txt"
: > "$REPORT" || { echo "Cannot write $REPORT" >&2; exit 2; }

# say: to screen (with color) and to the report file (color stripped)
say() {
  printf '%s\n' "$*"
  printf '%s\n' "$*" | sed 's/\x1b\[[0-9;]*m//g' >> "$REPORT"
}
hr()  { local pad=$(( 56 - ${#1} )); [ "$pad" -lt 1 ] && pad=1
        say "${C_CYN}== $1 $(printf -- '=%.0s' $(seq 1 $pad))${C_RST}"; }
sub() { say "${C_YEL}-- $1${C_RST}"; }
kv()  { say "$(printf '  %-28s %s' "$1" "$2")"; }

FLAGS=()
flag() { FLAGS+=("$1"); }

# -----------------------------------------------------------------------------
#  PostgreSQL plumbing
# -----------------------------------------------------------------------------
PG_OK=0
TARGET_DB=""

pg_query() {  # pg_query [-d db] "sql"  -> rows on stdout, '' on failure
  local db=""
  if [ "$1" = "-d" ]; then db="$2"; shift 2; fi
  if [ -n "$db" ]; then
    runuser -u postgres -- psql -d "$db" -tA -F'|' -c "$1" 2>/dev/null && return 0
    su -s /bin/sh postgres -c "psql -d \"$db\" -tA -F'|' -c \"$1\"" 2>/dev/null
  else
    runuser -u postgres -- psql -tA -F'|' -c "$1" 2>/dev/null && return 0
    su -s /bin/sh postgres -c "psql -tA -F'|' -c \"$1\"" 2>/dev/null
  fi
}

pg_init() {
  [ "$AM_ROOT" -eq 1 ] || return 1
  have psql || return 1
  local v
  v=$(pg_query 'SELECT 1' | head -n1)
  [ "$v" = "1" ] || return 1
  PG_OK=1
  TARGET_DB=$(pg_query "SELECT datname FROM pg_database WHERE NOT datistemplate ORDER BY pg_database_size(datname) DESC LIMIT 1" | head -n1)
  return 0
}

# -----------------------------------------------------------------------------
#  SECTION: host & OS
# -----------------------------------------------------------------------------
sec_os() {
  hr "HOST & OS"
  kv "Hostname"  "$(hostname)"
  [ -r /etc/os-release ] && kv "OS" "$(. /etc/os-release; echo "${PRETTY_NAME:-unknown}")"
  kv "Kernel"    "$(uname -r) ($(uname -m))"
  if have systemd-detect-virt; then kv "Virtualisation" "$(systemd-detect-virt 2>/dev/null || echo unknown)"; fi
  if [ -r /proc/uptime ]; then
    local up; up=$(cut -d. -f1 /proc/uptime)
    kv "Uptime" "$(( up / 86400 ))d $(( up % 86400 / 3600 ))h $(( up % 3600 / 60 ))m"
  fi
  if have timedatectl; then
    kv "Time sync" "$(timedatectl show -p NTPSynchronized --value 2>/dev/null | sed 's/yes/synchronized/;s/no/NOT SYNCHRONIZED/')"
  elif have chronyc; then
    kv "Time sync" "$(chronyc tracking 2>/dev/null | awk -F': ' '/Leap status/{print $2}')"
  fi
  if have getenforce; then kv "SELinux" "$(getenforce 2>/dev/null)"; fi
  if have tuned-adm; then kv "Tuned profile" "$(tuned-adm active 2>/dev/null | awk -F': ' '{print $2}' | head -n1)"; fi
  say ""
}

# -----------------------------------------------------------------------------
#  SECTION: CPU & memory
# -----------------------------------------------------------------------------
sec_cpu_mem() {
  hr "CPU & MEMORY"
  local cores model
  cores=$(grep -c '^processor' /proc/cpuinfo 2>/dev/null || echo 1)
  model=$(awk -F': ' '/^model name/{print $2; exit}' /proc/cpuinfo 2>/dev/null)
  kv "CPU" "${cores} logical core(s)  ${model}"
  if [ -r /proc/loadavg ]; then
    local l1 l5 l15
    read -r l1 l5 l15 _ < /proc/loadavg
    kv "Load average" "$l1 / $l5 / $l15  (1/5/15 min, ${cores} cores)"
    awk -v l="$l1" -v c="$cores" 'BEGIN{exit !(l > c)}' && \
      flag "CPU: 1-minute load ($l1) exceeds core count ($cores) - the host is CPU-saturated right now."
  fi
  local mt ma st sf
  mt=$(awk '/^MemTotal:/{print $2}' /proc/meminfo)
  ma=$(awk '/^MemAvailable:/{print $2}' /proc/meminfo)
  st=$(awk '/^SwapTotal:/{print $2}' /proc/meminfo)
  sf=$(awk '/^SwapFree:/{print $2}' /proc/meminfo)
  kv "Memory" "$(( mt / 1024 )) MB total, $(( ma / 1024 )) MB available ($(( ma * 100 / (mt>0?mt:1) ))%)"
  if [ "${st:-0}" -gt 0 ]; then
    local su=$(( (st - sf) / 1024 ))
    kv "Swap" "$(( st / 1024 )) MB total, ${su} MB used"
    [ $(( (st - sf) * 100 / st )) -gt 10 ] && \
      flag "MEMORY: more than 10% of swap is in use - the host is under memory pressure; check the top-RSS list."
  else
    kv "Swap" "none configured"
  fi
  if have ps; then
    sub "Top 10 processes by resident memory"
    ps axo rss=,pid=,comm= --sort=-rss 2>/dev/null | head -n 10 | \
      awk '{printf "  %8.1f MB  pid %-7s %s\n", $1/1024, $2, $3}' | while IFS= read -r l; do say "$l"; done
  fi
  say ""
}

# -----------------------------------------------------------------------------
#  SECTION: storage
# -----------------------------------------------------------------------------
sec_storage() {
  hr "STORAGE"
  if have lsblk; then
    sub "Block devices"
    lsblk -o NAME,SIZE,TYPE,MOUNTPOINT,ROTA 2>/dev/null | while IFS= read -r l; do say "  $l"; done
  fi
  sub "Filesystems"
  df -hPT 2>/dev/null | awk 'NR==1 || $2 !~ /^(tmpfs|devtmpfs|overlay|squashfs)$/' | \
    while IFS= read -r l; do say "  $l"; done
  # NOTE: fed via process substitution, not a pipeline - flag() must run in
  # this shell or the verdict would lose the finding.
  while IFS= read -r w; do
    [ -n "$w" ] && flag "DISK: $w - a full filesystem stops PostgreSQL and Veeam services dead."
  done < <(df -P 2>/dev/null | awk 'NR>1 && $1 !~ /^(tmpfs|devtmpfs|overlay)/ && $5+0 >= 85 {print $6" is "$5" full"}')
  sub "I/O schedulers"
  local d s
  for d in /sys/block/*/queue/scheduler; do
    [ -r "$d" ] || continue
    s=$(tr -d '\n' < "$d")
    say "  $(echo "$d" | cut -d/ -f4): $s"
  done
  say ""
}

# -----------------------------------------------------------------------------
#  SECTION: kernel tunables that matter for a DB host
# -----------------------------------------------------------------------------
sec_kernel() {
  hr "KERNEL TUNABLES (DB-relevant)"
  local k
  for k in vm.swappiness vm.dirty_ratio vm.dirty_background_ratio vm.overcommit_memory \
           vm.nr_hugepages fs.file-max net.core.somaxconn kernel.sched_autogroup_enabled; do
    if [ -r "/proc/sys/$(echo "$k" | tr . /)" ]; then
      kv "$k" "$(cat "/proc/sys/$(echo "$k" | tr . /)")"
    fi
  done
  if [ -r /sys/kernel/mm/transparent_hugepage/enabled ]; then
    local thp; thp=$(cat /sys/kernel/mm/transparent_hugepage/enabled)
    kv "transparent_hugepage" "$thp"
    echo "$thp" | grep -q '\[always\]' && \
      flag "KERNEL: transparent hugepages are set to 'always' - PostgreSQL generally performs better with 'madvise' or 'never'."
  fi
  say ""
}

# -----------------------------------------------------------------------------
#  SECTION: packages
# -----------------------------------------------------------------------------
sec_packages() {
  hr "PACKAGES"
  local full="$OUTDIR/packages-full.txt"
  if have rpm; then
    sub "Veeam packages"
    rpm -qa --qf '  %-50{NAME} %{VERSION}-%{RELEASE}\n' 'veeam*' 'Veeam*' 2>/dev/null | sort | while IFS= read -r l; do say "$l"; done
    kv "Total packages" "$(rpm -qa 2>/dev/null | wc -l)"
    rpm -qa --qf '%{INSTALLTIME:date}|%{NAME}-%{VERSION}-%{RELEASE}\n' 2>/dev/null | sort -r > "$full.tmp" 2>/dev/null
    sub "Most recently installed/updated (top 15)"
    head -n 15 "$full.tmp" 2>/dev/null | awk -F'|' '{printf "  %s  %s\n", $1, $2}' | while IFS= read -r l; do say "$l"; done
    mv "$full.tmp" "$full" 2>/dev/null
  elif have dpkg-query; then
    sub "Veeam packages"
    dpkg-query -W -f='  ${Package} ${Version}\n' 2>/dev/null | grep -i veeam | while IFS= read -r l; do say "$l"; done
    kv "Total packages" "$(dpkg-query -W 2>/dev/null | wc -l)"
    dpkg-query -W -f='${Package} ${Version}\n' 2>/dev/null | sort > "$full"
  fi
  [ -s "$full" ] && say "  ${C_DIM}Full inventory written to $full${C_RST}"
  say ""
}

# -----------------------------------------------------------------------------
#  SECTION: ports (summary - the blueprint/portcheck scripts do the full map)
# -----------------------------------------------------------------------------
sec_ports() {
  hr "PORTS (summary - run veeam-blueprint.sh for the full annotated map)"
  if ! have ss; then say "  ss not available (iproute2)."; say ""; return; fi
  local rows
  rows=$(ss -H -lntupn 2>/dev/null | awk '
    {
      users=""; for (i=6;i<=NF;i++) users=users $i
      nm="-"
      if (match(users, /\("[^"]+"/)) { nm=substr(users, RSTART+2, RLENGTH-3) }
      n=split($5,a,":"); port=a[n]
      if (port ~ /^[0-9]+$/) print $1"\t"port"\t"nm
    }' | sort -u)
  kv "TCP listeners" "$(echo "$rows" | awk -F'\t' '$1=="tcp"' | wc -l)"
  kv "UDP endpoints" "$(echo "$rows" | awk -F'\t' '$1=="udp"' | wc -l)"
  sub "Listeners whose process name is not veeam/postgres/core-OS"
  local any=0
  while IFS=$'\t' read -r pr po nm; do
    [ -z "${po:-}" ] && continue
    case "$nm" in
      *[Vv]eeam*|postgres|postmaster|sshd|systemd*|rpcbind|chronyd|dbus*|firewalld|NetworkManager|rsyslogd|auditd|-) ;;
      *) say "  ${C_YEL}$pr :$po  $nm${C_RST}"; any=1 ;;
    esac
  done <<< "$rows"
  [ "$any" -eq 0 ] && say "  ${C_GRN}none - every listener is Veeam, PostgreSQL, or core OS.${C_RST}"
  say ""
}

# -----------------------------------------------------------------------------
#  SECTION: recent errors
# -----------------------------------------------------------------------------
sec_journal() {
  hr "RECENT ERRORS (journal/kernel)"
  if have journalctl; then
    local out
    out=$(journalctl -p err -n 15 --no-pager --output=short 2>/dev/null)
    if [ -n "$out" ]; then
      echo "$out" | while IFS= read -r l; do say "  $l"; done
    else
      say "  ${C_GRN}No recent error-priority journal entries.${C_RST}"
    fi
  else
    dmesg 2>/dev/null | tail -n 10 | while IFS= read -r l; do say "  $l"; done
  fi
  say ""
}

# -----------------------------------------------------------------------------
#  SECTION: database deep analysis
# -----------------------------------------------------------------------------
sec_db() {
  hr "DATABASE (PostgreSQL - the VBR configuration DB)"
  if [ "$PG_OK" -ne 1 ]; then
    if [ "$AM_ROOT" -ne 1 ]; then say "  ${C_YEL}Not root - cannot query PostgreSQL via the postgres account.${C_RST}"
    elif ! have psql; then say "  ${C_YEL}psql not found.${C_RST}"
    else say "  ${C_YEL}PostgreSQL is not answering (service down, or not installed).${C_RST}"
    fi
    say ""
    return
  fi

  local ver dir dirsize
  ver=$(pg_query 'SHOW server_version' | head -n1)
  dir=$(pg_query 'SHOW data_directory' | head -n1)
  kv "Server version" "$ver"
  kv "Data directory" "$dir"
  if [ -n "$dir" ] && [ -d "$dir" ]; then
    dirsize=$(du -sm "$dir" 2>/dev/null | awk '{print $1}')
    kv "Data dir size" "${dirsize} MB"
  fi
  kv "Largest database" "$TARGET_DB (analysis target)"
  sub "Databases"
  pg_query "SELECT datname||' = '||pg_size_pretty(pg_database_size(datname)) FROM pg_database WHERE NOT datistemplate ORDER BY pg_database_size(datname) DESC" | \
    while IFS= read -r l; do say "  $l"; done

  # -- the tuning surface: every setting someone (or Veeam) changed ----------
  sub "Non-default settings (the tuning surface)"
  local nd="$OUTDIR/db-settings-nondefault.txt"
  pg_query "SELECT name||' = '||
      CASE WHEN unit='8kB' THEN pg_size_pretty(setting::bigint*8192)
           WHEN unit='kB'  THEN pg_size_pretty(setting::bigint*1024)
           ELSE setting||coalesce(' '||unit,'') END
      ||'   ['||source||']'
    FROM pg_settings WHERE source NOT IN ('default','override') ORDER BY name" > "$nd"
  if [ -s "$nd" ]; then
    while IFS= read -r l; do say "  $l"; done < "$nd"
    say "  ${C_DIM}(also written to $nd)${C_RST}"
  else
    say "  everything is at compiled defaults"
  fi

  # -- connections -------------------------------------------------------------
  sub "Connections"
  local maxc used
  maxc=$(pg_query "SELECT setting FROM pg_settings WHERE name='max_connections'" | head -n1)
  used=$(pg_query "SELECT count(*) FROM pg_stat_activity" | head -n1)
  kv "In use / max" "${used} / ${maxc} ($(( used * 100 / (maxc>0?maxc:1) ))%)"
  [ $(( used * 100 / (maxc>0?maxc:1) )) -ge 80 ] && \
    flag "DB: connections at $(( used * 100 / maxc ))% of max_connections - Veeam job bursts will start failing; investigate before raising the limit."
  pg_query "SELECT '  '||coalesce(state,'(none)')||': '||count(*) FROM pg_stat_activity GROUP BY state ORDER BY count(*) DESC" | \
    while IFS= read -r l; do say "$l"; done
  sub "Connections by application"
  pg_query "SELECT '  '||coalesce(nullif(application_name,''),'(unnamed)')||': '||count(*) FROM pg_stat_activity GROUP BY application_name ORDER BY count(*) DESC LIMIT 15" | \
    while IFS= read -r l; do say "$l"; done
  local lq litx
  lq=$(pg_query "SELECT coalesce(max(extract(epoch FROM now()-query_start))::int,0) FROM pg_stat_activity WHERE state='active' AND pid<>pg_backend_pid()" | head -n1)
  litx=$(pg_query "SELECT coalesce(max(extract(epoch FROM now()-xact_start))::int,0) FROM pg_stat_activity WHERE state LIKE 'idle in transaction%'" | head -n1)
  kv "Longest active query" "${lq:-0}s"
  kv "Longest idle-in-transaction" "${litx:-0}s"
  [ "${litx:-0}" -gt 300 ] && \
    flag "DB: an idle-in-transaction session is ${litx}s old - it blocks vacuum and bloats tables; find the client holding it."

  # -- workload counters --------------------------------------------------------
  sub "Workload counters (database: $TARGET_DB, since stats reset)"
  pg_query "SELECT
      '  commits: '||xact_commit||'   rollbacks: '||xact_rollback,
      '  cache hit: '||CASE WHEN blks_hit+blks_read=0 THEN '100.0' ELSE round(100.0*blks_hit/(blks_hit+blks_read),1)::text END||'%  (hit '||blks_hit||' / read '||blks_read||')',
      '  rows: ins '||tup_inserted||'  upd '||tup_updated||'  del '||tup_deleted||'  fetched '||tup_fetched,
      '  temp spill: '||temp_files||' file(s), '||pg_size_pretty(temp_bytes),
      '  deadlocks: '||deadlocks,
      '  stats since: '||coalesce(to_char(stats_reset,'YYYY-MM-DD HH24:MI'),'(never reset)')
    FROM pg_stat_database WHERE datname='$TARGET_DB'" | tr '|' '\n' | \
    while IFS= read -r l; do [ -n "$l" ] && say "$l"; done
  local hitpct dl tb
  hitpct=$(pg_query "SELECT CASE WHEN blks_hit+blks_read=0 THEN 100 ELSE (100*blks_hit/(blks_hit+blks_read))::int END FROM pg_stat_database WHERE datname='$TARGET_DB'" | head -n1)
  dl=$(pg_query "SELECT deadlocks FROM pg_stat_database WHERE datname='$TARGET_DB'" | head -n1)
  tb=$(pg_query "SELECT temp_bytes FROM pg_stat_database WHERE datname='$TARGET_DB'" | head -n1)
  [ "${hitpct:-100}" -lt 99 ] && \
    flag "DB: cache hit ratio is ${hitpct}% (<99%) - the working set does not fit in shared_buffers; consider raising shared_buffers (and effective_cache_size) if host memory allows."
  [ "${dl:-0}" -gt 0 ] && flag "DB: ${dl} deadlock(s) recorded since stats reset."
  [ "${tb:-0}" -gt 104857600 ] && \
    flag "DB: $(pg_query "SELECT pg_size_pretty(${tb}::bigint)" | head -n1) spilled to temp files - sorts/hashes exceed work_mem; consider a moderate work_mem raise (it multiplies per connection)."

  # -- checkpoints -----------------------------------------------------------------
  sub "Checkpoints"
  local cp ct cr
  cp=$(pg_query "SELECT num_timed||'|'||num_requested FROM pg_stat_checkpointer" | head -n1)
  [ -z "$cp" ] && cp=$(pg_query "SELECT checkpoints_timed||'|'||checkpoints_req FROM pg_stat_bgwriter" | head -n1)
  ct=$(echo "$cp" | cut -d'|' -f1); cr=$(echo "$cp" | cut -d'|' -f2)
  kv "Timed / requested" "${ct:-?} / ${cr:-?}"
  if [ -n "${ct:-}" ] && [ -n "${cr:-}" ] && [ "${cr:-0}" -gt "${ct:-0}" ]; then
    flag "DB: requested checkpoints (${cr}) outnumber timed ones (${ct}) - WAL fills before checkpoint_timeout; raise max_wal_size to smooth I/O during job windows."
  fi

  # -- tables -----------------------------------------------------------------------
  sub "Top 15 tables by size (db: $TARGET_DB)"
  say "  $(printf '%-34s %9s %10s %10s %10s %8s  %s' 'TABLE' 'SIZE MB' 'SEQ_SCAN' 'IDX_SCAN' 'LIVE' 'DEAD' 'LAST AUTOVACUUM')"
  # process substitution, not a pipeline: flag() must run in this shell
  while IFS='|' read -r rn sz ss is lt dt av; do
    [ -z "${rn:-}" ] && continue
    say "  $(printf '%-34s %9s %10s %10s %10s %8s  %s' "$rn" "$sz" "$ss" "$is" "$lt" "$dt" "$av")"
    if [ "${lt:-0}" -gt 10000 ] && [ "${dt:-0}" -gt $(( lt / 5 )) ]; then
      flag "DB: table '$rn' carries ${dt} dead tuples against ${lt} live (>20%) - autovacuum is not keeping up on it."
    fi
  done < <(pg_query -d "$TARGET_DB" "SELECT relname, pg_total_relation_size(relid)/1048576, seq_scan, coalesce(idx_scan,0), n_live_tup, n_dead_tup, coalesce(to_char(last_autovacuum,'MM-DD HH24:MI'),'never') FROM pg_stat_user_tables ORDER BY pg_total_relation_size(relid) DESC LIMIT 15")
  local unused
  unused=$(pg_query -d "$TARGET_DB" "SELECT count(*) FROM pg_stat_user_indexes WHERE idx_scan=0 AND pg_relation_size(indexrelid) > 10485760" | head -n1)
  [ -n "${unused:-}" ] && kv "Unused indexes >10MB" "${unused} (never scanned since stats reset)"

  # -- locks ---------------------------------------------------------------------------
  local blocked
  blocked=$(pg_query "SELECT count(*) FROM pg_locks WHERE NOT granted" | head -n1)
  kv "Blocked lock waits (now)" "${blocked:-0}"
  [ "${blocked:-0}" -gt 0 ] && flag "DB: ${blocked} lock wait(s) in progress right now - check pg_locks / pg_blocking_pids."

  # -- pg_stat_statements ------------------------------------------------------------
  local ext
  ext=$(pg_query "SELECT count(*) FROM pg_extension WHERE extname='pg_stat_statements'" | head -n1)
  if [ "${ext:-0}" -ge 1 ]; then
    sub "Top 10 statements by total execution time"
    local tq="$OUTDIR/db-top-queries.txt"
    pg_query "SELECT round(total_exec_time)::bigint||'ms|'||calls||'|'||left(regexp_replace(query,'\s+',' ','g'),140) FROM pg_stat_statements ORDER BY total_exec_time DESC LIMIT 10" > "$tq"
    [ -s "$tq" ] || pg_query "SELECT round(total_time)::bigint||'ms|'||calls||'|'||left(regexp_replace(query,'\s+',' ','g'),140) FROM pg_stat_statements ORDER BY total_time DESC LIMIT 10" > "$tq"
    if [ -s "$tq" ]; then
      awk -F'|' '{printf "  %10s  calls=%-8s %s\n", $1, $2, $3}' "$tq" | while IFS= read -r l; do say "$l"; done
      say "  ${C_DIM}(also written to $tq)${C_RST}"
    fi
  else
    say "  ${C_DIM}pg_stat_statements not installed - per-query timing unavailable. It can be${C_RST}"
    say "  ${C_DIM}enabled via shared_preload_libraries, but changing the appliance DB config${C_RST}"
    say "  ${C_DIM}is a support-approval conversation, not a casual toggle.${C_RST}"
  fi
  say ""
}

# -----------------------------------------------------------------------------
#  WATCH MODE: timed database capture
# -----------------------------------------------------------------------------
CLK_TCK=$( (have getconf && getconf CLK_TCK) 2>/dev/null || echo 100)

pg_proc_sample() {  # -> "jiffies|rss_kb" summed over all postgres processes
  local j=0 r=0 p stat rss
  for p in /proc/[0-9]*; do
    [ -r "$p/comm" ] || continue
    case "$(cat "$p/comm" 2>/dev/null)" in
      postgres|postmaster)
        stat=$(cat "$p/stat" 2>/dev/null) || continue
        # utime+stime are fields 14+15 counted after the (comm) parens
        set -- ${stat##*) }
        j=$(( j + ${12:-0} + ${13:-0} ))
        rss=$(awk '/^VmRSS:/{print $2}' "$p/status" 2>/dev/null)
        r=$(( r + ${rss:-0} ))
        ;;
    esac
  done
  echo "${j}|${r}"
}

disk_sample() {  # disk_sample <dev-basename> -> "reads|writes|read_sectors|write_sectors"
  [ -n "${1:-}" ] || { echo "0|0|0|0"; return; }
  awk -v d="$1" '$3==d {print $4"|"$8"|"$6"|"$10; found=1} END {if (!found) print "0|0|0|0"}' /proc/diskstats 2>/dev/null
}

watch_db() {
  hr "DATABASE CAPTURE (${WATCH_MIN} min, sampling every ${INTERVAL}s)"
  if [ "$PG_OK" -ne 1 ]; then
    say "  ${C_YEL}PostgreSQL is not reachable - capture skipped.${C_RST}"
    return
  fi

  local csv="$OUTDIR/db-watch.csv"
  echo "timestamp,epoch,conn_active,conn_idle,conn_idle_in_tx,conn_waiting,conn_total,conn_pct_of_max,longest_query_s,longest_tx_s,commits_delta,rollbacks_delta,cache_hit_pct,blks_read_delta,tup_ins_delta,tup_upd_delta,tup_del_delta,temp_files_delta,temp_mb_delta,deadlocks_delta,wal_mb_delta,ckpt_timed_delta,ckpt_req_delta,blocked_locks,load1,mem_avail_mb,pg_cpu_pct,pg_rss_mb,datadir_mb,disk_read_kb_s,disk_write_kb_s" > "$csv"

  local dir dev
  dir=$(pg_query 'SHOW data_directory' | head -n1)
  dev=""
  if [ -n "$dir" ]; then
    dev=$(df -P "$dir" 2>/dev/null | awk 'NR==2 {print $1}' | xargs -r readlink -f 2>/dev/null | xargs -r basename 2>/dev/null)
  fi
  [ -n "$dev" ] && kv "Data-dir device" "/dev/$dev" || say "  ${C_DIM}(data-dir device not resolvable - disk I/O columns will be zero)${C_RST}"
  say "  ${C_DIM}CSV: $csv   (Ctrl+C stops early and still prints the summary)${C_RST}"
  say ""

  local samples=$(( WATCH_MIN * 60 / INTERVAL ))
  [ "$samples" -lt 1 ] && samples=1
  local maxc; maxc=$(pg_query "SELECT setting FROM pg_settings WHERE name='max_connections'" | head -n1)

  # previous-sample state
  local p_commit="" p_rb p_hit p_read p_ins p_upd p_del p_tf p_tb p_dl p_wal p_ct p_cr
  local p_jiff p_dr p_dw p_drs p_dws
  local stop=0
  trap 'stop=1' INT

  # aggregates for the summary
  local n=0 sum_act=0 max_act=0 sum_hit=0 hit_n=0 tot_commit=0 tot_rb=0 tot_tempmb=0
  local tot_walmb=0 tot_ct=0 tot_cr=0 max_lq=0 max_conn_pct=0 tot_dl=0 sum_pgcpu=0

  local i=0
  while [ "$i" -lt "$samples" ] && [ "$stop" -eq 0 ]; do
    i=$(( i + 1 ))
    local row
    row=$(pg_query "SELECT
      (SELECT count(*) FROM pg_stat_activity WHERE state='active' AND pid<>pg_backend_pid()),
      (SELECT count(*) FROM pg_stat_activity WHERE state='idle'),
      (SELECT count(*) FROM pg_stat_activity WHERE state LIKE 'idle in transaction%'),
      (SELECT count(*) FROM pg_stat_activity WHERE wait_event_type IS NOT NULL AND state='active'),
      (SELECT count(*) FROM pg_stat_activity),
      (SELECT coalesce(max(extract(epoch FROM now()-query_start))::bigint,0) FROM pg_stat_activity WHERE state='active' AND pid<>pg_backend_pid()),
      (SELECT coalesce(max(extract(epoch FROM now()-xact_start))::bigint,0) FROM pg_stat_activity WHERE xact_start IS NOT NULL),
      (SELECT sum(xact_commit) FROM pg_stat_database),
      (SELECT sum(xact_rollback) FROM pg_stat_database),
      (SELECT sum(blks_hit) FROM pg_stat_database),
      (SELECT sum(blks_read) FROM pg_stat_database),
      (SELECT sum(tup_inserted) FROM pg_stat_database),
      (SELECT sum(tup_updated) FROM pg_stat_database),
      (SELECT sum(tup_deleted) FROM pg_stat_database),
      (SELECT sum(temp_files) FROM pg_stat_database),
      (SELECT sum(temp_bytes) FROM pg_stat_database),
      (SELECT sum(deadlocks) FROM pg_stat_database),
      pg_wal_lsn_diff(pg_current_wal_lsn(),'0/0')::bigint,
      (SELECT count(*) FROM pg_locks WHERE NOT granted)" | head -n1)
    if [ -z "$row" ]; then
      say "  ${C_RED}$(date '+%H:%M:%S')  sample $i: PostgreSQL did not answer - retrying next tick.${C_RST}"
      sleep "$INTERVAL"
      continue
    fi
    local act idle iitx wait tot lq ltx commit rb hit read ins upd del tf tbytes dl wal blocked
    IFS='|' read -r act idle iitx wait tot lq ltx commit rb hit read ins upd del tf tbytes dl wal blocked <<< "$row"

    local cp2 ct2 cr2
    cp2=$(pg_query "SELECT num_timed||'|'||num_requested FROM pg_stat_checkpointer" | head -n1)
    [ -z "$cp2" ] && cp2=$(pg_query "SELECT checkpoints_timed||'|'||checkpoints_req FROM pg_stat_bgwriter" | head -n1)
    ct2=$(echo "$cp2" | cut -d'|' -f1); cr2=$(echo "$cp2" | cut -d'|' -f2)
    ct2=${ct2:-0}; cr2=${cr2:-0}

    local pj pr ds dr dw drs dws
    IFS='|' read -r pj pr <<< "$(pg_proc_sample)"
    IFS='|' read -r dr dw drs dws <<< "$(disk_sample "$dev")"

    local load1 ma
    read -r load1 _ < /proc/loadavg
    ma=$(( $(awk '/^MemAvailable:/{print $2}' /proc/meminfo) / 1024 ))

    if [ -n "$p_commit" ]; then
      local d_commit=$(( commit - p_commit )) d_rb=$(( rb - p_rb ))
      local d_hit=$(( hit - p_hit )) d_read=$(( read - p_read ))
      local d_ins=$(( ins - p_ins )) d_upd=$(( upd - p_upd )) d_del=$(( del - p_del ))
      local d_tf=$(( tf - p_tf )) d_tmb=$(( (tbytes - p_tb) / 1048576 ))
      local d_dl=$(( dl - p_dl )) d_walmb=$(( (wal - p_wal) / 1048576 ))
      local d_ct=$(( ct2 - p_ct )) d_cr=$(( cr2 - p_cr ))
      local hitpct="100.0"
      [ $(( d_hit + d_read )) -gt 0 ] && hitpct=$(awk -v h="$d_hit" -v r="$d_read" 'BEGIN{printf "%.1f", 100*h/(h+r)}')
      # A backend that exits mid-interval takes its jiffies with it, which can
      # make the summed delta negative - clamp to 0 rather than report noise.
      local pgcpu="0.0"
      [ "$INTERVAL" -gt 0 ] && pgcpu=$(awk -v j="$(( pj - p_jiff ))" -v hz="$CLK_TCK" -v s="$INTERVAL" 'BEGIN{if (j<0) j=0; printf "%.1f", 100*j/hz/s}')
      local rkbs=0 wkbs=0
      rkbs=$(( (drs - p_drs) / 2 / INTERVAL ))
      wkbs=$(( (dws - p_dws) / 2 / INTERVAL ))
      local pct=$(( tot * 100 / (maxc>0?maxc:1) ))
      local ddmb=""
      [ -n "$dir" ] && ddmb=$(du -sm "$dir" 2>/dev/null | awk '{print $1}')

      echo "$(date '+%Y-%m-%d %H:%M:%S'),$(date +%s),$act,$idle,$iitx,$wait,$tot,$pct,$lq,$ltx,$d_commit,$d_rb,$hitpct,$d_read,$d_ins,$d_upd,$d_del,$d_tf,$d_tmb,$d_dl,$d_walmb,$d_ct,$d_cr,$blocked,$load1,$ma,$pgcpu,$(( pr / 1024 )),${ddmb:-0},$rkbs,$wkbs" >> "$csv"
      say "  $(date '+%H:%M:%S')  [$i/$samples] conn ${tot}/${maxc} (${act} active)  hit ${hitpct}%  tx +${d_commit}  wal +${d_walmb}MB  temp +${d_tmb}MB  lq ${lq}s  pgCPU ${pgcpu}%  io ${rkbs}/${wkbs} KB/s"

      n=$(( n + 1 ))
      sum_act=$(( sum_act + act )); [ "$act" -gt "$max_act" ] && max_act=$act
      sum_hit=$(awk -v a="$sum_hit" -v b="$hitpct" 'BEGIN{printf "%.1f", a+b}'); hit_n=$(( hit_n + 1 ))
      tot_commit=$(( tot_commit + d_commit )); tot_rb=$(( tot_rb + d_rb ))
      tot_tempmb=$(( tot_tempmb + d_tmb )); tot_walmb=$(( tot_walmb + d_walmb ))
      tot_ct=$(( tot_ct + d_ct )); tot_cr=$(( tot_cr + d_cr )); tot_dl=$(( tot_dl + d_dl ))
      [ "$lq" -gt "$max_lq" ] && max_lq=$lq
      [ "$pct" -gt "$max_conn_pct" ] && max_conn_pct=$pct
      sum_pgcpu=$(awk -v a="$sum_pgcpu" -v b="$pgcpu" 'BEGIN{printf "%.1f", a+b}')
    else
      say "  $(date '+%H:%M:%S')  [$i/$samples] baseline sample taken."
    fi

    p_commit=$commit; p_rb=$rb; p_hit=$hit; p_read=$read; p_ins=$ins; p_upd=$upd; p_del=$del
    p_tf=$tf; p_tb=$tbytes; p_dl=$dl; p_wal=$wal; p_ct=$ct2; p_cr=$cr2
    p_jiff=$pj; p_drs=$drs; p_dws=$dws; p_dr=$dr; p_dw=$dw

    [ "$i" -lt "$samples" ] && [ "$stop" -eq 0 ] && sleep "$INTERVAL"
  done
  trap - INT

  say ""
  sub "Capture summary (${n} measured interval(s))"
  if [ "$n" -gt 0 ]; then
    kv "Avg / max active connections" "$(( sum_act / n )) / ${max_act}"
    kv "Peak connection usage" "${max_conn_pct}% of max_connections"
    kv "Avg cache hit ratio" "$(awk -v s="$sum_hit" -v c="$hit_n" 'BEGIN{printf "%.1f%%", s/c}')"
    kv "Transactions" "${tot_commit} commits, ${tot_rb} rollbacks"
    kv "WAL written" "${tot_walmb} MB"
    kv "Temp spill" "${tot_tempmb} MB"
    kv "Checkpoints" "${tot_ct} timed, ${tot_cr} requested"
    kv "Longest query seen" "${max_lq}s"
    kv "Avg postgres CPU" "$(awk -v s="$sum_pgcpu" -v c="$n" 'BEGIN{printf "%.1f%%", s/c}')"

    local avg_hit_int; avg_hit_int=$(awk -v s="$sum_hit" -v c="$hit_n" 'BEGIN{printf "%d", s/c}')
    [ "$avg_hit_int" -lt 99 ] && [ $(( tot_commit + tot_rb )) -gt 100 ] && \
      flag "CAPTURE: average cache hit ratio ${avg_hit_int}% during the window - shared_buffers is likely undersized for this workload."
    [ "$max_conn_pct" -ge 80 ] && \
      flag "CAPTURE: connection usage peaked at ${max_conn_pct}% of max_connections."
    [ "$tot_cr" -gt "$tot_ct" ] && [ $(( tot_cr + tot_ct )) -gt 0 ] && \
      flag "CAPTURE: ${tot_cr} requested vs ${tot_ct} timed checkpoints in the window - raise max_wal_size."
    [ "$tot_tempmb" -gt 100 ] && \
      flag "CAPTURE: ${tot_tempmb} MB spilled to temp files in the window - work_mem is too small for the running queries."
    [ "$tot_dl" -gt 0 ] && flag "CAPTURE: ${tot_dl} deadlock(s) during the window."
  else
    say "  Not enough samples for deltas (capture shorter than two intervals)."
  fi
  say ""
}

# -----------------------------------------------------------------------------
#  SECTION: support file collection
#  Gathers the Veeam + system files support asks for in a performance case.
# -----------------------------------------------------------------------------
snap() {  # snap <outfile> <cmd> [args...] - command snapshot if the tool exists
  local out="$1"; shift
  have "$1" || return 0
  "$@" > "$out" 2>&1 || true
  [ -s "$out" ] || rm -f "$out"
}

copy_recent() {  # copy_recent <src-root> <dst-dir> -> prints number of files copied
  local root="$1" dst="$2" f rel n=0 sz
  [ -d "$root" ] || { echo 0; return 0; }
  while IFS= read -r -d '' f; do
    rel=${f#/}
    mkdir -p "$dst/$(dirname "$rel")" 2>/dev/null
    sz=$(stat -c %s "$f" 2>/dev/null || echo 0)
    if [ "$sz" -gt $(( MAX_MB * 1024 * 1024 )) ]; then
      # huge log: keep the newest MAX_MB (the end is where the incident lives)
      tail -c $(( MAX_MB * 1024 * 1024 )) "$f" > "$dst/$rel.tail" 2>/dev/null
    else
      cp -p "$f" "$dst/$rel" 2>/dev/null
    fi
    n=$(( n + 1 ))
  done < <(find "$root" -xdev -type f -mtime -"$COLLECT_DAYS" -print0 2>/dev/null)
  echo "$n"
}

sec_collect() {
  hr "SUPPORT FILE COLLECTION (last ${COLLECT_DAYS} day(s), cap ${MAX_MB}MB/file)"
  local col="$OUTDIR/collected"
  mkdir -p "$col/system" "$col/veeam-logs" "$col/postgres" "$col/configs"

  # ---- system state snapshots (what was the box doing when this ran) --------
  sub "System snapshots"
  snap "$col/system/ps-auxww.txt"     ps auxww
  snap "$col/system/top.txt"          top -b -n 1
  snap "$col/system/free.txt"         free -m
  snap "$col/system/vmstat.txt"       vmstat 1 3
  snap "$col/system/iostat.txt"       iostat -x 1 3
  snap "$col/system/mpstat.txt"       mpstat -P ALL 1 3
  snap "$col/system/ss-summary.txt"   ss -s
  snap "$col/system/ss-listeners.txt" ss -lntupn
  snap "$col/system/ip-link.txt"      ip -s link
  snap "$col/system/sysctl-a.txt"     sysctl -a
  snap "$col/system/lsblk.txt"        lsblk -f
  snap "$col/system/mount.txt"        mount
  snap "$col/system/df.txt"           df -hPT
  snap "$col/system/dmesg.txt"        dmesg -T
  snap "$col/system/numactl.txt"      numactl --hardware
  if have journalctl; then
    journalctl -b --no-pager --since "-${COLLECT_DAYS}d" > "$col/system/journal.log" 2>/dev/null
    journalctl -p warning --no-pager --since "-${COLLECT_DAYS}d" > "$col/system/journal-warnings.log" 2>/dev/null
  fi
  # sysstat history - support can replay CPU/IO/memory for the whole window
  if [ -d /var/log/sa ]; then
    mkdir -p "$col/system/sa"
    find /var/log/sa -type f -mtime -"$COLLECT_DAYS" -exec cp -p {} "$col/system/sa/" \; 2>/dev/null
  fi
  kv "Snapshots" "$(find "$col/system" -type f 2>/dev/null | wc -l) file(s)"

  # ---- Veeam logs -------------------------------------------------------------
  sub "Veeam logs"
  local root n total=0
  for root in /var/log/veeam /var/log/VeeamBackup /opt/veeam/logs /var/lib/veeam/logs; do
    [ -d "$root" ] || continue
    n=$(copy_recent "$root" "$col/veeam-logs")
    total=$(( total + n ))
    kv "$root" "$n file(s)"
  done
  [ "$total" -eq 0 ] && say "  ${C_YEL}no Veeam log directories found under the usual paths.${C_RST}"

  # ---- Veeam file inventory (every veeam-named path on the appliance) --------
  # Opt-in: this is a complete metadata walk of the root filesystem, and this
  # script is usually run BECAUSE the appliance is slow. Left on by default the
  # collector can become the dominant I/O load during the incident it is
  # supposed to be diagnosing.
  sub "Veeam file inventory"
  if [ "${FULL_INVENTORY:-0}" -eq 1 ]; then
    find / -xdev \( -path /proc -o -path /sys -o -path /run -o -path /dev -o -path "$OUTDIR" \) -prune \
         -o -iname '*veeam*' -print 2>/dev/null | sort > "$col/veeam-file-inventory.txt"
    kv "Veeam-named paths" "$(wc -l < "$col/veeam-file-inventory.txt" 2>/dev/null || echo 0) (collected/veeam-file-inventory.txt)"
  else
    kv "Veeam-named paths" "skipped (pass --inventory to walk the whole filesystem)"
  fi

  # ---- PostgreSQL configs + logs ----------------------------------------------
  sub "PostgreSQL"
  if [ "$PG_OK" -eq 1 ]; then
    local ddir ldir f
    ddir=$(pg_query 'SHOW data_directory' | head -n1)
    ldir=$(pg_query 'SHOW log_directory'  | head -n1)
    case "$ldir" in /*) : ;; *) ldir="$ddir/$ldir" ;; esac
    for f in postgresql.conf postgresql.auto.conf pg_hba.conf pg_ident.conf; do
      [ -r "$ddir/$f" ] && cp -p "$ddir/$f" "$col/postgres/" 2>/dev/null
    done
    if [ -d "$ldir" ]; then
      n=$(copy_recent "$ldir" "$col/postgres/logs")
      kv "DB logs ($ldir)" "$n file(s)"
    fi
  else
    say "  ${C_YEL}PostgreSQL not reachable - configs/logs skipped.${C_RST}"
  fi
  [ -d /var/log/postgresql ] && copy_recent /var/log/postgresql "$col/postgres/logs" >/dev/null

  # ---- OS + Veeam configuration files ------------------------------------------
  sub "Configuration files"
  local c
  for c in /etc/veeam /etc/os-release /etc/fstab /etc/sysctl.conf /etc/sysctl.d \
           /etc/security/limits.conf /etc/security/limits.d /etc/tuned; do
    [ -e "$c" ] || continue
    mkdir -p "$col/configs$(dirname "$c")" 2>/dev/null
    cp -rp "$c" "$col/configs$(dirname "$c")/" 2>/dev/null
  done
  if ls /etc/systemd/system/veeam* >/dev/null 2>&1; then
    mkdir -p "$col/configs/etc/systemd/system"
    cp -p /etc/systemd/system/veeam* "$col/configs/etc/systemd/system/" 2>/dev/null
  fi
  have nft && snap "$col/configs/nft-ruleset.txt" nft list ruleset
  have iptables-save && snap "$col/configs/iptables.txt" iptables-save
  kv "Config files" "$(find "$col/configs" -type f 2>/dev/null | wc -l)"

  # ---- performance-signal scan across the collected logs -----------------------
  sub "Performance-signal scan (veeam + db logs)"
  local sig="$col/log-signal-hits.txt"
  local pat='error|fail(ed|ure)|timeout|timed out|slow|latenc|retry|deadlock|out of memory|oom-killer|cannot allocate|too many (open files|connections|clients)|connection (refused|reset)|checkpoint'
  grep -rnIiE "$pat" "$col/veeam-logs" "$col/postgres" 2>/dev/null | head -n 5000 > "$sig"
  if [ -s "$sig" ]; then
    kv "Signal lines" "$(wc -l < "$sig") (first 5000 kept: collected/log-signal-hits.txt)"
    sub "Top signal sources"
    awk -F: '{c[$1]++} END {for (f in c) printf "%7d  %s\n", c[f], f}' "$sig" | sort -rn | head -n 10 | \
      while IFS= read -r l; do say "  $l"; done
  else
    say "  ${C_GRN}no error/timeout/latency signals in the collected logs.${C_RST}"
  fi

  kv "Collected total" "$(du -sm "$col" 2>/dev/null | awk '{print $1}') MB in $(find "$col" -type f 2>/dev/null | wc -l) file(s)"
  say ""
}

make_bundle() {
  local tarball="${OUTDIR}.tar.gz"
  if tar -C "$(dirname "$OUTDIR")" -czf "$tarball" "$(basename "$OUTDIR")" 2>/dev/null; then
    echo ""
    echo "  Support bundle: $tarball ($(du -h "$tarball" 2>/dev/null | awk '{print $1}')) - attach this to the case."
  else
    echo "  Could not create $tarball - hand support the $OUTDIR directory instead." >&2
  fi
}

# -----------------------------------------------------------------------------
#  VERDICT
# -----------------------------------------------------------------------------
sec_verdict() {
  hr "VERDICT"
  if [ ${#FLAGS[@]} -eq 0 ]; then
    say "  ${C_GRN}No overload or misconfiguration signals found.${C_RST}"
  else
    say "  ${C_RED}${#FLAGS[@]} signal(s):${C_RST}"
    local f
    for f in "${FLAGS[@]}"; do
      say "  ${C_RED}*${C_RST} $f"
    done
  fi
  say ""
  say "  Output files:"
  local f
  for f in "$OUTDIR"/*; do
    [ -f "$f" ] && say "    $f"
  done
}

# -----------------------------------------------------------------------------
#  RUN
# -----------------------------------------------------------------------------
say ""
say "${C_CYN}=======================================================${C_RST}"
say "${C_CYN}  Veeam VSA Deep Dive  ->  $(hostname)${C_RST}"
say "${C_DIM}  $(date '+%Y-%m-%d %H:%M:%S')  |  output: $OUTDIR${C_RST}"
say "${C_CYN}=======================================================${C_RST}"
say ""

pg_init || true

if [ "$DB_ONLY" -eq 0 ]; then
  sec_os
  sec_cpu_mem
  sec_storage
  sec_kernel
  sec_packages
  sec_ports
  sec_journal
fi
sec_db
[ "$COLLECT" -eq 1 ] && [ "$DB_ONLY" -eq 0 ] && sec_collect
[ "$WATCH_MIN" -gt 0 ] && watch_db
sec_verdict
[ "$COLLECT" -eq 1 ] && [ "$DB_ONLY" -eq 0 ] && make_bundle
exit 0
