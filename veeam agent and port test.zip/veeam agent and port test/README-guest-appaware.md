# App-aware / guest processing diagnostics

Added to `portest3.ps1` and `functions\`. Diagnoses why a Veeam Windows agent or an app-aware backup job fails: RPC errors, VSS failures, credential and policy problems, application-side blockers, and agent deployment faults.

**Read-only.** Nothing here starts, stops, restarts or reconfigures anything. That is deliberate — an app-aware failure is almost always a change someone else already made, and a diagnostic that "helpfully" restarts VSS destroys the evidence before you have read it. Every finding carries the remediation as text; you apply it.

## The three modes

| Mode | Runs | Answers |
|---|---|---|
| `-GuestCheck` | on the protected guest, elevated | what is wrong *inside* this machine |
| `-GuestTarget <host>` | from the backup server / a workstation, over WinRM | the same, without logging into the guest |
| `-ParseLogs` | wherever the logs are | what the job logs already said, decoded |

Plus `-ErrorCode <code>` — a pure lookup, no host touched.

## Quick start

```powershell
.\portest3.ps1 -GuestCheck
```

```powershell
.\portest3.ps1 -GuestTarget sql01 -GuestPorts
```

```powershell
.\portest3.ps1 -ParseLogs
```

```powershell
.\portest3.ps1 -ErrorCode 1722
```

```powershell
.\portest3.ps1 -GuestTarget sql01 -OutFile C:\temp\sql01.csv -HtmlOut C:\temp\sql01.html
```

Menu entries **17–21** cover the same ground interactively.

## Parameters

| Parameter | Notes |
|---|---|
| `-GuestCheck` | Run the collector on this machine. Run elevated, or the VSS section comes back `UNKNOWN` rather than `PASS`. |
| `-GuestTarget <host>` | Run the same collector on a remote guest over WinRM. Reuses `-VbrCredential` if supplied. |
| `-GuestPorts` | With `-GuestTarget`: TCP reachability for 135, 445, the Veeam agent ports and a sample of the dynamic RPC range, before the collector runs. |
| `-GuestGroups` | Limit to `Network`, `Credentials`, `VSS`, `Application`, `Agent`. Default: all five. |
| `-EventLogDays <n>` | How far back to read VSS/volsnap errors. Default 7. |
| `-NoSqlQuery` | Skip the live SQL `sys.databases` / `IS_SRVROLEMEMBER` queries. |
| `-FailuresOnly` | Hide `PASS` and `INFO` rows. |
| `-ParseLogs` | Scan Veeam logs for known failure signatures. |
| `-LogPath <path>` | A `.log` file, or a folder searched recursively. Omit to use the default Veeam locations. |
| `-SinceDays <n>` | Only files modified in the last *n* days. Default 14. |
| `-ShowAllLogHits` | Include informational signatures. |
| `-ErrorCode <code>` | `1722`, `0x800706BA`, `0x800423F4` … then exit. |
| `-OutFile <path>` | CSV export for whichever mode ran. |
| `-HtmlOut <path>` | HTML report for whichever mode ran. Works alongside `-OutFile`. |

## Reading the output

Findings are grouped into the five domains, **in dependency order**:

```
Network  ->  Credentials  ->  VSS  ->  Application  ->  Agent
```

Fix `FAIL`s top-down. An RPC failure makes every VSS answer below it meaningless, because those answers were never collected from a reachable host.

| Status | Means |
|---|---|
| `PASS` | Checked, healthy. |
| `WARN` | Will degrade the backup, or will bite later. |
| `FAIL` | Blocks app-aware processing now. |
| `UNKNOWN` | **Could not be checked.** Not a pass. Usually missing elevation. |
| `INFO` | Context you need to interpret the rest. |

`~` next to an error code means the code is field knowledge, not confirmed against vendor documentation — same convention as `~` on a port number in `PortTables.ps1`.

## Exit codes

Same convention as the SSH path, safe for pipelines:

| Code | Meaning |
|---|---|
| 0 | No blockers found |
| 1 | At least one `FAIL` (or, for `-ParseLogs`, a blocking signature) |
| 2 | The check could not be completed — no remoting, or not elevated |

## The 1722 trap

"RPC server is unavailable" is overwhelmingly a **half-open firewall**, not a dead host.

The endpoint mapper answers on TCP 135 and then hands back a port in the high dynamic range — 49152–65535 by default. Open 135 alone and every call fails at the second hop, with an error that reads like the guest is offline.

`-GuestCheck` reports the range the guest *actually* uses (`netsh int ipv4 show dynamicport tcp`), because policy narrows it more often than people expect. That reported range is what the firewall has to permit inbound.

`-GuestPorts` samples the range rather than scanning all 16,384 ports. Firewalls open or close this range wholesale; samples tell you the same thing in seconds. A silent sample is **not** proof of a block — RPC binds these on demand, so most are genuinely unbound on an idle guest, and a TCP connect from outside cannot distinguish "dropped" from "nothing listening". The scan says so rather than inventing a verdict.

## HTML reports

`-HtmlOut <path>` writes a single self-contained `.html` document for `-GuestCheck`, `-GuestTarget` or `-ParseLogs`. Inline SVG, inline CSS, **zero JavaScript**, nothing to install — same promise as the blueprint report. It opens in any browser, prints to PDF, and attaches to a ticket.

`-HtmlOut` also works with the port conflict checks (`-LocalCheck`, `-ComputerName`, `-VbrServer`, `-SshServer`) — see [README-portest3.md](README-portest3.md).

It uses the same engine as `veeam-blueprint.ps1`: `ConvertTo-HtmlText`, `New-BlueprintHtmlTable`, `New-BlueprintSvgBar` and the shared palette. The stylesheet was **extracted** out of `ConvertTo-BlueprintHtml` into `Get-VeeamHtmlCss` so there is one copy rather than two that are supposed to match — the same reasoning the file already applies to `$script:PortKnowledge` mirroring `PortTables.ps1`. Guest-specific rules are appended by the caller, not added to the shared block.

The guest report carries:

- a KPI row (FAIL / WARN / UNKNOWN / PASS / INFO) and a plain-language verdict
- an **elevation banner** when the collector was not elevated, stating that the VSS section is incomplete rather than letting a short report read as a clean one
- a bar chart of findings needing attention by category, red where that category holds a FAIL
- a **Fix these first** list, in dependency order, with the remediation under each item
- one table per category, each with the note explaining why that group sits where it does

The log triage report carries the same shell plus occurrence counts, the resolved error code and its meaning per signature, first/last seen timestamps, and the sample log lines behind a `<details>` disclosure so evidence does not stretch every row.

Row colouring reuses the existing severity classes. `UNKNOWN` gets its own (`tr.sevUnknown`) rather than borrowing the warning colour — "could not be checked" is not a warning and must not read as one.

Interactively, menu entry **[7]** gained `[H]` (last guest check as HTML) and `[T]` (log triage as HTML), alongside `[P]` and `[E]` for the port checks. Note the asymmetry with the CSV exports: CSV `[G]` spans every host checked this session, while the HTML report covers **one** run. It carries a host header, an elevation banner and that collection's notes, and those belong to a single collection.

## What gets checked

**Network / RPC** — RpcSs, RpcEptMapper, LanmanServer, DcomLaunch, EventSystem; dynamic RPC range; 135/445 listeners; `ADMIN$` and `AutoShareServer`; firewall profiles, the live network category per NIC, and the built-in SMB/WMI inbound rules (matched by non-localised rule *name*); forward and reverse DNS, duplicate A records, IPv6 registration.

**Credentials** — `LocalAccountTokenFilterPolicy` (the UAC remote-token trap that makes a correct local-admin password return "access denied" on a workgroup guest); Restrict NTLM policy; domain secure channel; time service and clock skew against the machine running the check; the four `SeDeny*` logon rights exported via `secedit`.

**VSS** — VSS and swprv service state *and start type*; `vssadmin list writers` with each failed writer mapped to the service that owns it; `vssadmin list providers` flagging anything that is not the Microsoft software provider; shadow storage caps; existing shadow copy count; free space and filesystem per fixed volume; clustered/raw disks; VSS and volsnap event log errors.

**Application** — SQL instances; the `SQLWriter` service (stopped or non-Automatic far more often than people expect); SQL Browser for named instances; TCP/IP per instance; live `sys.databases` state and recovery model; whether the running account actually holds `sysadmin`; Exchange presence; domain controller role; Oracle VSS services.

**Agent** — Veeam services and installed product versions; the Veeam CBT driver; system drive free space; pending reboot (CBS, Windows Update, `PendingFileRenameOperations`); `winmgmt /verifyrepository`; PowerShell language mode; running EDR/AV products; leftover guest runtime paths.

## Extending it

`functions\GuestKnowledge.ps1` is the knowledge base, and it is **data, not logic**:

- `$guestWin32Errors` — RPC and Win32 codes
- `$guestHexAliases` — hex spellings of those codes
- `$guestVssErrors` — VSS HRESULTs
- `$guestVssWriters` — writer name → owning service
- `$guestLogPatterns` — log signature → cause + action

New codes and new log signatures go **there**, not into the collector or the parser. Patterns are ordered specific-first; the first match on a line wins.

If the log triage finds nothing, that means nothing matched the patterns — not that there is no problem. If you have the failing line in front of you and it is not in the output, add it to `$guestLogPatterns`.

## Design notes

`$guestCollector` (in `functions\GuestCollector.ps1`) is a self-contained scriptblock, exactly like `$collector` in `Collector.ps1`. It is shipped verbatim over WinRM, so it cannot call anything defined outside itself, and it is written for Windows PowerShell 5.1 — `Invoke-Command`'s default endpoint is 5.1 on most targets, and guests are frequently older than the backup server.

Everything that needs the knowledge base — writer ownership, code resolution, clock skew against the caller — is applied on the *caller* side in `GuestReport.ps1`, after collection.

Guest findings use their own session accumulator and their own CSV export rather than sharing `$script:AllResults`. A guest finding and a port row have nothing in common beyond a host name; merging them would produce a CSV with half its columns empty on every row.

Several checks shell out to `vssadmin`, `netsh`, `w32tm`, `secedit` and `winmgmt`. All are query verbs. Their output is **localised**, so the parsers key on numbers and stable identifiers rather than English labels, and report `UNKNOWN` with the manual command when parsing fails — never a false `PASS`.

## Verification status

Consistent with the rest of this tree: **no PowerShell interpreter was available in the authoring environment, so nothing here has been executed.** The files were checked for balanced braces, brackets and quoting, and reviewed by reading. Test in a lab before customer use.

Worth a live check first:

- `vssadmin` parsing on a non-English guest — the writer, provider and shadowstorage parsers should degrade to `UNKNOWN`, not to a wrong answer.
- The `secedit /export` user-rights check — it writes to `%TEMP%` and deletes the file; confirm the temp path is writable under the account you use.
- The live SQL queries under an account without `sysadmin` — they should report `WARN` with the account name, not throw.
- `Get-NetFirewallRule -Name FPS-SMB-In-TCP` on a host whose rules were replaced by a custom set — it should report `WARN` ("built-in rule not found"), which is guidance, not a failure.
- The HTML output in a browser — the CSS extraction into `Get-VeeamHtmlCss` and `$script:VeeamReportExtraCss` touched the blueprint report's own stylesheet path, so check a blueprint HTML still renders correctly as well as the port, guest and log-triage reports.
- The port report's failed-collection path — force a collection failure (run unelevated against a host you cannot enumerate) and confirm the HTML shows the diagnosis with no tables, rather than a page of ports reading free.
