<#
.SYNOPSIS
    Veeam port diagnostic - connects to a VBR server and finds port conflicts.

.DESCRIPTION
    Three kinds of check:

    CONNECT + LOCAL CHECK ON THE VBR SERVER
        Connect-VBRServer authenticates to the backup server (v13 default port
        443, -ForceAcceptTlsCertificate for self-signed) and identifies whether
        it is Windows or a Linux/Veeam Software Appliance.

        Windows backup server -> the conflict check is executed ON that host
        over PowerShell remoting (Invoke-Command). The collector needs only
        Get-NetTCPConnection / Get-Process / Win32_Service, so Windows
        PowerShell 5.1 on the target is enough - the Veeam module's PowerShell
        7.6.3 requirement does not apply to the collector.

        Linux / VSA -> see the constraint below.

    LOCAL CHECK ON THIS MACHINE
        Same collector, run against localhost.

    REMOTE REACHABILITY
        Plain TCP connect tests against a target (the portest2.ps1 behaviour).

    APP-AWARE / GUEST PROCESSING DIAGNOSTICS
        A port conflict and an app-aware failure are different problems, but
        they are reported to the same person on the same bad morning, so the
        checks live in the same toolkit.

        -GuestCheck            run ON a protected guest, elevated. Walks the
                               five domains an app-aware backup has to clear:
                               Network/RPC, Credentials, VSS, Application,
                               Agent. Read-only - it starts nothing, stops
                               nothing, changes nothing.
        -GuestTarget <host>    the same collector over WinRM, from the backup
                               server or a workstation.
        -GuestPorts            with -GuestTarget: TCP reachability for the
                               guest processing path (135, 445, the dynamic
                               RPC range) before the collector runs.
        -ParseLogs             read Veeam job / agent / guest helper logs,
                               match known failure signatures, resolve the
                               numeric codes, and rank by what blocks the job.
        -ErrorCode <code>      look a single RPC or VSS code up and exit.
        -HtmlOut <path>        write this run as a
                               single self-contained .html document - inline
                               SVG, inline CSS, no JavaScript, nothing to
                               install. Opens in a browser, prints to PDF,
                               attaches to a ticket. Uses the same engine and
                               the same stylesheet as the blueprint report
                               (functions\HtmlReport.ps1). Works with the
                               conflict checks (-LocalCheck, -ComputerName,
                               -VbrServer, -SshServer) and with -GuestCheck,
                               -GuestTarget and -ParseLogs. The reachability,
                               TLS and CRL probes stay console-only.

        WHY THE ORDER MATTERS: the five groups are checked in dependency
        order. An RPC failure makes every VSS answer meaningless, because the
        VSS answers were never collected - they were guessed at from a host
        that could not be reached. Fix FAILs top-down.

        THE 1722 TRAP: "RPC server is unavailable" is overwhelmingly a
        half-open firewall, not a dead host. The endpoint mapper answers on
        TCP 135, then hands back a port in the dynamic range (default
        49152-65535). Open 135 alone and every call fails at the second hop.
        -GuestCheck reports the range the guest actually uses, which is the
        range the firewall has to permit.

    Conflict classification:
        OK        free, or held by Veeam / Windows / the config DB as expected
        CONFLICT  held by a process that is not the expected owner
        UNKNOWN   a listener exists but its owner could not be resolved

.NOTES
    RUNTIMES: the script runs under Windows PowerShell 5.1 AND PowerShell 7.
    v13 backup servers standardise on PS7 - run it with pwsh there, and the
    -VbrServer path REQUIRES it (the v13 Veeam module needs PS 7.6.3+).
    Remote collectors still execute under Windows PowerShell on the target
    (Invoke-Command's default WinRM endpoint), which is why they are kept
    5.1-compatible.

    ** VEEAM SOFTWARE APPLIANCE (v13) CONSTRAINT **
    There is no supported remote command execution path into a locked-down
    VSA. Per Veeam docs: SSH is off by default and, where a Security Officer
    account exists, must be approved before it can be enabled; the TUI root
    shell "cannot be accessed through SSH - only local connection through a
    physical console or a virtual remote console is supported", and approved
    root access lasts 8 hours. Veeam PowerShell modules are also explicitly
    unavailable in pre/post-job scripts on the appliance.

    So for a VSA this script does not pretend to find a back door. It:
      1. connects with Connect-VBRServer and confirms the server is Linux,
      2. pushes veeam-portcheck.sh over SSH and runs it, IF you have enabled
         SSH on the appliance,
      3. otherwise hands you the script to run in the console shell,
      4. or prints a compact one-liner for console-only access.

    SSH PUSH
        Two transports, auto-detected. Posh-SSH is preferred because it takes
        a PSCredential and so works unattended; native ssh.exe/scp.exe is the
        no-dependency fallback but OpenSSH prompts for the password itself, so
        only key auth (-SshKeyFile) is truly unattended there.

        Three delivery modes:
          Stream       (default) pipe the script to `bash -s` over stdin, so
                       nothing is ever written to the appliance filesystem
          UploadDelete scp to /tmp, run, remove
          UploadKeep   scp to /tmp and leave it for re-runs from the console

        The remote script is invoked with --report, a pipe-delimited format
        that is parsed back into the same objects the Windows collector
        returns. One renderer, and one CSV that can span a mixed estate.

        Use -UseSudo unless you log in as root. It uses `sudo -n`, so it
        fails cleanly rather than hanging if sudo wants a password.

        HOST KEY CAVEAT: the SSH calls use StrictHostKeyChecking=accept-new
        (native) and -AcceptKey (Posh-SSH), so the FIRST connection to a host
        trusts whatever key it presents without a fingerprint check. That is
        convenient for a diagnostic tool but it does not protect against a
        first-connect man-in-the-middle. If that matters in your environment,
        SSH to the appliance once by hand to pin the key in known_hosts, then
        run this.

    veeam-portcheck.sh must sit in the same folder as this script.

    Run ELEVATED for local checks and use an account with admin rights on the
    target for remote checks, or process owners resolve to UNKNOWN.

    Examples:
      .\portest3.ps1                                          # menu
      .\portest3.ps1 -LocalCheck
      .\portest3.ps1 -VbrServer vbr01.corp.local              # connect + check
      .\portest3.ps1 -VbrServer 10.0.0.5 -ForceAcceptCert
      .\portest3.ps1 -ComputerName vbr01                      # skip the VBR API
      .\portest3.ps1 -SshServer vsa01 -SshUser admin -UseSudo
      .\portest3.ps1 -SshServer vsa01 -SshUser root -SshKeyFile C:\keys\id_ed25519
      .\portest3.ps1 -SshServer vsa01 -SshMode UploadKeep -OutFile C:\temp\vsa.csv
      .\portest3.ps1 -EmitLinuxScript C:\temp                 # no SSH at all
      .\portest3.ps1 -Target 192.168.1.50 -ScanRange
      .\portest3.ps1 -Target em01 -Probe -IncludeEnterpriseManager  # DNS + ports + HTTP, no login
      .\portest3.ps1 -Target vbr01 -TlsProbe                  # real TLS handshakes
      .\portest3.ps1 -Target vbr01 -TlsProbe -TlsPorts 9401   # + port from the log
      .\portest3.ps1 -CertAudit                               # ON the VBR server, elevated
      .\portest3.ps1 -CertAudit -Thumbprint AB12...           # audit a specific cert
      .\portest3.ps1 -CrlCheck                                # outbound port 80 / CRL / CTL
      .\portest3.ps1 -Target vbr01 -TlsProbe -CrlCheck        # + probe the wire certs' CDPs
      .\portest3.ps1 -CertAudit -CrlCheck                     # + probe the store certs' CDPs
      .\portest3.ps1 -CrlCheck -CrlUrls http://crl.corp.local/ca.crl   # internal CA
      .\portest3.ps1 -GuestCheck                              # ON the guest, elevated
      .\portest3.ps1 -GuestCheck -GuestGroups VSS,Application # just the snapshot path
      .\portest3.ps1 -GuestTarget sql01 -GuestPorts           # ports + full check, remote
      .\portest3.ps1 -GuestTarget sql01 -FailuresOnly -OutFile C:\temp\sql01.csv
      .\portest3.ps1 -GuestTarget web01 -NoSqlQuery           # no live SQL queries
      .\portest3.ps1 -ParseLogs                               # default log locations
      .\portest3.ps1 -ParseLogs -LogPath 'C:\ProgramData\Veeam\Backup\Daily SQL'
      .\portest3.ps1 -ParseLogs -SinceDays 30 -OutFile C:\temp\triage.csv
      .\portest3.ps1 -ErrorCode 1722                          # what does this mean
      .\portest3.ps1 -ErrorCode 0x800423F4
      .\portest3.ps1 -GuestTarget sql01 -HtmlOut C:\temp\sql01.html
      .\portest3.ps1 -ParseLogs -HtmlOut C:\temp\triage.html
      .\portest3.ps1 -GuestCheck -OutFile C:\temp\g.csv -HtmlOut C:\temp\g.html
      .\portest3.ps1 -LocalCheck -HtmlOut C:\temp\vbr01-ports.html
      .\portest3.ps1 -ComputerName vbr01 -HtmlOut C:\temp\vbr01-ports.html
      .\portest3.ps1 -SshServer vsa01 -SshUser root -HtmlOut C:\temp\vsa01-ports.html

    TLS / CERTIFICATE DIAGNOSTICS: a port can pass every TCP test and still
    reset each TLS handshake - the signature of a badly installed certificate
    ("The SSL connection could not be established ... SocketException 10054"
    in the VBR logs, gRPC services reported unavailable). -TlsProbe negotiates
    TLS for real from a client machine and shows the certificate presented;
    -CertAudit runs on the backup server and checks the store (LocalMachine vs
    CurrentUser), the private key, and the key ACL against the accounts the
    Veeam services actually run as. See functions\TlsProbe.ps1.

    -SshServer exit codes: 0 clean, 1 conflicts found, 2 the check could not
    be completed. Safe to use in a pipeline.

    -GuestCheck / -GuestTarget use the same convention: 0 no blockers, 1 at
    least one FAIL, 2 the check could not be completed (no remoting, or the
    collector was not elevated so the VSS section is missing). -ParseLogs
    returns 1 when a blocking signature was found. An UNKNOWN is never a pass.

    GUEST CHECK ELEVATION: vssadmin, winmgmt and parts of the event log need
    administrator rights. Without them the VSS section is reported UNKNOWN
    rather than PASS, and the exit code is 2. Run it elevated, or remotely
    with an account that is a local admin on the guest.

    APP-AWARE KNOWLEDGE BASE: functions\GuestKnowledge.ps1 holds the RPC and
    VSS error tables, the VSS writer-to-service map, and the log signature
    patterns. New error codes and new log signatures belong THERE, not in the
    collector or the parser. Entries carry the same Verified flag as the port
    table, and unverified ones are rendered with a ~.

    PORT DATA: $windowsPorts (functions\PortTables.ps1) is the source of truth
    for Windows checks. Confirmed from v13 docs: 443 (Connect-VBRServer
    default), 9392 (Windows backup server initial connection), 9405, 6160,
    6162, 2500-3300, 5432, 9419, 6172, 10006. Confirmed by search:
    111/1058/2049 vPower NFS, and that from v13 vPower NFS hard-fails if 111
    is locked. Enterprise Manager ports (9080, 9443, 9398, 9399, 9394, 10443)
    are verified against the v13 EM Used Ports page:
    https://helpcenter.veeam.com/docs/vbr/em/used_ports.html?ver=13
    Others (6161, 9393, 9401, 9380, Cloud Connect, WAN) are from general
    knowledge and are marked Verified=$false - check them against the Ports
    page for your build and edit the table, not the logic.

    Use -IncludeEnterpriseManager with -Target to add the EM web UI / REST
    ports to the reachability scan, or with the local/remote conflict checks
    to include the EM listener ports.
#>

[CmdletBinding()]
param(
    # --- Connect to a VBR server and check it -------------------------------
    [string]$VbrServer,
    [int]$VbrPort = 443,
    [System.Management.Automation.PSCredential]$VbrCredential,
    [switch]$ForceAcceptCert,

    # --- Check a Windows host directly, no VBR API --------------------------
    [string]$ComputerName,
    [switch]$RemoteCheck,   # kept for compatibility; -ComputerName is enough

    # --- Check this machine -------------------------------------------------
    [switch]$LocalCheck,

    # --- Linux / VSA over SSH -----------------------------------------------
    [string]$SshServer,
    [string]$SshUser,
    [int]$SshPort = 22,
    [System.Management.Automation.PSCredential]$SshCredential,
    [string]$SshKeyFile,
    [ValidateSet('Stream','UploadDelete','UploadKeep')][string]$SshMode = 'Stream',
    # Absolute POSIX path, restricted charset - it is interpolated into a
    # remote shell command line, so no quotes, spaces, or metacharacters.
    [ValidatePattern('^/[A-Za-z0-9._/-]+$')]
    [string]$SshRemotePath = '/tmp/veeam-portcheck.sh',
    [switch]$UseSudo,

    # --- Linux / VSA helper -------------------------------------------------
    [string]$EmitLinuxScript,

    # --- Scope --------------------------------------------------------------
    [switch]$IncludeEnterpriseManager,
    [switch]$IncludeCloudConnect,
    [switch]$IncludeWanAccelerator,
    [switch]$SkipDynamicRange,
    [string]$OutFile,

    # --- TLS / certificate diagnostics ---------------------------------------
    [switch]$TlsProbe,  # with -Target: real TLS handshakes, not just TCP connects
    [int[]]$TlsPorts,   # extra ports for -TlsProbe (e.g. the port from the log)
    [switch]$CertAudit, # run ON the backup server: store/key/ACL audit
    [string]$Thumbprint, # with -CertAudit: audit this specific certificate
    [switch]$CrlCheck,  # outbound CRL/OCSP/CTL reachability (port 80). Standalone,
                        # or combine with -TlsProbe / -CertAudit to probe the URLs
                        # carried by the certs those modes find
    [string[]]$CrlUrls, # extra revocation URLs to probe with -CrlCheck

    # --- App-aware / guest processing diagnostics ----------------------------
    [switch]$GuestCheck,          # run the guest check on THIS machine (elevated)
    [string]$GuestTarget,         # run the guest check against a remote guest over WinRM
    [switch]$GuestPorts,          # with -GuestTarget: TCP reachability for guest processing
    [ValidateSet('Network','Credentials','VSS','Application','Agent')]
    [string[]]$GuestGroups,       # limit the guest check to these groups
    [ValidateRange(1,90)][int]$EventLogDays = 7,
    [switch]$NoSqlQuery,          # skip the live SQL database/sysadmin queries
    [switch]$FailuresOnly,        # hide PASS/INFO rows in the guest report
    [string]$HtmlOut,             # write this run as a self-contained .html report

    # --- Veeam log triage ----------------------------------------------------
    [switch]$ParseLogs,
    [string]$LogPath,             # a .log file, or a folder to search recursively
    [ValidateRange(1,365)][int]$SinceDays = 14,
    [switch]$ShowAllLogHits,

    # --- Error code lookup ----------------------------------------------------
    [string]$ErrorCode,           # 1722, 0x800706BA, 0x800423F4 ... then exit

    # --- Remote reachability mode -------------------------------------------
    [string]$Target,
    [switch]$Probe,     # with -Target: DNS check + ports + HTTP probe, no login
    [switch]$ScanRange,
    [ValidateRange(2500,3300)][int]$RangeStart = 2500,
    [ValidateRange(2500,3300)][int]$RangeEnd   = 3300
)

$ErrorActionPreference = 'Continue'

$script:ScriptDir        = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$script:LinuxScriptName  = 'veeam-portcheck.sh'
$script:LastResults      = @()
$script:LastResultHost   = ''
$script:AllResults       = @()
$script:VbrConnected     = $false
$script:VbrServerName    = ''
$script:VbrPlatform      = 'Unknown'
$script:VbrCred          = $null
$script:LastGuestFindings = @()
$script:LastGuestPayload  = $null
$script:LastPortPayload   = $null
$script:LastGuestHost     = ''
$script:AllGuestFindings  = @()
$script:LastLogHits       = @()

# =============================================================================
#  FUNCTION LOADER
#  Every *.ps1 under functions\ is dot-sourced into this script's scope, so a
#  new function file dropped into that folder is picked up automatically -
#  no registration list to maintain. Because dot-sourcing runs each file in
#  THIS script's scope, the shared port tables (functions\PortTables.ps1) and
#  all $script: state behave exactly as they did in the single-file version.
# =============================================================================

$script:FunctionsDir = Join-Path $script:ScriptDir 'functions'
if (-not (Test-Path $script:FunctionsDir -PathType Container)) {
    Write-Host ''
    Write-Host ('  ERROR: functions folder not found at {0}' -f $script:FunctionsDir) -ForegroundColor Red
    Write-Host '  portest3.ps1 is modular - copy the functions folder along with it.' -ForegroundColor Red
    exit 2
}
foreach ($functionFile in @(Get-ChildItem -Path $script:FunctionsDir -Filter '*.ps1' -File | Sort-Object Name)) {
    try {
        . $functionFile.FullName
    } catch {
        Write-Host ('  ERROR: failed to load {0}: {1}' -f $functionFile.Name, $_.Exception.Message) -ForegroundColor Red
        exit 2
    }
}

# =============================================================================
#  NON-INTERACTIVE ENTRY POINTS
# =============================================================================

# -ErrorCode is a pure lookup against functions\GuestKnowledge.ps1 - no host is
# touched, nothing is collected. It resolves before every other mode so that
# "what does 1722 mean" never needs a target.
if ($ErrorCode) {
    Write-Banner 'Veeam Error Code Lookup' $ErrorCode
    Show-GuestErrorCode -Code $ErrorCode
    Write-Host ''
    exit 0
}

# The entry points below are mutually exclusive and resolve in this order.
# Warn rather than silently drop a mode the caller also asked for.
$requestedModes = @()
if ($SshServer)       { $requestedModes += '-SshServer' }
if ($VbrServer)       { $requestedModes += '-VbrServer' }
if ($ComputerName)    { $requestedModes += '-ComputerName' }
if ($LocalCheck)      { $requestedModes += '-LocalCheck' }
if ($CertAudit)       { $requestedModes += '-CertAudit' }
if ($Target)          { $requestedModes += '-Target' }
if ($GuestCheck)      { $requestedModes += '-GuestCheck' }
if ($GuestTarget)     { $requestedModes += '-GuestTarget' }
if ($ParseLogs)       { $requestedModes += '-ParseLogs' }
if ($requestedModes.Count -gt 1) {
    Write-Host ''
    Write-Host ('  Note: {0} were all supplied. Only {1} will run.' -f
        ($requestedModes -join ', '), $requestedModes[0]) -ForegroundColor Yellow
}
if (-not $SshServer -and ($SshUser -or $SshKeyFile -or $UseSudo -or $SshMode -ne 'Stream')) {
    Write-Host ''
    Write-Host '  Note: the -Ssh* / -UseSudo options are ignored without -SshServer.' -ForegroundColor Yellow
}
if (($TlsProbe -or $TlsPorts) -and -not $Target) {
    Write-Host ''
    Write-Host '  Note: -TlsProbe / -TlsPorts need -Target <host> to have anything to probe.' -ForegroundColor Yellow
}
if ($Thumbprint -and -not $CertAudit) {
    Write-Host ''
    Write-Host '  Note: -Thumbprint is ignored without -CertAudit.' -ForegroundColor Yellow
}
if (($LogPath -or $ShowAllLogHits) -and -not $ParseLogs) {
    Write-Host ''
    Write-Host '  Note: -LogPath / -ShowAllLogHits are ignored without -ParseLogs.' -ForegroundColor Yellow
}
if ($GuestPorts -and -not $GuestTarget) {
    Write-Host ''
    Write-Host '  Note: -GuestPorts needs -GuestTarget <guest> to have anything to scan.' -ForegroundColor Yellow
}
if ($HtmlOut -and -not ($GuestCheck -or $GuestTarget -or $ParseLogs -or
                        $LocalCheck -or $ComputerName -or $VbrServer -or $SshServer)) {
    Write-Host ''
    Write-Host '  Note: -HtmlOut applies to the conflict checks (-LocalCheck, -ComputerName,' -ForegroundColor Yellow
    Write-Host '        -VbrServer, -SshServer) and to -GuestCheck / -GuestTarget / -ParseLogs.' -ForegroundColor Yellow
    Write-Host '        The reachability, TLS and CRL probes are console-only.' -ForegroundColor Yellow
    Write-Host '        For a blueprint HTML report use veeam-blueprint.ps1.' -ForegroundColor Yellow
}
if (($GuestGroups -or $NoSqlQuery -or $FailuresOnly) -and -not ($GuestCheck -or $GuestTarget)) {
    Write-Host ''
    Write-Host '  Note: -GuestGroups / -NoSqlQuery / -FailuresOnly need -GuestCheck or -GuestTarget.' -ForegroundColor Yellow
}
if ($CrlUrls -and -not $CrlCheck) {
    Write-Host ''
    Write-Host '  Note: -CrlUrls is ignored without -CrlCheck.' -ForegroundColor Yellow
}

if ($SshServer) {
    Write-Banner 'Veeam Port Conflict Check (Linux over SSH)' $SshServer
    $payload = Invoke-LinuxCheckOverSsh -Server $SshServer -User $SshUser -Port $SshPort `
                   -Credential $SshCredential -KeyFile $SshKeyFile -Mode $SshMode `
                   -RemotePath $SshRemotePath -UseSudo:$UseSudo `
                   -NonInteractive:($null -ne $SshCredential -or [bool]$SshKeyFile)
    if ($OutFile) { Export-Results $OutFile }
    if ($HtmlOut) { Export-PortCheckHtml -OutPath $HtmlOut | Out-Null }
    Write-Host ''
    if (-not $payload) { exit 2 }
    if ($payload.Meta.CollectError) { exit 2 }

    $conflicts = @($payload.Results | Where-Object { $_.Status -eq 'CONFLICT' })
    $unknowns  = @($payload.Results | Where-Object { $_.Status -eq 'UNKNOWN' })
    if ($conflicts.Count -gt 0) { exit 1 }
    # UNKNOWN means the check resolved nothing - do not hand a pipeline a green
    # light. This is the normal outcome without root and without working sudo.
    if ($unknowns.Count -gt 0) { exit 2 }
    exit 0
}

if ($EmitLinuxScript -and -not $VbrServer) {
    Show-VsaGuidance
    Copy-LinuxScript $EmitLinuxScript | Out-Null
    Show-VsaConsoleOneLiner
    Write-Host ''
    exit 0
}

if ($VbrServer) {
    Invoke-VbrConnectAndCheck -Server $VbrServer -Port $VbrPort -Credential $VbrCredential `
        -AcceptCert:$ForceAcceptCert -WithEM:$IncludeEnterpriseManager `
        -WithCC:$IncludeCloudConnect -WithWan:$IncludeWanAccelerator -NoRange:$SkipDynamicRange
    if ($EmitLinuxScript) { Copy-LinuxScript $EmitLinuxScript | Out-Null }
    if ($OutFile) { Export-Results $OutFile }
    if ($HtmlOut) { Export-PortCheckHtml -OutPath $HtmlOut | Out-Null }
    if ($script:VbrConnected) { Disconnect-Vbr }
    Write-Host ''
    exit 0
}

if ($ComputerName) {
    Write-Banner 'Veeam Port Conflict Check (direct remoting)' $ComputerName
    $cred = $VbrCredential
    if (-not $cred) {
        $ans = (Read-Host '  Use current Windows credentials? [Y/n]').Trim().ToUpper()
        if ($ans -eq 'N') { $cred = Get-Credential -Message "Admin on $ComputerName" }
    }
    $payload = Invoke-RemoteCollector -Computer $ComputerName -Credential $cred `
        -WithEM:$IncludeEnterpriseManager -WithCC:$IncludeCloudConnect `
        -WithWan:$IncludeWanAccelerator -NoRange:$SkipDynamicRange
    if ($payload) { Save-Results $payload; Show-ConflictReport $payload }
    if ($OutFile) { Export-Results $OutFile }
    if ($HtmlOut) { Export-PortCheckHtml -OutPath $HtmlOut | Out-Null }
    Write-Host ''
    exit 0
}

if ($LocalCheck) {
    Write-Banner 'Veeam Port Conflict Check' $env:COMPUTERNAME
    $payload = Invoke-LocalCollector -WithEM:$IncludeEnterpriseManager `
        -WithCC:$IncludeCloudConnect -WithWan:$IncludeWanAccelerator -NoRange:$SkipDynamicRange
    Save-Results $payload
    Show-ConflictReport $payload
    if ($OutFile) { Export-Results $OutFile }
    if ($HtmlOut) { Export-PortCheckHtml -OutPath $HtmlOut | Out-Null }
    Write-Host ''
    exit 0
}

if ($CertAudit) {
    Invoke-LocalCertAudit -Thumbprint $Thumbprint
    if ($CrlCheck) { Invoke-CrlCheck -FromLocalStore -Thumbprint $Thumbprint -ExtraUrls $CrlUrls }
    Write-Host ''
    exit 0
}

if ($Target) {
    if ($RangeStart -gt $RangeEnd) {
        Write-Host "  Error: RangeStart ($RangeStart) must be <= RangeEnd ($RangeEnd)." -ForegroundColor Red
        exit 1
    }
    if ($TlsProbe -or $TlsPorts) {
        Write-Banner 'Veeam TLS Handshake Probe' $Target
        Invoke-TlsScan $Target -IncludeEM:$IncludeEnterpriseManager -ExtraPorts $TlsPorts `
            -CheckCrl:$CrlCheck -CrlExtraUrls $CrlUrls
        Write-Host ''
        exit 0
    }
    if ($Probe) {
        Invoke-RemoteProbe $Target -IncludeEM:$IncludeEnterpriseManager
        if ($ScanRange) { Invoke-RangeScan $Target $RangeStart $RangeEnd }
        Write-Host ''
        exit 0
    }
    Write-Banner 'Veeam Port Reachability' $Target
    Invoke-CoreScan $Target -IncludeEM:$IncludeEnterpriseManager
    if ($ScanRange) { Invoke-RangeScan $Target $RangeStart $RangeEnd }

    # -CrlCheck used to be silently dropped here: the standalone -CrlCheck
    # branch below is unreachable once -Target is set, and only the -TlsProbe
    # path above honoured it. '-Target x -CrlCheck' therefore did nothing,
    # one character away from the documented '-Target x -TlsProbe -CrlCheck'.
    if ($CrlCheck) {
        Write-Host ''
        Write-Banner 'Outbound CRL / Revocation Check' $env:COMPUTERNAME
        Invoke-CrlCheck -FromLocalStore -ExtraUrls $CrlUrls
    }

    Write-Host ''
    exit 0
}

if ($GuestCheck) {
    Write-Banner 'Veeam App-Aware Guest Check' $env:COMPUTERNAME
    $groups  = if ($GuestGroups) { $GuestGroups } else { $guestGroupsAll }
    $payload = Invoke-LocalGuestCheck -Groups $groups -EventLogDays $EventLogDays -NoSql:$NoSqlQuery
    Save-GuestFindings $payload
    Show-GuestReport $payload -FailuresOnly:$FailuresOnly
    if ($OutFile) { Export-GuestFindings $OutFile }
    if ($HtmlOut) { Export-GuestHtml -Payload $payload -OutPath $HtmlOut | Out-Null }
    Write-Host ''
    exit (Get-GuestExitCode $payload)
}

if ($GuestTarget) {
    Write-Banner 'Veeam App-Aware Guest Check' $GuestTarget

    if ($GuestPorts) { Invoke-GuestPortScan -TargetHost $GuestTarget }

    $cred = $VbrCredential
    if (-not $cred -and -not $PSBoundParameters.ContainsKey('VbrCredential')) {
        # Non-interactive callers get the current identity rather than a prompt
        # they cannot answer; the collector reports which account it ran as, so
        # an under-privileged run is visible in the report rather than silent.
        if ([Environment]::UserInteractive) {
            $ans = (Read-Host '  Use current Windows credentials? [Y/n]').Trim().ToUpper()
            if ($ans -eq 'N') { $cred = Get-Credential -Message "Local admin on $GuestTarget" }
        }
    }

    $groups  = if ($GuestGroups) { $GuestGroups } else { $guestGroupsAll }
    $payload = Invoke-RemoteGuestCheck -Computer $GuestTarget -Credential $cred `
                   -Groups $groups -EventLogDays $EventLogDays -NoSql:$NoSqlQuery
    if ($payload) {
        Save-GuestFindings $payload
        Show-GuestReport $payload -FailuresOnly:$FailuresOnly
        if ($OutFile) { Export-GuestFindings $OutFile }
        if ($HtmlOut) { Export-GuestHtml -Payload $payload -OutPath $HtmlOut | Out-Null }
    }
    Write-Host ''
    exit (Get-GuestExitCode $payload)
}

if ($ParseLogs) {
    Write-Banner 'Veeam Log Triage' $(if ($LogPath) { $LogPath } else { 'default log locations' })
    $hits = Invoke-VeeamLogTriage -Path $LogPath -SinceDays $SinceDays -ShowAll:$ShowAllLogHits
    if ($OutFile) { Export-LogTriage $OutFile }
    if ($HtmlOut) {
        Export-LogTriageHtml -OutPath $HtmlOut -Hits @($hits) -IncludeInfo:$ShowAllLogHits `
            -SourceName $(if ($LogPath) { $LogPath } else { 'default log locations' }) | Out-Null
    }
    Write-Host ''
    if (@($hits | Where-Object { $_.Severity -eq 'FAIL' }).Count -gt 0) { exit 1 }
    exit 0
}

if ($CrlCheck) {
    Write-Banner 'Outbound CRL / Revocation Check' $env:COMPUTERNAME
    Invoke-CrlCheck -FromLocalStore -ExtraUrls $CrlUrls
    Write-Host ''
    exit 0
}

# =============================================================================
#  INTERACTIVE MENU
# =============================================================================

Invoke-InteractiveMenu

if ($script:VbrConnected) { Disconnect-Vbr }
Write-Host ''
Write-Host '  Goodbye.' -ForegroundColor DarkCyan
Write-Host ''
