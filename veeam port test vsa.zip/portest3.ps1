<#
.SYNOPSIS
    Veeam port diagnostic - connects to a VBR server and finds port conflicts.

.DESCRIPTION
    Three kinds of check:

    CONNECT + LOCAL CHECK ON THE VBR SERVER
        Connect-VBRServer authenticates to the backup server (v13 default port
        443, -ForceAcceptTlsCertificate for self-signed) and identifies whether
        it is Windows or a Linux/Veeam Software Appliance.

        Windows backup server -> the conflict check is executed ON that host
        over PowerShell remoting (Invoke-Command). The collector needs only
        Get-NetTCPConnection / Get-Process / Win32_Service, so Windows
        PowerShell 5.1 on the target is enough - the Veeam module's PowerShell
        7.6.3 requirement does not apply to the collector.

        Linux / VSA -> see the constraint below.

    LOCAL CHECK ON THIS MACHINE
        Same collector, run against localhost.

    REMOTE REACHABILITY
        Plain TCP connect tests against a target (the portest2.ps1 behaviour).

    Conflict classification:
        OK        free, or held by Veeam / Windows / the config DB as expected
        CONFLICT  held by a process that is not the expected owner
        UNKNOWN   a listener exists but its owner could not be resolved

.NOTES
    ** VEEAM SOFTWARE APPLIANCE (v13) CONSTRAINT **
    There is no supported remote command execution path into a locked-down
    VSA. Per Veeam docs: SSH is off by default and, where a Security Officer
    account exists, must be approved before it can be enabled; the TUI root
    shell "cannot be accessed through SSH - only local connection through a
    physical console or a virtual remote console is supported", and approved
    root access lasts 8 hours. Veeam PowerShell modules are also explicitly
    unavailable in pre/post-job scripts on the appliance.

    So for a VSA this script does not pretend to find a back door. It:
      1. connects with Connect-VBRServer and confirms the server is Linux,
      2. pushes veeam-portcheck.sh over SSH and runs it, IF you have enabled
         SSH on the appliance,
      3. otherwise hands you the script to run in the console shell,
      4. or prints a compact one-liner for console-only access.

    SSH PUSH
        Two transports, auto-detected. Posh-SSH is preferred because it takes
        a PSCredential and so works unattended; native ssh.exe/scp.exe is the
        no-dependency fallback but OpenSSH prompts for the password itself, so
        only key auth (-SshKeyFile) is truly unattended there.

        Three delivery modes:
          Stream       (default) pipe the script to `bash -s` over stdin, so
                       nothing is ever written to the appliance filesystem
          UploadDelete scp to /tmp, run, remove
          UploadKeep   scp to /tmp and leave it for re-runs from the console

        The remote script is invoked with --report, a pipe-delimited format
        that is parsed back into the same objects the Windows collector
        returns. One renderer, and one CSV that can span a mixed estate.

        Use -UseSudo unless you log in as root. It uses `sudo -n`, so it
        fails cleanly rather than hanging if sudo wants a password.

        HOST KEY CAVEAT: the SSH calls use StrictHostKeyChecking=accept-new
        (native) and -AcceptKey (Posh-SSH), so the FIRST connection to a host
        trusts whatever key it presents without a fingerprint check. That is
        convenient for a diagnostic tool but it does not protect against a
        first-connect man-in-the-middle. If that matters in your environment,
        SSH to the appliance once by hand to pin the key in known_hosts, then
        run this.

    veeam-portcheck.sh must sit in the same folder as this script.

    Run ELEVATED for local checks and use an account with admin rights on the
    target for remote checks, or process owners resolve to UNKNOWN.

    Examples:
      .\portest3.ps1                                          # menu
      .\portest3.ps1 -LocalCheck
      .\portest3.ps1 -VbrServer vbr01.corp.local              # connect + check
      .\portest3.ps1 -VbrServer 10.0.0.5 -ForceAcceptCert
      .\portest3.ps1 -ComputerName vbr01                      # skip the VBR API
      .\portest3.ps1 -SshServer vsa01 -SshUser admin -UseSudo
      .\portest3.ps1 -SshServer vsa01 -SshUser root -SshKeyFile C:\keys\id_ed25519
      .\portest3.ps1 -SshServer vsa01 -SshMode UploadKeep -OutFile C:\temp\vsa.csv
      .\portest3.ps1 -EmitLinuxScript C:\temp                 # no SSH at all
      .\portest3.ps1 -Target 192.168.1.50 -ScanRange

    -SshServer exit codes: 0 clean, 1 conflicts found, 2 the check could not
    be completed. Safe to use in a pipeline.

    PORT DATA: $windowsPorts below is the source of truth for Windows checks.
    Confirmed from v13 docs: 443 (Connect-VBRServer default), 9392 (Windows
    backup server initial connection), 9405, 6160, 6162, 2500-3300, 5432,
    9419, 6172, 10006. Confirmed by search: 111/1058/2049 vPower NFS, and
    that from v13 vPower NFS hard-fails if 111 is locked. Others (6161, 9393,
    9401, 9380, EM, Cloud Connect, WAN) are from general knowledge and are
    marked Verified=$false - check them against the Ports page for your build
    and edit the table, not the logic.
#>

[CmdletBinding()]
param(
    # --- Connect to a VBR server and check it -------------------------------
    [string]$VbrServer,
    [int]$VbrPort = 443,
    [System.Management.Automation.PSCredential]$VbrCredential,
    [switch]$ForceAcceptCert,

    # --- Check a Windows host directly, no VBR API --------------------------
    [string]$ComputerName,
    [switch]$RemoteCheck,   # kept for compatibility; -ComputerName is enough

    # --- Check this machine -------------------------------------------------
    [switch]$LocalCheck,

    # --- Linux / VSA over SSH -----------------------------------------------
    [string]$SshServer,
    [string]$SshUser,
    [int]$SshPort = 22,
    [System.Management.Automation.PSCredential]$SshCredential,
    [string]$SshKeyFile,
    [ValidateSet('Stream','UploadDelete','UploadKeep')][string]$SshMode = 'Stream',
    # Absolute POSIX path, restricted charset - it is interpolated into a
    # remote shell command line, so no quotes, spaces, or metacharacters.
    [ValidatePattern('^/[A-Za-z0-9._/-]+$')]
    [string]$SshRemotePath = '/tmp/veeam-portcheck.sh',
    [switch]$UseSudo,

    # --- Linux / VSA helper -------------------------------------------------
    [string]$EmitLinuxScript,

    # --- Scope --------------------------------------------------------------
    [switch]$IncludeEnterpriseManager,
    [switch]$IncludeCloudConnect,
    [switch]$IncludeWanAccelerator,
    [switch]$SkipDynamicRange,
    [string]$OutFile,

    # --- Remote reachability mode -------------------------------------------
    [string]$Target,
    [switch]$ScanRange,
    [ValidateRange(2500,3300)][int]$RangeStart = 2500,
    [ValidateRange(2500,3300)][int]$RangeEnd   = 3300
)

$ErrorActionPreference = 'Continue'

$script:ScriptDir        = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$script:LinuxScriptName  = 'veeam-portcheck.sh'
$script:LastResults      = @()
$script:LastResultHost   = ''
$script:AllResults       = @()
$script:VbrConnected     = $false
$script:VbrServerName    = ''
$script:VbrPlatform      = 'Unknown'
$script:VbrCred          = $null

# =============================================================================
#  PORT TABLES
# =============================================================================
# ExpectedOwner : Veeam | Windows | Database
# Profile       : Core | EnterpriseManager | CloudConnect | WanAccelerator
# Verified      : $true if confirmed against v13 documentation

$windowsPorts = @(
    # -- vPower NFS - the classic upgrade blockers ----------------------------
    @{Port=111;   Proto='TCP+UDP'; ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Veeam vPower NFS Service (RPC portmapper)'
      Notes='HIGHEST RISK. From v13 the service fails to start if 111 is locked and the port cannot be changed. Common squatters: ONC/RPC Portmapper (portmap.exe), Windows "Server for NFS" / Services for UNIX, hanewin NFS, Arcserve, Cygwin rpcbind.'}
    @{Port=1058;  Proto='TCP+UDP'; ExpectedOwner='Veeam'; Profile='Core'; Verified=$false
      Component='Veeam vPower NFS mount service'
      Notes='Can be taken by RPC dynamic allocation or third-party NFS.'}
    @{Port=2049;  Proto='TCP+UDP'; ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Veeam vPower NFS server'
      Notes='HIGH RISK. Standard NFS port - any other NFS server on the box takes it.'}
    @{Port=6161;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$false
      Component='Veeam vPower NFS Service (control)'; Notes=''}

    # -- Backup server services ----------------------------------------------
    @{Port=9392;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Windows backup server - initial connection (console / EM)'; Notes=''}
    @{Port=443;   Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='v13 certificate/connection port; Connect-VBRServer default'
      Notes='Frequently taken by IIS, other web consoles, or an existing HTTPS binding.'}
    @{Port=9405;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Certificate port for EM collecting from v12 backup servers'; Notes=''}
    @{Port=9393;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$false
      Component='Veeam Guest Catalog Service'; Notes=''}
    @{Port=9401;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$false
      Component='Veeam Mount Service (mount server <-> backup server)'; Notes=''}
    @{Port=9419;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Veeam RESTful API Service (HTTPS)'; Notes='Optional at install - skip if REST API not installed.'}
    @{Port=6172;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Backup server database communication (Veeam Plug-in for Kasten)'; Notes=''}
    @{Port=10006; Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Backup server connection port'; Notes=''}
    @{Port=9380;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$false
      Component='Veeam Distribution Service (agent management)'; Notes=''}
    @{Port=6160;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Veeam Installer / Deployer Service'; Notes=''}
    @{Port=6162;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='Core'; Verified=$true
      Component='Veeam Data Mover / Transport Service'; Notes=''}

    # -- Configuration database ----------------------------------------------
    @{Port=5432;  Proto='TCP';     ExpectedOwner='Database'; Profile='Core'; Verified=$true
      Component='PostgreSQL - VBR configuration database (v12+)'
      Notes='A second PostgreSQL instance bundled with another product will collide.'}
    @{Port=1433;  Proto='TCP';     ExpectedOwner='Database'; Profile='Core'; Verified=$false
      Component='Microsoft SQL Server - VBR configuration database'
      Notes='Only relevant if the config DB is MSSQL.'}

    # -- OS ports Veeam depends on -------------------------------------------
    @{Port=135;   Proto='TCP';     ExpectedOwner='Windows'; Profile='Core'; Verified=$true
      Component='RPC Endpoint Mapper (component/agent deploy)'; Notes='Owned by svchost - expected.'}
    @{Port=445;   Proto='TCP';     ExpectedOwner='Windows'; Profile='Core'; Verified=$true
      Component='SMB (component deploy / upgrade file copy)'; Notes='Owned by System - expected.'}
    @{Port=139;   Proto='TCP';     ExpectedOwner='Windows'; Profile='Core'; Verified=$false
      Component='NetBIOS session service'; Notes='Owned by System - expected.'}

    # -- Enterprise Manager ---------------------------------------------------
    @{Port=9394;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='EnterpriseManager'; Verified=$false
      Component='Veeam Backup Enterprise Manager Service'; Notes=''}
    @{Port=9443;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='EnterpriseManager'; Verified=$false
      Component='Enterprise Manager web UI (HTTPS)'
      Notes='Commonly taken by VMware appliances and other web consoles.'}
    @{Port=9398;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='EnterpriseManager'; Verified=$false
      Component='Enterprise Manager RESTful API (HTTPS)'; Notes=''}
    @{Port=9399;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='EnterpriseManager'; Verified=$false
      Component='Enterprise Manager RESTful API (HTTP)'; Notes=''}
    @{Port=10443; Proto='TCP';     ExpectedOwner='Veeam'; Profile='EnterpriseManager'; Verified=$true
      Component='Veeam Host Management'; Notes=''}

    # -- Cloud Connect --------------------------------------------------------
    @{Port=6180;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='CloudConnect'; Verified=$false
      Component='Veeam Cloud Connect Service'; Notes=''}
    @{Port=10003; Proto='TCP';     ExpectedOwner='Veeam'; Profile='CloudConnect'; Verified=$false
      Component='Veeam Cloud Gateway'; Notes=''}

    # -- WAN accelerator ------------------------------------------------------
    @{Port=6164;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='WanAccelerator'; Verified=$false
      Component='Veeam WAN Accelerator Service (control)'; Notes=''}
    @{Port=6165;  Proto='TCP';     ExpectedOwner='Veeam'; Profile='WanAccelerator'; Verified=$false
      Component='Veeam WAN Accelerator Service (data)'; Notes=''}
)

# Reference only - the Linux check runs inside veeam-portcheck.sh
$linuxPortsReference = @(
    '443   Backup server initial connection + Identity Service; Guest Catalog replication'
    '6160  Veeam Deployer Service (veeamdeployment)'
    '6162  Veeam Transport Service / Data Mover (veeamtransport)'
    '6172  Backup server database communication'
    '9419  Veeam RESTful API Service'
    '10006 Backup server connection port'
    '10443 Veeam Host Management'
    '5432  PostgreSQL configuration database'
    '2500-3300  Data transfer range'
    'NOT CHECKED on Linux: 111 / 1058 / 2049 - vPower NFS is a Windows service.'
)

$knownRangeSquatters = @{
    2598 = 'Citrix ICA session reliability'
    2701 = 'SCCM / SMS remote control'
    2702 = 'SCCM / SMS remote control'
    2869 = 'Windows UPnP / SSDP event notification'
    2967 = 'Symantec Endpoint Protection'
    3050 = 'Firebird / InterBase database'
    3260 = 'iSCSI target'
    3268 = 'Active Directory Global Catalog (LDAP)'
    3269 = 'Active Directory Global Catalog (LDAPS)'
    3306 = 'MySQL / MariaDB'
}

# Remote reachability list
$corePorts = @(
    @{Port=443;   Description='v13 backup server connection / certificate port'}
    @{Port=9392;  Description='Windows backup server initial connection'}
    @{Port=9393;  Description='Veeam Guest Catalog Service'}
    @{Port=9401;  Description='Veeam Mount Service'}
    @{Port=9419;  Description='Veeam RESTful API Service'}
    @{Port=9380;  Description='Veeam Distribution Service'}
    @{Port=6160;  Description='Veeam Installer / Deployer Service'}
    @{Port=6162;  Description='Veeam Data Mover / Transport Service'}
    @{Port=6161;  Description='Veeam vPower NFS Service'}
    @{Port=2500;  Description='Data transfer range start (2500-3300)'}
    @{Port=3300;  Description='Data transfer range end   (2500-3300)'}
    @{Port=445;   Description='SMB - component deploy/upgrade'}
    @{Port=135;   Description='RPC Endpoint Mapper'}
)

# =============================================================================
#  THE COLLECTOR
#  Self-contained so it can run locally or via Invoke-Command against a
#  Windows host. Returns a hashtable: @{ Results=<pscustomobject[]>; Meta=@{} }
#  No dependency on anything outside this scriptblock.
# =============================================================================

$collector = {
    param(
        [object[]]$PortTable,
        [bool]$CheckRange   = $true,
        [int]$RangeLo       = 2500,
        [int]$RangeHi       = 3300,
        [hashtable]$Squatters = @{}
    )

    function Get-Listeners {
        $tcp = @{}; $udp = @{}; $fallback = $false; $collectError = ''

        if (Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue) {
            try {
                foreach ($c in @(Get-NetTCPConnection -State Listen -ErrorAction Stop)) {
                    $p = [int]$c.LocalPort
                    if (-not $tcp.ContainsKey($p)) { $tcp[$p] = @() }
                    if ($tcp[$p] -notcontains [int]$c.OwningProcess) { $tcp[$p] += [int]$c.OwningProcess }
                }
            } catch { $collectError = $_.Exception.Message }
            try {
                foreach ($u in @(Get-NetUDPEndpoint -ErrorAction Stop)) {
                    $p = [int]$u.LocalPort
                    if (-not $udp.ContainsKey($p)) { $udp[$p] = @() }
                    if ($udp[$p] -notcontains [int]$u.OwningProcess) { $udp[$p] += [int]$u.OwningProcess }
                }
            } catch { if (-not $collectError) { $collectError = $_.Exception.Message } }
        }

        # An empty TCP table means the modern path is missing or failed. A host
        # with zero TCP listeners is not a real scenario, so fall back rather
        # than reporting every port FREE (which would read as "no conflicts").
        if ($tcp.Count -eq 0) {
            if (-not (Get-Command netstat -ErrorAction SilentlyContinue)) {
                return @{ TCP=$tcp; UDP=$udp; Fallback=$false
                          Error=("Could not enumerate listeners. " + $collectError).Trim() }
            }
            $fallback = $true
            try {
                foreach ($line in (netstat -ano)) {
                    $t = $line.Trim()
                    if ($t -match '^TCP\s+\S+:(\d+)\s+\S+\s+LISTENING\s+(\d+)$') {
                        $p = [int]$Matches[1]; $procId = [int]$Matches[2]
                        if (-not $tcp.ContainsKey($p)) { $tcp[$p] = @() }
                        if ($tcp[$p] -notcontains $procId) { $tcp[$p] += $procId }
                    } elseif ($t -match '^UDP\s+\S+:(\d+)\s+\S+\s+(\d+)$') {
                        $p = [int]$Matches[1]; $procId = [int]$Matches[2]
                        if (-not $udp.ContainsKey($p)) { $udp[$p] = @() }
                        if ($udp[$p] -notcontains $procId) { $udp[$p] += $procId }
                    }
                }
            } catch { $collectError = $_.Exception.Message }
            if ($tcp.Count -eq 0) {
                return @{ TCP=$tcp; UDP=$udp; Fallback=$true
                          Error=("Listener enumeration returned nothing. " + $collectError).Trim() }
            }
        }

        return @{ TCP = $tcp; UDP = $udp; Fallback = $fallback; Error = '' }
    }

    function Get-Processes {
        $map = @{}; $svcByPid = @{}
        try {
            foreach ($s in @(Get-CimInstance Win32_Service -ErrorAction Stop |
                             Where-Object { $_.ProcessId -and $_.ProcessId -gt 0 })) {
                $k = [int]$s.ProcessId
                if (-not $svcByPid.ContainsKey($k)) { $svcByPid[$k] = @() }
                $svcByPid[$k] += $s.Name
            }
        } catch { }
        foreach ($p in @(Get-Process -ErrorAction SilentlyContinue)) {
            $path = ''; $company = ''
            try { $path    = $p.Path }    catch { }
            try { $company = $p.Company } catch { }
            $map[[int]$p.Id] = @{
                Name     = $p.ProcessName
                Path     = $path
                Company  = $company
                Services = @(if ($svcByPid.ContainsKey([int]$p.Id)) { $svcByPid[[int]$p.Id] })
            }
        }
        return $map
    }

    function Get-Class($procId, $map) {
        if ($procId -eq 0 -or $procId -eq 4) { return 'Windows' }
        if (-not $map.ContainsKey([int]$procId)) { return 'Unknown' }
        $i   = $map[[int]$procId]
        $hay = '{0} {1} {2} {3}' -f $i.Name, $i.Path, $i.Company, ($i.Services -join ' ')
        if ($hay -match '(?i)veeam') { return 'Veeam' }
        if ($i.Name -match '(?i)^(postgres|postmaster|sqlservr|mysqld|mariadbd)$') { return 'Database' }
        if ($i.Name -match '(?i)^(System|Idle|svchost|lsass|services|spoolsv|wininit|dns|Registry|dfsrs|inetinfo)$') { return 'Windows' }
        if ($i.Path -and $i.Path -match '(?i)^[A-Z]:\\Windows\\') { return 'Windows' }
        return 'ThirdParty'
    }

    function Get-Owner($procId, $map) {
        if ($procId -eq 0 -or $procId -eq 4) { return 'System (kernel)' }
        if (-not $map.ContainsKey([int]$procId)) { return "PID $procId (unresolved - run elevated)" }
        $i = $map[[int]$procId]
        $d = '{0} (PID {1})' -f $i.Name, $procId
        if ($i.Services.Count -gt 0) { $d += ' svc:' + ($i.Services -join ',') }
        if ($i.Path) { $d += ' [' + $i.Path + ']' }
        return $d
    }

    $elevated = $false
    try {
        $elevated = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                    ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { }

    $listeners = Get-Listeners
    $procs     = Get-Processes
    $results   = @()

    foreach ($entry in $PortTable) {
        $protos = @()
        if ([string]$entry.Proto -like '*TCP*') { $protos += 'TCP' }
        if ([string]$entry.Proto -like '*UDP*') { $protos += 'UDP' }

        foreach ($proto in $protos) {
            $table = if ($proto -eq 'TCP') { $listeners.TCP } else { $listeners.UDP }
            $port  = [int]$entry.Port
            $pids  = @(if ($table.ContainsKey($port)) { $table[$port] })

            if ($pids.Count -eq 0) {
                $results += [pscustomobject]@{
                    Port=$port; Protocol=$proto; Status='FREE'; OwnerType=''; Owner=''
                    Component=[string]$entry.Component; Verified=[bool]$entry.Verified
                    Notes=[string]$entry.Notes; InRange=$false
                }
                continue
            }
            foreach ($procId in $pids) {
                $cls = Get-Class $procId $procs
                $st  = if ($cls -eq 'Unknown') { 'UNKNOWN' }
                       elseif ($cls -eq [string]$entry.ExpectedOwner) { 'OK' }
                       else { 'CONFLICT' }
                $results += [pscustomobject]@{
                    Port=$port; Protocol=$proto; Status=$st; OwnerType=$cls
                    Owner=(Get-Owner $procId $procs)
                    Component=[string]$entry.Component; Verified=[bool]$entry.Verified
                    Notes=[string]$entry.Notes; InRange=$false
                }
            }
        }
    }

    if ($CheckRange) {
        foreach ($port in @($listeners.TCP.Keys | Where-Object { $_ -ge $RangeLo -and $_ -le $RangeHi } | Sort-Object)) {
            foreach ($procId in $listeners.TCP[[int]$port]) {
                $cls = Get-Class $procId $procs
                if ($cls -eq 'Veeam') { continue }
                $note = if ($Squatters.ContainsKey([int]$port)) { $Squatters[[int]$port] } else { '' }
                $rangeStatus = if ($cls -eq 'Unknown') { 'UNKNOWN' } else { 'CONFLICT' }
                $results += [pscustomobject]@{
                    Port=[int]$port; Protocol='TCP'
                    Status=$rangeStatus
                    OwnerType=$cls; Owner=(Get-Owner $procId $procs)
                    Component=("Data transfer range {0}-{1}" -f $RangeLo, $RangeHi)
                    Verified=$true; Notes=$note; InRange=$true
                }
            }
        }
    }

    $veeamSvcs = @()
    try {
        $veeamSvcs = @(Get-Service -ErrorAction SilentlyContinue |
                       Where-Object { $_.Name -like 'Veeam*' -or $_.DisplayName -like 'Veeam*' } |
                       ForEach-Object { [pscustomobject]@{ Name=$_.Name; DisplayName=$_.DisplayName; Status=[string]$_.Status } })
    } catch { }

    $osCaption = ''
    try { $osCaption = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).Caption } catch { }

    return @{
        Results = $results
        Meta    = @{
            Host         = $env:COMPUTERNAME
            OS           = $osCaption
            Elevated     = $elevated
            Fallback     = $listeners.Fallback
            CollectError = [string]$listeners.Error
            RangeChecked = $CheckRange
            TcpCount     = $listeners.TCP.Count
            UdpCount     = $listeners.UDP.Count
            ProcCount    = $procs.Count
            Services     = $veeamSvcs
            Collected    = (Get-Date)
        }
    }
}

# =============================================================================
#  RENDERING
# =============================================================================

function Write-Rule($text, $color = 'Yellow') {
    $pad = [math]::Max(0, 54 - $text.Length)
    Write-Host ('-- {0} {1}' -f $text, ('-' * $pad)) -ForegroundColor $color
}

function Write-Banner($title, $subject) {
    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host ("  {0}  ->  {1}" -f $title, $subject) -ForegroundColor Cyan
    Write-Host ("  {0}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) -ForegroundColor DarkCyan
    Write-Host '=======================================================' -ForegroundColor Cyan
}

function Show-ConflictReport($payload) {
    if (-not $payload) { Write-Host '  No data returned.' -ForegroundColor Red; return }

    $results = @($payload.Results)
    $meta    = $payload.Meta

    Write-Host ''
    Write-Host ('  Host      : {0}' -f $meta.Host) -ForegroundColor White
    if ($meta.OS) { Write-Host ('  OS        : {0}' -f $meta.OS) -ForegroundColor DarkCyan }
    if ($meta.ProcCount -gt 0) {
        Write-Host ('  Listeners : {0} TCP, {1} UDP across {2} processes' -f
            $meta.TcpCount, $meta.UdpCount, $meta.ProcCount) -ForegroundColor DarkCyan
    } else {
        Write-Host ('  Listeners : {0} TCP, {1} UDP' -f $meta.TcpCount, $meta.UdpCount) -ForegroundColor DarkCyan
    }
    if (-not $meta.Elevated) {
        Write-Host '  ! Collector was not elevated - some owners may read UNKNOWN.' -ForegroundColor Yellow
    }
    if ($meta.Fallback) {
        Write-Host '  (NetTCPIP unavailable or empty on target - used netstat fallback.)' -ForegroundColor DarkYellow
    }
    if ($meta.CollectError) {
        Write-Host ''
        Write-Host '  ***********************************************************' -ForegroundColor Red
        Write-Host '  LISTENER ENUMERATION FAILED - RESULTS BELOW ARE NOT VALID.' -ForegroundColor Red
        Write-Host ('  {0}' -f $meta.CollectError) -ForegroundColor Red
        Write-Host '  Every port will read FREE. Do not treat this as an all-clear.' -ForegroundColor Red
        Write-Host '  ***********************************************************' -ForegroundColor Red
    }

    Write-Host ''
    Write-Rule 'Veeam Port Ownership'
    Write-Host ''
    Write-Host ('  {0,-6} {1,-5} {2,-9} {3}' -f 'PORT','PROTO','STATUS','OWNER / COMPONENT') -ForegroundColor White
    Write-Host ('  ' + ('-' * 84)) -ForegroundColor DarkGray

    foreach ($r in ($results | Where-Object { -not $_.InRange })) {
        $color = switch ($r.Status) {
            'CONFLICT' { 'Red' }
            'UNKNOWN'  { 'Yellow' }
            'OK'       { 'Green' }
            default    { 'DarkGray' }
        }
        $right = if ($r.Owner) { $r.Owner } else { $r.Component }
        $flag  = if (-not $r.Verified) { '~' } else { ' ' }
        Write-Host ('  {0,-6}{1}{2,-5} {3,-9} {4}' -f $r.Port, $flag, $r.Protocol, $r.Status, $right) -ForegroundColor $color
        if ($r.Status -eq 'CONFLICT' -or $r.Status -eq 'UNKNOWN') {
            Write-Host ('           -> needs: {0}' -f $r.Component) -ForegroundColor DarkGray
        }
    }
    Write-Host ''
    Write-Host '  ~ = port number not confirmed against v13 docs (see header notes)' -ForegroundColor DarkGray

    # -- range ----------------------------------------------------------------
    $rangeRows = @($results | Where-Object { $_.InRange })
    Write-Host ''
    Write-Rule 'Data Transfer Range 2500-3300'
    if (-not $meta.RangeChecked) {
        Write-Host '  NOT CHECKED - the range scan was skipped for this run.' -ForegroundColor Yellow
    } elseif ($rangeRows.Count -eq 0) {
        Write-Host '  No non-Veeam process is listening in the range.' -ForegroundColor Green
    } else {
        Write-Host ('  {0} non-Veeam listener(s) inside the range:' -f $rangeRows.Count) -ForegroundColor Red
        foreach ($r in $rangeRows) {
            $line = '    {0,-6} {1}' -f $r.Port, $r.Owner
            if ($r.Notes) { $line += '  [' + $r.Notes + ']' }
            Write-Host $line -ForegroundColor Red
        }
        Write-Host ''
        Write-Host '  Veeam takes one port from this range per job TCP connection. A few' -ForegroundColor DarkCyan
        Write-Host '  occupied ports are tolerable; large blocks are not.' -ForegroundColor DarkCyan
    }

    # -- services -------------------------------------------------------------
    $svcs = @($meta.Services)
    Write-Host ''
    Write-Rule 'Veeam Services On That Host'
    if ($svcs.Count -eq 0) {
        Write-Host '  No Veeam services found - treating as a pre-install host.' -ForegroundColor DarkCyan
    } else {
        foreach ($s in $svcs) {
            $c = if ($s.Status -eq 'Running') { 'Green' } else { 'Yellow' }
            Write-Host ('  {0,-9} {1}' -f $s.Status, $s.DisplayName) -ForegroundColor $c
        }
        $stopped = @($svcs | Where-Object { $_.Status -ne 'Running' })
        if ($stopped.Count -gt 0) {
            Write-Host ''
            Write-Host ('  {0} Veeam service(s) not running. A port they own reads FREE now but' -f $stopped.Count) -ForegroundColor Yellow
            Write-Host '  must still be free when the upgrade restarts them.' -ForegroundColor Yellow
        }
    }

    # -- verdict --------------------------------------------------------------
    $conflicts = @($results | Where-Object { $_.Status -eq 'CONFLICT' })
    $unknowns  = @($results | Where-Object { $_.Status -eq 'UNKNOWN' })

    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    if ($meta.CollectError) {
        Write-Host '  RESULT: INCONCLUSIVE - listeners could not be enumerated.' -ForegroundColor Red
    } elseif ($conflicts.Count -eq 0 -and $unknowns.Count -eq 0) {
        if ($meta.RangeChecked) {
            Write-Host '  RESULT: No port conflicts detected.' -ForegroundColor Green
        } else {
            Write-Host '  RESULT: No conflicts on the named ports. Range 2500-3300 NOT checked.' -ForegroundColor Yellow
        }
    } else {
        if ($conflicts.Count -gt 0) {
            Write-Host ('  RESULT: {0} CONFLICT(S) - resolve before upgrading VBR.' -f $conflicts.Count) -ForegroundColor Red
            Write-Host ''
            foreach ($c in $conflicts) {
                Write-Host ('  * {0}/{1} held by {2}' -f $c.Port, $c.Protocol, $c.Owner) -ForegroundColor Red
                Write-Host ('    Needed by: {0}' -f $c.Component) -ForegroundColor DarkGray
                if ($c.Notes) { Write-Host ('    {0}' -f $c.Notes) -ForegroundColor DarkGray }
            }
        }
        if ($unknowns.Count -gt 0) {
            Write-Host ''
            Write-Host ('  {0} port(s) have an unresolvable owner - re-run with admin rights on the target.' -f $unknowns.Count) -ForegroundColor Yellow
        }
    }
    Write-Host '=======================================================' -ForegroundColor Cyan
}

# =============================================================================
#  RUNNING THE COLLECTOR
# =============================================================================

function Get-ScopedPortTable {
    param([switch]$WithEM, [switch]$WithCC, [switch]$WithWan)
    $profiles = @('Core')
    if ($WithEM)  { $profiles += 'EnterpriseManager' }
    if ($WithCC)  { $profiles += 'CloudConnect' }
    if ($WithWan) { $profiles += 'WanAccelerator' }
    return @($windowsPorts | Where-Object { $profiles -contains $_.Profile })
}

function Invoke-LocalCollector {
    param([switch]$WithEM, [switch]$WithCC, [switch]$WithWan, [switch]$NoRange)
    $table = Get-ScopedPortTable -WithEM:$WithEM -WithCC:$WithCC -WithWan:$WithWan
    return (& $collector $table (-not $NoRange) 2500 3300 $knownRangeSquatters)
}

function Invoke-RemoteCollector {
    param(
        [Parameter(Mandatory)][string]$Computer,
        [System.Management.Automation.PSCredential]$Credential,
        [switch]$WithEM, [switch]$WithCC, [switch]$WithWan, [switch]$NoRange
    )
    $table = Get-ScopedPortTable -WithEM:$WithEM -WithCC:$WithCC -WithWan:$WithWan

    Write-Host ''
    Write-Host ('  Opening a PowerShell remoting session to {0}...' -f $Computer) -ForegroundColor DarkCyan

    $icmArgs = @{
        ComputerName = $Computer
        ScriptBlock  = $collector
        ArgumentList = @($table, (-not $NoRange), 2500, 3300, $knownRangeSquatters)
        ErrorAction  = 'Stop'
    }
    if ($Credential) { $icmArgs['Credential'] = $Credential }

    try {
        return (Invoke-Command @icmArgs)
    } catch {
        Write-Host ''
        Write-Host ('  Remoting to {0} failed: {1}' -f $Computer, $_.Exception.Message) -ForegroundColor Red
        Write-Host ''
        Write-Host '  Things to check on the target:' -ForegroundColor Yellow
        Write-Host '    Enable-PSRemoting -Force            (run on the backup server)' -ForegroundColor DarkCyan
        Write-Host '    Test-WSMan -ComputerName <server>   (run from here)' -ForegroundColor DarkCyan
        Write-Host '    TCP 5985/5986 open, and the account is a local admin on the target.' -ForegroundColor DarkCyan
        Write-Host '    For a non-domain target, add it to TrustedHosts:' -ForegroundColor DarkCyan
        Write-Host '      Set-Item WSMan:\localhost\Client\TrustedHosts -Value <server> -Concatenate' -ForegroundColor DarkCyan
        return $null
    }
}

function Export-Results($path) {
    if (-not $script:LastResults -or $script:LastResults.Count -eq 0) {
        Write-Host '  Nothing to export - run a conflict check first.' -ForegroundColor Red
        return
    }
    try {
        $script:LastResults |
            Select-Object @{n='Host';e={$script:LastResultHost}}, Port, Protocol, Status,
                          OwnerType, Owner, Component, Verified, Notes |
            Sort-Object Status, Port |
            Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
        Write-Host ('  Exported {0} rows to {1}' -f $script:LastResults.Count, $path) -ForegroundColor Green
    } catch {
        Write-Host ('  Export failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
    }
}

function Save-Results($payload) {
    # Always overwrite, so a failed run cannot leave a previous host's rows
    # sitting there waiting to be exported as if they were current.
    if ($payload) {
        $script:LastResults    = @($payload.Results)
        $script:LastResultHost = [string]$payload.Meta.Host

        # Accumulate for the mixed-estate CSV - but never accumulate a run we
        # already know is invalid, or the CSV would look clean while the
        # console said the results were not valid.
        if ($payload.Meta.CollectError) {
            Write-Host '  (Not adding this run to the session CSV - the collection failed.)' -ForegroundColor DarkYellow
            return
        }
        $hostName = [string]$payload.Meta.Host
        $platform = if ($payload.Meta.Platform) { [string]$payload.Meta.Platform } else { 'Windows' }
        $stamp    = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        foreach ($r in @($payload.Results)) {
            $script:AllResults += [pscustomobject]@{
                Host=$hostName; Platform=$platform; Checked=$stamp
                Port=$r.Port; Protocol=$r.Protocol; Status=$r.Status
                OwnerType=$r.OwnerType; Owner=$r.Owner; Component=$r.Component
                Verified=$r.Verified; Notes=$r.Notes
            }
        }
    } else {
        $script:LastResults    = @()
        $script:LastResultHost = ''
    }
}

function Export-AllResults($path) {
    if (-not $script:AllResults -or $script:AllResults.Count -eq 0) {
        Write-Host '  Nothing accumulated yet - run at least one conflict check.' -ForegroundColor Red
        return
    }
    try {
        $script:AllResults |
            Sort-Object Host, Status, Port |
            Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
        $hosts = @($script:AllResults | Select-Object -ExpandProperty Host -Unique).Count
        Write-Host ('  Exported {0} rows across {1} host(s) to {2}' -f
            $script:AllResults.Count, $hosts, $path) -ForegroundColor Green
    } catch {
        Write-Host ('  Export failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
    }
}

# =============================================================================
#  VBR CONNECTION LAYER
# =============================================================================

function Import-VeeamModule {
    if (Get-Module Veeam.Backup.PowerShell) { return $true }
    try {
        $path = [Environment]::GetEnvironmentVariable('PSModulePath','Machine')
        if ($path) { $env:PSModulePath += [System.IO.Path]::PathSeparator + $path }
    } catch { }
    $m = Get-Module -ListAvailable -Name 'Veeam.Backup.PowerShell' -ErrorAction SilentlyContinue |
         Sort-Object Version -Descending | Select-Object -First 1
    if (-not $m) {
        Write-Host ''
        Write-Host '  Veeam.Backup.PowerShell module not found.' -ForegroundColor Red
        Write-Host '  On Windows it installs with the Veeam Backup & Replication console.' -ForegroundColor DarkCyan
        Write-Host '  v13 also requires PowerShell 7.6.3 or later for Veeam cmdlets.' -ForegroundColor DarkCyan
        Write-Host ('  This session is PowerShell {0}.' -f $PSVersionTable.PSVersion) -ForegroundColor DarkCyan
        return $false
    }
    try {
        Import-Module $m.Path -DisableNameChecking -ErrorAction Stop
        return $true
    } catch {
        Write-Host ('  Failed to import Veeam module: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $false
    }
}

function Connect-Vbr {
    param(
        [Parameter(Mandatory)][string]$Server,
        [int]$Port = 443,
        [System.Management.Automation.PSCredential]$Credential,
        [switch]$AcceptCert
    )

    if (-not (Import-VeeamModule)) { return $false }

    if (-not $Credential) {
        Write-Host ''
        Write-Host '  Credentials for the Veeam backup server.' -ForegroundColor DarkCyan
        Write-Host '  Use DOMAIN\User or UPN format. MFA and SAML accounts are not supported' -ForegroundColor DarkCyan
        Write-Host '  by Veeam PowerShell. The account needs the Backup Administrator role.' -ForegroundColor DarkCyan
        $Credential = Get-Credential -Message "Veeam backup server: $Server"
        if (-not $Credential) { Write-Host '  Cancelled.' -ForegroundColor Red; return $false }
    }
    $script:VbrCred = $Credential

    # One VBR connection per PowerShell session - drop any existing one.
    try {
        if (Get-Command Get-VBRServerSession -ErrorAction SilentlyContinue) {
            if (Get-VBRServerSession -ErrorAction SilentlyContinue) {
                Disconnect-VBRServer -ErrorAction SilentlyContinue
            }
        }
    } catch { }

    $connArgs = @{ Server = $Server; Port = $Port; Credential = $Credential; ErrorAction = 'Stop' }
    if ($AcceptCert) {
        $connectCmd = Get-Command Connect-VBRServer -ErrorAction SilentlyContinue
        if ($connectCmd -and $connectCmd.Parameters -and
            $connectCmd.Parameters.ContainsKey('ForceAcceptTlsCertificate')) {
            $connArgs['ForceAcceptTlsCertificate'] = $true
        } else {
            Write-Host '  -ForceAcceptTlsCertificate not available in this module version (v13+ only) - skipping.' -ForegroundColor DarkYellow
        }
    }

    Write-Host ''
    Write-Host ('  Connecting to {0}:{1} ...' -f $Server, $Port) -ForegroundColor DarkCyan
    try {
        Connect-VBRServer @connArgs | Out-Null
    } catch {
        Write-Host ('  Connect-VBRServer failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        if ($_.Exception.Message -match '(?i)certificate|trust|ssl|tls') {
            Write-Host '  Looks like a certificate trust problem - retry with -ForceAcceptCert.' -ForegroundColor Yellow
        }
        if ($Port -ne 9392) {
            Write-Host '  If this is a v12 or older server, try -VbrPort 9392 (v13 default is 443).' -ForegroundColor Yellow
        }
        return $false
    }

    $script:VbrConnected  = $true
    $script:VbrServerName = $Server
    Write-Host '  Connected.' -ForegroundColor Green

    $script:VbrPlatform = Get-VbrPlatform
    Write-Host ('  Backup server platform: {0}' -f $script:VbrPlatform) -ForegroundColor Cyan
    return $true
}

function Get-VbrPlatform {
    # Get-VBRLinuxPackage is a v13 cmdlet that returns the Linux components
    # installed on the backup server - a non-empty result means Linux/VSA.
    # CHost properties are explicitly undocumented, so .Type is only a hint.
    try {
        if (Get-Command Get-VBRLinuxPackage -ErrorAction SilentlyContinue) {
            $pkgs = @(Get-VBRLinuxPackage -ErrorAction Stop)
            if ($pkgs.Count -gt 0) { return 'Linux' }
        }
    } catch { }

    try {
        $lh = Get-VBRLocalhost -ErrorAction Stop
        $t  = [string]$lh.Type
        if ($t -match '(?i)linux')             { return 'Linux' }
        if ($t -match '(?i)windows|^Local$')   { return 'Windows' }
        if ($t) { return "Unknown (Type=$t)" }
    } catch { }

    return 'Unknown'
}

function Disconnect-Vbr {
    try {
        if (Get-Command Disconnect-VBRServer -ErrorAction SilentlyContinue) {
            Disconnect-VBRServer -ErrorAction SilentlyContinue
        }
    } catch { }
    $script:VbrConnected  = $false
    $script:VbrServerName = ''
    $script:VbrPlatform   = 'Unknown'
    Write-Host '  Disconnected from VBR.' -ForegroundColor DarkCyan
}

function Show-VbrInfrastructure {
    if (-not $script:VbrConnected) { Write-Host '  Not connected.' -ForegroundColor Red; return }
    Write-Host ''
    Write-Rule 'Managed Servers (Get-VBRServer)'
    try {
        $srv = @(Get-VBRServer -ErrorAction Stop)
        if ($srv.Count -eq 0) { Write-Host '  None returned.' -ForegroundColor DarkCyan; return }
        foreach ($s in $srv) {
            Write-Host ('  {0,-14} {1}' -f [string]$s.Type, [string]$s.Name) -ForegroundColor DarkCyan
        }
        Write-Host ''
        Write-Host ('  {0} managed server(s). Windows ones can be checked with menu option 3.' -f $srv.Count) -ForegroundColor White
    } catch {
        Write-Host ('  Get-VBRServer failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
    }
}

# =============================================================================
#  LINUX / VSA PATH
# =============================================================================

function Get-LinuxScriptPath {
    $p = Join-Path $script:ScriptDir $script:LinuxScriptName
    if (Test-Path $p) { return $p }
    return $null
}

function Show-VsaGuidance {
    param([string]$ServerName = '(the appliance)')

    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host '  Linux / Veeam Software Appliance' -ForegroundColor Cyan
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host '  There is no supported remote command execution path into a' -ForegroundColor Yellow
    Write-Host '  locked-down VSA. Per Veeam documentation:' -ForegroundColor Yellow
    Write-Host ''
    Write-Host '    - SSH is off by default. Enabling it is a Host Administrator' -ForegroundColor DarkCyan
    Write-Host '      action in Host Management (web UI or TUI), and where a' -ForegroundColor DarkCyan
    Write-Host '      Security Officer account exists it needs their approval.' -ForegroundColor DarkCyan
    Write-Host '    - The TUI root shell cannot be reached over SSH at all -' -ForegroundColor DarkCyan
    Write-Host '      only a physical or virtual console. Approved root access' -ForegroundColor DarkCyan
    Write-Host '      lasts 8 hours from first login.' -ForegroundColor DarkCyan
    Write-Host '    - Veeam PowerShell modules are not available in pre/post-job' -ForegroundColor DarkCyan
    Write-Host '      scripts on the appliance.' -ForegroundColor DarkCyan
    Write-Host ''
    Write-Host '  Connect-VBRServer on 443 reaches the VBR API, not a shell, so it' -ForegroundColor DarkCyan
    Write-Host '  cannot enumerate OS listeners. Use one of the options below.' -ForegroundColor DarkCyan
    Write-Host ''
    Write-Host '  Ports checked on Linux:' -ForegroundColor White
    foreach ($l in $linuxPortsReference) { Write-Host ('    ' + $l) -ForegroundColor DarkGray }
}

function Copy-LinuxScript($destination) {
    $src = Get-LinuxScriptPath
    if (-not $src) {
        Write-Host ''
        Write-Host ('  {0} not found next to this script.' -f $script:LinuxScriptName) -ForegroundColor Red
        Write-Host ('  Expected at: {0}' -f (Join-Path $script:ScriptDir $script:LinuxScriptName)) -ForegroundColor DarkCyan
        return $null
    }
    if (-not $destination) { return $src }
    try {
        # Resolve against the PowerShell location, not the process working dir.
        $dest = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($destination)

        # Treat it as a directory if it exists as one, ends in a separator, or
        # has no file extension. Otherwise it is a full target file path.
        $looksLikeDir = (Test-Path $dest -PathType Container) -or
                        ($dest -match '[\\/]$') -or
                        ([string]::IsNullOrEmpty([IO.Path]::GetExtension($dest)))
        if ($looksLikeDir) {
            if (-not (Test-Path $dest -PathType Container)) {
                New-Item -ItemType Directory -Path $dest -Force -ErrorAction Stop | Out-Null
            }
            $dest = Join-Path $dest $script:LinuxScriptName
        } else {
            $parent = Split-Path $dest -Parent
            if ($parent -and -not (Test-Path $parent -PathType Container)) {
                New-Item -ItemType Directory -Path $parent -Force -ErrorAction Stop | Out-Null
            }
        }

        # Force LF endings so bash on the appliance is happy.
        $text = [IO.File]::ReadAllText($src) -replace "`r`n", "`n"
        [IO.File]::WriteAllText($dest, $text, (New-Object Text.UTF8Encoding($false)))
        Write-Host ('  Wrote {0}' -f $dest) -ForegroundColor Green
        return $dest
    } catch {
        Write-Host ('  Copy failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}

function Show-VsaConsoleOneLiner {
    Write-Host ''
    Write-Rule 'Console paste version (no file transfer needed)'
    Write-Host ''
    Write-Host '  Type or paste this at the TUI root shell. It is the essential check' -ForegroundColor DarkCyan
    Write-Host '  only - the full script gives systemd unit mapping and exit codes.' -ForegroundColor DarkCyan
    Write-Host ''
    $oneLiner = @'
for p in 443 6160 6162 6172 9419 10006 10443 5432; do o=$(ss -Hlntup "sport = :$p" 2>/dev/null | grep -o '"[^"]*"' | head -1); if [ -z "$o" ]; then echo "FREE      $p"; else case "$o" in *[Vv]eeam*) echo "OK        $p  $o";; *) echo "CONFLICT  $p  $o";; esac; fi; done; echo "-- non-Veeam in 2500-3300 --"; ss -Hlntup 2>/dev/null | awk '{n=split($5,a,":"); if(a[n]+0>=2500 && a[n]+0<=3300) print a[n], $NF}' | grep -vi veeam; echo "-- veeam units --"; systemctl list-units --all --type=service --no-legend --no-pager 'veeam*' 2>/dev/null | awk '{print "  "$3"  "$1}'
'@
    Write-Host $oneLiner -ForegroundColor Gray
    Write-Host ''
    Write-Host '  Reminder: vPower NFS (111 / 1058 / 2049) is a Windows service and is' -ForegroundColor DarkGray
    Write-Host '  deliberately not checked on Linux.' -ForegroundColor DarkGray
}

# =============================================================================
#  SSH TRANSPORT
#  Two transports, auto-detected:
#    Posh-SSH   - takes a PSCredential, so it works unattended. Preferred.
#    native ssh - ssh.exe / scp.exe. No dependency, but OpenSSH prompts for
#                 the password on the console itself; only key auth is
#                 genuinely unattended.
# =============================================================================

function Get-SshCapability {
    $poshVersion = $null
    $m = Get-Module -ListAvailable -Name 'Posh-SSH' -ErrorAction SilentlyContinue |
         Sort-Object Version -Descending | Select-Object -First 1
    if ($m) { $poshVersion = $m.Version }

    # Invoke-SSHCommand only splits .Output into a string array from 2.0 on.
    # On 1.x it returns one multi-line blob, which would parse as a single
    # truncated line and silently report "no result rows". Treat 1.x as absent.
    $poshUsable = [bool]($m -and $m.Version -ge [version]'2.0')

    return [pscustomobject]@{
        PoshSsh        = $poshUsable
        PoshSshPresent = [bool]$m
        PoshSshVersion = $poshVersion
        NativeSsh      = [bool](Get-Command ssh -ErrorAction SilentlyContinue)
        NativeScp      = [bool](Get-Command scp -ErrorAction SilentlyContinue)
    }
}

function Show-SshCapability {
    $c = Get-SshCapability
    Write-Host ''
    Write-Rule 'SSH transport'
    if ($c.PoshSsh) {
        Write-Host ('  Posh-SSH      : available (v{0}) - preferred, accepts a credential object' -f $c.PoshSshVersion) -ForegroundColor Green
    } elseif ($c.PoshSshPresent) {
        Write-Host ('  Posh-SSH      : v{0} found but too old (needs 2.0+) - will not be used' -f $c.PoshSshVersion) -ForegroundColor DarkYellow
    } else {
        Write-Host '  Posh-SSH      : not installed' -ForegroundColor DarkYellow
    }
    if ($c.NativeSsh) {
        Write-Host '  ssh.exe       : available' -ForegroundColor Green
    } else {
        Write-Host '  ssh.exe       : not found' -ForegroundColor DarkYellow
    }
    if ($c.NativeScp) {
        Write-Host '  scp.exe       : available' -ForegroundColor Green
    } else {
        Write-Host '  scp.exe       : not found (upload modes need this)' -ForegroundColor DarkYellow
    }
    if (-not $c.PoshSsh -and -not $c.NativeSsh) {
        Write-Host ''
        Write-Host '  No SSH transport at all. Either:' -ForegroundColor Red
        Write-Host '    Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0' -ForegroundColor DarkCyan
        Write-Host '    Install-Module Posh-SSH -Scope CurrentUser' -ForegroundColor DarkCyan
    }
    return $c
}

function Install-PoshSshInteractive {
    Write-Host ''
    Write-Host '  Posh-SSH comes from the PowerShell Gallery. It is not required -' -ForegroundColor DarkCyan
    Write-Host '  native ssh.exe works too, it just cannot accept a credential object.' -ForegroundColor DarkCyan
    $a = (Read-Host '  Install Posh-SSH for the current user now? [y/N]').Trim().ToUpper()
    if ($a -ne 'Y') { Write-Host '  Skipped.' -ForegroundColor DarkCyan; return $false }
    try {
        Install-Module -Name Posh-SSH -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
        Import-Module Posh-SSH -ErrorAction Stop
        Write-Host '  Posh-SSH installed.' -ForegroundColor Green
        return $true
    } catch {
        Write-Host ('  Install failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        Write-Host '  A locked-down server often blocks PSGallery. Use native ssh.exe instead.' -ForegroundColor DarkCyan
        return $false
    }
}

# -----------------------------------------------------------------------------
#  Parse the bash --report output into the same payload the Windows collector
#  returns, so one renderer and one CSV cover a mixed estate.
# -----------------------------------------------------------------------------
function ConvertFrom-LinuxReport {
    param([Parameter(Mandatory)][AllowEmptyCollection()][string[]]$Lines)

    $results  = @()
    $services = @()
    $meta     = @{
        Host='(unknown)'; OS=''; Elevated=$false; Fallback=$false; CollectError=''
        RangeChecked=$true; TcpCount=0; UdpCount=0; ProcCount=0
        Services=@(); Collected=(Get-Date); Platform='Linux'
    }
    $sawEnd = $false

    foreach ($raw in $Lines) {
        if ($null -eq $raw) { continue }
        $line = $raw.TrimEnd()
        if (-not $line.StartsWith('#')) { continue }
        $p = $line.Split('|')

        switch ($p[0]) {
            '#META' {
                if ($p.Count -ge 7) {
                    $meta.Host         = $p[1]
                    $meta.OS           = $p[2]
                    $meta.Elevated     = ($p[3] -eq '1')
                    $meta.TcpCount     = [int]($p[4] -as [int])
                    $meta.UdpCount     = [int]($p[5] -as [int])
                    $meta.RangeChecked = ($p[6] -eq '1')
                }
            }
            '#SVC' {
                if ($p.Count -ge 3) {
                    # systemd "active"/"inactive" -> the Running/Stopped the
                    # renderer already understands.
                    $state = if ($p[2] -eq 'active') { 'Running' } else { $p[2] }
                    $services += [pscustomobject]@{ Name=$p[1]; DisplayName=$p[1]; Status=$state }
                }
            }
            '#ROW' {
                if ($p.Count -ge 8) {
                    # Rejoin any trailing fields in case a note still held a pipe.
                    $notes = if ($p.Count -gt 8) { ($p[7..($p.Count-1)] -join '|') } else { $p[7] }
                    $results += [pscustomobject]@{
                        Port      = [int]($p[2] -as [int])
                        Protocol  = $p[3].ToUpper()
                        Status    = $p[1]
                        OwnerType = $p[4]
                        Owner     = $p[5]
                        Component = $p[6]
                        Verified  = $true
                        Notes     = $notes
                        InRange   = ($p[6] -like 'Data transfer range*')
                    }
                }
            }
            '#END' { $sawEnd = $true }
        }
    }

    if (-not $sawEnd) {
        $meta.CollectError = 'The remote report was truncated - no #END marker. Treat the results as incomplete.'
    }
    if ($results.Count -eq 0 -and -not $meta.CollectError) {
        $meta.CollectError = 'The remote script produced no result rows.'
    }
    $meta.Services  = $services
    $meta.ProcCount = 0

    return @{ Results = $results; Meta = $meta }
}

# -----------------------------------------------------------------------------
#  Build the remote command for a given mode.
#  Stream mode leaves nothing on the appliance filesystem.
# -----------------------------------------------------------------------------
function Get-RemoteCommand {
    param(
        [Parameter(Mandatory)][ValidateSet('Stream','UploadDelete','UploadKeep')][string]$Mode,
        [string]$RemotePath = '/tmp/veeam-portcheck.sh',
        [switch]$UseSudo,
        [switch]$ForPoshSsh,
        [string]$Base64Body
    )
    $bash = if ($UseSudo) { 'sudo -n bash' } else { 'bash' }

    if ($Mode -eq 'Stream') {
        if ($ForPoshSsh) {
            # Posh-SSH has no stdin channel, so carry the script inside the
            # command as base64 and decode it into bash on the far side.
            return ("echo '{0}' | base64 -d | {1} -s -- --report" -f $Base64Body, $bash)
        }
        return ('{0} -s -- --report' -f $bash)
    }

    # Single-quote for the REMOTE shell. PowerShell does not escape embedded
    # double quotes when building a native command line, so double quotes here
    # would be eaten before ssh saw them - and a path containing ';' would then
    # be executed by the remote shell. $RemotePath is also pattern-validated in
    # param(), so it cannot contain a quote to break out with.
    $q = "'" + $RemotePath + "'"
    $cmd = '{0} {1} --report' -f $bash, $q
    if ($Mode -eq 'UploadDelete') {
        # Capture the exit code before rm so conflicts still surface.
        $cmd = '{0}; __rc=$?; rm -f {1}; exit $__rc' -f $cmd, $q
    }
    return $cmd
}

# Split a POSIX remote path. Never use Split-Path here - on Windows the
# FileSystem provider rewrites '/tmp/x.sh' to '\tmp', which would upload to a
# bogus directory and only fail in the Upload modes.
function Split-PosixPath {
    param([Parameter(Mandatory)][string]$Path)
    $dir  = if ($Path -match '^(.*)/[^/]+$' -and $Matches[1]) { $Matches[1] } else { '/tmp' }
    $leaf = if ($Path -match '([^/]+)$') { $Matches[1] } else { 'veeam-portcheck.sh' }
    return [pscustomobject]@{ Directory = $dir; Leaf = $leaf }
}

function Invoke-LinuxCheckViaPoshSsh {
    param(
        [Parameter(Mandatory)][string]$Server,
        [int]$Port = 22,
        [System.Management.Automation.PSCredential]$Credential,
        [string]$KeyFile,
        [ValidateSet('Stream','UploadDelete','UploadKeep')][string]$Mode = 'Stream',
        [string]$RemotePath = '/tmp/veeam-portcheck.sh',
        [switch]$UseSudo
    )

    try { Import-Module Posh-SSH -ErrorAction Stop } catch {
        Write-Host ('  Could not load Posh-SSH: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }

    $src = Get-LinuxScriptPath
    if (-not $src) { return $null }
    $body = [IO.File]::ReadAllText($src) -replace "`r`n", "`n"

    $remote = Split-PosixPath -Path $RemotePath

    $session = $null
    try {
        $who = if ($Credential) { $Credential.UserName } else { '(key auth)' }
        Write-Host ('  Opening SSH session to {0}@{1}:{2} (Posh-SSH) ...' -f
            $who, $Server, $Port) -ForegroundColor DarkCyan

        $sessArgs = @{
            ComputerName = $Server
            Port         = $Port
            AcceptKey    = $true
            ErrorAction  = 'Stop'
        }
        if ($Credential) { $sessArgs['Credential'] = $Credential }
        if ($KeyFile) {
            if (-not (Test-Path $KeyFile)) {
                Write-Host ('  Key file not found: {0}' -f $KeyFile) -ForegroundColor Red
                return $null
            }
            $sessArgs['KeyFile'] = $KeyFile
        }
        $session = New-SSHSession @sessArgs

        $b64 = ''
        if ($Mode -eq 'Stream') {
            $b64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($body))
            Write-Host '  Streaming the script (nothing written to the appliance).' -ForegroundColor DarkCyan
        } else {
            Write-Host ('  Uploading to {0} ...' -f $RemotePath) -ForegroundColor DarkCyan
            # Set-SCPItem -Destination is a DIRECTORY and the file keeps its
            # local leaf name, so the temp file must be named after the remote
            # leaf or the subsequent bash call would miss it.
            $tmp = Join-Path ([IO.Path]::GetTempPath()) $remote.Leaf
            [IO.File]::WriteAllText($tmp, $body, (New-Object Text.UTF8Encoding($false)))
            $scpArgs = @{
                ComputerName = $Server
                Port         = $Port
                Path         = $tmp
                Destination  = $remote.Directory
                AcceptKey    = $true
                ErrorAction  = 'Stop'
            }
            if ($Credential) { $scpArgs['Credential'] = $Credential }
            if ($KeyFile)    { $scpArgs['KeyFile']    = $KeyFile }
            Set-SCPItem @scpArgs
            Remove-Item $tmp -Force -ErrorAction SilentlyContinue
        }

        $cmd = Get-RemoteCommand -Mode $Mode -RemotePath $RemotePath -UseSudo:$UseSudo `
                                 -ForPoshSsh -Base64Body $b64

        $r = Invoke-SSHCommand -SessionId $session.SessionId -Command $cmd -TimeOut 300 -ErrorAction Stop
        # Normalise: split any multi-line element so a single blob still parses.
        $out = @(@($r.Output) | ForEach-Object { [string]$_ -split "`r?`n" })

        if ($r.ExitStatus -gt 1) {
            Write-Host ('  Remote command exited {0}.' -f $r.ExitStatus) -ForegroundColor Red
            if ($r.Error) { Write-Host ('  {0}' -f ($r.Error -join ' ')) -ForegroundColor Red }
            if ($UseSudo) {
                Write-Host '  sudo -n fails when the account needs a password for sudo.' -ForegroundColor Yellow
                Write-Host '  Connect as root, or drop sudo and accept UNKNOWN owners.' -ForegroundColor Yellow
            }
        }
        if ($Mode -eq 'UploadKeep') {
            Write-Host ('  Left the script at {0} on the appliance.' -f $RemotePath) -ForegroundColor DarkCyan
        }
        return (ConvertFrom-LinuxReport -Lines @($out))
    } catch {
        Write-Host ('  Posh-SSH run failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    } finally {
        if ($session) { Remove-SSHSession -SessionId $session.SessionId -ErrorAction SilentlyContinue | Out-Null }
    }
}

function Invoke-LinuxCheckViaNativeSsh {
    param(
        [Parameter(Mandatory)][string]$Server,
        [int]$Port = 22,
        [Parameter(Mandatory)][string]$User,
        [string]$KeyFile,
        [ValidateSet('Stream','UploadDelete','UploadKeep')][string]$Mode = 'Stream',
        [string]$RemotePath = '/tmp/veeam-portcheck.sh',
        [switch]$UseSudo
    )

    if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) {
        Write-Host '  ssh.exe not found.' -ForegroundColor Red
        return $null
    }
    $src = Get-LinuxScriptPath
    if (-not $src) { return $null }
    $body = [IO.File]::ReadAllText($src) -replace "`r`n", "`n"

    $target  = '{0}@{1}' -f $User, $Server
    $sshOpts = @('-o','StrictHostKeyChecking=accept-new','-o','ConnectTimeout=15','-p',"$Port")
    if ($KeyFile) {
        if (-not (Test-Path $KeyFile)) {
            Write-Host ('  Key file not found: {0}' -f $KeyFile) -ForegroundColor Red
            return $null
        }
        $sshOpts += @('-i', $KeyFile)
        # With a key supplied, never fall through to an interactive password
        # prompt - that would hang an unattended run forever, because
        # ConnectTimeout only bounds the handshake, not the prompt.
        $sshOpts += @('-o','BatchMode=yes')
    } else {
        Write-Host '  No key file given - ssh.exe will prompt for the password itself.' -ForegroundColor DarkYellow
    }

    # Probe before streaming. If ssh cannot connect at all (the common VSA
    # case: SSH not enabled -> exit 255) it dies immediately, and writing 15 KB
    # of script into the closed pipe would raise an IOException that masks the
    # real cause with a generic failure message.
    Write-Host ('  Testing SSH reachability of {0}:{1} ...' -f $Server, $Port) -ForegroundColor DarkCyan
    & ssh @sshOpts $target 'true' 2>&1 | Out-Null
    $probeRc = $LASTEXITCODE
    if ($probeRc -eq 255) {
        Write-Host '  ssh could not connect or authenticate (exit 255).' -ForegroundColor Red
        Write-Host '  On a VSA, SSH must be enabled in Host Management -> Remote Access ->' -ForegroundColor DarkCyan
        Write-Host '  SSH Server, and approved by the Security Officer if that account exists.' -ForegroundColor DarkCyan
        Write-Host '  Also check the user, the port, and the key if you supplied one.' -ForegroundColor DarkCyan
        return $null
    }

    $cmd = Get-RemoteCommand -Mode $Mode -RemotePath $RemotePath -UseSudo:$UseSudo
    $out = @()

    try {
        if ($Mode -eq 'Stream') {
            Write-Host '  Streaming the script over stdin (nothing written to the appliance).' -ForegroundColor DarkCyan
            $out = @($body | & ssh @sshOpts $target $cmd 2>&1)
        } else {
            if (-not (Get-Command scp -ErrorAction SilentlyContinue)) {
                Write-Host '  scp.exe not found - upload modes need it. Use stream mode.' -ForegroundColor Red
                return $null
            }
            $tmp = Join-Path ([IO.Path]::GetTempPath()) $script:LinuxScriptName
            [IO.File]::WriteAllText($tmp, $body, (New-Object Text.UTF8Encoding($false)))

            $scpOpts = @('-o','StrictHostKeyChecking=accept-new','-o','ConnectTimeout=15','-P',"$Port")
            if ($KeyFile) { $scpOpts += @('-i', $KeyFile) }

            Write-Host ('  Uploading to {0}:{1} ...' -f $Server, $RemotePath) -ForegroundColor DarkCyan
            & scp @scpOpts $tmp ('{0}:{1}' -f $target, $RemotePath) 2>&1 | ForEach-Object {
                Write-Host ('    ' + $_) -ForegroundColor DarkGray
            }
            $scpRc = $LASTEXITCODE
            Remove-Item $tmp -Force -ErrorAction SilentlyContinue
            if ($scpRc -ne 0) {
                Write-Host ('  scp failed (exit {0}).' -f $scpRc) -ForegroundColor Red
                return $null
            }
            $out = @(& ssh @sshOpts $target $cmd 2>&1)
        }

        $rc = $LASTEXITCODE
        if ($rc -eq 255) {
            Write-Host '  ssh could not connect (exit 255).' -ForegroundColor Red
            Write-Host '  On a VSA, SSH must be enabled in Host Management -> Remote Access,' -ForegroundColor DarkCyan
            Write-Host '  and approved by the Security Officer if that account is configured.' -ForegroundColor DarkCyan
            $nonReport = @($out | Where-Object { $_ -and -not ([string]$_).StartsWith('#') })
            foreach ($l in $nonReport) { Write-Host ('    ' + $l) -ForegroundColor DarkGray }
            return $null
        }
        if ($rc -gt 1 -and $UseSudo) {
            Write-Host ('  Remote command exited {0} - sudo -n fails when sudo needs a password.' -f $rc) -ForegroundColor Yellow
        }
        if ($Mode -eq 'UploadKeep') {
            Write-Host ('  Left the script at {0} on the appliance.' -f $RemotePath) -ForegroundColor DarkCyan
        }
        # @() so that no output at all binds as an empty array rather than
        # $null, which AllowEmptyCollection does not cover.
        return (ConvertFrom-LinuxReport -Lines @($out | ForEach-Object { [string]$_ }))
    } catch {
        Write-Host ('  SSH run failed: {0}' -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}

# -----------------------------------------------------------------------------
#  Front door: pick a transport, run, render, accumulate.
# -----------------------------------------------------------------------------
function Invoke-LinuxCheckOverSsh {
    param(
        [Parameter(Mandatory)][string]$Server,
        [string]$User,
        [int]$Port = 22,
        [System.Management.Automation.PSCredential]$Credential,
        [string]$KeyFile,
        [ValidateSet('Stream','UploadDelete','UploadKeep')][string]$Mode = 'Stream',
        [string]$RemotePath = '/tmp/veeam-portcheck.sh',
        [switch]$UseSudo,
        [switch]$NonInteractive
    )

    if (-not (Get-LinuxScriptPath)) {
        Write-Host ''
        Write-Host ('  {0} must sit in the same folder as this script.' -f $script:LinuxScriptName) -ForegroundColor Red
        Write-Host ('  Expected at: {0}' -f (Join-Path $script:ScriptDir $script:LinuxScriptName)) -ForegroundColor DarkCyan
        return $null
    }

    $cap = Get-SshCapability
    if (-not $cap.PoshSsh -and -not $cap.NativeSsh) {
        Show-SshCapability | Out-Null
        return $null
    }
    if (-not $cap.PoshSsh -and -not $NonInteractive) {
        Write-Host ''
        Write-Host '  Posh-SSH is not installed, so native ssh.exe will be used and will' -ForegroundColor DarkYellow
        Write-Host '  prompt for the password on the console rather than taking a credential.' -ForegroundColor DarkYellow
        if (Install-PoshSshInteractive) { $cap = Get-SshCapability }
    }

    Write-Host ''
    Write-Host '  Reminder: on a Veeam Software Appliance, SSH is off by default. Enable it' -ForegroundColor DarkCyan
    Write-Host '  in Host Management -> Remote Access -> SSH Server. Where a Security Officer' -ForegroundColor DarkCyan
    Write-Host '  account exists the request needs their approval first.' -ForegroundColor DarkCyan

    $payload = $null

    if ($cap.PoshSsh) {
        # Key auth needs no credential. Only prompt when we have neither, and
        # never prompt in a non-interactive run - fail loudly instead.
        if (-not $Credential -and -not $KeyFile) {
            if ($NonInteractive) {
                Write-Host '  No -SshCredential and no -SshKeyFile supplied, and this is a' -ForegroundColor Red
                Write-Host '  non-interactive run. Nothing to authenticate with.' -ForegroundColor Red
                return $null
            }
            $Credential = if ($User) {
                Get-Credential -UserName $User -Message "SSH to $Server"
            } else {
                Get-Credential -Message "SSH to $Server"
            }
            if (-not $Credential) { Write-Host '  Cancelled.' -ForegroundColor Red; return $null }
        }
        if ($KeyFile -and -not $Credential -and $User) {
            # Posh-SSH still wants a user name alongside a key file.
            $Credential = New-Object System.Management.Automation.PSCredential(
                $User, (New-Object System.Security.SecureString))
        }
        $payload = Invoke-LinuxCheckViaPoshSsh -Server $Server -Port $Port -Credential $Credential `
                       -KeyFile $KeyFile -Mode $Mode -RemotePath $RemotePath -UseSudo:$UseSudo
    } else {
        if (-not $User) {
            if ($Credential) { $User = $Credential.UserName }
            else { $User = (Read-Host '  SSH user').Trim() }
        }
        if (-not $User) { Write-Host '  Cancelled.' -ForegroundColor Red; return $null }
        $payload = Invoke-LinuxCheckViaNativeSsh -Server $Server -Port $Port -User $User `
                       -KeyFile $KeyFile -Mode $Mode -RemotePath $RemotePath -UseSudo:$UseSudo
    }

    if (-not $payload) { return $null }

    if (-not $payload.Meta.Elevated) {
        Write-Host ''
        Write-Host '  The remote script did not run as root, so listener owners it could not' -ForegroundColor Yellow
        Write-Host '  read are reported UNKNOWN. Re-run with sudo, or connect as root.' -ForegroundColor Yellow
    }

    Save-Results $payload
    Show-ConflictReport $payload
    return $payload
}

function Invoke-VsaWorkflow {
    param([string]$ServerName)
    Show-VsaGuidance -ServerName $ServerName

    Write-Host ''
    Write-Rule 'How do you want to run the Linux check'
    Write-Host '  [1] Push over SSH and run it  <- results merge into the same report' -ForegroundColor Green
    Write-Host '  [2] Write veeam-portcheck.sh somewhere I can copy from' -ForegroundColor Green
    Write-Host '  [3] Show the console paste one-liner (no SSH needed)' -ForegroundColor Green
    Write-Host '  [4] Show SSH transport status' -ForegroundColor Yellow
    Write-Host '  [B] Back' -ForegroundColor Red
    Write-Host ''
    $c = (Read-Host '  Select').Trim().ToUpper()

    switch ($c) {
        '1' { Invoke-SshPushWorkflow -ServerName $ServerName }

        '2' {
            $default = Join-Path ([Environment]::GetFolderPath('Desktop')) $script:LinuxScriptName
            $p = (Read-Host "  Destination [Enter=$default]").Trim()
            if (-not $p) { $p = $default }
            $written = Copy-LinuxScript $p
            if ($written) {
                Write-Host ''
                Write-Host '  On the appliance, in the TUI root shell:' -ForegroundColor DarkCyan
                Write-Host '    bash /path/to/veeam-portcheck.sh' -ForegroundColor Gray
                Write-Host '    bash /path/to/veeam-portcheck.sh --csv    # machine readable' -ForegroundColor Gray
                Write-Host '    bash /path/to/veeam-portcheck.sh --all    # every listener' -ForegroundColor Gray
            }
        }
        '3' { Show-VsaConsoleOneLiner }
        '4' { Show-SshCapability | Out-Null }
        default { }
    }
}

function Invoke-SshPushWorkflow {
    param([string]$ServerName)

    $srv = if ($ServerName) {
        $t = (Read-Host ("  Appliance hostname or IP [Enter={0}]" -f $ServerName)).Trim()
        if ($t) { $t } else { $ServerName }
    } else {
        (Read-Host '  Appliance hostname or IP').Trim()
    }
    if (-not $srv) { Write-Host '  Cancelled.' -ForegroundColor Red; return }

    $pRaw = (Read-Host '  SSH port [Enter=22]').Trim()
    $sshPort = if ($pRaw -match '^\d+$') { [int]$pRaw } else { 22 }

    Write-Host ''
    Write-Host '  How should the script get there?' -ForegroundColor DarkCyan
    Write-Host '    [Enter] Stream it - nothing is ever written to the appliance' -ForegroundColor Gray
    Write-Host '    [D]     Upload to /tmp, run, then delete' -ForegroundColor Gray
    Write-Host '    [K]     Upload to /tmp and keep it there for re-runs' -ForegroundColor Gray
    $mRaw = (Read-Host '  Choice').Trim().ToUpper()
    $mode = switch ($mRaw) {
        'D'     { 'UploadDelete' }
        'K'     { 'UploadKeep' }
        default { 'Stream' }
    }

    $remotePath = '/tmp/veeam-portcheck.sh'
    if ($mode -ne 'Stream') {
        $rp = (Read-Host "  Remote path [Enter=$remotePath]").Trim()
        if ($rp) { $remotePath = $rp }
    }

    $sudoAns = (Read-Host '  Run it through sudo? Needed unless you log in as root [y/N]').Trim().ToUpper()
    $useSudo = ($sudoAns -eq 'Y')

    $keyFile = ''
    $cap = Get-SshCapability
    if (-not $cap.PoshSsh -and $cap.NativeSsh) {
        $k = (Read-Host '  Private key file for key auth [Enter = password prompt]').Trim()
        if ($k) { $keyFile = $k }
    }

    Invoke-LinuxCheckOverSsh -Server $srv -Port $sshPort -Mode $mode `
        -RemotePath $remotePath -UseSudo:$useSudo -KeyFile $keyFile | Out-Null
}

# =============================================================================
#  CONNECT-AND-CHECK ORCHESTRATION
# =============================================================================

function Invoke-VbrConnectAndCheck {
    param(
        [Parameter(Mandatory)][string]$Server,
        [int]$Port = 443,
        [System.Management.Automation.PSCredential]$Credential,
        [switch]$AcceptCert,
        [switch]$WithEM, [switch]$WithCC, [switch]$WithWan, [switch]$NoRange
    )

    Write-Banner 'Veeam Port Conflict Check' $Server

    if (-not (Connect-Vbr -Server $Server -Port $Port -Credential $Credential -AcceptCert:$AcceptCert)) {
        Write-Host ''
        Write-Host '  Could not use the VBR API. You can still check the host directly with' -ForegroundColor Yellow
        Write-Host ('    .\portest3.ps1 -ComputerName {0} -RemoteCheck' -f $Server) -ForegroundColor DarkCyan
        return
    }

    Show-VbrInfrastructure

    if ($script:VbrPlatform -eq 'Linux') {
        Invoke-VsaWorkflow -ServerName $Server
        return
    }

    if ($script:VbrPlatform -ne 'Windows') {
        Write-Host ''
        Write-Host ('  Platform came back as "{0}". Get-VBRLinuxPackage returned nothing and' -f $script:VbrPlatform) -ForegroundColor Yellow
        Write-Host '  CHost properties are undocumented, so this is inconclusive.' -ForegroundColor Yellow
        $a = (Read-Host '  Treat as Windows and try PowerShell remoting? [Y/n]').Trim().ToUpper()
        if ($a -eq 'N') { Invoke-VsaWorkflow -ServerName $Server; return }
    }

    $payload = Invoke-RemoteCollector -Computer $Server -Credential $script:VbrCred `
                                      -WithEM:$WithEM -WithCC:$WithCC -WithWan:$WithWan -NoRange:$NoRange
    if ($payload) {
        Save-Results $payload
        Show-ConflictReport $payload
    }
}

# =============================================================================
#  REMOTE REACHABILITY (portest2 behaviour)
# =============================================================================

function Test-PortOpen($server, $port) {
    $tcp = New-Object System.Net.Sockets.TcpClient
    try {
        $ar = $tcp.BeginConnect($server, $port, $null, $null)
        if ($ar.AsyncWaitHandle.WaitOne(500, $false)) { $tcp.EndConnect($ar); return $true }
        return $false
    } catch { return $false } finally { $tcp.Close() }
}

function Compress-Ranges($ports) {
    if (-not $ports -or $ports.Count -eq 0) { return }
    $sorted = @($ports | Sort-Object)
    $start = $sorted[0]; $prev = $sorted[0]
    if ($sorted.Count -gt 1) {
        foreach ($p in $sorted[1..($sorted.Count - 1)]) {
            if ($p -ne $prev + 1) {
                if ($start -eq $prev) { "$start" } else { "$start - $prev" }
                $start = $p
            }
            $prev = $p
        }
    }
    if ($start -eq $prev) { "$start" } else { "$start - $prev" }
}

function Read-PortNumber($prompt, $min, $max, $default) {
    while ($true) {
        $raw = (Read-Host "  $prompt [$min-$max, Enter=$default]").Trim()
        if ($raw -eq '') { return $default }
        if ($raw -match '^\d+$') {
            $n = [int]$raw
            if ($n -ge $min -and $n -le $max) { return $n }
        }
        Write-Host "  Invalid - enter a number between $min and $max." -ForegroundColor Red
    }
}

function Ensure-Target($current) {
    if ($current) { return $current }
    $val = (Read-Host '  Enter VBR server hostname or IP').Trim()
    if (-not $val) { Write-Host '  No target entered.' -ForegroundColor Red; return $null }
    return $val
}

function Invoke-CoreScan($testTarget) {
    Write-Host ''
    Write-Rule 'Core Ports'
    $fail = @()
    foreach ($e in $corePorts) {
        $open   = Test-PortOpen $testTarget $e.Port
        $status = if ($open) { '  OPEN  ' } else { ' FAILED ' }
        $color  = if ($open) { 'Green' }    else { 'Red' }
        Write-Host ('[{0}] {1,-8} {2}' -f $status, $e.Port, $e.Description) -ForegroundColor $color
        if (-not $open) { $fail += $e.Port }
    }
    Write-Host ''
    if ($fail.Count -eq 0) { Write-Host '  All core ports OPEN.' -ForegroundColor Green }
    else { Write-Host ("  Blocked core ports: {0}" -f ($fail -join ', ')) -ForegroundColor Red }
}

function Invoke-RangeScan($testTarget, $scanStart, $scanEnd) {
    $total  = $scanEnd - $scanStart + 1
    $estMin = [math]::Round($total * 0.5 / 60, 1)

    Write-Host ''
    Write-Rule ('Dynamic Range Scan (TCP {0}-{1})' -f $scanStart, $scanEnd)
    Write-Host ('  Scanning {0} ports, est. ~{1} min...' -f $total, $estMin) -ForegroundColor DarkCyan
    Write-Host '  Press Ctrl+C to abort and return to the menu.' -ForegroundColor DarkCyan
    Write-Host ''

    $failed = @(); $open = @(); $i = 0; $aborted = $false
    try {
        foreach ($port in $scanStart..$scanEnd) {
            try {
                if ($Host.UI.RawUI.KeyAvailable) {
                    $key = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
                    if ($key.VirtualKeyCode -eq 67 -and
                        ($key.ControlKeyState -band [System.Management.Automation.Host.ControlKeyStates]::LeftCtrlPressed -or
                         $key.ControlKeyState -band [System.Management.Automation.Host.ControlKeyStates]::RightCtrlPressed)) {
                        $aborted = $true; break
                    }
                }
            } catch { }
            $i++
            Write-Progress -Id 1 -Activity "Scanning $testTarget" -Status "Port $port  ($i of $total)" `
                           -PercentComplete (($i / $total) * 100)
            if (Test-PortOpen $testTarget $port) { $open += $port } else { $failed += $port }
        }
    } catch { $aborted = $true }
    Write-Progress -Id 1 -Activity "Scanning $testTarget" -Completed

    if ($aborted) {
        Write-Host ''
        Write-Host "  ** Scan aborted after $i of $total ports." -ForegroundColor Yellow
    }
    Write-Host ('  OPEN  : {0} ports' -f $open.Count)   -ForegroundColor Green
    Write-Host ('  FAILED: {0} ports' -f $failed.Count) -ForegroundColor Red
    if ($failed.Count -gt 0) {
        Write-Host ''
        Write-Host '  Blocked ranges:' -ForegroundColor Red
        Compress-Ranges $failed | ForEach-Object { Write-Host "    $_" -ForegroundColor Red }
    }
    if (-not $aborted -and $open.Count -eq $total) {
        Write-Host ('  Full range {0}-{1} is open.' -f $scanStart, $scanEnd) -ForegroundColor Green
    }
}

function Write-Footer {
    Write-Host ''
    Write-Host '  Press Enter to return to the menu.' -ForegroundColor Cyan
    $null = Read-Host
}

# =============================================================================
#  NON-INTERACTIVE ENTRY POINTS
# =============================================================================

# The entry points below are mutually exclusive and resolve in this order.
# Warn rather than silently drop a mode the caller also asked for.
$requestedModes = @()
if ($SshServer)       { $requestedModes += '-SshServer' }
if ($VbrServer)       { $requestedModes += '-VbrServer' }
if ($ComputerName)    { $requestedModes += '-ComputerName' }
if ($LocalCheck)      { $requestedModes += '-LocalCheck' }
if ($Target)          { $requestedModes += '-Target' }
if ($requestedModes.Count -gt 1) {
    Write-Host ''
    Write-Host ('  Note: {0} were all supplied. Only {1} will run.' -f
        ($requestedModes -join ', '), $requestedModes[0]) -ForegroundColor Yellow
}
if (-not $SshServer -and ($SshUser -or $SshKeyFile -or $UseSudo -or $SshMode -ne 'Stream')) {
    Write-Host ''
    Write-Host '  Note: the -Ssh* / -UseSudo options are ignored without -SshServer.' -ForegroundColor Yellow
}

if ($SshServer) {
    Write-Banner 'Veeam Port Conflict Check (Linux over SSH)' $SshServer
    $payload = Invoke-LinuxCheckOverSsh -Server $SshServer -User $SshUser -Port $SshPort `
                   -Credential $SshCredential -KeyFile $SshKeyFile -Mode $SshMode `
                   -RemotePath $SshRemotePath -UseSudo:$UseSudo `
                   -NonInteractive:($null -ne $SshCredential -or [bool]$SshKeyFile)
    if ($OutFile) { Export-Results $OutFile }
    Write-Host ''
    if (-not $payload) { exit 2 }
    if ($payload.Meta.CollectError) { exit 2 }

    $conflicts = @($payload.Results | Where-Object { $_.Status -eq 'CONFLICT' })
    $unknowns  = @($payload.Results | Where-Object { $_.Status -eq 'UNKNOWN' })
    if ($conflicts.Count -gt 0) { exit 1 }
    # UNKNOWN means the check resolved nothing - do not hand a pipeline a green
    # light. This is the normal outcome without root and without working sudo.
    if ($unknowns.Count -gt 0) { exit 2 }
    exit 0
}

if ($EmitLinuxScript -and -not $VbrServer) {
    Show-VsaGuidance
    Copy-LinuxScript $EmitLinuxScript | Out-Null
    Show-VsaConsoleOneLiner
    Write-Host ''
    exit 0
}

if ($VbrServer) {
    Invoke-VbrConnectAndCheck -Server $VbrServer -Port $VbrPort -Credential $VbrCredential `
        -AcceptCert:$ForceAcceptCert -WithEM:$IncludeEnterpriseManager `
        -WithCC:$IncludeCloudConnect -WithWan:$IncludeWanAccelerator -NoRange:$SkipDynamicRange
    if ($EmitLinuxScript) { Copy-LinuxScript $EmitLinuxScript | Out-Null }
    if ($OutFile) { Export-Results $OutFile }
    if ($script:VbrConnected) { Disconnect-Vbr }
    Write-Host ''
    exit 0
}

if ($ComputerName) {
    Write-Banner 'Veeam Port Conflict Check (direct remoting)' $ComputerName
    $cred = $VbrCredential
    if (-not $cred) {
        $ans = (Read-Host '  Use current Windows credentials? [Y/n]').Trim().ToUpper()
        if ($ans -eq 'N') { $cred = Get-Credential -Message "Admin on $ComputerName" }
    }
    $payload = Invoke-RemoteCollector -Computer $ComputerName -Credential $cred `
        -WithEM:$IncludeEnterpriseManager -WithCC:$IncludeCloudConnect `
        -WithWan:$IncludeWanAccelerator -NoRange:$SkipDynamicRange
    if ($payload) { Save-Results $payload; Show-ConflictReport $payload }
    if ($OutFile) { Export-Results $OutFile }
    Write-Host ''
    exit 0
}

if ($LocalCheck) {
    Write-Banner 'Veeam Port Conflict Check' $env:COMPUTERNAME
    $payload = Invoke-LocalCollector -WithEM:$IncludeEnterpriseManager `
        -WithCC:$IncludeCloudConnect -WithWan:$IncludeWanAccelerator -NoRange:$SkipDynamicRange
    Save-Results $payload
    Show-ConflictReport $payload
    if ($OutFile) { Export-Results $OutFile }
    Write-Host ''
    exit 0
}

if ($Target) {
    if ($RangeStart -gt $RangeEnd) {
        Write-Host "  Error: RangeStart ($RangeStart) must be <= RangeEnd ($RangeEnd)." -ForegroundColor Red
        exit 1
    }
    Write-Banner 'Veeam Port Reachability' $Target
    Invoke-CoreScan $Target
    if ($ScanRange) { Invoke-RangeScan $Target $RangeStart $RangeEnd }
    Write-Host ''
    exit 0
}

# =============================================================================
#  INTERACTIVE MENU
# =============================================================================

$menuTarget = ''
$optEM = $false; $optCC = $false; $optWan = $false
$quit  = $false

while (-not $quit) {

    $vbrDisplay = if ($script:VbrConnected) {
        '{0}  [{1}]' -f $script:VbrServerName, $script:VbrPlatform
    } else { '(not connected)' }
    $targetDisplay = if ($menuTarget) { $menuTarget } else { '(not set)' }
    $extras = @()
    if ($optEM)  { $extras += 'EM' }
    if ($optCC)  { $extras += 'CloudConnect' }
    if ($optWan) { $extras += 'WAN' }
    $extrasDisplay = if ($extras.Count -gt 0) { $extras -join ', ' } else { 'none' }

    Write-Host ''
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host '  Veeam Port Diagnostic' -ForegroundColor Cyan
    Write-Host '=======================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ('  This host      : {0}' -f $env:COMPUTERNAME)  -ForegroundColor White
    Write-Host ('  VBR connection : {0}' -f $vbrDisplay)        -ForegroundColor White
    Write-Host ('  Scan target    : {0}' -f $targetDisplay)     -ForegroundColor White
    Write-Host ('  Extra profiles : {0}' -f $extrasDisplay)     -ForegroundColor White
    Write-Host ''
    Write-Host '  VBR SERVER' -ForegroundColor Magenta
    Write-Host '  [1] Connect to VBR server and run the conflict check' -ForegroundColor Green
    Write-Host '       Connect-VBRServer, detect Windows vs VSA, then check that host'
    Write-Host '  [2] Show managed servers (Get-VBRServer)' -ForegroundColor Green
    Write-Host '  [3] Check a named Windows host directly (no VBR API)' -ForegroundColor Green
    Write-Host '  [4] Linux / VSA - push over SSH, or emit the script' -ForegroundColor Green
    Write-Host '  [5] Disconnect from VBR' -ForegroundColor Yellow
    Write-Host '  -----------------------------------------------'
    Write-Host '  THIS MACHINE' -ForegroundColor Magenta
    Write-Host '  [6] Port conflict check on this machine' -ForegroundColor Green
    Write-Host '  [7] Export results to CSV (last check, or the whole session)' -ForegroundColor Green
    Write-Host '  [8] Toggle extra profiles (EM / Cloud Connect / WAN)' -ForegroundColor Yellow
    Write-Host '  -----------------------------------------------'
    Write-Host '  REACHABILITY' -ForegroundColor Magenta
    Write-Host '  [9] Set / change scan target' -ForegroundColor Yellow
    Write-Host '  [10] Core ports only' -ForegroundColor Green
    Write-Host '  [11] Core ports + full dynamic range (2500-3300)' -ForegroundColor Green
    Write-Host '  [12] Core ports + custom range' -ForegroundColor Green
    Write-Host '  -----------------------------------------------'
    Write-Host '  [Q] Quit' -ForegroundColor Red
    Write-Host ''

    $choice = (Read-Host '  Select').Trim().ToUpper()

    switch ($choice) {

        '1' {
            $srv = (Read-Host '  VBR server hostname or IP').Trim()
            if (-not $srv) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $pRaw = (Read-Host '  Port [Enter=443, use 9392 for v12 and older]').Trim()
            $prt  = if ($pRaw -match '^\d+$') { [int]$pRaw } else { 443 }
            $ac   = (Read-Host '  Accept the server TLS certificate? [Y/n]').Trim().ToUpper()
            Invoke-VbrConnectAndCheck -Server $srv -Port $prt -AcceptCert:($ac -ne 'N') `
                -WithEM:$optEM -WithCC:$optCC -WithWan:$optWan
            Write-Footer
        }

        '2' { Show-VbrInfrastructure; Write-Footer }

        '3' {
            $cn = (Read-Host '  Windows host to check').Trim()
            if (-not $cn) { Write-Host '  Cancelled.' -ForegroundColor Red; continue }
            $prompt = if ($script:VbrCred) {
                '  Credentials: [Enter] reuse the VBR credential, [C] current Windows user, [N] prompt me'
            } else {
                '  Credentials: [Enter] current Windows user, [N] prompt me'
            }
            Write-Host $prompt -ForegroundColor DarkCyan
            $ans = (Read-Host '  Choice').Trim().ToUpper()
            $cred = switch ($ans) {
                'N'     { Get-Credential -Message "Admin on $cn" }
                'C'     { $null }
                default { if ($script:VbrCred) { $script:VbrCred } else { $null } }
            }
            Write-Banner 'Veeam Port Conflict Check' $cn
            $payload = Invoke-RemoteCollector -Computer $cn -Credential $cred `
                -WithEM:$optEM -WithCC:$optCC -WithWan:$optWan
            if ($payload) { Save-Results $payload; Show-ConflictReport $payload }
            Write-Footer
        }

        '4' { Invoke-VsaWorkflow -ServerName $script:VbrServerName; Write-Footer }

        '5' { Disconnect-Vbr }

        '6' {
            Write-Banner 'Veeam Port Conflict Check' $env:COMPUTERNAME
            $payload = Invoke-LocalCollector -WithEM:$optEM -WithCC:$optCC -WithWan:$optWan
            Save-Results $payload
            Show-ConflictReport $payload
            Write-Footer
        }

        '7' {
            Write-Host ''
            Write-Host ('  [Enter] last check only ({0})' -f
                $(if ($script:LastResultHost) { $script:LastResultHost } else { 'nothing yet' })) -ForegroundColor Gray
            Write-Host ('  [A]     every check this session ({0} rows, mixed Windows + Linux)' -f
                $script:AllResults.Count) -ForegroundColor Gray
            $which = (Read-Host '  Choice').Trim().ToUpper()

            $tag = if ($which -eq 'A') { 'AllHosts' }
                   elseif ($script:LastResultHost) { $script:LastResultHost }
                   else { $env:COMPUTERNAME }
            $default = Join-Path $env:TEMP ('VeeamPortCheck_{0}_{1}.csv' -f
                        $tag, (Get-Date -Format 'yyyyMMdd_HHmmss'))
            $path = (Read-Host "  CSV path [Enter=$default]").Trim()
            if (-not $path) { $path = $default }
            if ($which -eq 'A') { Export-AllResults $path } else { Export-Results $path }
        }

        '8' {
            Write-Host ''
            Write-Host '  [A] Enterprise Manager  [B] Cloud Connect  [C] WAN Accelerator' -ForegroundColor DarkCyan
            $t = (Read-Host '  Toggle which').Trim().ToUpper()
            switch ($t) {
                'A' { $optEM  = -not $optEM;  Write-Host "  Enterprise Manager: $optEM" -ForegroundColor DarkCyan }
                'B' { $optCC  = -not $optCC;  Write-Host "  Cloud Connect: $optCC"      -ForegroundColor DarkCyan }
                'C' { $optWan = -not $optWan; Write-Host "  WAN Accelerator: $optWan"   -ForegroundColor DarkCyan }
                default { Write-Host '  No change.' -ForegroundColor Red }
            }
        }

        '9' {
            $val = (Read-Host '  Enter hostname or IP').Trim()
            if ($val) { $menuTarget = $val; Write-Host "  Target set to: $menuTarget" -ForegroundColor DarkCyan }
        }

        '10' {
            $t = Ensure-Target $menuTarget
            if ($t) { $menuTarget = $t; Write-Banner 'Veeam Port Reachability' $t; Invoke-CoreScan $t; Write-Footer }
        }

        '11' {
            $t = Ensure-Target $menuTarget
            if ($t) {
                $menuTarget = $t; Write-Banner 'Veeam Port Reachability' $t
                Invoke-CoreScan $t; Invoke-RangeScan $t 2500 3300; Write-Footer
            }
        }

        '12' {
            Write-Host ''
            Write-Host '  Enter the sub-range to scan (within 2500-3300):' -ForegroundColor DarkCyan
            $s = Read-PortNumber 'Start port' 2500 3300 2500
            $e = Read-PortNumber 'End port  ' $s   3300 3300
            $t = Ensure-Target $menuTarget
            if ($t) {
                $menuTarget = $t
                Write-Host ''
                Write-Host ('  About to scan {0} ports ({1}-{2}) on {3}.' -f ($e-$s+1), $s, $e, $t) -ForegroundColor DarkCyan
                $confirm = (Read-Host '  Press Enter to start, or [B] to go back').Trim().ToUpper()
                if ($confirm -ne 'B') {
                    Write-Banner 'Veeam Port Reachability' $t
                    Invoke-CoreScan $t; Invoke-RangeScan $t $s $e; Write-Footer
                }
            }
        }

        'Q' { $quit = $true }

        default { Write-Host '  Invalid choice.' -ForegroundColor Red }
    }
}

if ($script:VbrConnected) { Disconnect-Vbr }
Write-Host ''
Write-Host '  Goodbye.' -ForegroundColor DarkCyan
Write-Host ''
